import { release } from 'os'
import { join } from 'path'
import { app, BrowserWindow, Tray, Menu } from 'electron'
import createLoginWindow from '../../src/windows/loginWindow'
import createIndexWindow from '../../src/windows/indexWindow'
import { APP_ICON } from '../../src/assets/js/appConfig'
import initIpcEvent from '../../src/assets/js/ipcEvent'
import electronStorage from 'electron-localstorage'
// import handleUpdate from './update'
if (release().startsWith('6.1')) app.disableHardwareAcceleration()
var trayMenuTemplate = [
  {
    label: '退出简知企微助手',
    click: function () {
      app.quit()
    }
  }
]
// Set application name for Windows 10+ notifications
if (process.platform === 'win32') app.setAppUserModelId(app.getName())
// 可以禁止多开应用
// if (!app.requestSingleInstanceLock()) {
//   app.quit()
//   process.exit(0)
// }
if (import.meta.env.DEV) {
  // 禁用当前应用程序的硬件加速
  app.disableHardwareAcceleration()
}

export const ROOT_PATH = {
  // /dist
  dist: join(__dirname, '../..'),
  // /dist or /public
  public: join(__dirname, app.isPackaged ? '../..' : '../../../public')
}

async function createWindow() {
  electronStorage.getItem('token') ? createIndexWindow() : createLoginWindow()
  initIpcEvent()
}

app.on('ready', async () => {
  await createWindow()
  await createTray()
  //handleUpdate(global.currentWindow)
})

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit()
})

app.on('activate', () => {
  const allWindows = BrowserWindow.getAllWindows()
  if (allWindows.length) {
    allWindows[0].focus()
  } else {
    createWindow()
  }
})

// 创建托盘，后续有托盘需求再抽离
function createTray() {
  let appTray = new Tray(APP_ICON)
  const contextMenu = Menu.buildFromTemplate(trayMenuTemplate)
  appTray.setContextMenu(contextMenu)
  appTray.setToolTip('简知企微助手')
  appTray.on('click', () => {
    global.currentWindow && global.currentWindow.show()
  })
}
