import { autoUpdater } from 'electron-updater'
import { ipcMain } from 'electron'

ipcMain.on('ev-update-now', () => {
  console.log('更新')
  autoUpdater.quitAndInstall()
})

ipcMain.on('ev-check-for-update', () => {
  console.log('update')
  autoUpdater.checkForUpdates()
})

const handleUpdate = function (mainWindow) {
  const message = {
    error: '检查更新出错,请关闭应用后重新打开',
    checking: '正在检查更新……',
    updateAva: '检测到新版本，正在下载……'
  }

  // if (!app.isPackaged) {
  //   Object.defineProperty(app, 'isPackaged', {
  //     get() {
  //       return true
  //     }
  //   })
  // }

  // 检查更新出错
  autoUpdater.on('error', (err) => {
    console.log(err)
    sendUpdateMessage(err, 1)
  })

  // 检查是否有版本更新
  autoUpdater.on('checking-for-update', () => {
    sendUpdateMessage(message.checking, 2)
  })

  // 检测到有版本更新
  autoUpdater.on('update-available', () => {
    sendUpdateMessage(message.updateAva, 3)
  })

  // 更新下载进度事件
  autoUpdater.on('download-progress', (progressObj) => {
    mainWindow.webContents.send('ev-progress', progressObj.percent)
  })

  // 下载完成，询问用户是否更新
  autoUpdater.on(
    'update-downloaded',
    (event, releaseNotes, releaseName, releaseDate, updateUrl, quitAndUpdate) => {
      mainWindow.webContents.send('ev-should-update', {
        event,
        releaseNotes,
        releaseName,
        releaseDate,
        updateUrl,
        quitAndUpdate
      })
    }
  )

  function sendUpdateMessage(text, type) {
    mainWindow.webContents.send('ev-message', { text, type })
  }
}
export default handleUpdate
