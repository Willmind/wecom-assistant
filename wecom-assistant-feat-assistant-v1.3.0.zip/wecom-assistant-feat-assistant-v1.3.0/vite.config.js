import { rmSync } from 'fs'
import path from 'path'
import { defineConfig, loadEnv } from 'vite'
// vue
import vue from '@vitejs/plugin-vue'
// electron
import electron from 'vite-plugin-electron'

import visualizer from 'rollup-plugin-visualizer'

// 自动引入插件属性
import AutoImport from 'unplugin-auto-import/vite'

// 按需引入antd
import ViteComponents from 'unplugin-vue-components/vite'
// 使用你所使用的UI组件库的resolver
import { AntDesignVueResolver } from 'unplugin-vue-components/resolvers'

import { createHtmlPlugin } from 'vite-plugin-html'

// svg插件
import { createSvgIconsPlugin } from 'vite-plugin-svg-icons'
import generateModifyVars from './build/genteror/generateModifyVars'

rmSync('dist', { recursive: true, force: true }) // v14.14.0

function pathResolve(dir) {
  return path.resolve(process.cwd(), '.', dir)
}

// cdn 外链
const cdnModules = [
  'https://ftd1.jianzhikeji.cn/static/libs/rsa/v1.0.0/rsa.js',
  'https://ftd1.jianzhikeji.cn/static/libs/xlsx/v0.18.5/xlsx.full.min.js'
]

// 配置文档https://vitejs.dev/config/
export default ({ mode }) => {
  const { VITE_APP_REMOTE } = loadEnv(mode, process.cwd())
  return defineConfig({
    plugins: [
      vue(),
      createHtmlPlugin({
        entry: 'src/main.js',
        inject: {
          data: {
            VITE_NODE_ENE: mode,
            injectScripts: cdnModules.map((path) => `<script src="${path}"></script>`).join('')
          }
        }
      }),
      // 配置需要默认导入的自定义组件文件夹，该文件夹下的所有组件都会自动import
      ViteComponents({
        dirs: ['src/components/apps', 'src/layouts'],
        resolvers: [AntDesignVueResolver({ importStyle: false, resolveIcons: true })]
      }),
      AutoImport({
        imports: ['vue', 'vue-router', 'pinia'],
        vueTemplate: true
      }),
      electron({
        main: {
          entry: 'electron/main/index.js',
          vite: withDebug({
            build: {
              outDir: 'dist/electron/main'
            }
          })
        },
        preload: {
          input: {
            index: path.join(__dirname, 'electron/preload/index.js')
          },
          vite: {
            build: {
              sourcemap: 'inline',
              outDir: 'dist/electron/preload'
            }
          }
        },
        renderer: {}
      }),
      createSvgIconsPlugin({
        iconDirs: [path.resolve(process.cwd(), 'src/assets/icons')],
        symbolId: 'icon-[dir]-[name]'
      }),
      process.env.REPORT &&
        visualizer({
          open: true,
          gzipSize: true,
          brotliSize: true
        })
    ],
    css: {
      preprocessorOptions: {
        // 配置less全局变量
        less: {
          javascriptEnabled: true,
          modifyVars: generateModifyVars(),
          additionalData: `@import "${path.resolve(__dirname, 'src/styles/config.less')}";`
        }
      }
    },
    resolve: {
      //设置路径别名
      alias: {
        '@': pathResolve('src/'),
        api: pathResolve('src/api/')
      }
    },
    server: {
      proxy: {
        '/api': {
          target: VITE_APP_REMOTE,
          ws: true,
          changeOrigin: true,
          rewrite: (path) => path.replace(/^\/api/, '')
        }
      }
    },
    // https://github.com/vitejs/vite/issues/1286#issuecomment-753495099
    esbuild: {
      jsxFactory: 'h',
      jsxFragment: 'Fragment'
    },
    build: {
      terserOptions: {
        compress: {
          drop_debugger: true,
          drop_console: true
        },
        sourceMap: false
      }
    }
  })
}

function withDebug(config) {
  if (process.env.VSCODE_DEBUG) {
    if (!config.build) config.build = {}
    config.build.sourcemap = true
    config.plugins = (config.plugins || []).concat({
      name: 'electron-vite-debug',
      configResolved(config) {
        const index = config.plugins.findIndex((p) => p.name === 'electron-main-watcher')
        config.plugins.splice(index, 1)
      }
    })
  }
  return config
}
