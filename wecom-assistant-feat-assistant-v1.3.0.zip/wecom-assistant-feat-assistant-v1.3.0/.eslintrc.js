module.exports = {
  env: {
    browser: true,
    node: true,
    es6: true
  },
  parser: 'vue-eslint-parser',
  parserOptions: {
    parser: '@typescript-eslint/parser',
    ecmaVersion: 2022,
    sourceType: 'module',
    jsxPragma: 'React',
    ecmaFeatures: {
      jsx: true
    }
  },
  extends: [
    'plugin:vue/vue3-recommended',
    'plugin:@typescript-eslint/recommended',
    'plugin:prettier/recommended'
  ],
  rules: {
    'new-cap': 'off',
    'no-duplicate-imports': 'error',
    'no-use-before-define': 'off',
    'vue/script-setup-uses-vars': 'error',
    'vue/custom-event-name-casing': 'off',
    'vue/attributes-order': 'off',
    '@typescript-eslint/no-var-requires': 0, //加这一条，用import引入就不用加了
    'vue/attribute-hyphenation': 'off',
    'vue/v-on-event-hyphenation': 'off',
    'vue/require-default-prop': 'off',
    'vue/require-explicit-emits': 'off',
    'vue/multi-word-component-names': 'off',
    'vue/multiline-html-element-content-newline': 'off',
    'vue/singleline-html-element-content-newline': 'off',
    'vue/name-property-casing': [1, 'PascalCase'], // JS/JSX中的组件名应该始终是帕斯卡命名法
    indent: [
      2,
      2,
      {
        // 强制执行一致的缩进
        SwitchCase: 1,
        ignoredNodes: [
          'ConditionalExpression',
          'CallExpression > FunctionExpression.callee > BlockStatement.body'
        ],
        VariableDeclarator: 1
      }
    ],
    eqeqeq: [2, 'always'],
    'vue/no-v-html': 'off',
    offsetTernaryExpressions: 'off',
    'vue/no-deprecated-slot-attribute': 'off', // 警告使用弃用插槽属性
    'vue/max-attributes-per-line': [
      'off',
      {
        singleline: 4
      }
    ],
    'arrow-spacing': [
      2,
      {
        // 在箭头函数之前/之后需要空格
        before: true,
        after: true
      }
    ],
    'brace-style': [
      1,
      '1tbs',
      {
        // 需要大括号样式
        allowSingleLine: true
      }
    ],
    'vue/brace-style': 'warn',
    'vue/object-curly-spacing': ['error', 'always'], // 强制括号内的间距一致
    '@typescript-eslint/no-unused-vars': [
      'error',
      {
        argsIgnorePattern: '^_',
        varsIgnorePattern: '^_'
      }
    ],
    'no-unused-vars': [
      'error',
      {
        argsIgnorePattern: '^_',
        varsIgnorePattern: '^_'
      }
    ],
    'vue/html-self-closing': [
      'error',
      {
        html: {
          void: 'always',
          normal: 'never',
          component: 'always'
        },
        svg: 'always',
        math: 'always'
      }
    ],
    // ts
    '@typescript-eslint/no-empty-function': 'off'
  },
  globals: {
    document: 'readonly',
    navigator: 'readonly',
    window: 'readonly'
  }
}
