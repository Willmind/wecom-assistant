// 创建 http hook
import { DEFAULT_PAGENATION } from '@/constants/common/table'
import { setRowSpanByDataIndexs } from '@/utils/common/table'

// 创建常规的请求（更加强大和可拓展。替换 useCreateHTTP）
export const createHTTP = (api, options = {}) => {
  const { defaultData = [], transformData = (i) => i, defaultParams = () => {} } = options

  // data 是对象时，务必传入 defaultData = {}，方便 updateData 正确更新
  const data = ref(defaultData)
  const params = ref({}) // 暂存一份 data 的 params
  const loading = ref(false)
  const state = ref('pending') // fetchData 的状态

  // 兼容对象取值
  const findItemById = (id) => {
    if (id) {
      return Array.isArray(data.value) ? data.value.find((i) => i.id === +id) : data.value[id]
    }
  }

  const updateData = (value = defaultData) => (data.value = value)
  const clearData = () => updateData()

  // 只能插入数组值
  const insertArrayData = (value = [], location = 'ending') => {
    if (!(data.value instanceof Array)) return console.warn('插入的对象不是数组')

    if (location === 'beginning') {
      data.value.unshift(...value)
    } else {
      data.value.push(...value)
    }
  }

  const fetchData = async (_params = {}) => {
    loading.value = true
    state.value = 'pending'
    try {
      params.value = { ...defaultParams(), ..._params }
      const res = await api(params.value)
      if (res.code === 1000) {
        updateData(transformData(res.data))
        state.value = 'done'
      } else if (typeof res.code === 'undefined') {
        updateData(transformData(res))
        state.value = 'error'
      }
    } catch {
      state.value = 'error'
    } finally {
      loading.value = false
    }

    return data.value
  }

  const tryFetchData = (params) => (state.value === 'done' ? Promise.resolve(data.value) : fetchData(params))

  return {
    data,
    params,
    loading,
    updateData,
    clearData,
    insertArrayData,
    findItemById,
    fetchData,
    tryFetchData
  }
}

// 创建带有分页的请求
// rowSpanKey 需要合并 key
export const useCreateListHTTP = (
  api,
  { rowSpanDataIndexs = [], totalKey = 'total', limitKey = 'limit' } = {},
  callback = () => {}
) => {
  const resData = ref({})
  const items = ref([])
  const loading = ref(false)
  const total = ref(0)
  const params = ref({
    page: 1,
    [limitKey]: 10
  })
  const pagination = computed(() => ({
    ...DEFAULT_PAGENATION,
    total: total.value,
    current: params.value.page,
    pageSize: params.value[limitKey]
  }))

  const updateParams = (args) => (params.value = { ...params.value, ...args })
  const initParams = (args) => (params.value = { page: 1, [limitKey]: 10, ...args }) // 可用来移除默认的一些参数（如排序参数）

  const fetchData = async () => {
    loading.value = true
    try {
      const { data } = await api(params.value)
      items.value = setRowSpanByDataIndexs(data.list, rowSpanDataIndexs)
      total.value = data[totalKey]
      resData.value = data
      callback(data)
    } finally {
      loading.value = false
    }
  }

  watch(params, fetchData)

  return {
    items,
    loading,
    resData,
    fetchData,

    params,
    updateParams,
    initParams,

    pagination
  }
}
