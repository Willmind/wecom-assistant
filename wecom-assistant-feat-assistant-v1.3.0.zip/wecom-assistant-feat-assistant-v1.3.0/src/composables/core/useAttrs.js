const LISTENER_PREFIX = /^on[A-Z]/
// 排除的attrs
const DEFAULT_EXCLUDE_KEYS = ['class', 'style']

export function useAttrs(params = {}) {
  const instance = getCurrentInstance()
  if (!instance) {
    return {}
  }

  let { isExcludeListen = false, isExcludeDefKeys = true, excludeKeys = [] } = params

  excludeKeys = [...excludeKeys, ...(isExcludeDefKeys ? DEFAULT_EXCLUDE_KEYS : [])]
  const attrs = shallowRef({})

  // 使attrs为响应式
  instance.attrs = reactive(instance.attrs)

  watchEffect(() => {
    const res = Object.entries(instance.attrs).reduce((ob, [key, val]) => {
      // 排除默认属性
      if (!excludeKeys.includes(key) && !(isExcludeListen && LISTENER_PREFIX.test(key))) {
        ob[key] = val
      }
      return ob
    }, {})
    attrs.value = res
  })

  return attrs
}
