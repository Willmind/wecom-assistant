import { createEnum } from '@/utils/common/enum'

/**
 * 返回数据状态码
 */
export const ResultEnum = createEnum({
  SUCCESS: 1000,
  ERROR: 1001,
  TOKEN_EXPIRE: 1003,
  ACCOUNT_DISABLED: 1004,
  ACCOUNT_LOSE: 1005
})

/**
 * 请求方法
 */
export const RequestEnum = createEnum({
  GET: 'GET',
  POST: 'POST',
  PUT: 'PUT',
  DELETE: 'DELETE'
})

/**
 * contentType enum
 */
export const ContentTypeEnum = {
  // json
  JSON: 'application/json;charset=UTF-8',
  // form-data qs
  FORM_URLENCODED: 'application/x-www-form-urlencoded;charset=UTF-8',
  // form-data  upload
  FORM_DATA: 'multipart/form-data;charset=UTF-8'
}
