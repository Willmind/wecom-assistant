//  2文本，13链接，14图片，15文件，16语音，23视频，29gif动画，
// 41名片，78小程序，141视频号 2文本，13链接，14图片，
// 15文件，16语音，23视频，29gif动画，41名片，78小程序，141视频号

import { createEnum } from '@/utils/common/enum'

export const MessageTypeEnum = createEnum({
  text: 2,
  image: 14,
  video: 23,
  voice: 16,
  file: 15,
  link: 13,
  mini: 78,
  video_num: 141,
  acement: 50001,
  invite: 50002
})
