export const PlacementEnum = {
  RIGHT: 'flex-end',
  LEFT: 'flex-start',
  CENTER: 'center',
  SPACE_BETWEEN: 'space-between'
}
