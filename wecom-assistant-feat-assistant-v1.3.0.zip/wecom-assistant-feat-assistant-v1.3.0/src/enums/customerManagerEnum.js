import { NOT, YES } from '@/constants/common'

export const SexEnum = [
  { label: '男', value: YES },
  { label: '女', value: NOT }
]
