import { createEnum } from '@/utils/common/enum'

export const SizeEnum = createEnum({
  SMALL: 'small',
  LARGE: 'large',
  MINI: 'mini'
})
