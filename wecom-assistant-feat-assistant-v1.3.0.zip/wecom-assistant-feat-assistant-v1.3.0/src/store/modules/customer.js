import { defineStore } from 'pinia'

export const customerStore = defineStore('app-customer', {
  state: () => {
    return {
      customerSelectCount: 0,
      customerCount: 0,
      groupsSelectCount: 0,
      groupsCount: 0
    }
  },
  getters: {},
  actions: {
    resetGroupsSelect() {
      this.groupsSelectCount = 0
      this.groupsCount = 0
    },
    resetCustomerSelect() {
      this.customerSelectCount = 0
      this.customerCount = 0
    }
  }
})
