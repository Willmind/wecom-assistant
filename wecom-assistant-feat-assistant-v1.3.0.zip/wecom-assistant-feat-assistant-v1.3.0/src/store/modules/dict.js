import { defineStore } from 'pinia'
import { queryDict } from '@/api/common'
import { createHTTP } from '@/composables/common/useCreate'

export const dictStore = defineStore('app-dict', () => {
  const { data: dictMap, tryFetchData } = createHTTP(queryDict)
  console.log('tryFetchData', tryFetchData)
  return {
    dictMap,
    tryFetchData: tryFetchData
  }
})
