import { defineStore } from 'pinia'

export const userStore = defineStore('app-user', {
  state: () => {
    return {
      userInfo: null,
      permCodeList: [],
      token: undefined
    }
  },
  getters: {
    getToken() {
      return this.token
    },
    getUserInfo() {
      return this.userInfo || {}
    },
    getPermCodeList() {
      return this.permCodeList || []
    }
  },
  actions: {
    setToken(token) {
      this.token = token
    },
    setUserInfo(info) {
      this.userInfo = info
    },
    setPermCodeList(list) {
      this.permCodeList = list || []
    },
    resetState() {
      this.token = ''
      this.userInfo = null
      this.permCodeList = []
    }
  }
})
