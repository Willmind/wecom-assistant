import { defineStore } from 'pinia'
export const applyStore = defineStore('app-apply', {
  // state 类似组件的data选项，函数形式返回对象
  state: () => {
    return {
      currentId: 1, // 当前打开的组件id
      list: [
        {
          id: 1, // 组件id
          isStick: false, // 是否置顶
          name: '功能', // 导航名称
          icon: 'nav_jz_apply'
        }
      ]
    }
  },
  getters: {},
  actions: {
    // 切换组件
    changeComponent(item = {}, isAdd = true) {
      let _tag = this.list.find((i) => i.id === item.id)
      let _tagIndex = this.list.findIndex((i) => i.id === item.id)
      if (isAdd && !_tag) {
        this.list.push(item)
      }
      if (!isAdd && _tag) {
        this.list.splice(_tagIndex, 1)
        this.currentId = this.list[_tagIndex - 1].id
      }
      if (isAdd) {
        this.currentId = item.id
      }
    }
  }
})
