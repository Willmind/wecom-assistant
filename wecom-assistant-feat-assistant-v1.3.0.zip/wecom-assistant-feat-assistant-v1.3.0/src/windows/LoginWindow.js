import { app, BrowserWindow } from 'electron'
import getAppScaleSize from '../assets/js/getAppScaleSize'
import { LOAD_URL, APP_ICON, PERLOAD, DEV_LOAD_URL } from '../assets/js/appConfig'
const createLoginWindow = function () {
  // 配置参考electron文档
  let { width, height } = getAppScaleSize(1200, 750)
  let windParams = {
    width,
    height,
    minHeight: height,
    minWidth: width,
    show: false, // 是否显示窗口
    frame: false, // 是否隐藏顶部导航
    icon: APP_ICON,
    resizable: process.env.NODE_ENV === 'development', // 窗口是否课调整
    webPreferences: {
      preload: PERLOAD,
      nodeIntegration: true,
      webSecurity: false,
      contextIsolation: false
    }
  }
  let loginWindow = new BrowserWindow(windParams)
  app.isPackaged ? loginWindow.loadURL(LOAD_URL + 'login') : loginWindow.loadURL(DEV_LOAD_URL + 'login')
  !app.isPackaged && loginWindow.webContents.openDevTools()
  // 关闭当前窗口
  loginWindow.on('closed', () => {
    loginWindow = null
  })
  // 打开当前窗口
  loginWindow.on('ready-to-show', () => {
    loginWindow.show()
  })
  // 最小化
  loginWindow.on('unmaximize', () => {
    loginWindow.webContents.send('windows-change', false)
  })

  // 最大化
  loginWindow.on('maximize', () => {
    loginWindow.webContents.send('windows-change', true)
  })
  global.loginWindow = loginWindow
  global.currentWindow = loginWindow
  return loginWindow
}

export default createLoginWindow
