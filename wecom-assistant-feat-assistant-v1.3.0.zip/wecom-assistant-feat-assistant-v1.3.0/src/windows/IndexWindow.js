import { app, BrowserWindow } from 'electron'
import { LOAD_URL, APP_ICON, PERLOAD, DEV_LOAD_URL } from '../assets/js/appConfig'
import getAppScaleSize from '../assets/js/getAppScaleSize'
import handleUpdate from '../../electron/main/update'
const createIndexWindow = function () {
  // 配置参考electron文档
  let { width, height } = getAppScaleSize(1200, 750)
  let windParams = {
    width,
    height,
    minHeight: height,
    minWidth: width,
    show: false, // 是否显示窗口
    frame: false, // 是否隐藏顶部导航
    maximizable: false,
    icon: APP_ICON,
    webPreferences: {
      preload: PERLOAD,
      nodeIntegration: true,
      webSecurity: false,
      contextIsolation: false
    }
  }
  let indexWindow = new BrowserWindow(windParams)
  // 加载页面
  app.isPackaged ? indexWindow.loadURL(LOAD_URL + 'home') : indexWindow.loadURL(DEV_LOAD_URL + 'home')
  !app.isPackaged && indexWindow.webContents.openDevTools()

  // 关闭当前窗口
  indexWindow.on('closed', () => {
    indexWindow = null
  })

  // 打开当前窗口
  indexWindow.on('ready-to-show', () => {
    indexWindow.show()
  })

  // 最小化
  indexWindow.on('unmaximize', () => {
    indexWindow.webContents.send('windows-change', false)
  })

  // 最大化
  indexWindow.on('maximize', () => {
    indexWindow.webContents.send('windows-change', true)
  })

  // 打开外部浏览器
  indexWindow.on('openExternal', (url) => {
    console.log(url)
    //shell.openExternal(url)
  })

  global.indexWindow = indexWindow
  global.currentWindow = indexWindow
  handleUpdate(indexWindow)
  return indexWindow
}

export default createIndexWindow
