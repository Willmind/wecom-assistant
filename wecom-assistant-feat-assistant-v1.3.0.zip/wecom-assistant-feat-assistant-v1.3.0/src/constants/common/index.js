export const YES = 1
export const NOT = 0
