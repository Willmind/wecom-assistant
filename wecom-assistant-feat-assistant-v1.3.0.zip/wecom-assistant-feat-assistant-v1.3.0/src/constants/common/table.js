// table 默认的分页参数
export const DEFAULT_PAGENATION = {
  defaultCurrent: 1,
  showSizeChanger: true,
  showQuickJumper: true
}
