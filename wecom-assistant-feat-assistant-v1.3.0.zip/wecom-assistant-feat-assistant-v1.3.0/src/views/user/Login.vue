<template>
  <div id="login" class="jz-flex jz-flex-center">
    <div class="navigator jz-flex jz-flex-rr jz-flex-cc">
      <span class="no-drag">
        <svg-icon icon-name="hide" class="jz-pointer" @click="hideWin" />
        <svg-icon :icon-name="!isMax ? 'w_max' : 'w_min'" @click="handleWindow" class="m-r-17 jz-pointer" />
        <svg-icon icon-name="close" class="jz-pointer" @click="exitWin" />
      </span>
    </div>
    <div class="left-wraper jz-flex jz-flex-dir-col">
      <div class="jz-flex img-wraper" :style="{ 'margin-left': `-${leftVal}px`, transition: `${ition}s` }">
        <img v-for="(item, index) in imgList" :key="index" :src="item" alt="" />
        <!-- 复制第一张放到最后,以实现无缝无限循环滚动效果 -->
        <img :src="imgList[0]" alt="" />
      </div>
      <span class="logo-span jz-flex jz-flex-center">用真诚和热情服务每一位客户</span>
      <div class="jz-flex jz-flex-center dot-footer">
        <div
          @click="instFun(index)"
          class="click-dot jz-pointer"
          v-for="(item, index) in imgList.length"
          :key="index"
          :style="{ opacity: index === imgShow ? 1 : 0.3 }"
        ></div>
      </div>
    </div>
    <div class="right-wraper jz-flex jz-flex-col">
      <i class="back-box jz-pointer" v-if="navCurrentIndex === 2" @click="changeView(0)">
        <svg-icon icon-name="login_back" />
      </i>
      <div class="logo jz-flex jz-flex-center">
        <svg-icon icon-name="logo" />
      </div>

      <div class="nav jz-flex jz-flex-center" v-if="navCurrentIndex !== 2">
        <span
          class="jz-flex-1 jz-flex jz-flex-center jz-pointer"
          v-for="(item, index) in comsList.slice(0, 2)"
          :key="index"
          :class="navCurrentIndex === index && 'current'"
          >{{ item.name }}</span
        >
      </div>
      <div class="jz-form jz-flex-1">
        <component :is="comCurrent.comName" @changeView="changeView" />
      </div>
    </div>
  </div>
</template>
<script setup>
import WxcodeForm from './comps/WxcodeForm.vue'
import logo from '@/assets/imgs/logo.png'
import logo2 from '@/assets/imgs/logo2.png'

import { onMounted } from 'vue'
const isMax = ref(false)
const { ipcRenderer } = require('electron')
const imgList = ref([logo, logo2])
const leftVal = ref(0) // 轮播图盒子的偏移值
const imgShow = ref(0) // 表示当前显示的图片索引
const ition = ref(0.8) // 设置轮播图过度时间
const imgWidth = ref(424) //需要的图片宽度

// 组件数据
const comsList = reactive([
  // {
  //   name: '账号密码',
  //   index: 0,
  //   comName: markRaw(AccountForm)
  // },
  {
    name: '企微二维码',
    index: 1,
    comName: markRaw(WxcodeForm)
  }
  // {
  //   name: '企业微信',
  //   index: 2,
  //   comName: markRaw(ForgotForm)
  // }
])
// 当前选中组件
const comCurrent = reactive({
  comName: comsList[0].comName
})
const navCurrentIndex = ref(0)

/**
 * 下一张
 */
const nextFun = () => {
  if (leftVal.value === (unref(imgList).length - 1) * imgWidth.value) {
    ition.value = 0.8
    leftVal.value += imgWidth.value
    imgShow.value = 0
    setTimeout(() => {
      ition.value = 0
      leftVal.value = 0
    }, ition.value * 1000)
  } else {
    ition.value = 0.8
    leftVal.value += imgWidth.value
    imgShow.value++
  }
}
/**
 * // 点击小圆点
 */
const instFun = (index) => {
  ition.value = 0.8
  leftVal.value = index * imgWidth.value
  imgShow.value = index
}
/**
 * 自动轮播定时器
 * @type {number}
 */
const timer = setInterval(() => {
  nextFun()
}, 3000)

onMounted(() => {
  $storeLocal.remove('isLoginOut')
  ipcRenderer.on('windows-change', (event, val) => {
    isMax.value = val
  })
  $storeLocal.get('token') && ipcRenderer.send('show-home', $storeLocal.get('token'))
})

onUnmounted(() => {
  clearInterval(timer)
})

// methods=========================

// 切换表单类型
const changeView = (index = 2) => {
  comCurrent.comName = comsList[index].comName
  navCurrentIndex.value = index
}

// 关闭窗口
const exitWin = () => {
  ipcRenderer.send('exit', 'loginWindow')
}

// 处理窗口隐藏缩小
const handleWindow = () => {
  let name = 'loginWindow'
  ipcRenderer.send('maximize', name)
}

// 隐藏窗口
const hideWin = () => {
  ipcRenderer.send('minimize', 'loginWindow')
}
</script>

<style lang="less" scoped>
#login {
  width: 100%;
  height: 100%;
  padding: 56px 130px;
  box-sizing: border-box;
  position: relative;
  .navigator {
    position: absolute;
    left: 0;
    top: 0;
    right: 0;
    height: 40px;
    -webkit-app-region: drag;
    .svg-icon {
      width: 20px !important;
      height: 20px !important;
      margin-right: 12px;
    }
  }
  .back-box {
    left: 24px;
    top: 24px;
    position: absolute;
    .svg-icon {
      width: 32px !important;
      height: 32px !important;
    }
  }
  .left-wraper {
    min-width: 424px;
    margin-right: 77px;
    position: relative;
    overflow: hidden;
    .img-wraper {
      transition: all 0.3s;
      width: 424px;
      height: 424px;
    }
    .dot-footer {
      margin-top: 80px;
      .click-dot {
        width: 4px;
        height: 4px;
        border-radius: 50%;
        background: #3165f5;
        margin-left: 4px;
      }
    }

    img {
      width: 424px;
      height: 424px;
      display: block;
      transition: all 0.3s;
    }
    .logo-span {
      font-size: 14px;
      color: @font-minor-color;
    }
  }
  .right-wraper {
    min-width: 474px;
    width: 474px;
    height: 638px;
    background: #ffffff;
    border-radius: 12px;
    padding: 48px;
    position: relative;
    box-shadow: 0px 6px 12px 0px rgba(0, 0, 0, 0.03);
    .logo {
      margin-bottom: 16px;
      .svg-icon {
        width: 234px !important;
        height: 67px !important;
      }
    }
    .nav {
      width: 378px;
      height: 48px;
      font-size: 14px;
      color: #999;
      span.current {
        cursor: pointer;
        color: @font-blue;
        position: relative;
        &::after {
          position: absolute;
          left: 50%;
          margin-left: -28px;
          right: 0;
          bottom: -12px;
          content: '';
          width: 56px;
          height: 2px;
          background: #3165f5;
        }
        // &:nth-of-type(1)::after {
        //   animation: ani-left-move 0.2s linear;
        // }
        // &:nth-of-type(2)::after {
        //   animation: ani-right-move 0.2s linear;
        // }
      }
    }
    .jz-form {
      height: 100%;
      overflow: hidden;
    }
  }
}
@keyframes ani-right-move {
  from {
    transform: translateX(-150px);
  }
  50% {
    transform: translateX(-50px);
  }
  to {
    transform: translateX(0px);
  }
}
@keyframes ani-left-move {
  from {
    transform: translateX(150px);
  }
  50% {
    transform: translateX(50px);
  }
  to {
    transform: translateX(0px);
  }
}
</style>
