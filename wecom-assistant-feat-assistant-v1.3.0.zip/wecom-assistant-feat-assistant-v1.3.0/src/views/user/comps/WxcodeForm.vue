<template>
  <div class="wx-box jz-flex jz-flex-col jz-flex-center">
    <a-spin :spinning="spinning">
      <div class="wx-code example jz-pointer" @click="getWxCode">
        <div class="reload jz-flex jz-flex-col jz-flex-center" v-if="state.isPast">
          <svg-icon icon-name="login_reload" />
          <span>刷新二维码</span>
        </div>
        <img :src="state.qr_code" alt="" v-if="state.qr_code" />
      </div>
    </a-spin>

    <div class="check-box jz-flex jz-flex-rc">
      <div class="jz-flex-1">
        <a-checkbox v-model:checked="state.checked">7天自动登录</a-checkbox>
      </div>
    </div>
    <div class="tip jz-flex jz-flex-col jz-flex-center">
      <span>请使用企业微信进行扫码登录</span>
    </div>
  </div>
</template>

<script setup>
import { getLoginQRcode, getLoginStatus } from 'api/login'
import { onUnmounted, reactive } from 'vue'
import useMessage from '@/composables/web/useMessage'
const { ipcRenderer } = require('electron')
const { createMessage } = useMessage()
const spinning = ref(false)
const state = reactive({
  qr_code: '', // 二维码
  checked: false, // 是否勾选7天
  isPast: '', // 二维码是否过期
  request_no: '', //  登录请求编号
  login_code_expire_time: '', // 过期时间
  errorArr: [1004, 1005]
})
let timer = null
onMounted(() => {
  getWxCode()
})

onUnmounted(() => {
  timer && window.clearInterval(timer)
  timer = null
})
// methods======================
// 获取二维码
const getWxCode = async () => {
  try {
    if (spinning.value) return
    spinning.value = true
    let { data, code } = await getLoginQRcode()
    state.isPast = false

    timer && window.clearInterval(timer)
    timer = null
    spinning.value = false
    if (code === 1000) {
      state.qr_code = data.login_code_url
      state.request_no = data.request_no
      let maps = {
        // 需要二次扫码
        3: () => {
          state.login_code_expire_time = data.login_code_expire_time
          handleExpireTime()
        },
        //  登录成功
        4: () => {},
        // 账号已在线
        5: () => {
          createMessage.success('账号已在线')
        }
      }[+data.login_status]
      maps && maps()
    }
  } catch (error) {
    spinning.value = false
  }
}

// 轮训二维码过期时间
const handleExpireTime = () => {
  timer = window.setInterval(() => {
    if (new Date().getTime() > state.login_code_expire_time) {
      state.isPast = true
      window.clearInterval(timer)
      getWxCode()
    }
    // 查询登录状态
    getStatus()
  }, 2000)
}

// 查询登录状态
const getStatus = () => {
  getLoginStatus({
    request_no: state.request_no,
    auto_login: state.checked ? 1 : 0
  })
    .then((res) => {
      console.log(res)
      if (res.code === 1000) {
        createMessage.success('登录成功')
        window.clearInterval(timer)
        timer = null
        $storeLocal.set('jzUserInfo', res.data)
        $storeLocal.set('token', 'bearer ' + res.data.token)
        setTimeout(() => {
          ipcRenderer.send('show-home', 'bearer ' + res.data.token)
        }, 1000)
      }
    })
    .catch((err) => {
      if (state.errorArr.includes(+err.code)) {
        state.isPast = true
        timer && window.clearInterval(timer)
        timer = null
      }
      if (err.code === 1001 && err.msg !== '等待扫码登录') {
        state.isPast = true
        createMessage.error(err.msg)
        timer && window.clearInterval(timer)
        timer = null
      }
    })
}
</script>

<style lang="less" scoped>
.wx-box {
  .wx-code {
    width: 200px;
    height: 200px;
    border-radius: 18px;
    padding: 9px;
    margin: 32px auto;
    border: 2px solid #eeeeee;
    position: relative;
    img {
      width: 100%;
      height: 100%;
      display: block;
    }
    .reload {
      position: absolute;
      left: 0;
      top: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.8);
      color: #fff;
      cursor: pointer;
      border-radius: 18px;
      .svg-icon {
        width: 56px !important;
        height: 56px !important;
      }
      span {
        font-size: 14px;
        margin-top: 8px;
      }
    }
  }
  .check-box {
    margin-bottom: 70px;
  }
  .tip {
    color: #999;
    font-size: 14px;
  }
}
</style>
