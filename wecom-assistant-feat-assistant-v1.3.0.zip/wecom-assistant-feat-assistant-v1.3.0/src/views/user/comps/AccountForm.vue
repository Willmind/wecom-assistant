<template>
  <div class="user-form jz-flex jz-flex-col jz-flex-center">
    <a-form :model="formState" autocomplete="off" @finish="onSubmit">
      <a-form-item name="account" :rules="[{ required: true, message: '请输入用户名/手机号' }]" class="mb-16">
        <a-input v-model:value="formState.account" placeholder="请输入用户名/手机号">
          <template #prefix>
            <svg-icon icon-name="login_user" style="width: 16px; height: 16px" />
          </template>
        </a-input>
      </a-form-item>
      <a-form-item name="password" :rules="[{ required: true, message: '请输入密码' }]" class="mb-16">
        <a-input-password v-model:value="formState.password" type="password" placeholder="请输入密码">
          <template #prefix>
            <svg-icon icon-name="login_lock" style="width: 16px; height: 16px" />
          </template>
        </a-input-password>
      </a-form-item>
      <a-form-item
        name="captcha"
        :rules="[{ required: true, message: '请输入验证码' }]"
        class="captcha mb-16"
      >
        <a-input v-model:value="formState.captcha" placeholder="请输入验证码">
          <template #prefix>
            <svg-icon
              icon-name="login_verification code"
              style="width: 16px; height: 16px; color: rgba(0, 0, 0, 0.4)"
            />
          </template>
        </a-input>
        <div class="captcha-btn">
          <img :src="captchaUrl" @click="refreshCaptcha" />
        </div>
      </a-form-item>
      <div class="check-box jz-flex jz-flex-rc">
        <div class="jz-flex-1">
          <a-checkbox v-model:checked="checked">7天自动登录</a-checkbox>
        </div>
        <span class="frd jz-pointer" @click="showForgotView">忘记密码</span>
      </div>
      <a-form-item>
        <a-button
          class="btn jz-pointer"
          type="primary"
          html-type="submit"
          :loading="submitting"
          :class="loginLock && 'disabled-btn'"
          >{{ submitting ? '登录中...' : '登录' }}</a-button
        >
      </a-form-item>
    </a-form>
  </div>
</template>

<script setup>
import { getApiLogin } from 'api/login'
import { rsaEncrypt, getRandomNum } from '@/assets/js/utils'
import { computed } from 'vue'
const { ipcRenderer } = require('electron')
// 表单信息
const formState = reactive({
  account: '',
  password: '',
  captcha: ''
})

const random = new Date().getTime() + getRandomNum(1, 99999999999, true)

const submitting = ref(false)
const captchaUrl = ref(
  `${import.meta.env.VITE_APP_REMOTE}/login/captcha?v=${new Date().getTime()}&random=${random}`
)
const checked = ref(false)
const emit = defineEmits(['changeView'])
const showForgotView = () => {
  emit('changeView', 2)
}

const loginLock = computed(() => {
  let { account, password, captcha } = formState
  return !(account && password && captcha)
})

// methods===============================

// 刷新验证码
const refreshCaptcha = () => {
  captchaUrl.value = `${
    import.meta.env.VITE_APP_REMOTE
  }/login/captcha?v=${new Date().getTime()}&random=${random}`
}

// 登录提交
const onSubmit = async (values) => {
  try {
    submitting.value = true
    let { account, password, captcha } = values
    let params = {
      account: rsaEncrypt(account),
      password: rsaEncrypt(password),
      captcha,
      random: random
    }
    params = Object.assign(params, { auto_login: checked.value ? 1 : 0 })
    getApiLogin(params)
      .then((res) => {
        if (res.code === 1000) {
          submitting.value = false
          $storeLocal.set('jzUserInfo', res.data)
          $storeLocal.set('token', 'bearer ' + res.data.token)
          ipcRenderer.send('show-home', 'bearer ' + res.data.token)
        }
      })
      .catch(() => {
        refreshCaptcha()
      })
      .finally(() => {
        submitting.value = false
      })
  } catch (error) {
    console.log(error)
    submitting.value = false
  }
}
</script>

<style lang="less" scoped>
.user-form {
  width: 100%;
  margin-top: 24px;
}
.mb-16 {
  margin-bottom: 16px;
}
.btn {
  width: 100%;
  height: 40px;
  border-radius: 8px;
  background: #3165f5;
  box-shadow: 0px 6px 58px 0px rgba(196, 203, 214, 0.1);
}
.check-box {
  margin-bottom: 132px;
}
.frd {
  color: #3165f5;
}
:deep(.anticon svg) {
  color: #999;
}
:deep(.ant-form-item-with-help) {
  margin-bottom: 0px !important;
}
:deep(.captcha .ant-form-item-control-input-content) {
  display: flex;
  align-items: center;
}

:deep(.captcha .ant-form-item-control-input-content) {
  display: flex;
  align-items: center;
}
:deep(.ant-input-affix-wrapper) {
  padding: 10px 14px;
  border-radius: 8px;
  height: 40px;
  border: 1px solid #eee;
}
:deep(.ant-btn-primary) {
  text-shadow: none;
  box-shadow: none;
}
#form_item_captcha {
  height: 40px;
  border-radius: 8px;
  border: 1px solid #eee;
}
.captcha-btn {
  width: 134px;
  height: 40px;
  margin-left: 8px;
  cursor: pointer;
  img {
    width: 100%;
    height: 100%;
    display: block;
  }
}
.disabled-btn {
  background: #d6e0fd;
  border: 1px solid #d6e0fd;
}
:deep(.ant-input-prefix) {
  margin-right: 10px;
}
</style>
