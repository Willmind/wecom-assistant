<template>
  <div class="user-form jz-flex jz-flex-col jz-flex-center">
    <div class="tit jz-flex jz-flex-center">
      <div class="jz-flex-1"></div>
      <label>重置密码</label>
      <div class="jz-flex-1"></div>
    </div>
    <a-form :model="formState" autocomplete="off" @finish="onSubmit" ref="formRef">
      <a-form-item
        name="account"
        class="mb-16"
        :rules="[{ required: true, message: '请输入绑定的手机号/邮箱' }, { validator: phoneCheck }]"
      >
        <a-input v-model:value="formState.account" placeholder="请输入绑定的手机号/邮箱">
          <template #prefix>
            <svg-icon icon-name="login_user" style="width: 16px; height: 16px; color: rgba(0, 0, 0, 0.4)" />
          </template>
        </a-input>
      </a-form-item>
      <a-form-item name="code" :rules="[{ required: true, message: '请输入验证码' }]" class="captcha mb-16">
        <a-input v-model:value="formState.code" type="password" placeholder="请输入验证码">
          <template #prefix>
            <svg-icon
              icon-name="login_verification code"
              color="rgba(0, 0, 0, 0.4)"
              style="width: 16px; height: 16px"
            />
          </template>
        </a-input>
        <div
          @click="getCode"
          class="captcha-btn jz-flex jz-flex-center"
          :class="(countdownTime > 0 && 'send', !formState.account && 'not-allowed')"
        >
          {{ countdownTime > 0 ? `重新发送（${countdownTime}）` : isFirst ? '发送验证码' : '重新发送' }}
        </div>
      </a-form-item>
      <a-form-item
        class="mb-16"
        name="password"
        :rules="[{ required: true, message: '请输入密码' }, { validator: pwdCheck }]"
      >
        <a-input-password v-model:value="formState.password" type="password" placeholder="请输入密码">
          <template #prefix>
            <svg-icon icon-name="login_lock" style="width: 16px; height: 16px" />
          </template>
        </a-input-password>
      </a-form-item>
      <a-form-item
        name="repeat_password"
        :rules="[{ required: true, message: '请再次输入密码' }, { validator: newPwdCheck }]"
      >
        <a-input-password
          v-model:value="formState.repeat_password"
          type="password"
          @blur="pwBlur"
          placeholder="请再次输入密码"
        >
          <template #prefix>
            <svg-icon icon-name="login_lock" style="width: 16px; height: 16px" />
          </template>
        </a-input-password>
      </a-form-item>
      <a-form-item>
        <a-button
          class="btn jz-pointer"
          type="primary"
          :class="loginLock && 'disabled-btn'"
          html-type="submit"
          :loading="submitting"
          >{{ submitting ? '重置中...' : '重置密码' }}</a-button
        >
      </a-form-item>
    </a-form>
  </div>
</template>

<script setup>
import { getApiPhoneCode, setApiAccountReset, getApiEmailCode } from 'api/login'
import { phoneReg, emailReg, rsaEncrypt, passwordReg } from '@/assets/js/utils'
import useMessage from '@/composables/web/useMessage'
import { onUnmounted, ref } from 'vue'
let timer = null
const { createMessage } = useMessage()
const isFirst = ref(true)
const submitting = ref(false)
const countdownTime = ref(0)
const accountType = ref(0)
const formRef = ref()
// 表单信息
const formState = reactive({
  account: '',
  password: '',
  code: '',
  repeat_password: ''
})
const confirmDirty = ref(false)
const emit = defineEmits(['changeView'])
onUnmounted(() => {
  clearInterval(timer)
  timer = null
})

const loginLock = computed(() => {
  let { account, password, code, repeat_password } = formState
  return !(account && password && repeat_password && code)
})

// methods========================================

const pwBlur = (e) => {
  confirmDirty.value = confirmDirty.value || !!e.target.value
}

// 获取验证码
const getCode = async () => {
  if (!formState.account) {
    return
  }
  if (countdownTime.value > 0 || !accountType.value) {
    return
  }
  let params = { phone: formState.account }
  let { code } =
    accountType.value === 1
      ? await getApiEmailCode({ email: formState.account })
      : await getApiPhoneCode(params)
  if (code === 1000) {
    createMessage.success('发送成功')
    countdown()
  }
}

// 倒计时
const countdown = () => {
  clearInterval(timer)
  countdownTime.value = 60
  isFirst.value = false
  timer = setInterval(() => {
    if (countdownTime.value > 0) {
      --countdownTime.value
    } else {
      clearInterval(timer)
    }
  }, 1000)
}

// 校验输入手机号
const phoneCheck = (rule, value) => {
  if (value && !emailReg.test(value) && !phoneReg.test(value)) {
    return Promise.reject('请输入正确的手机号或邮箱')
  } else {
    if (emailReg.test(value)) {
      accountType.value = 1
    } else if (phoneReg.test(value)) {
      accountType.value = 2
    } else {
      accountType.value = 0
    }
  }
  return Promise.resolve()
}

// 校验密码
const pwdCheck = (rule, value) => {
  if (formState.password) {
    if (!passwordReg.test(value) && value) {
      return Promise.reject('密码不少于 8位，且包含数字、字母和特殊字符。')
    }
  }
  if (value && confirmDirty.value) {
    formRef.value.validateFields(['repeat_password'], { force: true })
  }
  return Promise.resolve()
}

// 校验两次密码是否正确
const newPwdCheck = () => {
  if (formState.repeat_password && formState.password && formState.repeat_password !== formState.password) {
    return Promise.reject('两次输入的密码必须一致')
  }
  return Promise.resolve()
}
// 提交
const onSubmit = async (values) => {
  console.log(values)
  let params = {
    account: rsaEncrypt(values.account),
    code: rsaEncrypt(values.code),
    password: rsaEncrypt(values.password),
    repeat_password: rsaEncrypt(values.repeat_password),
    type: accountType.value
  }
  submitting.value = true
  setApiAccountReset(params)
    .then((res) => {
      if (res.code === 1000) {
        createMessage.success('重置成功，请重新登录')
        emit('changeView', 0)
      }
    })
    .finally(() => {
      submitting.value = false
    })
}
</script>

<style lang="less" scoped>
.tit {
  margin-bottom: 24px;
  width: 100%;
  label {
    margin: 0 16px;
    font-size: 14px;
  }
  div {
    width: 100%;
    height: 0px;
    opacity: 1;
    border: 1px solid;
    border-image: linear-gradient(270deg, rgba(238, 238, 238, 1), rgba(238, 238, 238, 0)) 1 1;
    &:last-child {
      border-image: linear-gradient(270deg, rgba(238, 238, 238, 0), rgba(238, 238, 238, 1)) 1 1;
    }
  }
}
.mb-16 {
  margin-bottom: 16px;
}
.user-form {
  width: 100%;
  margin-top: 24px;
}

.btn {
  width: 100%;
  height: 40px;
  margin-top: 90px;
  background: #3165f5;
}
.check-box {
  margin-bottom: 132px;
}
.frd {
  color: #3165f5;
}
:deep(.ant-input-prefix) {
  margin-right: 10px;
}
:deep(.ant-form-item-with-help) {
  margin-bottom: 0px !important;
}
:deep(.anticon svg) {
  color: #999;
}
:deep(.captcha .ant-form-item-control-input-content) {
  display: flex;
  align-items: center;
}

:deep(.captcha .ant-form-item-control-input-content) {
  display: flex;
  align-items: center;
}
:deep(.ant-input-affix-wrapper) {
  padding: 10px 14px;
  border-radius: 8px;
  height: 40px;
  border: 1px solid #eee;
}
:deep(.ant-btn-primary) {
  text-shadow: none;
  box-shadow: none;
}
:deep(.ant-input-affix-wrapper-focused) {
  box-shadow: none;
}
#form_item_captcha {
  height: 40px;
  border-radius: 8px;
  border: 1px solid #eee;
}
.captcha-btn {
  width: 170px;
  height: 40px;
  margin-left: 8px;
  border-radius: 8px;
  font-size: 14px;
  color: #999;
  cursor: pointer;
  border: 1px solid #eeeeee;
  background: rgba(0, 0, 0, 0.04);
  &:hover {
    color: #3165f5;
    background: #fff;
    border: 1px solid #3165f5;
  }
}
.send {
  width: 170px;
  border: 1px solid #eeeeee;
  background: rgba(0, 0, 0, 0.04);
  &:hover {
    cursor: pointer;
    border: 1px solid #eeeeee;
    background: rgba(0, 0, 0, 0.04);
  }
}
.disabled-btn {
  background: #d6e0fd;
  border: 1px solid #d6e0fd;
}
</style>
