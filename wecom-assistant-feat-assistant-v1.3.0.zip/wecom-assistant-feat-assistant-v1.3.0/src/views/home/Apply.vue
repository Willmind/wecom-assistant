<template>
  <div id="apply">
    <!--动态的组件-->
    <component :is="comCurrent.comName" />
  </div>
</template>

<script setup>
import toolData from '@/assets/js/toolConfig'
import { applyStore } from '@/store/modules/apply'
const store = applyStore()
const { currentId } = storeToRefs(store)
// 展示当前组件
let comCurrent = reactive({
  comName: markRaw(toolData.find((i) => i.id === currentId.value).comName)
})
// 监听
watch(currentId, (newVal) => {
  comCurrent.comName = markRaw(toolData.find((i) => i.id === newVal).comName)
})
</script>

<style lang="less">
#apply {
  background: #f5f5f5;
  width: 100%;
  height: 100%;
  overflow: hidden;
}
</style>
