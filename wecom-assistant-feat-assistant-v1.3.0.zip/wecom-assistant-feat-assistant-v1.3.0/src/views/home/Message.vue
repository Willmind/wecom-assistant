<template>
  <div>消息</div>
</template>

<script>
export default {}
</script>

<style></style>
