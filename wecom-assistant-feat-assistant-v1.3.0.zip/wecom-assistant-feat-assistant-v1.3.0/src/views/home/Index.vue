<template>
  <div class="jz-layout jz-flex">
    <!--导航头部-->
    <Header />
    <!--侧边栏-->
    <SideBar />
    <!-- 二级路由 -->
    <router-view class="jz-flex-1" />
    <AutoUpdater />
  </div>
</template>
<script setup>
import { userStore } from '@/store/modules/user'
import useMessage from '@/composables/web/useMessage'
import AutoUpdater from '@/components/AutoUpdater.vue'
const store = userStore()
const { createMessage } = useMessage()
onMounted(() => {
  if (!$storeLocal.get('jzUserInfo')?.admin_id) {
    createMessage.warn('当前企微未创建客服号，请联系上级创建使用。')
  }
  $storeLocal.get('jzUserInfo') && store.setToken($storeLocal.get('jzUserInfo')?.token)
  $storeLocal.get('jzUserInfo') && store.setUserInfo($storeLocal.get('jzUserInfo'))
})
</script>

<style lang="less" scoped></style>
