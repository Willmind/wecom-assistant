// API定义合集
import request from '@/utils/http/index'

// 模板列表
export const getSopTempList = (params) => request.get('/sopTemp/list', { params })

// 模板详情
export const getSopTempInfo = (params) => request.get('/sopTemp/info', { params, showLoading: true })

// 任务新增
export const createSopTask = (params) => request.post('/sop/task/create', params, { showLoading: true })

// 模板新增编辑
export const sopEdit = (params) => request.post('/sopTemp/edit', params, { showLoading: true })

// 获取模板列表
export const sopList = (params) => request.get('/sopTemp/list', { params })

// 移出我的模板
export const cancelCollect = (params) => request.post('/sopTemp/cancelCollect', params, { showLoading: true })

// 删除我的模板
export const deleteCollect = (params) => request.post('/sopTemp/delete', params, { showLoading: true })

// 加入我的模板
export const addCollect = (params) => request.post('/sopTemp/collect', params, { showLoading: true })

// 批量移除删除
export const batchDelete = (params) => request.post('/sopTemp/batchDelete', params, { showLoading: true })

// 任务取消
export const cancelSopTask = (params) => request.post('/sop/task/cancel', params, { showLoading: true })

// 任务列表
export const getSopTaskList = (params) => request.get('/sop/task/getMemberList', { params })

// 任务详情
export const getSopTaskDetail = (params) => request.get('/sop/task/getDetail', { params })

// 天数详情
export const getDayDetail = (params) => request.get('/sop/task/getDayDetail', { params })

// 任务统计
export const getTaskCount = (params) => request.post('/sop/task/getTaskCount', params, { showLoading: true })

// 过滤对象
export const getFilterMember = (params) => request.post('/sop/task/getFilterMember', params, { showLoading: true })

// 重发失败消息
export const resendSop = (params) => request.get('/sop/task/resend', { params })

