// API定义合集
import request from '@/utils/http/index'
// 获取列表
export const getApiApplyList = (params) => request.get('friend/applyList', { params })
// 任务设置
export const getApifriendPanel = (params) => request.get('friend/panel', { params })
// 接受好友
export const apiTakeAccept = (params) => request.post('/friend/accept', params, { showLoading: true })
// 删除好友
export const apiDeleteAccept = (params) => request.post('/friend/delete', params, { showLoading: true })
// 清空列表
export const apiClearAccept = (params) => request.post('/friend/clear', params, { showLoading: true })
// 启用|停用任务设置
export const apiOpenSetting = (params) => request.post('/friend/openSetting', params, { showLoading: true })
// 任务设置
export const apiTaskSetting = (params) => request.post('/friend/setting', params, { showLoading: true })
// 获取任务设置
export const apiGetSetting = (params) => request.get('/friend/getSetting', { params, showLoading: true })
