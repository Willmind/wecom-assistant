import request from '@/utils/http'

// 客户查询列表
export const queryList = (params) => request.get('/contact/contactList', { params })

// 添加称呼
export const addCall = (data) => request.post('/contactName/create', data)

//编辑称呼
export const editCall = (data) => request.post('/contactName/update', data)

// 保存称呼（新增、编辑）
export const saveCall = (data) => (data?.id ? editCall(data) : addCall(data))

// 删除称呼
export const removeCall = (data) => request.post('/contactName/delete', data)

// 设置-修改备注
export const updateRemark = (data) => request.post('/contact/updateRemark', data)

// 设置-修改标签
export const updateLabel = (data) => request.post('/contact/updateLabel', data)

// 设置-批量修改备注
export const batchUpdateRemark = (data) => request.post('/contact/batchUpdateRemark', data)

// 备注-批量替换
export const batchReplaceRemarkWork = (data) => request.post('/contact/replaceRemarkWord', data)

// 标签-批量添加
export const batchAddLabel = (data) => request.post('/contact/batchAddLabel', data)

// 标签-批量移除
export const batchDelLabel = (data) => request.post('/contact/batchDelLabel', data)

// 高级群任务列表
export const getTaskList = (params) => request.get('/msg/getTaskList', { params })

// 任务暂停
export const setTaskPause = (params) => request.post('/msg/setTaskPause', params, { showLoading: true })
// 任务继续
export const setTaskContinue = (params) => request.post('/msg/setTaskContinue', params, { showLoading: true })
// 任务取消
export const setTaskCancel = (params) => request.post('/msg/setTaskCancel', params, { showLoading: true })
// 设置群发配置
export const setMsgSendConfig = (params) =>
  request.post('/msg/setMsgSendConfig', params, { showLoading: true })
// 获取群发配置
export const getMsgSendConfig = (params) => request.get('/msg/getMsgSendConfig', { params })
// 任务详情
export const getTask = (params) => request.get('/msg/getTask', { params })
// 任务对象
export const getTaskMember = (params) => request.get('/msg/getTaskMember', { params, showLoading: true })
// 统计任务数量
export const getTaskCount = (params) => request.get('/msg/getTaskCount', { params })

// 获取群发默认配置
export const getMsgSendDefaultConfig = (params) =>
  request.get('/msg/getMsgSendDefaultConfig', { params, showLoading: true })

// 学员列表
export const getCampContacts = (params) => request.get('/contact/campContacts', { params, showLoading: true })

// 好友申请-添加任务
export const addTask = (params) => request.post('/friend/addTask', params, { showLoading: true })

// 好友申请-获取任务设置
export const getAddSetting = (params) => request.get('/friend/getAddSetting', params)

// 好友申请-任务设置
export const addSetting = (params) => request.post('/friend/addSetting', params, { showLoading: true })

// 统计添加好友申请.
export const statisticAddFriend = (params) => request.get('/friend/statisticAddFriend', params)

// 任务列表
export const getAddTaskList = (params) => request.get('/friend/getAddTaskList', { params })

// 任务暂停
export const setFriendTaskPause = (params) =>
  request.post('/friend/setTaskPause', params, { showLoading: true })

// 任务继续
export const setFriendTaskContinue = (params) =>
  request.post('/friend/setTaskContinue', params, { showLoading: true })

// 任务取消
export const setFriendTaskCancel = (params) =>
  request.post('/friend/setTaskCancel', params, { showLoading: true })

// 任务详情
export const getSubTaskInfo = (params) => request.get('/friend/getSubTaskInfo', { params })

// 任务详情
export const getTaskInfo = (params) => request.get('/friend/getTaskInfo', { params })
