// API定义合集
import request from '@/utils/http/index'
// 备注数据格式
export const getApiApplyList = (params) => request.get('friend/applyList', { params })
// 方案列表
export const getApiConfigList = (params) => request.get('customer/configList', { params, showLoading: true })
// 模板列表
export const getApitmList = (params) => request.get('customer/templateList', { params })
// 调用模板
export const getApiCopytmList = (params) => request.get('customer/copyTemplate', { params })
// 复制模板
export const getApiCopyCustomer = (params) => request.post('customer/copy', params, { showLoading: true })
// 删除模板
export const getApiDelCustomer = (params) => request.post('customer/delete', params, { showLoading: true })
// 启用模板
export const getApiOnlineCustomer = (params) => request.post('customer/online', params, { showLoading: true })
// 重命名模板
export const getApiRenameCustomer = (params) => request.post('customer/rename', params, { showLoading: true })
// 上传模板库
export const uploadCustomer = (params) => request.post('customer/switchPublic', params, { showLoading: true })

// 方案详情
export const getCustomerInfo = (params) => request.get('/customer/info', { params })

// 新建方案
export const createCustomer = (data) => request.post('/customer/create', data)

// 保存方案（新建/编辑）
export const saveCustomer = (data) => request.post('/customer/save', data, { showLoading: true })

// 删除方案
export const deleteCustomer = (data) => request.post('/customer/delete', data)

// 获取聊天上传的资源
export const getChatUpload = (params, config) => request.get('/msg/getChatUpload', { params, ...config })

// 客户群
export const getApiGroupList = (params) => request.get('group/list', { params })

// 企微成员列表
export const getApiUserList = (params) => request.get('contact/userList', { params })

// 企微成员列表
export const getApiContantList = (params) => request.get('contact/contactList', { params })
