// API定义合集
import request from '@/utils/http/index'
// 获取素材列表
export const getMediaList = (params) => request.get('/comm/media/list', { params, showLoading: true })
// 素材详情
export const getMediaInfo = (params) => request.get('/media/info', { params })
// 创建编辑
export const addMedia = (data) => request.post('/media/save', data)
// 删除素材
export const deleteMedia = (params) => request.post('/media/delete', params)
// 加入到我的素材
export const collectMedia = (params) => request.post('/media/collect', params)
// 移出我的素材
export const moveMedia = (params) => request.post('/media/move', params)
// 复制素材
export const copyMedia = (params) => request.post('/media/copy', { params })
