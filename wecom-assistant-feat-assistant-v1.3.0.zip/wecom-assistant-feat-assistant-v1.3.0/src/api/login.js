// API定义合集
import request from '@/utils/http/index'
// 获取二维码
export const getLoginQRcode = (params) => request.get('/login/code', { params })
// 查询登录状态(轮询) - 扫码登陆后
export const getLoginStatus = (params) => request.get('/login/status', { params, showErr: false })
// 获取登录验证码
export const getApiCaptcha = (params) => request.get('/login/captcha', { params })
// 账号登录
export const getApiLogin = (params) => request.post('/login/login', params, { showLoading: true })
// 获取登录配置
export const getApiLoginConfig = (params) => request.get('/login/getLoginConfig', { params })
// 重置密码 - 获取手机验证码
export const getApiPhoneCode = (params) => request.get('/account/getPhoneCode', { params })
// 重置密码 - 获取手机验证码
export const setApiAccountReset = (params) => request.get('/account/reset', { params })
// 重置密码 - 获取邮箱验证码
export const getApiEmailCode = (params) => request.get('/account/getEmailCode', { params })
// 账号登出
export const apiLoginOut = (params) => request.post('/login/logout', params, { showLoading: true })
// 个人账号信息
export const apiGetUserInfo = (params) => request.get('/user/info', { params, showLoading: true })
// 修改个人信息
export const apiEditUserInfo = (params) => request.post('/user/edit', params, { showLoading: true })
// 账号列表
export const apiAccountList = (params) => request.get('/user/accountList', { params, showLoading: true })
// 切换账号
export const apiAccountSwitch = (params) => request.post('/user/accountSwitch', params, { showLoading: true })
