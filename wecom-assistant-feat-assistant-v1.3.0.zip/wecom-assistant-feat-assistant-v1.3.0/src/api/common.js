import request from '@/utils/http'

// 用户搜索
export const searchUser = (params) => request.get('/comm/data/user', { params })

// 项目列表
export const queryProductList = (params) => request.get('/comm/data/project', { params })

// 课程搜索
export const searchCamp = (params) => request.get('/comm/data/camp', { params })

// 期数搜索
export const searchTerm = (params) => request.get('/comm/data/term', { params })

// 标签搜索
export const searchTag = (params) => request.get('/comm/data/label', { params })

// 下拉数据字典
export const queryDict = (params) => request.get('/comm/data/dict', { params })

// 群搜索
export const searchGroup = (params) => request.get('/group/list', { params })

// 上传图片
export const uploadImage = (data) => request.uploadFile({ url: '/upload/image' }, data)

// 上传视频
export const uploadVideo = (data) => request.uploadFile({ url: '/upload/video' }, data)

// 上传文件文档
export const uploadFile = (data) => request.uploadFile({ url: '/upload/file' }, data)

// 获取版本号
export const getApiversion = (params) => request.get('/version', { params })

// 新建群发
export const addMsgSend = (params) => request.post('/msg/addMsgSend', params, { showLoading: true })

// 部门列表-树结构
export const getDeptTreeApi = (params) => request.get('/comm/dept/tree', { params })

// 员工列表
export const getStaffListApi = (params) => request.get('/comm/staff/list', { params })

// 顾问默认信息
export const getDefaultCamp = (params) => request.get('/comm/data/getDefaultCamp', { params })
