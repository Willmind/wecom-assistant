<template>
  <div id="main">
    <a-config-provider :locale="zhCN">
      <!-- 一级路由 -->
      <router-view />
    </a-config-provider>
  </div>
</template>
<script setup>
import zhCN from 'ant-design-vue/es/locale/zh_CN'
import dayjs from 'dayjs'
import 'dayjs/locale/zh-cn'
import { getApiLoginConfig } from 'api/login'
import { onMounted } from 'vue'
dayjs.locale('zh-cn')
onMounted(async () => {
  let { data, code } = await getApiLoginConfig()
  if (code === 1000) {
    window.$JZPA = data.pk
  }
})
</script>
<style lang="less" scoped>
#main {
  width: 100%;
  height: 100%;
  background-color: #f5f5f5;
}
</style>
