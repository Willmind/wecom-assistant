<template>
  <BasicDrawer
    :register="registerDrawer"
    :showFooter="false"
    :loading="state.loading"
    @visible-change="handelVisibleChange"
    width="600px"
  >
    <template #title>
      <div class="head jz-flex jz-flex-cc">
        <span class="tit">任务列表</span>
      </div>
    </template>
    <div class="content jz-flex jz-flex-col">
      <div class="nav jz-flex">
        <ul class="jz-flex">
          <li
            @click="changeNav(index)"
            class="jz-pointer"
            :class="state.navIndex === index && 'current'"
            v-for="(item, index) in state.navs"
            :key="index"
          >
            {{ item }}
          </li>
        </ul>
        <i></i>
      </div>
      <div v-if="state.navIndex === 0" class="auto-message-list jz-flex-1">
        <div class="auto-message-item jz-flex jz-flex-cc" v-for="(msgItem, index) in []">
          <div class="box-serial">{{ +index + 1 < 10 ? `0${index + 1}` : index + 1 }}</div>
          <div class="jz-flex-1 text-type" v-if="msgItem.msg_type === 2">
            {{ msgItem.msg.text }}
          </div>
          <!--图片类型-->
          <div class="jz-flex-1 img-type" v-if="+msgItem.msg_type === 14">
            <img :src="msgItem.msg.url" alt="" />
          </div>
          <!--视频类型-->
          <div class="jz-flex-1 video-type" v-if="+msgItem.msg_type === 23">
            <video :src="msgItem.msg.url"></video>
            <svg-icon icon-name="ic_msg_video" />
          </div>
          <!--文件类型-->
          <div class="jz-flex-1 file-type jz-flex jz-flex-cc" v-if="+msgItem.msg_type === 15">
            <svg-icon icon-name="ic_msg_pdf" />
            <span class="lineClamp1">{{ msgItem.msg.name }}</span>
          </div>
          <!--链接类型-->
          <div class="jz-flex-1" v-if="+msgItem.msg_type === 13">
            <div class="link-type jz-flex jz-flex-cc jz-flex-col">
              <div class="link-tit">{{ msgItem.msg.title }}</div>
              <div class="desc jz-flex jz-flex-1">
                <div class="desc-text jz-flex-1">{{ msgItem.msg.des }}</div>
                <img :src="msgItem.msg.thumb_url" alt="" />
              </div>
            </div>
          </div>
          <!--小程序类型-->
          <div class="jz-flex-1" v-if="+msgItem.msg_type === 78">
            <div class="wx-type jz-flex jz-flex-cc jz-flex-col" v-if="+msgItem.msg_type === 78">
              <div class="logo-box jz-flex jz-flex-cc">
                <img :src="msgItem.msg.headimg" alt="" />
                <span>{{ msgItem.msg.title }}</span>
              </div>
              <div class="wx-bg jz-flex-1 jz-flex jz-flex-center">
                <img :src="msgItem.msg.icon_url" alt="" />
              </div>
              <span class="wx-name">小程序</span>
            </div>
          </div>

          <!--语音类型-->
          <div class="jz-flex-1" v-if="+msgItem.msg_type === 16">
            <div class="audio-type jz-flex jz-flex-cc">
              <svg-icon icon-name="ic_msg_audio" />
            </div>
          </div>

          <!--视频号类型-->
          <div class="jz-flex-1" v-if="+msgItem.msg_type === 141">
            <div class="wx-video-type jz-flex jz-flex-cc jz-flex-col">
              <div class="jz-flex-1 head">
                <img :src="msgItem.msg.head_img_url" alt="" />
                <svg-icon icon-name="ic_msg_video" />
              </div>
              <div class="wx-tit jz-flex jz-flex-cc"><img src="@/assets/imgs/sph.png" alt="" /> 简知科技</div>
            </div>
          </div>

          <!--群邀请-->
          <div class="jz-flex-1" v-if="+msgItem.msg_type === 50002">
            <div class="jz-flex jz-flex-rc jz-flex-cc group-invite-box">群邀请</div>
            <div class="group-invite-text" v-for="(invite, index) in msgItem.msg?.data" :key="index">
              {{ invite.text }}
            </div>
          </div>
          <!--群公告-->
          <div class="jz-flex-1" v-if="+msgItem.msg_type === 50001">
            <div class="jz-flex jz-flex-rc jz-flex-cc group-notice-box">群公告</div>
            <div>
              <template v-for="(acement, index) in msgItem.msg?.data" :key="index">
                <a-tag class="ant-tag-plain ang-tag-big" v-if="acement.type === 2">
                  {{ acement.text }}
                </a-tag>
                <span v-else>&nbsp;{{ acement.desc }}</span>
              </template>
            </div>
          </div>

          <div class="jz-flex jz-flex-center auto-message-item-time">
            <svg-icon v-if="msgItem.status === 1" icon-name="sop_finish" />
            <svg-icon v-if="msgItem.status === 2" icon-name="sop_fail" />
            <svg-icon v-if="msgItem.status === 3" icon-name="sop_wait" />
            <div>停留 {{ msgItem.wait }} {{ timeOptions[msgItem.time_type] }}后发送</div>
          </div>
        </div>
      </div>
      <div
        v-if="state.navIndex === 1"
        class="jz-flex jz-flex-col jz-flex-1"
        style="height: calc(100% - 48px); overflow: auto"
      >
        <div class="jz-flex-1 avatar-list">
          <div class="avatar jz-flex jz-flex-cc" v-for="i in 20">
            <div class="jz-flex jz-flex-cc jz-flex-1">
              <a-avatar :size="40" src="" shape="square" />
              <div class="customer-info">
                <div class="customer-name">123</div>
                <div class="customer-num">群成员: 12</div>
              </div>
            </div>
            <div class="customer-num">你是群主</div>
          </div>
        </div>
        <div class="pagination-wrap jz-flex jz-flex-cc">
          <basic-pagination @change="pageChange" :params="state.paginationParams">
            <template #extra>
              <span class="page-total">共 {{ state.paginationParams.total }} 群聊</span>
            </template>
          </basic-pagination>
        </div>
      </div>
    </div>
  </BasicDrawer>
</template>
<script setup>
import { useDrawerInner, useDrawer } from '@/components/basic/drawer'
import { reactive, ref, unref } from 'vue'
const state = reactive({
  loading: false,
  navs: ['欢迎语内容', '生效群'],
  navIndex: 0,
  paginationParams: {
    total: 0,
    current: 1,
    showSizeChanger: false
  }
})
const props = defineProps({
  register: Function
})
// 抽屉参数
const [registerDrawer, { closeDrawer }] = useDrawerInner()
/**
 * @desc 切换
 * @param index 索引
 */
const changeNav = (index) => {
  state.navIndex = index
}

/**
 * @desc 切换分页
 * @param current 当前页码
 */
const pageChange = ({ current }) => {
  state.paginationParams.current = current
}
// 抽屉展示关闭
const handelVisibleChange = (val) => {}

// 返回
const closeTagDrawer = () => {
  closeDrawer()
}
// 消息=========================end
</script>

<style lang="less" scoped>
.head {
  position: relative;
  display: flex;
  padding: 16px 0;

  .tit {
    font-size: 20px;
    font-weight: bold;
  }

  .back-btn {
    margin-right: 8px;
    border-radius: 4px;
    padding-left: 0px;
    position: relative;
    width: 32px;
    height: 32px;
    .svg-icon {
      position: absolute;
      left: 8px;
    }
  }

  .line {
    width: 100%;
    height: 1px;
    background-color: #eee;
    transform: scaleY(0.6);
    position: absolute;
    left: 0;
    bottom: 0;
    right: 0;
  }
}
.content {
  height: 100%;
  padding: 0 32px;
  .nav {
    height: 48px;
    position: relative;
    width: 100%;
    margin-bottom: 8px;
    &:after {
      position: absolute;
      left: 0;
      bottom: 0;
      right: 0;
      width: 100%;
      height: 1px;
      content: '';
      background-color: #eee;
      transform: scaleY(0.6);
    }
    ul {
      height: 100%;
      li {
        color: @font-minor-color;
        padding: 0 24px;
        position: relative;
        height: 48px;
        line-height: 48px;
        &.current {
          color: #3165f5;
        }
        &.current::after {
          content: '';
          width: 100%;
          height: 1px;
          display: block;
          margin: 0 auto;
          border-bottom: 2px solid #3165f5;
        }
        &:first-child {
          padding-left: 0px;
        }
      }
    }
  }
  .auto-message-list {
    overflow: auto;
    // 修改滚动条
    &:hover {
      &::-webkit-scrollbar-thumb {
        visibility: visible;
      }
      .page-side-fold.is-expand {
        opacity: 1;
      }
    }
    &::-webkit-scrollbar {
      width: 2px;
    }
    &::-webkit-scrollbar-thumb {
      visibility: hidden;
      transition: all 0.28s;
    }
    .auto-message-item {
      padding: 12px;
      background: #f5f5f5;
      border-radius: 6px 6px 6px 6px;
      margin-bottom: 12px;
      &:last-child {
        margin-bottom: 0px;
      }
      .box-serial {
        font-size: 12px;
        font-weight: 400;
        color: #999999;
        line-height: 14px;
        background: #eeeeee;
        width: 24px;
        height: 24px;
        display: flex;
        justify-content: center;
        align-items: center;
        border-radius: 50%;
        margin-right: 16px;
      }

      .text-type {
        color: #000;
        font-size: 14px;
      }

      .img-type {
        img {
          width: 120px;
          height: 120px;
          border-radius: 4px;
        }
      }

      .video-type {
        position: relative;

        > video {
          width: 120px;
          height: 120px;
          object-fit: cover;
          border-radius: 4px;
        }

        .svg-icon {
          position: absolute;
          left: 15px;
          top: 10px;
          color: #fff;
          width: 16px !important;
          height: 16px !important;
        }
      }

      .file-type {
        .svg-icon {
          width: 20px !important;
          height: 20px !important;
          min-width: 20px;
          min-height: 20px;
          margin-right: 4px;
        }
      }

      .link-type {
        width: 90px;
        height: 42px;
        background: #eee;
        position: relative;
        padding: 5px;
        border-radius: 4px;

        &::before {
          content: '';
          width: 0;
          height: 0;
          left: -7px;
          top: 10px;
          position: absolute;
          border-right: 5px solid transparent;
          border-left: 5px solid transparent;
          border-bottom: 5px solid #eee;
          transform: rotate(-90deg);
        }

        .link-tit {
          font-size: 6px;
          color: #000;
          display: -webkit-box;
          -webkit-box-orient: vertical;
          -webkit-line-clamp: 2;
          overflow: hidden;
          line-height: 7px;
          text-align: left;
          width: 100%;
        }

        .desc {
          width: 100%;

          &-text {
            font-size: 5px;
            color: @font-minor-color;
            overflow: hidden;
          }

          img {
            width: 18px;
            height: 18px;
          }
        }
      }

      .wx-type {
        width: 90px;
        height: 100px;
        background: #eee;
        position: relative;
        padding: 5px;
        border-radius: 4px;

        &::before {
          content: '';
          width: 0;
          height: 0;
          left: -7px;
          top: 10px;
          position: absolute;
          border-right: 5px solid transparent;
          border-left: 5px solid transparent;
          border-bottom: 5px solid #eee;
          transform: rotate(-90deg);
        }

        .logo-box {
          width: 100%;
          font-size: 8px;
          color: @font-minor-color;
          margin-bottom: 2px;

          img {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            margin-right: 5px;
          }
        }

        .wx-bg {
          width: 100%;
          height: 100%;

          img {
            width: 100%;
            height: 100%;
          }
        }

        .wx-name {
          font-size: 6px;
          margin-top: 3px;
          display: block;
          width: 100%;
          display: flex;
        }
      }

      .audio-type {
        .svg-icon {
          width: 58px !important;
          height: 24px !important;
        }
      }

      .voice-type {
        width: 58px;
        height: 24px;
        background: #eeeeee;
        border-radius: 4px;
      }

      .wx-video-type {
        width: 83px;
        height: 110px;
        position: relative;
        border-radius: 4px;
        background: #eeeeee linear-gradient(360deg, rgba(0, 0, 0, 0.5) 0%, rgba(0, 0, 0, 0) 100%);

        .head {
          width: 100%;
          height: 100%;
          position: relative;

          .svg-icon {
            width: 16px !important;
            height: 16px !important;
            left: 50%;
            top: 50%;
            position: absolute;
            color: #fff;
            margin-left: -8px;
          }

          img {
            width: 100%;
            height: 100%;
            border-radius: 4px;
          }
        }

        .wx-tit {
          font-size: 6px;
          color: #fff;
          position: absolute;
          left: 0;
          bottom: 0px;
          right: 0;
          padding-left: 4px;

          img {
            width: 10px;
            height: 10px;
            margin-right: 3px;
          }
        }
      }

      .group-invite-box {
        background: #fdeee4;
        color: #ed7b2f;
        width: 52px;
        height: 22px;
        border-radius: 4px 4px 4px 4px;
        font-size: 12px;
      }
      .group-notice-box {
        background: #fff6e5;
        color: #ffa800;
        width: 52px;
        height: 22px;
        border-radius: 4px 4px 4px 4px;
        font-size: 12px;
        margin-bottom: 6px;
      }
      .group-invite-text {
        margin-top: 6px;
        color: #ed7b2f;
      }
      .auto-message-item-time {
        > div {
          color: #999999;
          margin-left: 12px;
        }
        > svg {
          color: white;
        }
        margin-left: 16px;
      }
    }
  }
  .avatar-list {
    overflow: auto;
    // 修改滚动条
    &::-webkit-scrollbar {
      width: 0px;
    }
    .avatar {
      height: 78px;
      width: 100%;
      position: relative;
      border-bottom: 1px solid rgba(238,238,238,0.6);
      img {
        width: 40px;
        height: 40px;
        border-radius: 8px;
      }
      .customer-info {
        margin-left: 16px;
        .customer-name {
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
          width: 86px;
        }
      }
      .customer-num {
        color: #999999;
        font-size: 12px;
      }
    }
  }

  .pagination-wrap {
    height: 64px;
    .page-total {
      color: #999;
    }
  }
}
</style>
