<template>
  <BasicDrawer
    v-bind="$attrs"
    showFooter
    innerPage
    showForehead
    :register="registerDrawer"
    :showCancelBtn="false"
    okText="保存"
    :mask="false"
    :showClose="false"
    :loading="state.loading"
    :confirmLoading="state.isSubmiting"
    classes="editor-drawer"
    @ok="handleConfirm"
    @close="onClose"
    @visible-change="handleVisivleChange"
  >
    <template #title>
      <div class="head jz-flex jz-flex-cc">
        <a-tooltip placement="top">
          <template #title>
            <span>返回</span>
          </template>
          <span class="back-btn jz-flex jz-flex-center jz-pointer" @click="closeDrawer">
            <svg-icon icon-name="login_back" style="width: 32px; height: 32px" />
          </span>
        </a-tooltip>

        <span class="tit">{{ getTitle }}</span>
      </div>
    </template>

    <div class="wrapper jz-flex jz-flex-col">
      <a-form class="editor-form" :colon="false" v-bind="formLayout">
        <a-form-item label="任务标题" v-bind="validateInfos.is_auto_remark">
          <a-input
            v-model:value="state.form.title"
            :maxlength="15"
            placeholder="请输入标题"
            style="width: 226px; margin-right: 8px"
          />
          <span style="color: #999">{{ state.form.title.length }}/15</span>
        </a-form-item>

        <a-form-item label="生效群">
          <div class="customer-group jz-flex jz-flex-cc">
            <a-tag
              class="ant-tag-plain ant-tag-huge"
              v-for="(group, index) in modelRef.auto_group_config.group_data"
              :key="group.id"
              closable
              @close="() => modelRef.auto_group_config.group_data.splice(index, 1)"
            >
              <img :src="group.avatar" />
              <span class="lineClamp1">{{ group.name }}</span>
            </a-tag>
            <CustomerGroupPopover
              :disabled="isUpperLimitWithType('group_data')"
              :ids="getSelectedGroupIds()"
              @success="handleSelectedCustomerGroup"
            >
              <a-button
                class="add-btn"
                type="info"
                size="large"
                :disabled="isUpperLimitWithType('group_data')"
              >
                <template #icon>
                  <SvgIcon
                    :icon-name="isEmptyDataWithType('group_data') ? 'ic_add_btn' : 'ic_aas'"
                    :iconSize="28"
                  />
                </template>
                {{ isEmptyDataWithType('group_data') ? '添加' : '修改' }}客户群
                {{ modelRef?.auto_group_config?.group_data?.length || 0 }}/100</a-button
              >
            </CustomerGroupPopover>
          </div>
        </a-form-item>
        <a-form-item label="添加客户账号">
          <div class="add-customer-account">
            <div>
              <a-checkbox v-model:checked="state.allCheck" />
              <span>进群</span>
              <a-input-number style="width: 56px" id="inputNumber" v-model:value="value" />
              <span>秒后发送欢迎语</span>
            </div>
            <div>
              <a-checkbox v-model:checked="state.allCheck" />
              <span>进群</span>
              <a-input-number style="width: 56px" id="inputNumber" v-model:value="value" />
              <span>秒后发送欢迎语</span>
            </div>
            <span class="tips">进群时间和进群人数同时设置时，将触发先满足条件的设置项。</span>
          </div>
        </a-form-item>
        <a-divider />
        <h3 style="font-size: 20px; margin-bottom: 32px"><strong>入群欢迎语</strong></h3>

        <a-form-item label="发送设置">
          <div class="jz-flex-1 jz-input jz-flex jz-flex-rl">
            <a-radio-group v-model:value="state.form.type">
              <a-radio :value="1">按顺序发送全部</a-radio>
              <a-radio :value="2">随机发送 1 条</a-radio>
            </a-radio-group>
          </div>
        </a-form-item>

        <a-form-item label="欢迎语内容">
          <div class="card-list jz-flex jz-flex-col">
            <draggable
              handle=".menu-handle"
              itemKey="uid"
              :component-data="{
                tag: 'div',
                type: 'transition-group',
                name: !state.isDrag ? 'flip-list' : null
              }"
              v-model="modelRef.auto_message_config"
              v-bind="dragOptions"
              @start="state.isDrag = true"
              @end="state.isDrag = false"
            >
              <template #item="{ element: item, index }">
                <div class="card-item-wrap jz-flex jz-flex-cc" :key="index">
                  <a-dropdown :trigger="['click']">
                    <a-tooltip title="长按拖拽 点击打开菜单">
                      <menu-outlined class="menu-handle" />
                    </a-tooltip>
                    <template #overlay>
                      <a-menu class="menu-list">
                        <a-menu-item
                          v-for="option in state.operateOptions"
                          :disabled="getDisableOperate(option, index)"
                          :key="option.icon"
                          @click="handleRemoveOperation(option, index)"
                        >
                          <div class="menu-item jz-flex jz-flex-cc" style="padding: 4px 0">
                            <svg-icon :icon-name="`ic_${option.icon}`" style="margin-right: 8px" />
                            <span>{{ option.label }}</span>
                          </div>
                        </a-menu-item>
                      </a-menu>
                    </template>
                  </a-dropdown>
                  <div class="card-item jz-flex">
                    <div class="card-num jz-flex jz-flex-center">{{ getMsgNumber(index) }}</div>
                    <div class="card-content">
                      <MessageCardWithType :item="item" :msgType="item.msg_type" />
                    </div>
                    <div class="card-extra jz-flex">
                      <div class="operate-btns jz-flex jz-flex-cc">
                        <UploadFile
                          :data="item"
                          v-if="isResMsg(item)"
                          class="jz-flex jz-flex-cc"
                          @change="(file) => handleSelectedFile({ file, item }, index, 'update')"
                        >
                          <a-tooltip title="编辑">
                            <svg-icon icon-name="ic_edit" />
                          </a-tooltip>
                        </UploadFile>
                        <a-tooltip title="编辑" v-else>
                          <SvgIcon icon-name="ic_edit" @click="handleCurdOperate('edit', item, index)" />
                        </a-tooltip>
                        <MessageTypeDropdown
                          :disabled="isUpperLimitWithType('addContent')"
                          @select="(item) => handleSelectMenu(item, index, 'insert')"
                          @select-file="(res) => handleSelectedFile(res, index, 'insert')"
                        >
                          <template #insert-item>
                            <p style="color: rgba(0, 0, 0, 0.4); padding: 8px 0 8px 8px">下方新增一条</p>
                          </template>
                          <template #adduction>
                            <SvgIcon icon-name="ic_add" />
                          </template>
                        </MessageTypeDropdown>
                        <a-tooltip title="删除">
                          <SvgIcon icon-name="ic_delete" @click="handleCurdOperate('delete', item, index)" />
                        </a-tooltip>
                      </div>
                      <div class="time-bar jz-flex jz-flex-cc">
                        <span>停留时间</span>
                        <a-input-number v-model:value="item.wait" :min="0" class="time-input">
                          <template #addonAfter>
                            <api-select
                              v-model:value="item.time_type"
                              :options="state.timeOptions"
                              style="width: 60px"
                            />
                          </template>
                        </a-input-number>
                      </div>
                    </div>
                  </div>
                </div>
              </template>
            </draggable>
          </div>
          <div class="add-content jz-flex jz-flex-cc">
            <MessageTypeDropdown
              :disabled="isUpperLimitWithType('addContent')"
              @select="handleSelectMenu"
              @select-file="handleSelectedFile"
            >
              <template #adduction>
                <div class="jz-flex jz-flex-cc">
                  <plus-circle-filled class="add-icon" />
                  <a-button type="link">添加内容</a-button>
                </div>
              </template>
            </MessageTypeDropdown>
            <span class="desc">{{ modelRef.auto_message_config?.length || 0 }}/20</span>
          </div>
        </a-form-item>
      </a-form>
      <EditorTextModal ref="textRef" @success="handleMsgMoadlCallback" />
      <EditorLinkModal ref="linkRef" @success="handleMsgMoadlCallback" />
      <EditorResourceModal ref="resRef" @success="handleMsgMoadlCallback" />
      <EditorMediaModal
        :media_length="modelRef.auto_message_config?.length || 0"
        ref="mediaRef"
        @success="handleMediaMoadCallback"
      />
    </div>
  </BasicDrawer>
</template>
<script setup>
import { Form } from 'ant-design-vue'
import { cloneDeep, extend } from 'lodash-es'
import draggable from 'vuedraggable'
import useMessage from '@/composables/web/useMessage'
import { computed, reactive, ref, toRef, unref } from 'vue'
import { useDrawerInner } from '@/components/basic/drawer'
import { MessageTypeEnum } from '@/enums/MessageTypeEnum'
import { getCustomerInfo, saveCustomer } from '@/api/customerOperationManager'
import SvgIcon from '@/components/SvgIcon/index.vue'
import { uploadFile, uploadImage, uploadVideo } from '@/api/common'
import { isWechatMsg, isResMsg } from '../../customerOperationManager/copms/popover/utils'
import { getTranformJSONContentToText, getTranformRemarkToJSONContent } from '@/utils/customer'

defineProps({
  register: Function
})

const state = reactive({
  isSubmiting: false,
  isUpdate: false,
  form: {
    title: '',

    name: '方案1',
    id: undefined,
    is_auto_remark: 0,
    remarkJSON: null,
    auto_remark_config: {
      remark: [],
      data: []
    },
    auto_label_config: {
      label: []
    },
    is_auto_group: 0,
    auto_group_config: {
      is_auto_create: 0,
      max_member: 500,
      group_ids: [],
      group_data: [],
      create_group: {
        group_name: '',
        group_number: undefined,
        user: [],
        customer: []
      }
    },
    auto_message_config: []
  },
  rulesRef: {
    name: [{ required: true }]
  },
  selectedTagList: [],
  timeOptions: [
    { label: '秒', value: 1 },
    { label: '分', value: 2 },
    { label: '时', value: 3 }
  ],
  operateOptions: [
    { label: '置顶', icon: 'top', key: 1 },
    { label: '上移一条', icon: 'up', key: 2 },
    { label: '下移一条', icon: 'down', key: 3 },
    { label: '置底', icon: 'bottom', key: 4 }
  ],
  remarkOptions: ['微信昵称', '性别', '添加日期'],
  isDrag: false,
  loading: false
})
const textRef = ref()
const linkRef = ref()
const resRef = ref()
const richRef = ref()
const mediaRef = ref()

const modelRef = toRef(state, 'form')

const emit = defineEmits(['success'])

const formLayout = {
  labelCol: { span: 4 },
  wrapperCol: { span: 20 }
}

const { createMessage } = useMessage()
const { validate, resetFields, validateInfos } = Form.useForm(modelRef, state.rulesRef)

const getTitle = computed(() => (state.isUpdate ? '任务编辑' : '创建任务'))

const [registerDrawer, { closeDrawer }] = useDrawerInner((res) => {
  state.isUpdate = res.isUpdate
  state.form.id = res?.data?.id
})

const queryInfo = async () => {
  try {
    state.loading = true
    const { data } = await getCustomerInfo({ id: unref(modelRef).id })
    if (!data.auto_group_config || !data.auto_group_config?.create_group) {
      data.auto_group_config = {}
      data.auto_group_config.max_member = data.auto_group_config?.max_member || 500
      data.auto_group_config.is_auto_create = data.auto_group_config?.is_auto_create ?? 0
      data.auto_group_config.create_group = extend(
        {},
        {
          group_name: '',
          group_number: undefined,
          user: [],
          customer: []
        },
        data.auto_group_config || {}
      )
    }

    if (!data.auto_label_config) {
      data.auto_label_config = {
        label: []
      }
    }
    if (!data.auto_remark_config) {
      data.auto_remark_config = {}
      data.auto_remark_config.remark = []
      data.auto_remark_config.data = []
    }
    if (!data.auto_message_config) {
      data.auto_message_config = []
    }
    state.form = Object.assign({}, state.form, data || {})
    state.form.remarkJSON = getTranformRemarkToJSONContent(state.form.auto_remark_config?.data)
    state.form.auto_remark_config.remark = getTranformJSONContentToText(state.form.remarkJSON)
    // state.form.auto_remark_config.data = remarkLabels.filter((row) => +row.type === 2)
    // state.form.auto_remark_config.remark =
    //   remarkLabels
    //     ?.filter((row) => +row.type === 1)
    //     ?.map((d) => d.text)
    //     ?.join('') ?? ''
  } finally {
    state.loading = false
  }
}

const handleRemarkContentChange = ({ json }) => {
  unref(modelRef).auto_remark_config.remark = getTranformJSONContentToText(json)
}

// 选择备注标签
const handleSelectedTag = (tag) => {
  unref(richRef).editorRef.chain().focus().setTag(tag).run()
  // if (!unref(modelRef).auto_remark_config?.data?.length) {
  //   unref(modelRef).auto_remark_config.data = []
  // }
  // unref(modelRef).auto_remark_config.data.push({ text: tag, type: 2 })
}

// 选择自动打标签
const handleSelectedLabel = (res) => {
  unref(modelRef).auto_label_config.label = res?.tags || []
}

// 上限判断
const isUpperLimitWithType = (type) => {
  if (type === 'addContent') {
    return unref(modelRef).auto_message_config?.length >= 20
  } else if (type === 'group_data') {
    return unref(modelRef).auto_group_config?.group_data?.length >= 100
  } else if (type === 'customer' || type === 'user') {
    let { customer, user } = unref(modelRef).auto_group_config.create_group
    return customer?.length + user?.length >= 10
  }
}

//素材库信息
const handleMediaMoadCallback = (data) => {
  for (let item of data) {
    unref(modelRef).auto_message_config.push(item)
  }

  createMessage.success('导入成功')
}

const isEmptyDataWithType = (type) => {
  if (type === 'group_data') {
    return unref(modelRef).auto_group_config?.group_data?.length === 0
  } else if (type === 'customer' || type === 'user') {
    return unref(modelRef).auto_group_config?.create_group[type]?.length === 0
  }
}

// 展示侧边栏
const handleVisivleChange = (visivle) => {
  if (visivle) {
    unref(modelRef).id && queryInfo()
    return
  }
  resetFields()
}

// --------选择客户/群-------
const getUserCount = () => modelRef.value.auto_group_config?.create_group?.user?.length || 0
const getCustomerCount = () => modelRef.value.auto_group_config?.create_group?.customer?.length || 0

const getSelectedIdsWithProp = (prop) => {
  const ids = unref(modelRef).auto_group_config?.create_group?.[prop]?.map(
    (item) => item.contact_id || item.id
  )
  return ids.length ? ids.join(',') : ''
}

// --------选择已添加客户/群-------
const getSelectedGroupIds = () => {
  const ids = unref(modelRef).auto_group_config.group_ids
  return ids.length ? ids.join(',') : ''
}

const handleSelectedCustomer = (items = []) => {
  unref(modelRef).auto_group_config.create_group.customer = [...items]
}

const handleSelectedUser = (items = []) => {
  unref(modelRef).auto_group_config.create_group.user = [...items]
}

const handleSelectedCustomerGroup = (items = []) => {
  unref(modelRef).auto_group_config.group_data = [...items]
  unref(modelRef).auto_group_config.group_ids = items.map((row) => row.id)
}

// ------------------------自动发消息----------------
// 拖动动效
const dragOptions = ref({
  animation: 200,
  disabled: false,
  ghostClass: 'ghost'
})

const currMessageItemIndex = ref(-1)
// 删除/修改操作
const handleCurdOperate = (operType, item, index) => {
  let { msg_type } = item
  currMessageItemIndex.value = index
  switch (operType) {
    case 'edit':
      item.is_section = false
      handleOpenMsgModal(MessageTypeEnum[msg_type], item, true, 'insert')
      break
    case 'delete':
      unref(modelRef).auto_message_config.splice(index, 1)
      break
  }
}

// 添加消息内容
const handleSelectMenu = (item, index, operType) => {
  let { icon: type } = item
  currMessageItemIndex.value = index
  handleOpenMsgModal(type, item, false, operType)
}

const handleOpenMsgModal = (type, item = {}, isUpdate, operType) => {
  const { key, msg_type } = item
  switch (type) {
    case 'media':
      mediaRef.value.openModal({
        isUpdate,
        operType,
        data: cloneDeep(item),
        media_length: unref(modelRef).auto_message_config.length //传入当前素材长度
      })
      break
    case 'text':
      textRef.value.openModal({
        isUpdate,
        operType,
        data: cloneDeep(item)
      })
      break
    case 'link':
      linkRef.value.openModal({
        isUpdate,
        operType,
        data: cloneDeep(item)
      })
      break
    default:
      if (isWechatMsg(item)) {
        resRef.value.openModal({
          isUpdate,
          operType,
          title: item.label,
          data: {
            ...cloneDeep(item),
            msg_type: key || msg_type
          }
        })
      }
      break
  }
}

// 保存消息成功回调处理
const handleMsgMoadlCallback = (msgType, { isUpdate, data, operType }) => {
  // 存在分段
  if (Array.isArray(data)) {
    let textList = data.map((row) => ({ ...row, wait: row.wait || 10, time_type: row.time_type || 1 }))
    if (operType === 'insert') {
      if (msgType === 'text') {
        const nextIndex = isUpdate ? currMessageItemIndex.value : currMessageItemIndex.value + 1
        unref(modelRef).auto_message_config.splice(nextIndex, isUpdate ? 1 : 0, ...textList)
      }
    } else {
      unref(modelRef).auto_message_config.push(...textList)
    }
    currMessageItemIndex.value = -1
    return
  }
  const params = {
    ...data,
    wait: data.wait || 10,
    time_type: data.time_type || 1
  }
  if (isUpdate && ~currMessageItemIndex.value) {
    unref(modelRef).auto_message_config[unref(currMessageItemIndex)] = params
  } else {
    if (operType === 'insert') {
      unref(modelRef).auto_message_config.splice(currMessageItemIndex.value + 1, 0, params)
    } else {
      unref(modelRef).auto_message_config.push(params)
    }
  }
  currMessageItemIndex.value = -1
}

// 上传图片/文件/文档
const handleSelectedFile = async ({ file, item: { key, msg_type } }, updateIndex, operType) => {
  key = key ?? msg_type
  if (file) {
    let index = -1
    if (updateIndex !== undefined && updateIndex > -1) {
      if (operType !== 'insert') {
        const editItem = unref(modelRef).auto_message_config[updateIndex]
        if (editItem) {
          editItem.msg.url = ''
          editItem.msg.name = file.name
          editItem.uploading = true
        }
      }
      index = operType === 'insert' ? updateIndex + 1 : updateIndex
    } else {
      index = unref(modelRef).auto_message_config.push(addNewMsg()) - 1
    }
    try {
      const uploadRequest =
        key === MessageTypeEnum.image ? uploadImage : key === MessageTypeEnum.video ? uploadVideo : uploadFile
      const { data } = await uploadRequest({ file })
      if (operType === 'insert') {
        unref(modelRef).auto_message_config.splice(index, 0, addNewMsg())
      } else {
        unref(modelRef).auto_message_config[index].msg.url = data.url
      }
      createMessage.success('上传成功')
    } catch (err) {
      unref(modelRef).auto_message_config.splice(index, 1)
    } finally {
      unref(modelRef).auto_message_config[index].uploading = false
    }
  }

  function addNewMsg() {
    return {
      msg_type: key,
      wait: 10,
      time_type: 1,
      msg: {
        name: file.name,
        url: ''
      },
      uploading: true
    }
  }
}

const getDisableOperate = (item, index) => {
  let { icon: key } = item
  let isDisabled = false
  switch (key) {
    case 'top':
    case 'up':
      isDisabled = index === 0
      break
    case 'bottom':
    case 'down':
      isDisabled = index === unref(modelRef).auto_message_config.length - 1
      break
  }
  return isDisabled
}

// 移动操作
const handleRemoveOperation = (item, index) => {
  let isDisabled = getDisableOperate(item, index)
  if (isDisabled) return

  const { icon: key } = item
  const [removeItem] = unref(modelRef).auto_message_config.splice(index, 1)
  switch (key) {
    case 'top':
    case 'bottom':
      unref(modelRef).auto_message_config[key === 'top' ? 'unshift' : 'push'](removeItem)
      break
    case 'up':
    case 'down':
      let idx = key === 'up' ? index - 1 : index + 1
      unref(modelRef).auto_message_config.splice(idx, 0, removeItem)
      break
  }
}

// 确定提交操作
const handleConfirm = () => {
  validate().then(async () => {
    let { form } = state
    if (form.is_auto_remark) {
      if (!form.auto_remark_config?.remark?.length) {
        createMessage.warning('请填写备注')
        return
      }
    }
    if (form.is_auto_group) {
      if (!form.auto_group_config?.group_ids?.length) {
        createMessage.warning('请选择现有客户群')
        return
      }
    }
    if (form.auto_group_config.is_auto_create) {
      const { create_group } = form.auto_group_config
      if (
        !create_group?.group_name ||
        !create_group?.group_number ||
        (!create_group?.customer?.length && !create_group.user?.length)
      ) {
        createMessage.warning('请完善自动建群信息')
        return
      }
    }
    const params = toRaw(getTranformParams(state.form))
    try {
      state.isSubmiting = true
      await saveCustomer({ ...params })
      createMessage.success('保存成功')
      emitSuccess()
    } finally {
      state.isSubmiting = false
    }
  })
}

const getMsgNumber = (index) => {
  return +index + 1 < 10 ? `0${index + 1}` : index + 1
}

// 转换数据
const getTranformParams = (params = {}) => {
  const {
    auto_remark_config: { remark = '' },
    auto_label_config: { label = [] },
    auto_group_config: {
      create_group: { customer = [], user = [] }
    },
    auto_message_config
  } = cloneDeep(params)

  params.auto_message_config = auto_message_config
    ? auto_message_config.map((row) => ({ ...row, uploading: undefined }))
    : []
  params.auto_group_config.create_group.customer = customer?.map((item) => item.contact_id || item.id) ?? []
  params.auto_group_config.create_group.user = user?.map((item) => item.contact_id || item.id) ?? []
  // let rek =
  //   unref(modelRef)
  //     .auto_remark_config.data.map((item) => `{${item?.label || item?.text || item}}`)
  //     .join('') + remark
  return {
    ...params,
    auto_label_config: {
      label: label.map((item) => ({
        id: item.value || item.id,
        name: item.label || item.name,
        type: item.type
      }))
    }
  }
}

const emitSuccess = () => {
  emit('success')
  closeDrawer()
}

const onClose = () => {
  // resetFields()
}
</script>
<style lang="less" scoped>
.head {
  position: relative;
  padding-top: 28px;
  .tit {
    font-size: 20px;
    font-weight: bold;
  }
  .back-btn {
    margin-right: 8px;
    border-radius: 4px;
    padding-left: 0px;
    position: relative;
    width: 32px;
    height: 32px;
    .svg-icon {
      position: absolute;
      left: 8px;
    }
  }
}
.wrapper {
  height: 100%;
  padding: 24px 32px 32px;

  :deep(.add-btn) {
    border-style: dashed;
    height: 48px;
    box-sizing: border-box;
    padding: 0 10px;
    span {
      padding-left: 7px;
      font-size: 14px;
    }
  }

  .editor-form {
    .auto-label {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      padding-top: 8px;
      > p {
        color: rgba(0, 0, 0, 0.4);
        margin-top: 10px;
      }
    }
    .tag-group {
      .label {
        margin-right: 16px;
        font-size: 14px;
        color: #000000;
      }
    }

    .customer-group,
    .group-item,
    .tag-group {
      .ant-tag-plain {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 8px;
        max-width: 145px;
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
        img {
          width: 28px;
          height: 28px;
          border-radius: 6px;
          margin-right: 8px;
        }
      }
    }

    .add-customer-account {
      .tips {
        color: #999999;
      }
      > div {
        margin-bottom: 16px;
        > span {
          margin: 0 8px;
        }
      }
    }
    .card-list {
      width: 100%;
      .card-item-wrap {
        width: 100%;
        &:hover {
          .card-item .card-extra .operate-btns {
            visibility: visible;
            .svg-icon {
              width: 24px !important;
              height: 24px !important;
              padding: 4px;
              &:hover {
                background: rgba(0, 0, 0, 0.04);
                border-radius: 4px;
              }
            }
          }
          :deep(.anticon-menu) {
            visibility: visible;
          }
        }
        :deep(.anticon-menu) {
          margin-right: 12px;
          padding-top: 3px;
          visibility: hidden;
          :hover {
            color: @primary-color;
          }
        }
        .card-item {
          flex: auto;
          min-height: 56px;
          padding: 12px;
          background: rgba(0, 0, 0, 0.04);
          border-radius: 6px;
          box-sizing: border-box;
          .card-num {
            width: 24px;
            height: 24px;
            align-items: center;
            border-radius: 50%;
            background: #eeeeee;
            color: #000000;
            font-size: 12px;
            margin-right: 16px;
          }
          .card-content {
            flex: auto;
          }

          .card-extra {
            flex: none;
            display: flex;
            align-items: flex-start;
            .operate-btns {
              height: 32px;
              visibility: hidden;
              > * {
                margin-right: 16px;
                cursor: pointer;
              }
            }
            .time-bar {
              > span {
                margin-right: 12px;
                color: rgba(0, 0, 0, 0.4);
              }
              .time-input {
                :deep(.ant-input-number-input-wrap) {
                  width: 56px;
                }
              }
            }
          }
        }
        + .card-item-wrap {
          margin-top: 12px;
        }
        + .add-content {
          margin-top: 16px;
        }
      }
    }
    .rich-input {
      margin-top: 16px;
    }
    .add-content {
      .add-icon {
        font-size: 16px;
        color: @primary-color;
      }
      .decs {
        margin-left: 8px;
        color: rgba(0, 0, 0, 0.4);
      }
    }
    .auto-create-box {
      .sub-form-item {
        width: 100%;
        .input-area {
          width: 100%;
          margin-top: 10px;
          .ant-input {
            flex: 0 0 220px;
          }
          > span {
            margin-left: 16px;
          }
          .ant-input-number {
            margin-left: 8px;
          }
        }
      }
    }
    .news-group-box {
      .label {
        margin-bottom: 10px;
      }
      .group-item {
        flex-wrap: wrap;
        + .group-item {
          margin-top: 8px;
        }
      }
    }
    .tip-desc {
      color: rgba(0, 0, 0, 0.4);
      margin-top: 10px;
    }
    .min-tip {
      color: rgba(0, 0, 0, 0.4);
      margin-top: 6px !important;
    }
    :deep(.ant-form-item) {
      // &.form-item-auto-msg {
      //   .ant-form-item-control {
      //     margin-left: -25px;
      //   }
      // }
      .ant-form-item-label {
        flex: 0 0 140px;
        max-width: 140px;
        display: inline-flex;
        > label {
          width: 120px;
          font-weight: 550;
          font-size: 14px;
          color: #000;
          justify-content: flex-end;
        }
      }
    }
  }
  .flip-list-move {
    transition: transform 0.5s;
  }
  .no-move {
    transition: transform 0s;
  }
  .ghost {
    opacity: 0.5;
    background: rgba(0, 0, 0, 0.05);
  }
}
</style>
<style lang="less">
.editor-drawer {
  .ant-drawer-content {
    box-shadow: none;
  }
}
</style>
