<template>
  <BasicDrawer
    :register="registerDrawer"
    showFooter
    width="560px"
    title="发送设置"
    okText="确定"
    :loading="state.loading"
    @visible-change="handelVisibleChange"
  >
    <div class="container">
      <div class="edit-box jz-flex jz-flex-col">
        <div class="info jz-flex-1 jz-flex jz-flex-col">
          <div class="item jz-flex">
            <span class="label" style="font-weight: 600">休眠时间段</span>
            <div class="jz-flex-1 jz-input"><a-switch v-model:checked="form.is_dormancy" /></div>
          </div>
          <div class="item jz-flex jz-flex-cc" v-if="form.is_dormancy" style="margin-top: 16px">
            <span class="label">每日</span>
            <div class="jz-flex-1 jz-input jz-flex jz-flex-rl">
              <div
                ref="picker1"
                class="time-picker jz-flex jz-flex-center"
                @click.stop.prevent="handleShowTime(1)"
                :class="state.timeType === 1 && 'current'"
              >
                <span>{{ form.dormancy_time_start }}</span>
              </div>
              <span class="dot jz-flex jz-flex-center">-</span>
              <div
                ref="picker2"
                class="time-picker jz-flex jz-flex-center"
                @click.stop.prevent="handleShowTime(2)"
                :class="state.timeType === 2 && 'current'"
              >
                <span>{{ form.dormancy_time_end }}</span>
              </div>
            </div>
          </div>
          <div class="item jz-flex">
            <span class="label jz-flex jz-flex-rr jz-flex-cc" style="font-weight: 600">
              消息发送间隔
              <a-tooltip placement="top">
                <template #title>
                  <span
                  >同一个对象的上一条消息发送完毕到下一条消息开始发送的间隔时间。为降低风险，建议最短设置3秒。</span
                  >
                </template>
                <question-circle-outlined class="ask" />
              </a-tooltip>
            </span>
            <div class="jz-flex-1 jz-input jz-flex jz-flex-rl">
              <a-input-number
                v-model:value="form.msg_frequency_start"
                :min="1"
                :max="100"
                :controls="false"
              />
              <span class="dot jz-flex jz-flex-center">-</span>
              <a-input-number v-model:value="form.msg_frequency_end" :min="1" :max="999" :controls="false" />
              <span style="line-height: 32px; margin: 0 32px 0 8px">秒</span>
              <a-button @click="updatefrequency(1)" style="border-color: #eee" :disabled="msgBtnDisabled"
              >恢复推荐值</a-button
              >
            </div>
          </div>
        </div>
        <div
          class="time-box jz-flex jz-flex-col"
          v-if="state.showTime"
          @click.stop.prevent
          v-click-outside="hideOutside"
          :style="computedStyle"
        >
          <div class="jz-flex-1 jz-flex">
            <ul class="time-ul jz-flex-1 jz-flex jz-flex-col">
              <li
                v-for="(item, index) in state.hourArr"
                :key="index"
                :class="item.check && 'current'"
                @click="selectHour(item)"
              >
                {{ item.num }}
              </li>
            </ul>
            <ul class="time-ul jz-flex-1 jz-flex jz-flex-col">
              <li
                v-for="(item, index) in state.minArr"
                :key="index"
                :class="item.check && 'current'"
                @click="selectMin(item)"
              >
                {{ item.num }}
              </li>
            </ul>
          </div>
          <div class="time-btn jz-flex jz-flex-rr jz-flex-cc">
            <a-button type="primary" @click="hideOutside">确定</a-button>
          </div>
        </div>
      </div>
    </div>
    <template #footer>
      <div class="jz-flex jz-flex-rr">
        <a-button style="margin-right: 10px" @click="closeDrawer">取消</a-button>
        <a-button type="primary" @click="onsubmit">保存</a-button>
      </div>
    </template>
  </BasicDrawer>
</template>
<script setup>
import { useDrawerInner } from '@/components/basic/drawer'
import { reactive } from 'vue'
import datajs from 'dayjs'
import useMessage from '@/composables/web/useMessage'
import { setMsgSendConfig, getMsgSendConfig } from '@/api/customerManager'
import { addZero } from '@/assets/js/utils'
const { createMessage } = useMessage()
const emit = defineEmits(['success'])
const isLock = ref(false)
const state = reactive({
  hourArr: [],
  minArr: [],
  showTime: false,
  timeType: 1,
  loading: true
})
const picker1 = ref(null)
const picker2 = ref(null)
const form = reactive({
  is_dormancy: false,
  is_enable: false,
  msg_frequency_start: 3,
  msg_frequency_end: 10,
  contact_frequency_start: 10,
  contact_frequency_end: 60,
  group_frequency_start: 10,
  group_frequency_end: 60,
  dormancy_time_start: '00:00', // 休眠开始时间
  dormancy_time_end: '00:08' // 休眠开始时间
})

defineProps({
  register: Function
})

// ========================methods

const hideOutside = () => {
  state.timeType = -1
  state.showTime = false
}

// 选择时
const selectHour = (item) => {
  if (state.timeType === 1) {
    form.dormancy_time_start = item.num + ':' + form.dormancy_time_start.split(':')[1]
  } else {
    form.dormancy_time_end = item.num + ':' + form.dormancy_time_end.split(':')[1]
  }

  state.hourArr.forEach((i) => (i.check = false))
  item.check = true
}

// 选择秒
const selectMin = (item) => {
  if (state.timeType === 1) {
    form.dormancy_time_start = form.dormancy_time_start.split(':')[0] + ':' + item.num
  } else {
    form.dormancy_time_end = form.dormancy_time_end.split(':')[0] + ':' + item.num
  }
  state.minArr.forEach((i) => (i.check = false))
  item.check = true
}

// 选择时间
const handleShowTime = (type) => {
  state.timeType = type
  state.showTime = true
  if (form.dormancy_time_start) {
    let _tagArr = type === 1 ? form.dormancy_time_start.split(':') : form.dormancy_time_end.split(':')
    state.hourArr.forEach((i) => (i.check = i.num === _tagArr[0]))
    state.minArr.forEach((i) => (i.check = i.num === _tagArr[1]))
  }
  if (form.dormancy_time_end) {
    let _tagArr = type === 1 ? form.dormancy_time_start.split(':') : form.dormancy_time_end.split(':')
    state.hourArr.forEach((i) => (i.check = i.num === _tagArr[0]))
    state.minArr.forEach((i) => (i.check = i.num === _tagArr[1]))
  }
}
// 恢复默认值
const updatefrequency = (type) => {
  switch (type) {
    case 1:
      form.msg_frequency_start = 3
      form.msg_frequency_end = 10
      break
    case 2:
      form.contact_frequency_start = 10
      form.contact_frequency_end = 60
      break
    default:
      form.group_frequency_start = 10
      form.group_frequency_end = 60
      break
  }
}

// 获取任务设置信息
const getSettingInfo = async () => {
  initTime()
  let { code, data } = await getMsgSendConfig()
  state.loading = false
  if (code === 1000) {
    let { is_dormancy: dormancy, is_enable } = data
    form.is_dormancy = dormancy === 1 ? true : false
    form.is_enable = is_enable === 1 ? true : false

    form.dormancy_time_start = data.dormancy_time_start
    form.dormancy_time_end = data.dormancy_time_end

    form.msg_frequency_start = data.msg_frequency_start
    form.msg_frequency_end = data.msg_frequency_end

    form.group_frequency_start = data.group_frequency_start
    form.group_frequency_end = data.group_frequency_end

    form.contact_frequency_start = data.contact_frequency_start
    form.contact_frequency_end = data.contact_frequency_end
  }
}
const initTime = () => {
  state.hourArr = new Array(24).fill(0).map((i, index) => {
    return {
      num: addZero(index),
      check: false
    }
  })
  state.minArr = new Array(60).fill(0).map((i, index) => {
    return {
      num: addZero(index),
      check: false
    }
  })
}
// 提交
const onsubmit = () => {
  if (+form.msg_frequency_start > +form.msg_frequency_end) {
    createMessage.warn('消息发送间隔范围设置有误')
    return
  }
  if (+form.contact_frequency_start > +form.contact_frequency_end) {
    createMessage.warn('对象发送间隔范围设置有误')
    return
  }
  if (+form.group_frequency_start > +form.group_frequency_end) {
    createMessage.warn('客户群发送间隔范围设置有误')
    return
  }
  if (isLock.value) {
    return
  }
  isLock.value = true
  let _startTime = datajs(form.dormancy_time_start, 'HH:mm')
  let _endTime = datajs(form.dormancy_time_end, 'HH:mm')
  let dormancy_time_start = addZero(_startTime.$H) + ':' + addZero(_startTime.$m)
  let dormancy_time_end = addZero(_endTime.$H) + ':' + addZero(_endTime.$m)
  let params = {
    ...form,
    dormancy_time_end,
    dormancy_time_start
  }
  setMsgSendConfig(params)
    .then((res) => {
      if (res.code === 1000) {
        createMessage.success('设置成功')
        closeDrawer()
        emit('success')
      }
    })
    .finally(() => {
      isLock.value = false
    })
}

const computedStyle = computed(() => {
  let leftNum = ''
  if (state.timeType === 1) {
    leftNum = picker1.value.offsetLeft + 'px'
  } else {
    leftNum = picker2.value.offsetLeft + 'px'
  }
  return `left:${leftNum}`
})

const msgBtnDisabled = computed(() => {
  return form.msg_frequency_start === 3 && form.msg_frequency_end === 10
})

const contactbtnDisabled = computed(() => {
  return form.contact_frequency_start === 10 && form.contact_frequency_end === 60
})

const groupbtnDisabled = computed(() => {
  return form.group_frequency_start === 10 && form.group_frequency_end === 60
})

// 抽屉参数
const [registerDrawer, { closeDrawer }] = useDrawerInner()

// 抽屉展示关闭
const handelVisibleChange = (val) => {
  if (val) {
    getSettingInfo()
  }
}
</script>
<style lang="less" scoped>
.edit-box {
  padding: 0px 32px 20px;
  width: 100%;
  height: 100%;
  position: relative;
  font-size: 14px;
  .tip-box {
    color: #ed7b2f;
    > div {
      margin-left: 10px;
      padding-right: 46px;
    }
  }
  .example {
    width: 80px;
    height: 32px;

    border-radius: 6px;
    text-align: center;
    line-height: 32px;
    color: #3165f5;
    margin-left: 12px;
    cursor: pointer;
    &:hover {
      background: #eaf0fe;
    }
  }
  .tip-popover {
    width: 248px;
    height: 412px;
    img {
      width: 100%;
      height: 100%;
    }
  }
  .tit {
    margin-bottom: 8px;
    color: @font-minor-color;
  }
  .dot {
    width: 16px;
    height: 100%;
    color: #999;
  }
  .color-gray {
    color: @font-minor-color;
  }
  .info {
    .item {
      width: 100%;
      margin-top: 32px;
      position: relative;
      .label {
        font-weight: 500;
        margin-right: 32px;
        width: 104px;
        text-align: right;
        position: relative;
        color: @font-body-color;
      }
      .ask {
        position: absolute;
        right: -20px;
        color: #999;
      }
    }
    .line {
      margin: 48px 0;
      width: 100%;
      height: 0.5px;
      background: #eee;
    }
  }
}

.time-picker {
  width: 54px;
  height: 32px;
  font-size: 14px;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  border: 1px solid #eeeeee;
  &.current {
    border: 1px solid #3165f5;
  }
}
.time-box {
  position: absolute;
  width: 168px;
  height: 344px;
  border-radius: 5px;
  left: 130px;
  top: 95px;
  right: 0;
  background: #fff;
  z-index: 100;
  box-shadow: 0px 0px 24px 0px rgba(0, 0, 0, 0.2);
  > div {
    width: 100%;
    height: 100%;
    overflow-y: auto;
  }
  .time-ul {
    width: 100%;
    height: 100%;
    overflow-y: auto;
    padding: 8px 8px 0;
    li {
      width: 100%;
      height: 40px;
      line-height: 40px;
      text-align: center;
      cursor: pointer;
      &:hover {
        background: #f5f5f5;
        border-radius: 4px;
      }
      &.current {
        background: #ebf0fe;
        color: #3165f5;
        border-radius: 4px;
      }
    }
  }
  .time-btn {
    width: 100%;
    height: 56px;
    padding-right: 12px;
  }
}
:deep(.ant-input-number) {
  width: 65px;
  border-radius: 6px;
}
:deep(.ant-input-number-input) {
  border-radius: 6px;
  text-align: center;
}
:deep(.ant-input-number-input:hover) {
  border-radius: 6px;
  border-color: #3165f5;
}
:deep(.ant-radio-inner) {
  border-color: rgba(0, 0, 0, 0.1);
}
:deep(.ant-radio-checked .ant-radio-inner) {
  border-color: #3165f5;
}
:deep(.ant-radio-inner::after) {
  background-color: #3165f5;
}
:deep(.ant-drawer-header) {
  padding: 32px 32px 16px 32px !important;
}
:deep(.ant-popover-arrow) {
  opacity: 0;
}
</style>
