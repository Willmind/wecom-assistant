<template>
  <div class="group-welcome-wrapper jz-flex jz-flex-col jz-flex-1">
    <div class="head jz-flex jz-flex-cc">
      <strong>入群欢迎语</strong>
      <div class="jz-flex jz-flex-1 jz-flex-rr jz-flex-cc">
        <span style="margin-right: 24px">消息发送间隔：0-5 秒</span>
        <a-button @click="openGroupWelcomeSettingDrawer">发送设置</a-button>
        <a-button @click="handleOpenGroupWelcomeCreateDrawer" type="primary">创建任务</a-button>
      </div>
    </div>
    <div class="form">
      <a-form class="jz-flex">
        <a-form-item>
          <a-input v-model:value="form.name" allowClear placeholder="请输入任务标题">
            <template #suffix v-if="!form.name">
              <svg-icon icon-name="ic_search" />
            </template>
          </a-input>
        </a-form-item>
        <a-form-item>
          <a-form-item>
            <a-select v-model:value="form.type" :options="state.typeList" placeholder="请选择状态" />
          </a-form-item>
        </a-form-item>
      </a-form>
    </div>
    <div class="jz-flex jz-flex-1 table-wrap" ref="tabBox">
      <a-table
        row-key="id"
        class="sop-table"
        :class="!state.list.length && 'not-table'"
        :columns="state.columns"
        :data-source="state.list"
        :bordered="false"
        :pagination="false"
        :loading="loading"
        :scroll="{ y: state.scrollY }"
      >
        <template #bodyCell="{ column, record }">
          <template v-if="column.key === 'name'">
            <div class="jz-flex jz-flex-col name-text">
              <span>{{ record.name }}</span>
            </div>
          </template>
          <template v-if="column.key === 'type'">
            <div class="jz-flex jz-flex-cc">
              <div class="type-dot" style="background-color: #999999"></div>
              <!--              <div class="type-dot" style="background-color: #06D1D1;"></div>-->
              <span style="color: #999999">{{ record.type }}</span>
            </div>
          </template>
          <template v-if="column.key === 'create_time'">
            <div class="jz-flex jz-flex-col">
              <span>{{ record.create_time }}</span>
            </div>
          </template>
          <template v-if="column.key === 'effective_group'">
            <div class="jz-flex group-list">
              <a-avatar-group :max-count="8">
                <a-avatar :src="record.avatar" shape="square" />
                <a-avatar :src="record.avatar" shape="square" />
                <a-avatar :src="record.avatar" shape="square" />
              </a-avatar-group>
            </div>
          </template>
          <template v-if="column.key === 'action'">
            <div class="jz-flex jz-flex-cc task-btn">
              <svg-icon icon-name="task_start" class="jz-pointer" />
              <!--              <svg-icon icon-name="task_stop" class="jz-pointer" />-->
              <a-popover
                placement="bottomLeft"
                v-model:visible="record.visible"
                class="popover-wraper"
                :getPopupContainer="
                  (triggerNode) => {
                    return triggerNode.parentNode || document.body
                  }
                "
              >
                <template #content>
                  <p class="jz-pointer popover-p" @click="openGroupWelcomeTaskDetailDrawer">查看</p>
                  <p class="jz-pointer popover-p">编辑</p>
                  <p class="jz-pointer popover-p">删除</p>
                </template>
                <svg-icon icon-name="task_pr" class="jz-pointer" />
              </a-popover>
            </div>
          </template>
        </template>
        <template #emptyText>
          <div class="not-more jz-flex jz-flex-center jz-flex-col">
            <img src="@/assets/imgs/not_more.png" alt="" />
            <span>无内容</span>
          </div>
        </template>
      </a-table>
    </div>
    <div class="pagination-wrap jz-flex jz-flex-cc">
      <basic-pagination @change="pageChange" :params="state.paginationParams">
        <template #extra>
          <span class="page-total">共 {{ state.paginationParams.total }} 任务</span>
        </template>
      </basic-pagination>
    </div>

    <GroupWelcomeTaskDetailDrawer
      :register="registerGroupWelcomeTaskDetailDrawer"
    ></GroupWelcomeTaskDetailDrawer>
    <GroupWelcomeSettingDrawer :register="registerGroupWelcomeSettingDrawer"></GroupWelcomeSettingDrawer>
    <GroupWelcomeCreateDrawer :register="registerGroupWelcomeCreateDrawer"></GroupWelcomeCreateDrawer>
  </div>
</template>

<script setup>
import { onMounted, reactive } from 'vue'
import { Form } from 'ant-design-vue'
import { cloneDeep } from 'lodash-es'
import { sopList } from 'api/sop'
import { getSopIndexColumns } from '@/components/apps/sop/columnsConfig'
import { useDrawer } from '@/components/basic/drawer'
const loading = ref(false)
const tabBox = ref(null)
const [registerGroupWelcomeTaskDetailDrawer, { openDrawer: openGroupWelcomeTaskDetailDrawer }] = useDrawer()
const [registerGroupWelcomeSettingDrawer, { openDrawer: openGroupWelcomeSettingDrawer }] = useDrawer()
const [registerGroupWelcomeCreateDrawer, { openDrawer: openGroupWelcomeCreateDrawer }] = useDrawer()

const state = reactive({
  list: [
    {
      name: '这是一个非常很长的任务标题呢',
      type: '启用中',
      create_time: '2022.10.10 14:30:45',
      visible: false
    }
  ],
  columns: [
    { title: '任务标题', key: 'name' },
    { title: '生效群', key: 'effective_group' },
    { title: '创建时间', dataIndex: 'create_time', width: 160 },
    { title: '状态', key: 'type', width: 160 },
    { title: '操作', key: 'action', width: 160 }
  ],
  scrollY: 0,
  paginationParams: {
    total: 0,
    current: 1,
    showSizeChanger: false
  },
  typeList: [
    { label: '启用中', value: 1 },
    { label: '停用中', value: 2 }
  ]
})
// 表单
const useForm = Form.useForm
const form = reactive({
  name: '',
  type: null
})
const { resetFields } = useForm(form)

/**
 * @desc 切换分页
 * @param current 当前页码
 */
const pageChange = ({ current }) => {
  state.paginationParams.current = current
  getDataList()
}

/**
 * @desc 获取模板数据
 */
const getDataList = async () => {
  loading.value = true
  const params = unref(getParams)
  // let { code, data } = await sopList(params)
  // if (code === 1000) {
  //   data.data.forEach((i) => (i.visible = false))
  //   state.list = data.data
  //   state.paginationParams.total = data.total
  // }
  loading.value = false
}

const handleOpenGroupWelcomeCreateDrawer = (row) => {
  openGroupWelcomeCreateDrawer({
    data: { ...row },
    isUpdate: !!(row && row.id)
  })
}
watch(
  () => form,
  () => {
    state.paginationParams.current = 1
    const params = unref(getParams)
    getDataList(params)
  },
  {
    deep: true
  }
)
// 获取表单参数
const getParams = computed(() => {
  const deepData = cloneDeep(form)
  return {
    ...deepData,
    page: state.paginationParams.current,
    limit: 10
  }
})

/**
 * @desc 获取滚动表格滚高
 */
const getTableScrollY = () => {
  nextTick(() => {
    state.scrollY = tabBox?.value.clientHeight - 54 ?? 400
  })
}
onMounted(() => {
  window.addEventListener('resize', getTableScrollY)
  // 获取tab滚动高度
  getTableScrollY()
  // 获取数据
  getDataList()
})
</script>

<style lang="less" scoped>
.group-welcome-wrapper {
  height: 100%;
  width: 100%;
  position: relative;
  padding: 32px 32px 0;
  background: #fff;
  font-size: 14px;
  .head {
    width: 100%;
    height: 60px;
    strong {
      font-size: 20px;
    }
    .ant-btn {
      margin-right: 8px;
      &:last-child {
        margin-right: 0;
      }
    }
  }
  .form {
    padding: 16px 0;
    .ant-form-item {
      width: 296px;
      margin-right: 16px;
      margin-bottom: 8px;
    }
  }
  .table-wrap {
    height: 100%;
    overflow: hidden;
    .ant-table-wrapper {
      overflow: hidden;
    }
  }
  .pagination-wrap {
    height: 64px;
    .page-total {
      color: #999;
    }
  }
}
.not-more {
  margin-top: 120px;
  img {
    width: 110px;
    height: 110px;
    margin-bottom: 4px;
  }
  span {
    font-size: 12px;
  }
}
.not-table {
  :deep(.ant-table-tbody > tr > td) {
    border: none;
  }
}
.task-btn {
  .svg-icon {
    width: 20px !important;
    height: 20px !important;
    &:first-child {
      margin-right: 16px;
    }
  }
}
.type-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  margin-right: 10px;
}
.name-text {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.group-list {
  .ant-avatar {
    margin-right: 10px;
  }
}
.popover-wraper {
  font-size: 14px;
}
.popover-p {
  height: 40px;
  line-height: 40px;
  margin-bottom: 0px;
  padding: 0 8px;
  width: 130px;
  &:hover {
    background: #f5f5f5;
  }
}
</style>
