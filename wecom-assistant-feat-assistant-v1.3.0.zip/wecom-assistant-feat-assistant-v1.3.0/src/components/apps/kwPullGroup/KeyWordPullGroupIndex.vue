<template>
  <div id="kwg-wrapper" class="jz-flex jz-flex-col jz-flex-1">
    <div class="head jz-flex jz-flex-cc">
      <strong @click="openKeywordDetailDrawer()">关键词拉群</strong>
      <div class="jz-flex jz-flex-1 jz-flex-rr jz-flex-cc">
        <span style="margin-right: 20px">消息发送间隔：0-5秒</span>
        <a-button @click="openSendDrawer">发送设置</a-button>
        <a-button type="primary" @click="handleOpenKeywordDrawer()">新建任务</a-button>
      </div>
    </div>
    <div class="form">
      <a-form class="jz-flex">
        <a-form-item>
          <a-input v-model:value="form.name" allowClear placeholder="请输入任务标题">
            <template #suffix v-if="!form.name">
              <svg-icon icon-name="ic_search" />
            </template>
          </a-input>
        </a-form-item>
        <a-form-item>
          <a-select v-model:value="form.type" :options="state.typeList" placeholder="状态" />
        </a-form-item>
      </a-form>
    </div>
    <div class="jz-flex jz-flex-1 table-wrap" ref="tabBox">
      <a-table
        row-key="id"
        class="sop-table"
        :class="!state.list.length && 'not-table'"
        :columns="state.columns"
        :data-source="state.list"
        :bordered="false"
        :pagination="false"
        :loading="loading"
        :scroll="{ y: state.scrollY }"
      >
        <template #emptyText>
          <div class="not-more jz-flex jz-flex-center jz-flex-col">
            <img src="@/assets/imgs/not_more.png" alt="" />
            <span>无内容</span>
          </div>
        </template>
      </a-table>
    </div>
    <div class="pagination-wrap jz-flex jz-flex-cc">
      <basic-pagination @change="pageChange" :params="state.paginationParams">
        <template #extra>
          <span class="page-total">共 {{ state.paginationParams.total }} 模板</span>
        </template>
      </basic-pagination>
    </div>
    <!--发送设置-->
    <SendOutDrawer :register="sendDrawer" @success="() => sendCallBack()" />
    <!--任务设置-->
    <KeywordTaskDrawer :register="keywordDrawer" @success="() => sendCallBack()" />
    <!--任务详情-->
    <KeywordDetailDrawer :register="detailDrawer" />
  </div>
</template>

<script setup>
import { Form } from 'ant-design-vue'
import { cloneDeep } from 'lodash-es'
import { getColumns } from './columnsConfig'
import SendOutDrawer from './drawer/SendOutDrawer.vue'
import useMessage from '@/composables/web/useMessage'
import { useDrawerInner, useDrawer } from '@/components/basic/drawer'
const { createMessage, createConfirm } = useMessage()
const [sendDrawer, { openDrawer: openSendDrawer }] = useDrawer()
const [keywordDrawer, { openDrawer: openKeywordDrawer }] = useDrawer()
const [detailDrawer, { openDrawer: openKeywordDetailDrawer }] = useDrawer()
// ========================变量
const loading = ref(false)
const tabBox = ref(null)
const state = reactive({
  navIndex: 0,
  scrollY: 0,
  list: [],
  columns: getColumns(),
  navs: ['多客户任务'],
  paginationParams: {
    total: 0,
    current: 1,
    showSizeChanger: false
  },
  typeList: [
    { label: '全部', value: 0 },
    { label: '进行中', value: 1 },
    { label: '已暂停', value: 2 },
    { label: '已结束', value: 3 }
  ]
})

const useForm = Form.useForm

// 表单
const form = reactive({
  type: 0,
  name: ''
})

const { resetFields } = useForm(form)

onMounted(() => {
  window.addEventListener('resize', getTableScrollY)
  // 获取tab滚动高度
  getTableScrollY()
})

// watch==============================

watch(
  () => form,
  () => {
    state.paginationParams.current = 1
    const params = unref(getParams)
    getList(params)
  },
  {
    deep: true
  }
)

// computed=============================

// 获取表单参数
const getParams = computed(() => {
  const deepData = cloneDeep(form)
  return {
    ...deepData,
    page: state.paginationParams.current,
    limit: 10
  }
})

// methods===========================

// 新建or编辑任务
const handleOpenKeywordDrawer = (row) => {
  openKeywordDrawer({
    data: { ...row },
    isUpdate: row && row.id ? true : false
  })
}

const sendCallBack = () => {}

/**
 * @desc 获取数据
 */
const getList = async () => {
  loading.value = true
  const params = unref(getParams)
  console.log(params)
  loading.value = false
}

/**
 * @desc 获取滚动表格滚高
 */
const getTableScrollY = () => {
  nextTick(() => {
    state.scrollY = tabBox?.value.clientHeight - 54 ?? 400
  })
}

/**
 * @desc 切换分页
 * @param current 当前页码
 */
const pageChange = ({ current }) => {
  state.paginationParams.current = current
  getSopList()
}

onBeforeUnmount(() => {
  window.removeEventListener('resize', getTableScrollY)
})
</script>

<style lang="less" scoped>
#kwg-wrapper {
  height: 100%;
  width: 100%;
  position: relative;
  padding: 32px 32px 0;
  background: #fff;
  font-size: 14px;
  .head {
    width: 100%;
    height: 60px;
    strong {
      font-size: 20px;
    }
    .ant-btn {
      margin-right: 8px;
      &:last-child {
        margin-right: 0;
      }
    }
  }
  .form {
    padding: 16px 0;

    .ant-form-item {
      width: 296px;
      margin-right: 16px;
      margin-bottom: 8px;
    }
  }
  .tip {
    color: #ed7b2f;
    margin-bottom: 12px;
    div {
      margin-left: 10px;
    }
  }
  .table-wrap {
    height: 100%;
    overflow: hidden;
    .ant-table-wrapper {
      overflow: hidden;
    }
  }
  .pagination-wrap {
    height: 64px;
    .page-total {
      color: #999;
    }
  }
}
.team-label {
  color: #06d1d1;
  font-size: 12px;
  line-height: 22px;
  text-align: center;
  padding: 3px 8px;
  display: inline-block;
  background: #e6fafa;
  border-radius: 4px 4px 4px 4px;
}

.popover-wraper {
  font-size: 14px;
}
.popover-p {
  height: 40px;
  line-height: 40px;
  margin-bottom: 0px;
  padding: 0 8px;
  width: 130px;
  &:hover {
    background: #f5f5f5;
  }
}
.not-more {
  img {
    width: 110px;
    height: 110px;
    margin-bottom: 4px;
  }
  span {
    font-size: 12px;
  }
}
.not-table {
  :deep(.ant-table-tbody > tr > td) {
    border: none;
  }
}

:deep(.ant-popover-inner) {
  border-radius: 6px;
}
:deep(.ant-popover-arrow) {
  width: 0px;
}
:deep(.ant-table-thead > tr > th) {
  color: @font-minor-color;
  border-bottom: none;
}
::-webkit-scrollbar {
  width: 0px;
  height: 0px;
}
:deep(.ant-table-thead
    > tr
    > th:not(:last-child):not(.ant-table-selection-column):not(.ant-table-row-expand-icon-cell):not([colspan])::before) {
  width: 0;
}
</style>
<style lang="less">
.sop-table {
  .ant-spin-nested-loading {
    .ant-spin-container {
      .ant-table {
        .ant-table-container {
          .ant-table-body {
            min-height: 300px;
          }
        }
      }
    }
  }
  .ant-table-tbody > tr.ant-table-row-selected > td {
    background: rgba(49, 101, 245, 0.04);
  }
  .ant-table-thead
    > tr
    > th:not(:last-child):not(.ant-table-selection-column):not(.ant-table-row-expand-icon-cell):not([colspan])::before {
    width: 0;
  }
}
</style>
