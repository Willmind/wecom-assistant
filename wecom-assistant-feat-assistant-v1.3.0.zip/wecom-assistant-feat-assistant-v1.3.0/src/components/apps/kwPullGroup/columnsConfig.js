// 关键词拉群首页columns
export const getColumns = () => [
  { title: '任务标题', dataIndex: 'id', width: 100 },
  { title: '关键词', key: 'name' },
  { title: '添加客户群数', key: 'create_time' },
  { title: '新建客户群数', dataIndex: 'update_time' },
  { title: '状态', dataIndex: 'status' },
  { title: '操作', key: 'action', width: 250 }
]

// 任务详情
export const getTaskDetailColumns = () => [
  { title: '群名称', key: 'customerAction', width: '40px' },
  { title: '拉群人数', dataIndex: 'mobile', width: '100px' },
  { title: '状态', key: 'action', width: '200px' }
]
