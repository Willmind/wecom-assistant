<template>
  <div class="page-wrapper jz-flex jz-flex-col jz-flex-1">
    <div class="plan-header jz-flex jz-flex jz-flex-cc">
      <span class="plan-header-num">方案&nbsp;{{ online_num }}/{{ total }}</span>
      <div class="jz-flex-1 jz-flex jz-flex-rr">
        <a-button type="primary" style="margin-right: 8px" @click="handleOpenEditorDrawer()"
          ><plus-outlined />新增</a-button
        >
        <a-button @click="openPlanDrawer">调用</a-button>
      </div>
    </div>
    <div class="plan-wraper jz-flex jz-flex-col jz-flex-rb">
      <a-row class="live-list">
        <template v-if="state.list.length">
          <a-col :span="spanNum" v-for="(item, index) in state.list" :key="index">
            <li
              class="li-box"
              @mouseenter="handleMouse(index)"
              @mouseleave="handleMouse(index)"
              @click="handleOpenEditorDrawer(item)"
            >
              <div class="item">
                <div class="item-wrap jz-flex jz-flex-rl jz-flex-col">
                  <div class="tit jz-flex jz-flex-cc">
                    <span class="tit-tip lineClamp1">{{ item.is_default ? '默认方案' : item.name }}</span>
                    <div class="jz-flex-1 jz-flex jz-flex-rr jz-flex-cc" @click.stop.prevent>
                      <a-popover
                        placement="bottomLeft"
                        trigger="hover"
                        v-model:visible="item.popVisible"
                        style="padding-top: 3px"
                        class="popover-wraper"
                        :getPopupContainer="
                          (triggerNode) => {
                            return triggerNode.parentNode || document.body
                          }
                        "
                      >
                        <template #content>
                          <p class="jz-pointer popover-p" @click="handleReName(item)" v-if="!item.is_default">
                            重命名
                          </p>
                          <p class="jz-pointer popover-p" @click="handleCopyCustomer(item)">复制</p>
                          <p class="jz-pointer popover-p" @click="handleUploadCustomer(item)">
                            {{ item.is_public ? '从模板库移除' : '上传至模板库' }}
                          </p>
                          <p
                            class="jz-pointer popover-p"
                            @click.stop.prevent="deleteCustomer(item)"
                            v-if="!item.is_default"
                          >
                            删除
                          </p>
                        </template>
                        <svg-icon icon-name="jz_more" style="width: 24px; height: 24px" class="more-icon" />
                      </a-popover>

                      <check-circle-filled
                        class="check-color"
                        v-if="item.status"
                        @click="handleStartCustmoer(item.id)"
                      />
                      <span v-else class="not-check" @click="handleStartCustmoer(item.id)"></span>
                    </div>
                  </div>
                  <div class="jz-flex-1 item-content" @mouseleave="handleMouseleave($event)">
                    <div
                      class="remark jz-flex jz-flex-col"
                      v-if="
                        item.is_auto_remark &&
                        item.auto_remark_config &&
                        item.auto_remark_config.data &&
                        item.auto_remark_config.data.length
                      "
                    >
                      <span class="remark-tit">自动备注</span>
                      <div class="remark-info">
                        <span
                          v-for="(remarkItem, remarkIndex) in item.auto_remark_config.data"
                          :key="remarkIndex"
                        >
                          <label class="remark-txt">{{ remarkItem.text }}</label>
                          <i v-if="remarkIndex !== item.auto_remark_config.data.length - 1">-</i>
                        </span>
                      </div>
                    </div>
                    <div
                      class="tag jz-flex jz-flex-col"
                      v-if="
                        item.is_auto_label && item.auto_label_config && item.auto_label_config.label.length
                      "
                    >
                      <span class="tag-tit">自动打标签</span>
                      <ul class="tag-list jz-flex jz-flex-wrap">
                        <li
                          :class="+labelItem.type === 2 && 'green'"
                          v-for="(labelItem, labelIndex) in item.auto_label_config.label"
                          :key="labelIndex"
                        >
                          {{ labelItem.name }}
                        </li>
                      </ul>
                    </div>
                    <div
                      class="msg jz-flex jz-flex-col"
                      v-if="item.auto_message_config && item.auto_message_config.length"
                    >
                      <span class="msg-tit">自动发消息</span>
                      <ul class="msg-list jz-flex jz-flex-col">
                        <li
                          class="jz-flex jz-flex-rl"
                          v-for="(msgItem, msgIndex) in item.auto_message_config"
                          :key="msgIndex"
                        >
                          <span class="step jz-flex jz-flex-center">{{ msgIndex }}</span>
                          <!--文本类型-->
                          <div class="jz-flex-1 text-type" v-if="+msgItem.msg_type === 2">
                            {{ msgItem.msg.text }}
                          </div>
                          <!--图片类型-->
                          <div class="jz-flex-1 img-type" v-if="+msgItem.msg_type === 14">
                            <img :src="msgItem.msg.url" alt="" />
                          </div>
                          <!--视频类型-->
                          <div class="jz-flex-1 video-type" v-if="+msgItem.msg_type === 23">
                            <video :src="msgItem.msg.url"></video>
                            <svg-icon icon-name="ic_msg_video" />
                          </div>
                          <!--文件类型-->
                          <div class="jz-flex-1 file-type jz-flex jz-flex-cc" v-if="+msgItem.msg_type === 15">
                            <svg-icon icon-name="ic_msg_pdf" />
                            <span class="lineClamp1">{{ msgItem.msg.name }}</span>
                          </div>
                          <!--链接类型-->
                          <div
                            class="link-type jz-flex jz-flex-cc jz-flex-col"
                            v-if="+msgItem.msg_type === 13"
                          >
                            <div class="link-tit">{{ msgItem.msg.title }}</div>
                            <div class="desc jz-flex jz-flex-1">
                              <div class="desc-text jz-flex-1">{{ msgItem.msg.des }}</div>
                              <img :src="msgItem.msg.thumb_url" alt="" />
                            </div>
                          </div>
                          <!--小程序类型-->
                          <div class="wx-type jz-flex jz-flex-cc jz-flex-col" v-if="+msgItem.msg_type === 78">
                            <div class="logo-box jz-flex jz-flex-cc">
                              <img :src="msgItem.msg.icon_url" alt="" />
                              <span>{{ msgItem.msg.title }}</span>
                            </div>
                            <div class="wx-bg jz-flex-1 jz-flex jz-flex-center">
                              <img src="@/assets/imgs/wx.png" alt="" />
                            </div>
                            <span class="wx-name">小程序</span>
                          </div>
                          <!--语音类型-->
                          <div class="audio-type jz-flex jz-flex-cc" v-if="+msgItem.msg_type === 16">
                            <svg-icon icon-name="ic_msg_audio" />
                          </div>
                          <!--视频号类型-->
                          <div
                            class="wx-video-type jz-flex jz-flex-cc jz-flex-col"
                            v-if="+msgItem.msg_type === 141"
                          >
                            <div class="jz-flex-1 head">
                              <img :src="msgItem.msg.head_img_url" alt="" />
                              <svg-icon icon-name="ic_msg_video" />
                            </div>
                            <div class="wx-tit jz-flex jz-flex-cc">
                              <img src="@/assets/imgs/sph.png" alt="" /> 简知科技
                            </div>
                          </div>
                        </li>
                      </ul>
                    </div>
                    <div class="group jz-flex jz-flex-col" v-if="item.auto_group_config">
                      <div class="group-check jz-flex">
                        <span class="msg-tit">自动拉群</span>
                        <div class="jz-flex-1 jz-flex jz-flex-rr">
                          <a-switch
                            :checked="
                              item.auto_group_config && +item.auto_group_config.is_auto_create ? true : false
                            "
                            disabled
                          />
                        </div>
                      </div>
                      <template
                        v-if="
                          item.auto_group_config &&
                          item.auto_group_config.group_data &&
                          item.auto_group_config.group_data.length
                        "
                      >
                        <div
                          class="group-list jz-flex jz-flex-center"
                          v-for="(groupItem, groupIndex) in item.auto_group_config.group_data"
                          :key="groupIndex"
                        >
                          <img :src="groupItem.avatar" alt="" />
                          <div class="jz-flex-1 jz-flex jz-flex-col">
                            <span>{{ groupItem.name }}</span>
                            <span>3&nbsp;位成员</span>
                          </div>
                          <span
                            class="status-1"
                            v-if="groupItem.room_members >= item.auto_group_config.max_member"
                            ><i></i> 已满员</span
                          >
                          <span v-else class="status-2"><i></i>拉人中</span>
                        </div>
                      </template>

                      <div class="empty jz-flex jz-flex-cc" v-else>
                        <span class="empty-add jz-flex jz-flex-center">
                          <svg-icon icon-name="custer_add" style="width: 28px; height: 28px" />
                        </span>
                        <div>
                          <span class="gray-color">暂无选择客户群</span>
                          <a-button
                            type="link"
                            style="font-size: 14px; padding: 0"
                            @click="handleOpenEditorDrawer(item)"
                            >去添加</a-button
                          >
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </li>
          </a-col>
        </template>
        <a-col :span="spanNum">
          <li @click="handleOpenEditorDrawer()" class="li-box">
            <div class="item jz-flex jz-flex-center item-add">
              <svg-icon icon-name="add" style="color: #969696" />
              <span>新增方案</span>
            </div>
          </li>
        </a-col>
      </a-row>
    </div>
    <!--修改方案名称组件-->
    <a-modal v-model:visible="renameVisible" @ok="updateRename" :closable="false">
      <div class="jz-flex jz-flex-cc">
        <span class="rename">方案名称：</span>
        <a-input v-model:value="customerItem.name" style="width: 200px" />
      </div>
    </a-modal>
    <!--计划模板侧边栏-->
    <PlanTemplate :register="planDrawer" @success="() => planCallback()" />
    <EditorPlanDrawer :register="customerDrawer" @success="() => planCallback()" />
  </div>
</template>

<script setup>
import { debounce } from 'lodash-es'
import useMessage from '@/composables/web/useMessage'
import { useDrawer } from '@/components/basic/drawer'
import {
  getApiConfigList,
  getApiCopyCustomer,
  getApiDelCustomer,
  getApiOnlineCustomer,
  getApiRenameCustomer,
  uploadCustomer
} from 'api/customerOperationManager'
import { onUnmounted, ref } from 'vue'
const { createConfirm, createMessage } = useMessage()
const [planDrawer, { openDrawer: openPlanDrawer }] = useDrawer()
const [customerDrawer, { openDrawer: openCustomerDrawer }] = useDrawer()
const renameVisible = ref(false)
const online_num = ref(0)
const total = ref(0)
const state = reactive({
  list: [{ check: false, visible: false }]
})
const customerItem = ref(null)
const spanNum = ref(8)
onMounted(() => {
  handleResize()
  window.addEventListener('resize', debounce(handleResize))
  getConfigList()
})

// methods =====================

const handleResize = () => {
  let _w = document.documentElement.clientWidth || document.body.clientWidth
  if (_w < 1400) {
    spanNum.value = 12
  } else if (_w > 1400 && _w < 1876) {
    spanNum.value = 8
  } else {
    spanNum.value = 6
  }
}

// 上传模板库
const handleUploadCustomer = async (item) => {
  item.popVisible = false
  let { code, msg } = await uploadCustomer({ id: item.id })
  if (code === 1000) {
    createMessage.success(msg)
    getConfigList()
  }
}

// 启用模板
const handleStartCustmoer = async (id) => {
  let { code, msg } = await getApiOnlineCustomer({ id })
  if (code === 1000) {
    createMessage.success(msg)
    getConfigList()
  }
}

// 复制模板
const handleCopyCustomer = async (item) => {
  item.popVisible = false
  if (state.list.length >= 10) {
    createMessage.info('最多只能创建10个方案')
    return
  }
  let { code, msg } = await getApiCopyCustomer({ id: item.id })
  if (code === 1000) {
    createMessage.success(msg)
    getConfigList()
  }
}

// 获取方案列表
const getConfigList = async () => {
  let { code, data } = await getApiConfigList()
  if (code === 1000) {
    data.data.forEach((item) => {
      item.visible = false
      item.popVisible = false
      // if (item.auto_remark_config && item.auto_remark_config.data && item.auto_remark_config.data.length) {
      //   item.auto_remark_config.data = item.auto_remark_config.data.filter((i) => i.type === 2)
      // }
    })
    state.list = data.data
    online_num.value = data.online_num
    total.value = data.total
  }
}

// 鼠标移入移出
const handleMouse = (index) => {
  state.list[index].visible = !state.list[index].visible
}

// 重命名操作
const handleReName = (item) => {
  item.popVisible = false
  customerItem.value = { ...item }
  renameVisible.value = true
}

// 更新方案名称
const updateRename = async () => {
  if (!customerItem.value.name) {
    createMessage.info('请填写方案名称')
    return
  }
  let { name, id } = customerItem.value
  let { code, msg } = await getApiRenameCustomer({ id, name })
  if (code === 1000) {
    createMessage.success(msg)
    getConfigList()
    renameVisible.value = false
  }
}

// 删除方案弹窗
const deleteCustomer = (item) => {
  item.popVisible = false
  createConfirm({
    cancelText: '取消',
    content: `确认删除该方案吗？`,
    onOk() {
      // 调用清空接口
      deletePlan(item.id)
    }
  })
}

// 删除方案
const deletePlan = async (id) => {
  let { code, msg } = await getApiDelCustomer({ id })
  if (code === 1000) {
    createMessage.success(msg)
    getConfigList()
  }
}

const handleMouseleave = (e) => {
  e.currentTarget.scrollTo({ top: 0, behavior: 'smooth' })
}

// 新建/编辑方案
const handleOpenEditorDrawer = (row) => {
  openCustomerDrawer({
    data: { ...row },
    isUpdate: row && row.id ? true : false
  })
}

// 调用模板抽屉回调
const planCallback = () => {
  getConfigList()
}

onUnmounted(() => {
  window.removeEventListener('resize', handleResize)
})
</script>

<style lang="less" scoped>
.page-wrapper {
  height: 100%;
  width: 100%;
  position: relative;
  background: #fff;
  font-size: 14px;
  padding-top: 32px;
  .plan-header {
    width: 100%;
    height: 60px;
    padding: 0 32px;
    &-num {
      font-size: 20px;
      font-weight: 600;
    }
  }
  .plan-wraper {
    display: flex;
    overflow-y: auto;
    width: 100%;
    height: 100%;
    flex: 1;
    padding: 0 16px;
  }
  .li-box {
    width: 100%;
    padding: 0 8px;
  }
  .item {
    display: flex;
    flex-flow: column;
    position: relative;
    border-radius: 12px;
    padding: 0 0 24px 0;
    margin-bottom: 16px;
    height: 560px;
    position: relative;
    cursor: pointer;
    border: 1px solid #eee;
    box-shadow: 0px 0px 8px 0px rgba(0, 0, 0, 0.05);
    .item-wrap {
      width: 100%;
      height: 100%;
      display: flex;
      .tit {
        width: 100%;
        margin-bottom: 32px;
        margin-top: 24px;
        padding: 0 24px;

        .tit-tip {
          font-size: 20px;
          font-weight: 500;
          color: #000;
          margin-right: 24px;
        }
        .check-color {
          color: #3165f5;
          margin-left: 30px;
          font-size: 24px;
        }

        .more-icon {
          transition: all 0.3s;
          &:hover {
            background-color: #f5f5f5;
            border-radius: 4px;
          }
        }
        .popover-wraper {
          opacity: 0;
          font-size: 24px;
        }
        .not-check {
          width: 24px;
          height: 24px;
          margin-left: 30px;
          opacity: 0;
          border-radius: 50%;
          border: 1px solid #eeeeee;
          transition: all 0.3s;
          &:hover {
            border: 1px solid #3165f5;
          }
        }
      }
      .item-content {
        overflow: auto;
        padding: 0 24px;
        &::-webkit-scrollbar {
          width: 2px;
        }
        &::-webkit-scrollbar-thumb {
          visibility: hidden;
          transition: all 0.28s;
        }
        &:hover {
          &::-webkit-scrollbar-thumb {
            visibility: visible;
          }
        }
        .remark {
          width: 100%;
          &-tit {
            margin-bottom: 8px;
            color: @font-minor-color;
          }
          .remark-info {
            span {
              .remark-txt {
                background: #f5f5f5;
                padding: 0px 8px;
                height: 22px;
                line-height: 22px;
                display: inline-block;
              }
              i {
                margin: 0 4px;
              }
            }
          }
          &-info {
            width: 100%;
            border-radius: 6px;
            padding: 5px;
            font-size: 12px;
            border: 1px solid #eeeeee;
          }
        }
        .tag {
          width: 100%;
          margin: 24px 0 8px;
          &-tit {
            margin-bottom: 8px;
            color: @font-minor-color;
          }
          &-list {
            width: 100%;
            li {
              padding: 0 12px;
              font-size: 14px;
              height: 32px;
              line-height: 32px;
              margin: 0 8px 8px 0;
              color: #3165f5;
              box-sizing: border-box;
              background: rgba(49, 101, 245, 0.1);
              border-radius: 6px 6px 6px 6px;
            }
            li.green {
              color: #06d1d1;
              background: rgba(6, 209, 209, 0.1);
            }
          }
        }
        .msg {
          width: 100%;
          margin: 16px 0 0px;
          &-tit {
            margin-bottom: 8px;
            color: @font-minor-color;
          }
          &-list {
            width: 100%;
            border-radius: 6px;
            padding: 12px 12px 0;
            border: 1px solid #eeeeee;
            li {
              width: 100%;
              margin-bottom: 12px;
              overflow: hidden;
              .step {
                min-width: 24px;
                min-height: 24px;
                max-width: 24px;
                max-height: 24px;
                border-radius: 50%;
                font-size: 12px;
                color: @font-minor-color;
                background: #eeeeee;
                margin-right: 16px;
              }
              .text-type {
                color: #000;
                font-size: 12px;
              }
              .img-type {
                img {
                  width: 48px;
                  height: 48px;
                  border-radius: 4px;
                }
              }
              .video-type {
                position: relative;
                > video {
                  width: 48px;
                  height: 32px;
                  object-fit: cover;
                }
                .svg-icon {
                  position: absolute;
                  left: 15px;
                  top: 10px;
                  color: #fff;
                  width: 16px !important;
                  height: 16px !important;
                }
              }
              .file-type {
                .svg-icon {
                  width: 20px !important;
                  height: 20px !important;
                  min-width: 20px;
                  min-height: 20px;
                  margin-right: 4px;
                }
              }
              .link-type {
                width: 90px;
                height: 42px;
                background: #eee;
                position: relative;
                padding: 5px;
                border-radius: 4px;
                &::before {
                  content: '';
                  width: 0;
                  height: 0;
                  left: -7px;
                  top: 10px;
                  position: absolute;
                  border-right: 5px solid transparent;
                  border-left: 5px solid transparent;
                  border-bottom: 5px solid #eee;
                  transform: rotate(-90deg);
                }
                .link-tit {
                  font-size: 6px;
                  color: #000;
                  display: -webkit-box;
                  -webkit-box-orient: vertical;
                  -webkit-line-clamp: 2;
                  overflow: hidden;
                  line-height: 7px;
                  text-align: left;
                  width: 100%;
                }
                .desc {
                  width: 100%;
                  &-text {
                    font-size: 5px;
                    color: @font-minor-color;
                    overflow: hidden;
                  }
                  img {
                    width: 18px;
                    height: 18px;
                  }
                }
              }
              .wx-type {
                width: 90px;
                height: 100px;
                background: #eee;
                position: relative;
                padding: 5px;
                border-radius: 4px;
                &::before {
                  content: '';
                  width: 0;
                  height: 0;
                  left: -7px;
                  top: 10px;
                  position: absolute;
                  border-right: 5px solid transparent;
                  border-left: 5px solid transparent;
                  border-bottom: 5px solid #eee;
                  transform: rotate(-90deg);
                }
                .logo-box {
                  width: 100%;
                  font-size: 4px;
                  color: @font-minor-color;
                  margin-bottom: 2px;
                  img {
                    width: 8px;
                    height: 8px;
                    border-radius: 50%;
                    margin-right: 5px;
                  }
                }
                .wx-bg {
                  width: 100%;
                  height: 60px;
                  img {
                    width: 30px;
                    height: 30px;
                  }
                }
                .wx-name {
                  font-size: 6px;
                  margin-top: 3px;
                  display: block;
                  width: 100%;
                  display: flex;
                }
              }
              .audio-type {
                .svg-icon {
                  width: 58px !important;
                  height: 24px !important;
                }
              }
              .voice-type {
                width: 58px;
                height: 24px;
                background: #eeeeee;
                border-radius: 4px;
              }
              .wx-video-type {
                width: 83px;
                height: 110px;
                position: relative;
                border-radius: 4px;
                background: #eeeeee linear-gradient(360deg, rgba(0, 0, 0, 0.5) 0%, rgba(0, 0, 0, 0) 100%);
                .head {
                  width: 100%;
                  height: 100%;
                  position: relative;
                  .svg-icon {
                    width: 16px !important;
                    height: 16px !important;
                    left: 50%;
                    top: 50%;
                    position: absolute;
                    color: #fff;
                    margin-left: -8px;
                  }
                  img {
                    width: 100%;
                    height: 100%;
                    border-radius: 4px;
                  }
                }
                .wx-tit {
                  font-size: 6px;
                  color: #fff;
                  position: absolute;
                  left: 0;
                  bottom: 0px;
                  right: 0;
                  padding-left: 4px;
                  img {
                    width: 10px;
                    height: 10px;
                    margin-right: 3px;
                  }
                }
              }
            }
          }
        }
        .group {
          margin-top: 24px;

          .empty {
            margin-top: 8px;
            .empty-add {
              width: 40px;
              height: 40px;
              border-radius: 8px;
              margin-right: 16px;
              border: 1px dashed #eeeeee;
            }
          }
          .group-list {
            width: 100%;
            margin-top: 19px;
            img {
              width: 48px;
              height: 48px;
              border-radius: 4px;
              margin-right: 14px;
            }
            div {
              span:last-child {
                color: @font-minor-color;
              }
            }
            .status-1 {
              > i {
                width: 6px;
                height: 6px;
                background: #f5f5f5;
                display: inline-block;
                border-radius: 50%;
                margin-right: 6px;
              }
              color: @font-minor-color;
            }
            .status-2 {
              > i {
                width: 6px;
                height: 6px;
                background: #3165f5;
                display: inline-block;
                border-radius: 50%;
                margin-right: 6px;
              }
              color: #3165f5;
            }
          }
        }
      }
    }

    &:hover {
      .not-check,
      .popover-wraper {
        opacity: 1 !important;
      }
    }
  }
  .item-add {
    background: rgba(0, 0, 0, 0.02);
    .svg-icon {
      width: 32px !important;
      height: 32px !important;
    }
    span {
      color: @font-minor-color;
      margin-top: 16px;
      font-size: 20px;
    }
  }
  .popover-p {
    height: 40px;
    line-height: 40px;
    margin-bottom: 0px;
    padding: 0 8px;
    min-width: 100px;
    &:hover {
      background: #f5f5f5;
    }
  }
}
.rename {
  width: 80px;
}
.gray-color {
  color: @font-minor-color;
  margin-right: 6px;
}

:deep(.ant-popover) {
  box-shadow: none;
}
:deep(.ant-switch-disabled) {
  opacity: 1;
}
:deep(.ant-popover-inner) {
  border-radius: 6px;
}
:deep(.ant-popover-arrow) {
  width: 0px;
}
</style>
