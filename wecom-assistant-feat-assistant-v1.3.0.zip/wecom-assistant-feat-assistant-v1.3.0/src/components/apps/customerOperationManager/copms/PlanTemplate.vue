<template>
  <BasicDrawer
    v-bind="$attrs"
    showFooter
    :register="registerDrawer"
    :showCancelBtn="false"
    title="选择模板"
    :width="560"
    @visible-change="handleVisivleChange"
  >
    <div class="wrapper jz-flex jz-flex-col">
      <div class="search">
        <!-- <a-input-search
          v-model:value="state.searchVal"
          placeholder="请输入关键词"
          :loading="state.isSubmiting"
          enter-button
          @search="onSearch"
        /> -->
        <a-input v-model:value="state.searchVal" placeholder="请输入关键词" allow-clear>
          <template #prefix>
            <search-outlined />
          </template>
        </a-input>
      </div>
      <template v-if="state.list.length">
        <ul
          v-infinite-scroll="getPalnList"
          :infinite-scroll-immediate-check="false"
          :infinite-scroll-disabled="state.isFinished"
          :infinite-scroll-watch-disabled="state.isFinished"
          :infinite-scroll-distance="10"
          class="info jz-flex jz-flex-wrap"
        >
          <li
            v-for="(item, index) in state.list"
            class="jz-flex jz-flex-col jz-pointer"
            :key="index"
            @click="selectItem(item, index)"
            :class="index === state.currentIndex && 'current'"
          >
            <check-circle-filled class="check" />
            <span class="no-check"></span>
            <span class="tit">{{ item.name }}</span>
            <div class="col jz-flex jz-flex-cc">
              <span>类型</span>
              <span class="jz-flex-1 lineClamp1">{{ ['新客户运营'][item.type - 1] }}</span>
            </div>
            <div class="col jz-flex jz-flex-cc">
              <span>创建人</span>
              <span class="jz-flex-1 lineClamp1">{{ item.account_name }}</span>
            </div>
            <div class="col jz-flex jz-flex-cc">
              <span>创建时间</span>
              <span class="jz-flex-1 lineClamp1">{{ item.create_time }}</span>
            </div>
          </li>
        </ul>
      </template>
      <a-empty v-else />
      <!-- <div class="pagination-box">
        <basic-pagination @change="pageChange" :params="state.paginationParams">
          <template #extra>
            <span class="page-total">共{{ state.paginationParams.total }}条模板</span>
          </template>
        </basic-pagination>
      </div> -->
    </div>
    <template #footer>
      <footer class="custom-footer jz-flex jz-flex-rb">
        <a-button type="primary" @click="handleConfirm" :disabled="state.currentIndex === -1 ? true : false"
          >确定</a-button
        >
      </footer>
    </template>
  </BasicDrawer>
</template>
<script setup>
import { useDrawerInner } from '@/components/basic/drawer'
import useMessage from '@/composables/web/useMessage'
import { reactive } from 'vue'
import { getApitmList, getApiCopytmList } from 'api/customerOperationManager'

defineProps({
  register: Function
})
const state = reactive({
  id: '',
  list: [],
  isSubmiting: false,
  searchVal: '',
  currentIndex: -1,
  isFinished: false,
  paginationParams: {
    total: 0,
    current: 1,
    pageSize: 10,
    showSizeChanger: false
  }
})
const emit = defineEmits(['success'])
const { createMessage } = useMessage()

const [registerDrawer, { closeDrawer, setLoading }] = useDrawerInner()

// 搜索
const onSearch = () => {
  state.isSubmiting = true
  state.currentIndex = -1
  state.paginationParams.current = 1
  getPalnList()
}

// 选择模板
const selectItem = (item, index) => {
  state.id = item.id
  state.currentIndex = index
}

// 获取列表
const getPalnList = async () => {
  if (state.isFinished) return
  let { current: page, pageSize: limit } = state.paginationParams
  setLoading()
  getApitmList({ keyword: state.searchVal, page, limit })
    .then((res) => {
      const { data } = res
      if (!data.total || !data.data.length) {
        state.isFinished = true
      } else {
        state.paginationParams.current++
        state.paginationParams.total = data.total
        state.list.push(...data.data)
      }
    })
    .finally(() => {
      setLoading(false)
      state.isSubmiting = false
    })
}

// 展示侧边栏
const handleVisivleChange = (visivle) => {
  if (visivle) {
    getPalnList()
  } else {
    state.searchVal = ''
    state.currentIndex = -1
    state.list = []
    state.isFinished = false
    state.paginationParams.current = 1
  }
}

watch(
  () => unref(state).searchVal,
  () => {
    onSearch()
  }
)

// 确定操作
const handleConfirm = async () => {
  if (!state.id) {
    createMessage.warn('请选择模板')
    return
  }
  getApiCopytmList({ id: state.id })
    .then((res) => {
      if (res.code === 1000) {
        createMessage.success('调用成功')
      }
    })
    .finally(() => {
      closeDrawer()
      emit('success')
      state.isSubmiting = false
    })
}
</script>
<style lang="less" scoped>
.wrapper {
  height: 100%;
  overflow: hidden;
  position: relative;
  .search {
    padding: 0 32px;
    margin-bottom: 24px;
  }
  .info {
    padding: 0 24px;
    max-height: 100%;
    overflow-y: auto;
    li {
      width: 240px;
      height: 160px;
      margin: 8px;
      border-radius: 6px;
      background: #f5f5f5;
      padding: 16px;
      position: relative;
      &:hover {
        .no-check {
          opacity: 1;
        }
      }
      .no-check {
        width: 16px;
        height: 16px;
        position: absolute;
        right: 16px;
        top: 16px;
        margin-left: 30px;
        opacity: 0;
        border-radius: 50%;
        border: 1px solid @primary-color;
      }

      .check {
        position: absolute;
        right: 16px;
        top: 16px;
        width: 16px;
        height: 16px;
        opacity: 0;
        color: @primary-color;
        width: 16px;
        height: 16px;
        :deep(> svg) {
          width: 100%;
          height: 100%;
        }
      }
      &.current {
        .check {
          opacity: 1;
        }
      }
      .tit {
        font-weight: 500;
      }
      .col {
        margin-top: 16px;
        span:first-child {
          width: 57px;
          display: block;
          text-align: right;
          margin-right: 16px;
          color: @font-minor-color;
        }
      }
    }
    li:nth-child(even) {
      margin-right: 0px;
    }
  }
  // .pagination-box {
  //   padding: 0 24px;
  //   position: absolute;
  //   left: 0;
  //   bottom: 0;
  //   right: 0;
  //   height: 60px;
  //   background: #fff;
  // }
}
:deep(.ant-empty) {
  width: 100%;
}
</style>
