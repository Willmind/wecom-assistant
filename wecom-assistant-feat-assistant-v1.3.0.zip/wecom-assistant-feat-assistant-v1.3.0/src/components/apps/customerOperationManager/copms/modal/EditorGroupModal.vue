<!-- eslint-disable indent -->
<template>
  <a-modal
    ref="modalRef"
    v-model:visible="visible"
    centered
    :width="720"
    destroyOnClose
    title="选择对象"
    class="group-modal"
    @cancel="close"
    :footer="null"
  >
    <div class="pop jz-flex jz-flex-col">
      <div class="tip-box jz-flex jz-flex-cc">
        <exclamation-circle-filled style="color: #ed7b2f; font-size: 20px" />
        <div class="tip-box__txt">
          选择多个群聊时，每个客户只会按顺序加入其中一个群聊，加满后递补。<br />
          群聊人数多于40人后，需要发送群邀请链接，客户确认后才能进群；已在群中的客户不会重复邀请。
        </div>
      </div>
      <div class="pop-content jz-flex-1 jz-flex" v-loading="loading">
        <div class="form-wraper">
          <a-form class="ant-form-small">
            <div class="ant-form-head jz-flex jz-flex-rb jz-flex-cc">
              <span class="wecom-title">筛选</span>
              <a-button type="link" @click="clearForm" style="padding-right: 0px; padding-top: 0px"
                >清空筛选</a-button
              >
            </div>
            <a-form-item v-bind="validateInfos.keywork">
              <a-input v-model:value="form.keywork" allowClear placeholder="关键词筛选">
                <template #suffix>
                  <search-outlined />
                </template>
              </a-input>
            </a-form-item>
            <a-form-item v-bind="validateInfos.type">
              <a-select v-model:value="form.type" :options="state.typeList" placeholder="是否群主/群管理员" />
            </a-form-item>
            <!-- <div class="jz-flex jz-flex-center">
              <a-form-item v-bind="validateInfos.scope" style="margin-right: 10px">
                <a-input-number v-model:value="form.min" :min="1" :max="100" placeholder="最小值" />
              </a-form-item>
              <a-form-item v-bind="validateInfos.max">
                <a-input-number v-model:value="form.max" :min="1" :max="100" placeholder="最大值" />
              </a-form-item>
            </div> -->
            <a-form-item>
              <a-popover
                placement="bottom"
                trigger="click"
                v-model:visible="grouoVisible"
                class="popover-wraper"
                :getPopupContainer="
                  (triggerNode) => {
                    return triggerNode.parentNode || document.body
                  }
                "
              >
                <template #content>
                  <div class="count-box jz-flex jz-flex-col">
                    <div class="count-input jz-flex jz-flex-center">
                      <a-input-number
                        v-model:value="state.min_count"
                        :min="1"
                        :max="999"
                        placeholder="最小值"
                        :controls="false"
                        style="width: 86px"
                      />
                      <span class="count-line">-</span>
                      <a-input-number
                        v-model:value="state.max_count"
                        :min="1"
                        :max="1000"
                        placeholder="最大值"
                        :controls="false"
                        style="width: 86px"
                      />
                    </div>
                    <div class="count-btn jz-flex jz-flex-rr">
                      <a-button
                        type="primary"
                        :disabled="!(state.max_count && state.min_count)"
                        @click="handlegetGroupNum"
                        >确定</a-button
                      >
                    </div>
                  </div>
                </template>
                <a-input v-model:value="form.num" allowClear placeholder="群人数">
                  <template #suffix>
                    <down-outlined />
                  </template>
                </a-input>
              </a-popover>
            </a-form-item>
          </a-form>
        </div>
        <div class="list-wraper jz-flex-1 jz-flex-col jz-flex jz-flex-col">
          <div class="head jz-flex jz-flex-rb jz-flex-cc">
            <span class="head-num">客户群 {{ listCount }}</span>
            <div class="jz-flex jz-flex-1 jz-flex-rr">仅显示已选</div>
            <a-switch class="switch" v-model:checked="isSwitch" @change="changeSwitch" />
          </div>
          <template v-if="state.list.length">
            <ul
              class="group-wraper jz-flex jz-flex-col"
              v-infinite-scroll="getList"
              :infinite-scroll-immediate-check="false"
              :infinite-scroll-disabled="scrollDisabled"
              :infinite-scroll-watch-disabled="scrollDisabled"
              :infinite-scroll-distance="10"
            >
              <li
                class="item jz-flex jz-flex-center"
                :class="{ 'item-selected': item.isCheck }"
                v-for="(item, index) in state.list"
                :key="index"
              >
                <a-checkbox
                  v-model:checked="item.isCheck"
                  :disabled="item.isCheck ? false : isLimit"
                  @change="itemChange(item)"
                />
                <div class="jz-flex-1 jz-flex jz-flex-cc">
                  <img :src="item.avatar" alt="" />
                  <div class="jz-flex-1 jz-flex jz-flex-col">
                    <span class="lineClamp1">{{ item.name }}</span>
                    <span class="lineClamp1">群成员{{ item.room_members }}</span>
                  </div>
                </div>
              </li>
            </ul>
          </template>
          <a-empty v-if="!state.list.length && !loading" class="empty" />
        </div>
      </div>
      <div class="ant-popover-footer ant-popover-footer-line jz-flex jz-flex-rr">
        <div class="btns">
          <a-button @click="close">取消</a-button>
          <a-button type="primary" @click="handleConfirm">确认</a-button>
        </div>
      </div>
    </div>
  </a-modal>
</template>

<script setup>
import { cloneDeep } from 'lodash-es'
import { MessageTypeEnum } from '@/enums/MessageTypeEnum'
import { Form } from 'ant-design-vue'
import { getApiGroupList } from 'api/customerOperationManager'
import useMessage from '@/composables/web/useMessage'
const { createMessage } = useMessage()
const emit = defineEmits(['success'])
const useForm = Form.useForm
const visible = ref(false)
const grouoVisible = ref(false)
const loading = ref(false)
const listCount = ref(0)
const page = ref(1)
const isSwitch = ref(false)
const isCheck = ref(false)
const state = reactive({
  data: {},
  isUpdate: false,
  min_count: '',
  max_count: '',
  list: [],
  select_list: '',
  selectedKeys: [],
  typeList: [
    { label: '仅群主', value: 1 },
    { label: '仅群管理员', value: 2 },
    { label: '群主/群管理员', value: 3 },
    { label: '群成员', value: 4 }
  ]
})
// 筛选表单
const form = reactive({
  keywork: '',
  type: [],
  num: ''
})
const rulesRef = reactive({})
const { validateInfos, resetFields } = useForm(form, rulesRef)

const isLimit = computed(() => state.selectedKeys.length >= 100)

const onOpen = (params) => {
  visible.value = true
  state.data = params.data
  state.data.isUpdate = params.isUpdate
  if (params?.data?.group_list) {
    state.select_list = params?.data?.group_list.map((i) => i.id).join(',')
  }
  const _params = unref(getParams)
  search(unref(_params))
}

// 选择群人数
const handlegetGroupNum = () => {
  grouoVisible.value = false
  form.num = `${state.min_count}-${state.max_count}`
}

// 选择某一列
const itemChange = (ele) => {
  let sortIndexArr = state.list.filter((i) => i.isCheck).map((item) => item.sort_index)
  ele.sort_index = Math.max(...sortIndexArr) + 1
  state.select_list = state.list.filter((i) => i.isCheck)
  let ids = state.list
    .filter((i) => i.isCheck)
    .sort((a, b) => a.sort_index - b.sort_index)
    .map((item) => item.id)
  state.selectedKeys = ids
  state.select_list = ids.length ? ids.join(',') : ''
  if (isLimit.value) {
    createMessage.warning('最多添加100个群')
  }
}

// 仅显示已选
const changeSwitch = () => {
  page.value = 1
  listCount.value = 0
  state.list = []
  const params = unref(getParams)
  search(unref(params))
}

// 清空表单
const clearForm = () => {
  resetFields()
}
// 确认提交
const handleConfirm = () => {
  if (!state.select_list) {
    createMessage.info('请选择客户')
    return
  }
  let _defParams = {
    msg_type: MessageTypeEnum.invite,
    wait: 10,
    time_type: 1,
    icon: 'invite',
    isUpdate: false,
    msg: {
      group_ids: null,
      data: [{ text: '群人数 < 40 直接拉入群，群人数 ≥ 40 发送群邀请' }]
    }
  }
  _defParams = Object.assign({}, _defParams, state.data)
  let _arr = []
  if (state.list.length && state.select_list) {
    state.list.forEach((i) => {
      if (state.select_list.split(',').includes(i.id + '')) {
        _arr.push(i)
      }
    })
  }
  _defParams.group_list = unref(_arr)
  _defParams.msg.group_ids = state.select_list
  emit('success', _defParams)
  close()
}

// 关闭
const close = () => {
  visible.value = false
  page.value = 1
  state.list = []
  isSwitch.value = false
  state.select_list = ''
  state.selectedKeys = []
  state.max_count = ''
  state.min_count = ''
  clearForm()
}

// 滚动加载
const getList = () => {
  if (scrollDisabled.value) return
  const params = unref(getParams)
  search(toRaw(params), true)
}

// 搜索
const search = (vals, isScroll = false) => {
  if (loading.value) {
    return
  }
  loading.value = true
  page.value = isScroll ? page.value : 1
  let _params = {
    page: page.value,
    type: !Array.isArray(vals.type) ? vals.type : '',
    keyword: vals.keywork ?? '',
    num: vals.num,
    group_ids: state.select_list || '',
    is_show_selected: isSwitch.value ? 1 : 0
  }
  getApiGroupList(_params)
    .then((res) => {
      if (res.code === 1000) {
        if (res.data.data.length) {
          res.data.data.forEach((i) => {
            i.isCheck = isCheck.value
            i.sort_index = 0
            if (state.select_list) {
              let arr = state.select_list.split(',')
              if (arr.includes(i.id + '')) {
                i.isCheck = true
              }
            }
          })
        }
        state.list = isScroll ? [...state.list, ...res.data.data] : res.data.data
        if (!isScroll) {
          listCount.value = res.data.total
        }
        page.value = page.value + 1
      }
    })
    .finally(() => {
      loading.value = false
    })
}

// 获取form参数
const getParams = computed(() => {
  const deepData = cloneDeep(form)
  return {
    ...deepData,
    num: deepData.num.replace(/\-/g, ',')
  }
})

//  加载完毕
const scrollDisabled = computed(() => state.list.length >= listCount.value)

// 监听=======
watch(
  () => form,
  () => {
    const params = unref(getParams)
    search(unref(params))
  },
  {
    deep: true
  }
)

defineExpose({
  closeModal: close,
  openModal: onOpen
})
</script>

<style lang="less" scoped>
.wrapper {
  .content {
    margin-top: 16px;
  }
}
.tip-box {
  margin: 16px 0;
  padding: 16px 32px 0;
  .tip-box__txt {
    margin-left: 10px;
    color: #ed7b2f;
  }
}
.pop {
  height: 460px;
  overflow: hidden;
  .group-num {
    padding-bottom: 10px;
    text-align: center;
  }
  .pop-content {
    height: 100%;
    overflow: hidden;
    .form-wraper {
      width: 240px;
      height: 100%;
      padding-right: 16px;
      padding-left: 32px;
      border-right: 1px solid #eee;
      .ant-form-head {
        height: 22px;
        line-height: 22px;
        margin-bottom: 8px;
      }
    }
    .list-wraper {
      width: 100%;
      height: 100%;
      .head {
        color: @font-minor-color;
        padding-right: 8px;
        padding-left: 12px;
        .switch {
          margin-left: 18px;
        }
      }
      .group-wraper {
        height: 100%;
        margin-top: 10px;
        overflow-y: auto;
        .item {
          width: 100%;
          height: 54px;
          min-height: 54px;
          padding: 0 12px;
          cursor: pointer;
          &.item-selected {
            background: #ebf0fe !important;
          }
          > div {
            margin-left: 28px;
            img {
              width: 36px;
              height: 36px;
              border-radius: 6px;
              margin-right: 13px;
            }
            span:first-child {
              font-size: 14px;
            }
            span:last-child {
              font-size: 12px;
              color: @font-minor-color;
            }
          }
          &:hover {
            background: rgba(0, 0, 0, 0.02);
          }
        }
      }
    }
  }
}
.count-box {
  width: 100%;
  .count-line {
    margin: 0 8px;
  }
  .count-btn {
    margin-top: 28px;
  }
}
.empty {
  margin-top: 20px;
}
.not-more {
  height: 30px;
  line-height: 30px;
  text-align: center;
  color: @font-minor-color;
}
:deep(.ant-popover) {
  box-shadow: none;
}
:deep(.ant-popover-footer) {
  right: 0px;
  width: 100%;
  padding-right: 16px;
}
:deep(.ant-popover-content) {
  width: 200px;
}
:deep(.ant-popover-placement-bottom) {
  padding-top: 0px;
}
:deep(.ant-popover-inner-content) {
  padding: 16px 14px;
}
:deep(.ant-input-number-input) {
  text-align: center;
}
:deep(.ant-popover-arrow-content) {
  opacity: 0;
}
</style>
<style lang="less">
.group-modal {
  padding: 0px;
  .ant-modal-content {
    border-radius: 6px;
    height: 560px;
    .ant-modal-body {
      padding: 0;
    }
  }
}
</style>
