<!-- eslint-disable indent -->
<template>
  <a-modal
    ref="modalRef"
    v-model:visible="visible"
    centered
    destroyOnClose
    :title="genTitle"
    class="text-modal"
    @cancel="onClose"
  >
    <div class="wrapper">
      <div class="topic">
        <EmojiPopover @select="handleSelectEmoji">
          <SvgIcon class="emoji-icon" icon-name="emoji" />
        </EmojiPopover>
        <template v-for="item in tags" :key="item.value">
          <EmojiPopover
            trigger="hover"
            placement="top"
            :emojis="POSITIVE_ENERGY_EMOJIS"
            title="每个群发的消息，将再一下表情中随机，降低消息重复性带来的风险"
            v-if="item.value === 3"
          >
            <a-tag class="ant-tag-plain ant-tag-big" @click="handleTagClick(item)">{{ item.label }}</a-tag>
          </EmojiPopover>
          <a-tooltip placement="top" overlayClassName="bgc_tooltip">
            <template #title>
              <div>
                “客户管理”功能，可设置对好友的称呼，没有称呼将使用昵称 <br />举例：<br />
                称呼设置为“李总”，发送文字“
                <a-button style="height: 25px">称呼一/昵称</a-button>
                ，新年好”<br />
                即可发送“李总，新年好” <br />此外<a-button style="height: 25px">称呼一/昵称</a-button>
                只对客户生效，对群不生效。
              </div>
            </template>
            <a-tag class="ant-tag-plain ant-tag-big" @click="handleTagClick(item)" v-if="item.value === 4">
              {{ item.label }}
            </a-tag>
          </a-tooltip>
          <a-tooltip placement="top" overlayClassName="bgc_tooltip">
            <template #title>
              <div>
                “客户管理”功能，可设置对好友的称呼，没有称呼将使用昵称 <br />举例：
                <br />称呼设置为“李总”，发送文字“
                <a-button style="height: 25px">称呼二/昵称</a-button>
                ，新年好” <br />即可发送“李总，新年好” <br />此外<a-button style="height: 25px"
                  >称呼二/昵称</a-button
                >
                只对客户生效，对群不生效。
              </div>
            </template>
            <a-tag class="ant-tag-plain ant-tag-big" @click="handleTagClick(item)" v-if="item.value === 5">
              {{ item.label }}
            </a-tag>
          </a-tooltip>
          <a-tooltip placement="top">
            <template #title>
              <span>@所有人 ，只对群生效，对客户不生效。</span>
            </template>
            <a-tag class="ant-tag-plain ant-tag-big" @click="handleTagClick(item)" v-if="item.value === 6">
              {{ item.label }}
            </a-tag>
          </a-tooltip>
        </template>
      </div>
      <div class="content">
        <a-form>
          <a-form-item v-bind="validateInfos.text">
            <RichEdtior
              ref="richRef"
              :style="richStyle"
              :toolbar="['image', 'tag']"
              :value="model.jsonContent"
              @imagePasted="handleImagePasted"
            />
          </a-form-item>
        </a-form>
      </div>
    </div>
    <template #footer>
      <div class="modal-footer jz-flex jz-flex-rb">
        <div class="left-extra">
          <a-checkbox v-if="props.segmentation" v-model:checked="state.is_section"
            >智能分段
            <a-tooltip placement="top">
              <template #title>
                <span>勾选后，文字会按段落拆分为多条。</span>
              </template>
              <question-circle-outlined />
            </a-tooltip>
          </a-checkbox>
        </div>
        <div class="right-extra">
          <a-button type="info" @click="onClose">取消</a-button>
          <a-button type="primary" :disabled="!richRef?.isNotEmpty" @click="handleConfirm">确定</a-button>
        </div>
      </div>
    </template>
  </a-modal>
</template>

<script setup>
import { cloneDeep, extend } from 'lodash-es'
import { randomUUID } from 'crypto'
import { Form } from 'ant-design-vue'
import { reactive, ref, defineExpose, toRaw, computed, toRef, unref, watch } from 'vue'
import SvgIcon from '@/components/SvgIcon/index.vue'
import { POSITIVE_ENERGY_EMOJIS } from '@/utils/emoji/emojiData'
import { MessageTypeEnum } from '@/enums/MessageTypeEnum'
import { uploadImage } from '@/api/common'
import { getTranformJSONContentToText, getTranformRemarkToJSONContent } from '@/utils/customer'

const props = defineProps({
  msgTags: {
    type: Array,
    default: () => []
  },
  segmentation:{
    type:Boolean,
    default: () => true
  }
})

const emit = defineEmits(['success'])
const modalRef = ref()
const richRef = ref()
const tags = ref([
  { label: '随机表情', value: 3 },
  { label: '称呼一/昵称', value: 4 },
  { label: '称呼二/昵称', value: 5 }
])
tags.value = [...tags.value, ...props.msgTags]

const visible = ref(false)
const state = reactive({
  model: {
    msg: {
      text: ''
    },
    jsonContent: null,
    msg_type: MessageTypeEnum.text,
    is_section: false
  },
  operType: null,
  isUpdate: false,
  imageUrl: '',
  uploading: false
})
const model = toRef(state, 'model')
const rules = ref({
  text: [{ reuqired: true, message: '请输入内容' }]
})

const { validate, resetFields, validateInfos } = Form.useForm(model, rules)

const richStyle = computed(() => {
  return {
    background: 'rgba(0, 0,0, 0.04)',
    height: '160px'
  }
})

const handleImagePasted = async ({ file }) => {
  const { data } = await uploadImage({ file })
  state.imageUrl = data.url
  unref(richRef).editorRef.chain().focus().setImage({ src: data.url }).run()
}

const handleConfirm = () => {
  validate().then(() => {
    let textList = []
    const raw = toRaw(model.value)
    raw.msg.text = getTranformJSONContentToText(unref(richRef).getJSON(), true)
    raw.msg.data = getRemoteData(unref(richRef).getJSON())
    //智能分段
    if (state.is_section || state.imageUrl) {
      // 获取分段文本
      const muilSections = getTextSection(cloneDeep(raw.msg.data))

      textList.push(
        ...muilSections.map((item) => {
          const jsonItems = item.slice()
          const textStr = jsonItems
            .reduce((strs, current) => {
              if (current.type === 2) {
                strs.push(`{${current.text}}`)
              } else {
                strs.push(current.text)
              }
              return strs
            }, [])
            .join('')
          return {
            msg: { data: item.slice(), text: textStr },
            msg_type: MessageTypeEnum.text,
            id: randomUUID()
          }
        })
      )
      if (state.imageUrl) {
        textList.push({
          ...raw,
          msg: { url: state.imageUrl },
          msg_type: MessageTypeEnum.image,
          id: randomUUID()
        })
      }
      emit('success', 'text', {
        isUpdate: state.isUpdate,
        operType: state.operType,
        data: textList
      })
      onClose()
      return
    }
    emit('success', 'text', {
      isUpdate: state.isUpdate,
      operType: state.operType,
      data: {
        ...raw,
        id: raw.id || randomUUID(),
        msg_type: MessageTypeEnum.text
      }
    })
    onClose()
  })
}

// 获取分段文本
const getTextSection = (originData) => {
  let index = 0
  const muilSections = []
  while (originData.length) {
    if (!muilSections[index]) {
      muilSections[index] = []
    }
    const item = originData.shift()
    muilSections[index].push({ ...item, newLine: undefined })
    if (item.newLine) {
      index++
    }
  }
  return muilSections
}

// 转换服务端数据格式
const getRemoteData = (jsonContent) => {
  const msgData = []
  const list = jsonContent.content ?? []
  list.forEach((item, index) => {
    if (item.type === 'paragraph') {
      const items = item.content ?? []
      items.map((row) => {
        if (row.type === 'text') {
          msgData.push({ type: 1, text: row.text })
        } else if (row.type === 'TagComponent') {
          msgData.push({ type: 2, text: row.attrs.text })
        }
      })
      msgData[msgData.length - 1].newLine = index < list.length - 1
    }
  })
  return msgData
}

const genTitle = computed(() => (state.isUpdate ? '编辑' : '添加') + '文本')

const handleTagClick = (tag) => {
  unref(richRef).editorRef.chain().focus().setTag(tag.label).run()
}

const handleSelectEmoji = (emoji) => {
  unref(richRef).editorRef.chain().focus().insertContent(emoji.html).run()
}

const onOpen = (params) => {
  visible.value = true
  state.operType = params.operType
  state.isUpdate = !!params.isUpdate
  state.model = extend({}, state.model, params?.data)
  state.model.jsonContent = getTranformRemarkToJSONContent(state.model.msg?.data)
}

const onClose = () => {
  visible.value = false
  state.isUpdate = false
  state.imageUrl = ''
  resetFields()
  model.value.is_section = false
  unref(richRef)?.editorRef?.chain().focus().clearContent()
  visible.value = false
}

defineExpose({
  modalRef: modalRef.value,
  closeModal: onClose,
  openModal: onOpen
})
</script>

<style lang="less" scoped>
.wrapper {
  .content {
    margin-top: 16px;
  }
  .rich-input {
    width: 100%;
    box-sizing: border-box;
    margin: 0;
    padding: 0;
    color: #000000d9;
    font-size: 14px;
    font-variant: tabular-nums;
    line-height: 1.5715;
    list-style: none;
    font-feature-settings: 'tnum';
    position: relative;
    display: inline-block;
    outline: 0;
    height: 160px;
    overflow-y: auto;
    background: rgba(0, 0, 0, 0.02);
    border: 1px solid @input-border-color;
    border-radius: @border-radius-base;
    transition: all 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);
    :deep(.ProseMirror) {
      outline: 0;
      padding: 12px;
    }
    &:after {
      display: inline-block;
      width: 0;
      margin: 2px 0;
      line-height: 24px;
      content: '\a0';
    }
    &:not(.rich-input-disabled):hover {
      border-color: #40a9ff;
      border-right-width: 1px;
    }
    &:not(.rich-input-disabled):focus {
      box-shadow: 0 0 0 2px rgb(24 144 255 / 20%);
      outline: 0;
    }
  }
  .emoji-icon {
    height: 32px !important;
    width: 32px !important;
    margin-right: 8px;
    cursor: pointer;
    &:hover {
      color: @primary-color;
    }
    &:focus {
      border: none !important;
      color: @primary-color;
    }
  }
}
.modal-footer {
  align-items: center;
  color: rgba(0, 0, 0, 0.2);
  .left-extra {
    :deep(.anticon-question-circle) {
      color: rgba(0, 0, 0, 0.4);
    }
  }
}
</style>
<style lang="less">
.ProseMirror {
  > * + * {
    margin-top: 4px;
  }
  p {
    margin-bottom: 0;
  }
}
.bgc_tooltip {
  .ant-tooltip-inner {
    width: 396px;
    line-height: 30px;
  }
}
</style>
