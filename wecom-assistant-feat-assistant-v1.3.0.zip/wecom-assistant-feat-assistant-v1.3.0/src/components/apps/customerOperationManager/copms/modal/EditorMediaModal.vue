<template>
  <a-modal
    ref="modalRef"
    v-model:visible="visible"
    centered
    destroyOnClose
    class="media-modal"
    @cancel="onClose"
    width="1200px"
  >
    <div class="wrapper" style="height: 590px">
      <div class="content jz-flex">
        <div class="left-content">
          <div class="head">素材库导入</div>
          <a-menu @click="changeMenu" class="menu-list" v-model:selectedKeys="current" mode="horizontal">
            <a-menu-item key="myself"> 我的素材 </a-menu-item>
            <a-menu-item key="group"> 团队素材 </a-menu-item>
          </a-menu>
          <div class="search-list">
            <a-input
              style="margin-right: 16px; width: 186px"
              class="keywork-search-input"
              v-model:value="searchParams.title"
              allowClear
              placeholder="请输入关键词"
            >
              <template #suffix>
                <svg-icon icon-name="ic_search" />
              </template>
            </a-input>
            <api-select
              style="margin-right: 16px; width: 186px"
              allowClear
              mode="multiple"
              v-model:value="searchParams.msg_type"
              :options="dictMap.media_msg_type"
              :replaceFields="dictFields"
              placeholder="请选择类型"
            />
            <a-cascader
              style="margin-right: 16px; width: 186px"
              v-if="isGroup"
              change-on-select
              v-model:value="searchParams.dept_ids"
              :field-names="{ label: 'name', value: 'id', children: 'child' }"
              :options="deptTree"
              placeholder="组织部门"
            />
          </div>
          <a-row
            v-if="state.list.length > 0"
            v-infinite-scroll="debounceSearch"
            :infinite-scroll-immediate-check="false"
            :infinite-scroll-disabled="state.isFinished"
            :infinite-scroll-watch-disabled="state.isFinished"
            :infinite-scroll-distance="10"
            class="media-list"
          >
            <a-col
              @click="selectItem(item, index)"
              :span="12"
              class="li-box"
              v-for="(item, index) in state.list.filter((i) => i.can_import)"
              :key="randomUUID()"
            >
              <div class="content-box" :class="isSelectIndex === index ? 'active' : ''" :key="item.id">
                <div class="content-box-header jz-flex jz-flex-rb">
                  <div class="content-box-header-title">
                    {{ item.title }}
                  </div>
                </div>
                <div class="content-box-main">
                  <div
                    class="content-box-item jz-flex jz-flex-cc"
                    v-for="(msgItem, msgIndex) in item.media_content"
                    :key="randomUUID()"
                  >
                    <div class="box-serial">{{ addZero(msgIndex + 1) }}</div>
                    <!--              消息类型 2文本，13链接，14图片，15文件，16语音，23视频，29gif动画，41名片，78小程序，141视频号-->
                    <!--文本类型-->
                    <div class="jz-flex-1 text-type" v-if="+msgItem.msg_type === 2">
                      {{ msgItem.msg.text }}
                    </div>
                    <!--图片类型-->
                    <div class="jz-flex-1 img-type" v-if="+msgItem.msg_type === 14">
                      <img :src="msgItem.msg.url" alt="" />
                    </div>
                    <!--视频类型-->
                    <div class="jz-flex-1 video-type" v-if="+msgItem.msg_type === 23">
                      <video :src="msgItem.msg.url"></video>
                      <svg-icon icon-name="ic_msg_video" />
                    </div>
                    <!--文件类型-->
                    <div class="jz-flex-1 file-type jz-flex jz-flex-cc" v-if="+msgItem.msg_type === 15">
                      <svg-icon icon-name="ic_msg_pdf" />
                      <span class="lineClamp1">{{ msgItem.msg.name }}</span>
                    </div>
                    <!--链接类型-->
                    <div class="link-type jz-flex jz-flex-cc jz-flex-col" v-if="+msgItem.msg_type === 13">
                      <div class="link-tit">{{ msgItem.msg.title }}</div>
                      <div class="desc jz-flex jz-flex-1">
                        <div class="desc-text jz-flex-1">{{ msgItem.msg.des }}</div>
                        <img :src="msgItem.msg.thumb_url" alt="" />
                      </div>
                    </div>
                    <!--小程序类型-->
                    <div class="wx-type jz-flex jz-flex-cc jz-flex-col" v-if="+msgItem.msg_type === 78">
                      <div class="logo-box jz-flex jz-flex-cc">
                        <img :src="msgItem.msg.icon_url" alt="" />
                        <span>{{ msgItem.msg.title }}</span>
                      </div>
                      <div class="wx-bg jz-flex-1 jz-flex jz-flex-center">
                        <img src="@/assets/imgs/wx.png" alt="" />
                      </div>
                      <span class="wx-name">小程序</span>
                    </div>
                    <!--语音类型-->
                    <div class="audio-type jz-flex jz-flex-cc" v-if="+msgItem.msg_type === 16">
                      <svg-icon icon-name="ic_msg_audio" />
                    </div>
                    <!--视频号类型-->
                    <div
                      class="wx-video-type jz-flex jz-flex-cc jz-flex-col"
                      v-if="+msgItem.msg_type === 141"
                    >
                      <div class="jz-flex-1 head">
                        <img :src="msgItem.msg.head_img_url" alt="" />
                        <svg-icon icon-name="ic_msg_video" />
                      </div>
                      <div class="wx-tit jz-flex jz-flex-cc">
                        <img src="@/assets/imgs/sph.png" alt="" /> 简知科技
                      </div>
                    </div>
                  </div>
                </div>
                <div class="content-box-footer jz-flex jz-flex-rb">
                  <div>{{ item.create_time }}</div>
                  <div>共 {{ item.media_content.length }} 条</div>
                </div>
              </div>
            </a-col>
          </a-row>
          <div v-else class="content-none">
            <img src="@/assets/imgs/jz_none.png" alt="" />
            <div>无内容</div>
          </div>
        </div>

        <template v-if="state.list.length > 0">
          <div v-if="isSelect" class="right-content jz-flex-rb">
            <div>
              <div class="right-content-header">
                <div class="right-content-header-left">预览-{{ selectData.title }}</div>
              </div>
            </div>
            <div class="right-content-main">
              <div
                class="jz-flex jz-flex-cc"
                style="margin-bottom: 12px"
                v-for="(msgItem, msgIndex) in selectData.media_content"
                :key="randomUUID()"
              >
                <a-checkbox v-model:checked="msgItem.check" />
                <div class="right-content-main-box">
                  <div class="box-serial">{{ addZero(msgIndex + 1) }}</div>
                  <!--              消息类型 2文本，13链接，14图片，15文件，16语音，23视频，29gif动画，41名片，78小程序，141视频号-->
                  <!--文本类型-->
                  <div class="jz-flex-1 text-type" v-if="+msgItem.msg_type === 2">
                    {{ msgItem.msg.text }}
                  </div>
                  <!--图片类型-->
                  <div class="jz-flex-1 img-type" v-if="+msgItem.msg_type === 14">
                    <img :src="msgItem.msg.url" alt="" />
                  </div>
                  <!--视频类型-->
                  <div class="jz-flex-1 video-type" v-if="+msgItem.msg_type === 23">
                    <video :src="msgItem.msg.url"></video>
                    <svg-icon icon-name="ic_msg_video" />
                  </div>
                  <!--文件类型-->
                  <div class="jz-flex-1 file-type jz-flex jz-flex-cc" v-if="+msgItem.msg_type === 15">
                    <svg-icon icon-name="ic_msg_pdf" />
                    <span class="lineClamp1">{{ msgItem.msg.name }}</span>
                  </div>
                  <!--链接类型-->
                  <div class="link-type jz-flex jz-flex-cc jz-flex-col" v-if="+msgItem.msg_type === 13">
                    <div class="link-tit">{{ msgItem.msg.title }}</div>
                    <div class="desc jz-flex jz-flex-1">
                      <div class="desc-text jz-flex-1">{{ msgItem.msg.des }}</div>
                      <img :src="msgItem.msg.thumb_url" alt="" />
                    </div>
                  </div>
                  <!--小程序类型-->
                  <div class="wx-type jz-flex jz-flex-cc jz-flex-col" v-if="+msgItem.msg_type === 78">
                    <div class="logo-box jz-flex jz-flex-cc">
                      <img :src="msgItem.msg.icon_url" alt="" />
                      <span>{{ msgItem.msg.title }}</span>
                    </div>
                    <div class="wx-bg jz-flex-1 jz-flex jz-flex-center">
                      <img src="@/assets/imgs/wx.png" alt="" />
                    </div>
                    <span class="wx-name">小程序</span>
                  </div>
                  <!--语音类型-->
                  <div class="audio-type jz-flex jz-flex-cc" v-if="+msgItem.msg_type === 16">
                    <svg-icon icon-name="ic_msg_audio" />
                  </div>
                  <!--视频号类型-->
                  <div class="wx-video-type jz-flex jz-flex-cc jz-flex-col" v-if="+msgItem.msg_type === 141">
                    <div class="jz-flex-1 head">
                      <img :src="msgItem.msg.head_img_url" alt="" />
                      <svg-icon icon-name="ic_msg_video" />
                    </div>
                    <div class="wx-tit jz-flex jz-flex-cc">
                      <img src="@/assets/imgs/sph.png" alt="" /> 简知科技
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div v-else class="right-content jz-flex-rb"></div>
        </template>
      </div>
    </div>
    <template #footer>
      <div class="modal-footer jz-flex jz-flex-rb">
        <div>已选 {{ isSelectLength }}</div>
        <div class="right-extra">
          <a-button type="info" @click="onClose">取消</a-button>
          <a-button type="info" :disabled="isSelectLength === 0" @click="importMedia(0)">导入并继续</a-button>
          <a-button type="primary" :disabled="isSelectLength === 0" @click="importMedia(1)">导入</a-button>
        </div>
      </div>
    </template>
  </a-modal>
</template>

<script setup>
import { extend } from 'lodash-es'
import { randomUUID } from 'crypto'
import { Form } from 'ant-design-vue'
import { reactive, ref, defineExpose, computed, toRef, unref, watch } from 'vue'
import { MessageTypeEnum } from '@/enums/MessageTypeEnum'
import { getMediaList } from 'api/material'
import { dictStore } from '@/store/modules/dict'
import { getDeptTreeApi } from 'api/common'
import { debounce } from 'lodash-es'
import useMessage from '@/composables/web/useMessage'

const { createMessage } = useMessage()

const emit = defineEmits(['success'])
const modalRef = ref()

const props = defineProps({
  media_length: Number,
  importPage: String,
  canImportNum: {
    type: Number,
    default: 20
  }
})

const visible = ref(false)
const state = reactive({
  model: {
    msg: {
      text: ''
    },
    msg_type: MessageTypeEnum.text
  },

  operType: null,
  isUpdate: false,
  imageUrl: '',
  tagList: [],
  is_section: false,
  uploading: false,

  // ========
  list: [],
  isFinished: false,
  page: 1,
  count: 0,
  loading: false
})
const model = toRef(state, 'model')
const rules = ref({
  text: [{ reuqired: true, message: '请输入内容' }]
})

// =======================
const isSelect = ref(false)
const isSelectLength = computed(() => {
  return unref(selectData).media_content.filter((i) => i.check).length
})
const current = ref(['myself'])
const isGroup = computed(() => current.value.some((item) => item === 'group'))
const isSelectIndex = ref(null)
const selectData = ref({
  media_content: []
})
const changeMenu = () => {
  isSelect.value = false
  isSelectIndex.value = null
  selectData.value = {
    media_content: []
  }
  searchParams.dept_id = null
  searchParams.dept_ids = []
}
const searchParams = reactive({
  title: '',
  type: null,
  msg_type: [],
  dept_id: null,
  dept_ids: [],
  page: 1,
  limit: 1000
})
//获取素材列表
const getMediaListData = async () => {
  if (state.isFinished) return false
  state.loading = true
  let { code, data } = await getMediaList({
    title: searchParams.title,
    type: isGroup.value ? 2 : 1,
    msg_type: searchParams.msg_type,
    dept_id: searchParams.dept_ids ? searchParams.dept_ids[searchParams.dept_ids.length - 1] : null,
    page: state.page,
    limit: 10
  })
  if (code === 1000) {
    data.data.forEach((item) => {
      item.visible = false
    })
    if (data.data.length) {
      state.list = [...state.list, ...data.data]
      state.page += 1
    } else {
      state.isFinished = true
    }
  }
}
//数字前补零
const addZero = (num) => {
  if (num < 10) {
    return '0' + num
  } else {
    return num
  }
}

const selectItem = async (item, index) => {
  isSelect.value = true
  isSelectIndex.value = index

  item.media_content.forEach((i) => (i.check = true))
  selectData.value = item
}

const store = dictStore()
const dictMap = toRef(store, 'dictMap')
store.tryFetchData()
const dictFields = computed(() => ({ label: 'val', value: 'key' }))

const deptTree = ref([])
const getDeptTree = async () => {
  let { code, data } = await getDeptTreeApi()
  if (code === 1000) {
    deptTree.value = data
  }
}
const debounceSearch = debounce(getMediaListData, 350)

watch(
  () => searchParams,
  () => {
    state.isFinished = false
    state.list = []
    state.page = 1
    debounceSearch()
  },
  {
    deep: true
  }
)

const importMedia = (type) => {
  let selectMediaData = unref(selectData).media_content.filter((i) => i.check)

  //
  // if (
  //   props.media_length + isSelectLength.value >
  //   (props.canImportNum === 9 ? props.canImportNum+1 : props.canImportNum )
  // ) {
  //   createMessage.error(`添加素材内容最多不超过${props.canImportNum}条`)
  //   return
  // }

  //判断是极速群发页面调用
  if (props.importPage === 'rapidMass') {
    //已添加文本信息
    if (props.canImportNum === 9) {
      if (
        props.media_length -
          1 +
          unref(selectData).media_content.filter((i) => i.check && i.msg_type !== 2).length >
        props.canImportNum
      ) {
        createMessage.error(`添加多媒体素材内容最多不超过${props.canImportNum}条`)
        return
      }

      if (unref(selectData).media_content.filter((i) => i.check && i.msg_type === 2).length > 0) {
        createMessage.error(`文本内容已添加，请勿重复添加`)
        return
      }
    } else if (props.canImportNum === 10) {
      if (
        props.media_length +
          unref(selectData).media_content.filter((i) => i.check && i.msg_type !== 2).length >
        props.canImportNum
      ) {
        createMessage.error(`添加多媒体素材内容最多不超过${props.canImportNum}条`)
        return
      }
      if (unref(selectData).media_content.filter((i) => i.check && i.msg_type === 2).length > 1) {
        createMessage.error(`文本内容只能添加一条`)
        return
      }
    }
  } else {
    if (props.media_length + isSelectLength.value > props.canImportNum) {
      createMessage.error(`添加素材内容最多不超过${props.canImportNum}条`)
      return
    }
  }

  emit('success', selectMediaData)
  if (type === 1) {
    onClose()
  }
}
// =======================

const { resetFields } = Form.useForm(model, rules)

const media_length = ref(0) //当前素材长度
const media_default_length = ref(0) //默认素材长度
const onOpen = (params) => {
  media_default_length.value = params.media_length
  media_length.value = 0
  visible.value = true
  state.operType = params.operType
  state.isUpdate = !!params.isUpdate
  state.model = extend({}, state.model, params?.data)
  state.tagList = getTextTags()
  state.model.msg.text = getPlainText()

  getMediaListData()
  getDeptTree()
}

const getPlainText = () => state.model.msg?.text?.replace(/{(.*)}/gi, '') ?? ''

const getTextTags = () => {
  let match = Array.from(state.model?.msg?.text?.match?.(/{(.*?)}/gi) ?? [])
  return match.map((text) => text.replace(/^\{/, '').replace(/\}$/, ''))
}

const onClose = () => {
  visible.value = false
  state.isUpdate = false
  state.imageUrl = ''
  state.is_section = false
  state.tagList = []
  resetFields()

  isSelect.value = false
  isSelectIndex.value = null
  selectData.value = {
    media_content: []
  }
}

defineExpose({
  modalRef: modalRef.value,
  closeModal: onClose,
  openModal: onOpen
})
</script>

<style lang="less" scoped>
.media-modal {
  :deep(.ant-modal-body) {
    padding: 0 32px;
    background-color: black;
  }
}

.wrapper {
  .content {
    height: 100%;
    width: 100%;
    display: flex;

    .left-content {
      flex: 1;
      display: flex;
      flex-direction: column;

      .head {
        margin: 24px 0;
        padding: 0 32px;
        font-weight: 550;
        color: rgba(0, 0, 0, 0.9);
        font-size: 16px;
      }

      .search-list {
        display: flex;
        padding: 0 32px;
        margin: 16px 0 0 0;
      }
      .ant-menu {
        margin-left: 32px;

        :deep(.ant-menu-item) {
          padding-left: 0px;
          margin-right: 60px;
          color: #999999;
          &:hover {
            color: #3165f5;
          }
          &::after {
            left: 0px;
          }
          &:hover {
            &::after {
              border-bottom: 2px solid transparent;
            }
          }
        }
        :deep(.ant-menu-item-selected) {
          &:hover {
            &::after {
              border-bottom: 2px solid #3165f5;
            }
          }
          .ant-menu-title-content {
            color: #3165f5;
          }
        }
      }

      .media-list {
        display: flex;
        flex-wrap: wrap;
        overflow: auto;
        flex: 1;
        padding: 8px 24px 16px 24px;

        // 修改滚动条
        &:hover {
          &::-webkit-scrollbar-thumb {
            visibility: visible;
          }
        }
        &::-webkit-scrollbar {
          width: 2px;
        }
        &::-webkit-scrollbar-thumb {
          visibility: hidden;
          transition: all 0.28s;
        }

        .li-box {
          padding: 8px;

          .content-box {
            background: #ffffff;
            box-shadow: 0px 0px 8px 0px rgba(0, 0, 0, 0.05);
            border-radius: 12px 12px 12px 12px;
            opacity: 1;
            border: 1px solid #eeeeee;
            transition: all 0.2s;
            &:hover {
              cursor: pointer;
              box-shadow: 0px 12px 48px 0px rgba(0, 0, 0, 0.15);
            }

            .content-box-header {
              color: rgba(0, 0, 0, 0.9);
              font-weight: 550;
              padding: 16px;
              height: 60px;

              .content-box-header-title {
                width: 174px;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
              }

              .content-box-header-tool {
                white-space: nowrap;
              }
            }

            .content-box-main {
              padding: 8px 16px 16px 16px;
              overflow: hidden;
              height: 140px;

              .content-box-item {
                margin-bottom: 12px;
                font-size: 14px;

                .box-serial {
                  font-size: 12px;
                  font-weight: 400;
                  color: #999999;
                  line-height: 14px;
                  background: #eeeeee;
                  width: 24px;
                  height: 24px;
                  display: flex;
                  justify-content: center;
                  align-items: center;
                  border-radius: 50%;
                  margin-right: 16px;
                }

                .text-type {
                  color: #000;
                  font-size: 12px;
                }

                .img-type {
                  img {
                    width: 48px;
                    height: 48px;
                    border-radius: 4px;
                  }
                }

                .video-type {
                  position: relative;

                  > video {
                    width: 48px;
                    height: 32px;
                    object-fit: cover;
                  }

                  .svg-icon {
                    position: absolute;
                    left: 15px;
                    top: 10px;
                    color: #fff;
                    width: 16px !important;
                    height: 16px !important;
                  }
                }

                .file-type {
                  .svg-icon {
                    width: 20px !important;
                    height: 20px !important;
                    min-width: 20px;
                    min-height: 20px;
                    margin-right: 4px;
                  }
                }

                .link-type {
                  width: 90px;
                  height: 42px;
                  background: #eee;
                  position: relative;
                  padding: 5px;
                  border-radius: 4px;

                  &::before {
                    content: '';
                    width: 0;
                    height: 0;
                    left: -7px;
                    top: 10px;
                    position: absolute;
                    border-right: 5px solid transparent;
                    border-left: 5px solid transparent;
                    border-bottom: 5px solid #eee;
                    transform: rotate(-90deg);
                  }

                  .link-tit {
                    font-size: 6px;
                    color: #000;
                    display: -webkit-box;
                    -webkit-box-orient: vertical;
                    -webkit-line-clamp: 2;
                    overflow: hidden;
                    line-height: 7px;
                    text-align: left;
                    width: 100%;
                  }

                  .desc {
                    width: 100%;

                    &-text {
                      font-size: 5px;
                      color: @font-minor-color;
                      overflow: hidden;
                    }

                    img {
                      width: 18px;
                      height: 18px;
                    }
                  }
                }

                .wx-type {
                  width: 90px;
                  height: 100px;
                  background: #eee;
                  position: relative;
                  padding: 5px;
                  border-radius: 4px;

                  &::before {
                    content: '';
                    width: 0;
                    height: 0;
                    left: -7px;
                    top: 10px;
                    position: absolute;
                    border-right: 5px solid transparent;
                    border-left: 5px solid transparent;
                    border-bottom: 5px solid #eee;
                    transform: rotate(-90deg);
                  }

                  .logo-box {
                    width: 100%;
                    font-size: 4px;
                    color: @font-minor-color;
                    margin-bottom: 2px;

                    img {
                      width: 8px;
                      height: 8px;
                      border-radius: 50%;
                      margin-right: 5px;
                    }
                  }

                  .wx-bg {
                    width: 100%;
                    height: 60px;

                    img {
                      width: 30px;
                      height: 30px;
                    }
                  }

                  .wx-name {
                    font-size: 6px;
                    margin-top: 3px;
                    display: block;
                    width: 100%;
                    display: flex;
                  }
                }

                .audio-type {
                  .svg-icon {
                    width: 58px !important;
                    height: 24px !important;
                  }
                }

                .voice-type {
                  width: 58px;
                  height: 24px;
                  background: #eeeeee;
                  border-radius: 4px;
                }

                .wx-video-type {
                  width: 83px;
                  height: 110px;
                  position: relative;
                  border-radius: 4px;
                  background: #eeeeee linear-gradient(360deg, rgba(0, 0, 0, 0.5) 0%, rgba(0, 0, 0, 0) 100%);

                  .head {
                    width: 100%;
                    height: 100%;
                    position: relative;

                    .svg-icon {
                      width: 16px !important;
                      height: 16px !important;
                      left: 50%;
                      top: 50%;
                      position: absolute;
                      color: #fff;
                      margin-left: -8px;
                    }

                    img {
                      width: 100%;
                      height: 100%;
                      border-radius: 4px;
                    }
                  }

                  .wx-tit {
                    font-size: 6px;
                    color: #fff;
                    position: absolute;
                    left: 0;
                    bottom: 0px;
                    right: 0;
                    padding-left: 4px;

                    img {
                      width: 10px;
                      height: 10px;
                      margin-right: 3px;
                    }
                  }
                }
              }
            }

            .content-box-footer {
              font-weight: 400;
              color: #999999;
              line-height: 16px;
              font-size: 14px;
              border-top: 1px solid #f5f5f5;
              padding: 16px;
            }
          }

          .active {
            border: 1px solid #3165f5;
          }
        }
      }

      .content-none {
        height: 665px;
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;

        > div {
          font-weight: 400;
          color: #999999;
          font-size: 12px;
          margin-top: 2px;
        }

        img {
          width: 110px;
          height: 110px;
        }
      }
    }

    .right-content {
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      height: 100%;
      width: 400px;
      padding: 24px 32px 0 32px;
      border-left: 1px solid #eeeeee;

      .right-content-header {
        display: flex;
        //margin-top: 32px;
        margin-bottom: 8px;
        justify-content: space-between;
        align-items: center;
        padding: 0 0 16px 0;

        .right-content-header-left {
          font-size: 20px;
          font-weight: 550;
          color: #000000;
          line-height: 23px;
        }

        .right-content-header-right {
          font-weight: 400;
          color: #3165f5;
          font-size: 14px;
        }
      }

      .right-content-describe {
        .describe-creatInfo {
          font-weight: 400;
          color: #999999;
          line-height: 16px;
          font-size: 14px;
          display: flex;
          align-items: center;

          > span {
            margin-right: 24px;
          }

          &:last-child {
            margin-top: 6px;
          }
        }
      }

      .describe-line {
        height: 1px;
        background-color: #eeeeee;
        margin: 16px 0;
      }

      .right-content-main {
        flex: 1;
        overflow: auto;

        .right-content-main-box {
          flex: 1;
          margin-left: 8px;
          background: #f5f5f5;
          border-radius: 6px 6px 6px 6px;
          padding: 12px;
          display: flex;

          .box-serial {
            font-size: 12px;
            font-weight: 400;
            color: #999999;
            line-height: 14px;
            background: #eeeeee;
            width: 24px;
            height: 24px;
            display: flex;
            justify-content: center;
            align-items: center;
            border-radius: 50%;
            margin-right: 16px;
          }

          .text-type {
            color: #000;
            font-size: 12px;
          }

          .img-type {
            img {
              width: 120px;
              height: 120px;
              border-radius: 4px;
            }
          }

          .video-type {
            position: relative;

            > video {
              width: 120px;
              height: 120px;
              object-fit: cover;
              border-radius: 4px;
            }

            .svg-icon {
              position: absolute;
              left: 15px;
              top: 10px;
              color: #fff;
              width: 16px !important;
              height: 16px !important;
            }
          }

          .file-type {
            .svg-icon {
              width: 20px !important;
              height: 20px !important;
              min-width: 20px;
              min-height: 20px;
              margin-right: 4px;
            }
          }

          .link-type {
            width: 90px;
            height: 42px;
            background: #eee;
            position: relative;
            padding: 5px;
            border-radius: 4px;

            &::before {
              content: '';
              width: 0;
              height: 0;
              left: -7px;
              top: 10px;
              position: absolute;
              border-right: 5px solid transparent;
              border-left: 5px solid transparent;
              border-bottom: 5px solid #eee;
              transform: rotate(-90deg);
            }

            .link-tit {
              font-size: 6px;
              color: #000;
              display: -webkit-box;
              -webkit-box-orient: vertical;
              -webkit-line-clamp: 2;
              overflow: hidden;
              line-height: 7px;
              text-align: left;
              width: 100%;
            }

            .desc {
              width: 100%;

              &-text {
                font-size: 5px;
                color: @font-minor-color;
                overflow: hidden;
              }

              img {
                width: 18px;
                height: 18px;
              }
            }
          }

          .wx-type {
            width: 90px;
            height: 100px;
            background: #eee;
            position: relative;
            padding: 5px;
            border-radius: 4px;

            &::before {
              content: '';
              width: 0;
              height: 0;
              left: -7px;
              top: 10px;
              position: absolute;
              border-right: 5px solid transparent;
              border-left: 5px solid transparent;
              border-bottom: 5px solid #eee;
              transform: rotate(-90deg);
            }

            .logo-box {
              width: 100%;
              font-size: 4px;
              color: @font-minor-color;
              margin-bottom: 2px;

              img {
                width: 8px;
                height: 8px;
                border-radius: 50%;
                margin-right: 5px;
              }
            }

            .wx-bg {
              width: 100%;
              height: 60px;

              img {
                width: 30px;
                height: 30px;
              }
            }

            .wx-name {
              font-size: 6px;
              margin-top: 3px;
              display: block;
              width: 100%;
              display: flex;
            }
          }

          .audio-type {
            .svg-icon {
              width: 58px !important;
              height: 24px !important;
            }
          }

          .voice-type {
            width: 58px;
            height: 24px;
            background: #eeeeee;
            border-radius: 4px;
          }

          .wx-video-type {
            width: 83px;
            height: 110px;
            position: relative;
            border-radius: 4px;
            background: #eeeeee linear-gradient(360deg, rgba(0, 0, 0, 0.5) 0%, rgba(0, 0, 0, 0) 100%);

            .head {
              width: 100%;
              height: 100%;
              position: relative;

              .svg-icon {
                width: 16px !important;
                height: 16px !important;
                left: 50%;
                top: 50%;
                position: absolute;
                color: #fff;
                margin-left: -8px;
              }

              img {
                width: 100%;
                height: 100%;
                border-radius: 4px;
              }
            }

            .wx-tit {
              font-size: 6px;
              color: #fff;
              position: absolute;
              left: 0;
              bottom: 0px;
              right: 0;
              padding-left: 4px;

              img {
                width: 10px;
                height: 10px;
                margin-right: 3px;
              }
            }
          }

          .box-content {
            flex: 1;
            font-weight: 400;
            color: #000000;
            line-height: 22px;
            font-size: 14px;
          }
        }
      }

      .right-content-footer {
        display: flex;
        justify-content: flex-end;
        padding: 16px 0;

        button {
          margin-left: 10px;
        }
      }
    }
  }
}

.modal-footer {
  align-items: center;
}
</style>
<style lang="less">
.media-modal {
  .ant-modal-body {
    padding: 0;
  }
  .ant-modal-footer {
    border-top: 1px solid #eeeeee;
  }
  .ant-modal-close {
    right: 12px;
  }
}
</style>
