<!-- eslint-disable indent -->
<template>
  <a-modal
    v-model:visible="visible"
    centered
    destroyOnClose
    :title="genTitle"
    class="text-modal"
    @cancel="onClose"
  >
    <div class="wrapper">
      <div class="tip-box jz-flex jz-flex-cc">
        <exclamation-circle-filled style="color: #ed7b2f; font-size: 17px" />
        <div style="color: #ed7b2f; margin-left: 9px">群公告只对“客户群”生效，不会对“客户”发送。</div>
      </div>
      <div class="content">
        <a-form>
          <a-form-item>
            <a-textarea
              placeholder="请输入文字"
              style="height: 160px; resize: none"
              v-model:value="state.desc"
              :maxlength="500"
            />
          </a-form-item>
        </a-form>
        <div style="color: #999">{{ state.desc.length }} / 500</div>
      </div>
    </div>
    <template #footer>
      <div class="modal-footer jz-flex jz-flex-rb">
        <div class="left-extra"></div>
        <div class="right-extra">
          <a-button type="info" @click="onClose">取消</a-button>
          <a-button type="primary" :disabled="!state.desc.length" @click="handleConfirm">确定</a-button>
        </div>
      </div>
    </template>
  </a-modal>
</template>

<script setup>
import { randomUUID } from 'crypto'
import { reactive, ref, defineExpose, computed, toRef } from 'vue'
import { MessageTypeEnum } from '@/enums/MessageTypeEnum'

const emit = defineEmits(['success'])

const visible = ref(false)
const state = reactive({
  desc: '',
  model: {
    msg: {
      desc: ''
    },
    jsonContent: null,
    msg_type: MessageTypeEnum.acement,
    is_section: false
  },
  operType: null,
  isUpdate: false
})
const model = toRef(state, 'model')

const handleConfirm = () => {
  let params = {
    icon: 'acement',
    key: 50001,
    label: '群公告',
    msg_type: 50001,
    id: randomUUID(),
    msg: {
      desc: state.desc,
      data: [
        {
          desc: state.desc,
          type: 1,
          newLine: false
        }
      ]
    }
  }
  emit('success', 'acement', {
    isUpdate: state.isUpdate,
    operType: state.operType,
    data: { ...params }
  })
  onClose()
}

const genTitle = computed(() => (state.isUpdate ? '编辑' : '添加') + '群公告')

const onOpen = (params) => {
  visible.value = true
  state.operType = params.operType
  state.isUpdate = !!params.isUpdate
  state.desc = state.isUpdate ? params.data.msg.desc : ''
}

const onClose = () => {
  visible.value = false
  state.isUpdate = false
  model.value.is_section = false
  visible.value = false
}

defineExpose({
  closeModal: onClose,
  openModal: onOpen
})
</script>

<style lang="less" scoped>
.wrapper {
  .content {
    margin-top: 16px;
  }
}
.modal-footer {
  align-items: center;
  color: rgba(0, 0, 0, 0.2);
  .left-extra {
    :deep(.anticon-question-circle) {
      color: rgba(0, 0, 0, 0.4);
    }
  }
}
:deep(.ant-form-item) {
  margin-bottom: 0px;
}
</style>
<style lang="less">
.ProseMirror {
  > * + * {
    margin-top: 4px;
  }
  p {
    margin-bottom: 0;
  }
}
.bgc_tooltip {
  .ant-tooltip-inner {
    width: 396px;
    line-height: 30px;
  }
}
</style>
