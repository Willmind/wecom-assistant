<template>
  <a-modal
    ref="modalRef"
    v-model:visible="visible"
    centered
    destroyOnClose
    :title="genTitle"
    :okButtonProps="{
      disabled: state.uploading
    }"
    class="link-modal"
    @ok="handleConfirm"
    @cancel="onClose"
  >
    <div class="wrapper">
      <a-form class="editor-form" layout="vertical">
        <a-form-item label="标题" v-bind="validateInfos.title">
          <a-input v-model:value="modelRef.title" placeholder="请输入标题" />
        </a-form-item>
        <a-form-item label="链接" v-bind="validateInfos.url">
          <a-input v-model:value="modelRef.url" placeholder="请输入链接" />
        </a-form-item>
        <a-form-item label="描述" v-bind="validateInfos.des">
          <a-input v-model:value="modelRef.des" placeholder="请输入描述" />
        </a-form-item>
        <a-form-item v-bind="validateInfos.thumb_url" style="margin-bottom: 0">
          <a-upload
            accept="image/*"
            :maxCount="1"
            list-type="picture-card"
            class="custom-upload"
            v-model:file-list="state.fileList"
            :disabled="state.uploading"
            :beforeUpload="handleBeforeUpload"
            @preview="() => setShowPreview(true)"
          >
            <div v-if="!state.fileList.length">
              <loading-outlined v-if="state.uploading" />
              <plus-outlined v-else />
              <div class="ant-upload-text">上传图片</div>
            </div>
          </a-upload>
        </a-form-item>
      </a-form>
    </div>
    <!--    <a-image :src="modelRef.thumb_url" :width="300" :preview="previewOptions" style="display: none" />-->
  </a-modal>
</template>

<script setup>
import { Form } from 'ant-design-vue'
import { uploadImage } from '@/api/common'
import useMessage from '@/composables/web/useMessage'
import { computed, reactive, ref, toRefs, unref } from 'vue'
import { randomUUID } from 'crypto'
import { MessageTypeEnum } from '@/enums/MessageTypeEnum'
import { cloneDeep } from 'lodash-es'

const useForm = Form.useForm
const emit = defineEmits(['success'])

const state = reactive({
  model: {
    msg: {
      title: '',
      url: '',
      des: '',
      thumb_url: ''
    },
    msg_type: MessageTypeEnum.link
  },
  operType: null,
  isUpdate: false,
  uploading: false,
  fileList: []
})
const showPreview = ref(false)
const { msg: modelRef } = toRefs(state.model)
const modalRef = ref()

const rulesRef = ref({
  title: [{ required: true, message: '请输入标题' }],
  // url: [{ required: true, message: '请输入链接' }],
  // des: [{ required: true, message: '请输入描述' }],
  thumb_url: [{ required: true, message: '请上传图片' }]
})

const previewOptions = computed(() => ({ visible: showPreview.value, onVisibleChange: setShowPreview }))

const { createMessage } = useMessage()

const { validateInfos, validate, resetFields } = useForm(modelRef, rulesRef)
const genTitle = computed(() => (state.isUpdate ? '编辑' : '添加') + '链接')
const visible = ref(false)

const handleBeforeUpload = (file) => {
  if (!/image/i.test(file.type)) {
    createMessage.warning('请上传图片')
    return false
  } else if (file.size > 10 * 1024 * 1024) {
    createMessage.warning('图片大小不能超过10M')
    return false
  }
  // 上传
  state.uploading = true
  uploadImage({ file: file })
    .then((res) => {
      createMessage.success('上传成功')
      modelRef.value.thumb_url = res.data?.url
      state.uploading = false
    })
    .catch(() => {
      state.fileList.pop()
      state.uploading = false
    })
  return false
}

const setShowPreview = (show) => {
  showPreview.value = show
}

const handleConfirm = () => {
  validate().then(() => {
    emit('success', 'link', {
      isUpdate: state.isUpdate,
      operType: state.operType,
      data: {
        ...cloneDeep(state.model),
        id: unref(modelRef).id || randomUUID()
      }
    })
    onClose()
  })
}

const onClose = () => {
  resetFields()
  state.isUpdate = false
  state.uploading = false
  visible.value = false
  state.fileList = []
}

const onOpen = (params) => {
  visible.value = true
  state.isUpdate = !!params.isUpdate
  state.operType = params.operType
  state.model = Object.assign({}, state.model, params?.data || {})
  modelRef.value = state.model?.msg || {}
  if (modelRef.value.thumb_url) {
    state.fileList = [{ thumbUrl: modelRef.value.thumb_url }]
  }
}

defineExpose({
  modalRef: modalRef.value,
  closeModal: onClose,
  openModal: onOpen
})
</script>

<style lang="less" scoped>
.wrapper {
  padding: 24px 0 0 0;
  .content {
    margin-top: 16px;
  }
  :deep(.custom-upload) {
    .ant-upload.ant-upload-select-picture-card {
      border: none;
      border-radius: 6px;
    }
    .anticon-plus,
    .ant-upload-text {
      color: rgba(0, 0, 0, 0.4);
    }
  }
  .editor-form {
    padding: 0;
    :deep(.ant-form-item) {
      margin-bottom: 16px;
    }
  }
}

.modal-footer {
  height: 64px;
  align-items: center;
  color: rgba(0, 0, 0, 0.2);
}
</style>
<style lang="less">
.link-modal {
  .ant-modal-body {
    padding-bottom: 0;
  }
}
</style>
