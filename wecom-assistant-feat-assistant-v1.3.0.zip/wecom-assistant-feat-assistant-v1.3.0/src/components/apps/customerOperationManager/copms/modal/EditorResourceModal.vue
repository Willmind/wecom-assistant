<template>
  <a-modal
    ref="modalRef"
    v-model:visible="visible"
    centered
    destroyOnClose
    :keyboard="false"
    :maskClosable="false"
    :title="genTitle"
    :okButtonProps="{
      disabled: state.getting
    }"
    class="resource-modal"
    @cancel="onClose"
    @ok="handleConfirm"
  >
    <div class="wrapper">
      <div class="topic">
        <p>请在企业微信手机客户端将{{ state.title }}发送给自己，即可获取。</p>
        <p class="alert-desc">
          <exclamation-circle-filled />
          <span>{{ state.title }}存在过期风险，推荐三天内完成群发。</span>
        </p>
      </div>
      <div class="content">
        <div class="area-input jz-flex jz-flex-center">
          <template v-if="state.isGetMsg && model.msg && +model.msg_type">
            <MessageCardWithType :item="model" :msg-type="model.msg_type" />
          </template>
          <p v-else>请保持当前弹窗不关闭。</p>
        </div>
      </div>
    </div>
  </a-modal>
</template>

<script setup>
import { randomUUID } from 'crypto'
import { extend } from 'lodash-es'
import { getChatUpload } from '@/api/customerOperationManager'
import { reactive, ref, unref, toRef, toRaw } from 'vue'
import { MessageTypeEnum as TypeEnum } from '@/enums/MessageTypeEnum'
import useMessage from '@/composables/web/useMessage'

const emit = defineEmits(['success'])

const modalRef = ref()
const visible = ref(false)
const state = reactive({
  model: {
    msg: {}
  },
  title: '',
  // 是否获取消息
  isGetMsg: false,
  //获取中
  getting: true,
  operType: null,
  isUpdate: false
})

const { createMessage } = useMessage()

const model = toRef(state, 'model')
const genTitle = computed(() => (state.isUpdate ? '编辑' : '添加') + state.title)

const handleConfirm = () => {
  emit('success', TypeEnum[unref(model).msg_type], {
    isUpdate: state.isUpdate,
    operType: state.operType,
    data: { ...toRaw(unref(model)), id: unref(model).id || randomUUID() }
  })
  onClose()
}

const { run, clearTimer } = useTimer(pollReceiveMsg)

function useTimer(fn, time = 2000, immediate = true) {
  let timer = null

  function run() {
    if (immediate) {
      fn()
      immediate = false
    }
    timer = setTimeout(() => {
      fn()
      run()
    }, time)
  }

  const clear = () => {
    timer && clearTimeout(timer)
    timer = null
  }
  return {
    run,
    clearTimer: clear
  }
}

async function pollReceiveMsg() {
  try {
    if (state.isGetMsg) return

    state.getting = true
    const { data } = await getChatUpload({ msg_type: unref(model).msg_type })
    if (+data.status === 1) {
      clearTimer()
      model.value.msg = data.msg || {}
      state.getting = false
      state.isGetMsg = true
      createMessage.success(`收到一条${state.title}消息`)
    }
  } catch (error) {}
}

const onOpen = (params = {}) => {
  visible.value = true
  state.operType = params.operType
  state.isUpdate = !!params.isUpdate
  state.title = params.title
  state.model = extend({}, state.model, params?.data || { msg: {} })
  run()
}

const onClose = () => {
  clearTimer()
  state.isUpdate = false
  state.model.msg = {}
  state.isGetMsg = false
  visible.value = false
}

defineExpose({
  modalRef: modalRef.value,
  closeModal: onClose,
  openModal: onOpen
})
</script>

<style lang="less" scoped>
.wrapper {
  .alert-desc {
    color: #ed7b2f;
    line-height: 16px;
    font-size: 14px;
    > span {
      margin-right: 8px;
    }
  }
  .content {
    margin-top: 16px;
    .area-input {
      min-height: 160px;
      padding: 22px;
      background: rgba(0, 0, 0, 0.02);
      border-radius: 6px;
      > p {
        color: rgba(0, 0, 0, 0.4);
      }
    }
  }
}
.modal-footer {
  align-items: center;
  color: rgba(0, 0, 0, 0.2);
}
</style>
<style lang="less">
.resource-modal {
  .ant-modal-body {
    padding-bottom: 0;
  }
}
</style>
