<template>
  <div class="message-card-wrapper" v-if="item && item.msg">
    <!--群邀请-->
    <p :class="[bem, 'jz-flex jz-flex-col']" v-if="isCurrentType(TypeEnum.invite)">
      <span class="acement-tag">群邀请</span>
      <template v-for="(item, index) in props.item.msg?.data" :key="index">
        <span style="color: #ed7b2f">&nbsp;{{ item.text }}</span>
      </template>
    </p>
    <!--群公告-->
    <p :class="[bem, 'jz-flex jz-flex-col']" v-if="isCurrentType(TypeEnum.acement)">
      <span class="acement-tag">群公告</span>
      <template v-for="(item, index) in props.item.msg?.data" :key="index">
        <a-tag class="ant-tag-plain ang-tag-big" v-if="item.type === 2">{{ item.text }}</a-tag>
        <span v-else>&nbsp;{{ item.desc }}</span>
      </template>
    </p>
    <!-- 文本 -->
    <p :class="bem" v-if="isCurrentType(TypeEnum.text)">
      <template v-for="(item, index) in props.item.msg?.data" :key="index">
        <a-tag class="ant-tag-plain ang-tag-big" v-if="item.type === 2">{{ item.text }}</a-tag>
        <span v-else>&nbsp;{{ item.text }}</span>
      </template>
    </p>
    <!-- 链接 -->
    <div :class="bem" v-if="isCurrentType(TypeEnum.link)">
      <div class="link-title lineClamp2">{{ item.msg.title }}</div>
      <p v-if="item.msg.des">{{ item.msg.des }}</p>
      <img class="img" :src="item.msg.thumb_url" v-if="item.msg.thumb_url" />
    </div>
    <!-- 小程序 -->
    <div :class="bem" v-if="isCurrentType(TypeEnum.mini)">
      <div class="mini-head">
        <p clsss="jz-flex jz-flex-cc">
          <img :src="item.msg.headimg" />&nbsp;
          <span>{{ item.msg.title }}</span>
        </p>
        <span class="lineClamp1">{{ item.msg.des }}</span>
      </div>
      <div class="mini-content">
        <img :src="item.msg.icon_url" v-if="item.msg?.icon_url" />
        <div class="deafult-box" v-else>
          <svg-icon icon-name="mini_icon" :iconSize="20" />
        </div>
      </div>
      <p>
        <svg-icon icon-name="mini_small_icon" :iconSize="10" />
        <span>小程序</span>
      </p>
    </div>
    <!-- 文件 -->
    <div :class="[bem, 'jz-flex jz-flex-cc']" v-loading="item.uploading" v-if="isCurrentType(TypeEnum.file)">
      <img :src="getFileIconByType(item.msg)" class="icon" />
      <span>{{ item.msg.name }}</span>
    </div>
    <!-- 语音 -->
    <div :class="[bem, 'jz-flex jz-flex-cc']" v-if="isCurrentType(TypeEnum.voice)">
      <VoiceBubble ref="voiceRef" :url="item.msg.url" />
    </div>
    <!-- 视频 -->
    <div
      :class="[bem, 'jz-flex jz-flex-cc']"
      v-loading="item.uploading"
      @click="handlePreviewVideo(item)"
      v-if="isCurrentType(TypeEnum.video)"
    >
      <div class="play-btn">
        <img src="@/assets/imgs/ic_video.png" />
      </div>
    </div>
    <!-- 视频号 -->
    <div :class="[bem, 'jz-flex jz-flex-cc']" v-if="isCurrentType(TypeEnum.video_num)">
      <img :src="item.msg.head_img_url" />
      <div class="title-bottom jz-flex jz-flex-cc">
        <img src="@/assets/imgs/ic_vn_logo.png" />
        <span>简知科技</span>
      </div>
      <div class="play-btn">
        <img src="@/assets/imgs/ic_video.png" />
      </div>
    </div>
    <!-- 图片 -->
    <div :class="bem" v-if="isCurrentType(TypeEnum.image)">
      <div class="default-img" v-loading="item.uploading" v-if="item.uploading"></div>
      <a-image
        :src="item.msg.url"
        fallback="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMIAAADDCAYAAADQvc6UAAABRWlDQ1BJQ0MgUHJvZmlsZQAAKJFjYGASSSwoyGFhYGDIzSspCnJ3UoiIjFJgf8LAwSDCIMogwMCcmFxc4BgQ4ANUwgCjUcG3awyMIPqyLsis7PPOq3QdDFcvjV3jOD1boQVTPQrgSkktTgbSf4A4LbmgqISBgTEFyFYuLykAsTuAbJEioKOA7DkgdjqEvQHEToKwj4DVhAQ5A9k3gGyB5IxEoBmML4BsnSQk8XQkNtReEOBxcfXxUQg1Mjc0dyHgXNJBSWpFCYh2zi+oLMpMzyhRcASGUqqCZ16yno6CkYGRAQMDKMwhqj/fAIcloxgHQqxAjIHBEugw5sUIsSQpBobtQPdLciLEVJYzMPBHMDBsayhILEqEO4DxG0txmrERhM29nYGBddr//5/DGRjYNRkY/l7////39v///y4Dmn+LgeHANwDrkl1AuO+pmgAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAwqADAAQAAAABAAAAwwAAAAD9b/HnAAAHlklEQVR4Ae3dP3PTWBSGcbGzM6GCKqlIBRV0dHRJFarQ0eUT8LH4BnRU0NHR0UEFVdIlFRV7TzRksomPY8uykTk/zewQfKw/9znv4yvJynLv4uLiV2dBoDiBf4qP3/ARuCRABEFAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghgg0Aj8i0JO4OzsrPv69Wv+hi2qPHr0qNvf39+iI97soRIh4f3z58/u7du3SXX7Xt7Z2enevHmzfQe+oSN2apSAPj09TSrb+XKI/f379+08+A0cNRE2ANkupk+ACNPvkSPcAAEibACyXUyfABGm3yNHuAECRNgAZLuYPgEirKlHu7u7XdyytGwHAd8jjNyng4OD7vnz51dbPT8/7z58+NB9+/bt6jU/TI+AGWHEnrx48eJ/EsSmHzx40L18+fLyzxF3ZVMjEyDCiEDjMYZZS5wiPXnyZFbJaxMhQIQRGzHvWR7XCyOCXsOmiDAi1HmPMMQjDpbpEiDCiL358eNHurW/5SnWdIBbXiDCiA38/Pnzrce2YyZ4//59F3ePLNMl4PbpiL2J0L979+7yDtHDhw8vtzzvdGnEXdvUigSIsCLAWavHp/+qM0BcXMd/q25n1vF57TYBp0a3mUzilePj4+7k5KSLb6gt6ydAhPUzXnoPR0dHl79WGTNCfBnn1uvSCJdegQhLI1vvCk+fPu2ePXt2tZOYEV6/fn31dz+shwAR1sP1cqvLntbEN9MxA9xcYjsxS1jWR4AIa2Ibzx0tc44fYX/16lV6NDFLXH+YL32jwiACRBiEbf5KcXoTIsQSpzXx4N28Ja4BQoK7rgXiydbHjx/P25TaQAJEGAguWy0+2Q8PD6/Ki4R8EVl+bzBOnZY95fq9rj9zAkTI2SxdidBHqG9+skdw43borCXO/ZcJdraPWdv22uIEiLA4q7nvvCug8WTqzQveOH26fodo7g6uFe/a17W3+nFBAkRYENRdb1vkkz1CH9cPsVy/jrhr27PqMYvENYNlHAIesRiBYwRy0V+8iXP8+/fvX11Mr7L7ECueb/r48eMqm7FuI2BGWDEG8cm+7G3NEOfmdcTQw4h9/55lhm7DekRYKQPZF2ArbXTAyu4kDYB2YxUzwg0gi/41ztHnfQG26HbGel/crVrm7tNY+/1btkOEAZ2M05r4FB7r9GbAIdxaZYrHdOsgJ/wCEQY0J74TmOKnbxxT9n3FgGGWWsVdowHtjt9Nnvf7yQM2aZU/TIAIAxrw6dOnAWtZZcoEnBpNuTuObWMEiLAx1HY0ZQJEmHJ3HNvGCBBhY6jtaMoEiJB0Z29vL6ls58vxPcO8/zfrdo5qvKO+d3Fx8Wu8zf1dW4p/cPzLly/dtv9Ts/EbcvGAHhHyfBIhZ6NSiIBTo0LNNtScABFyNiqFCBChULMNNSdAhJyNSiECRCjUbEPNCRAhZ6NSiAARCjXbUHMCRMjZqBQiQIRCzTbUnAARcjYqhQgQoVCzDTUnQIScjUohAkQo1GxDzQkQIWejUogAEQo121BzAkTI2agUIkCEQs021JwAEXI2KoUIEKFQsw01J0CEnI1KIQJEKNRsQ80JECFno1KIABEKNdtQcwJEyNmoFCJAhELNNtScABFyNiqFCBChULMNNSdAhJyNSiECRCjUbEPNCRAhZ6NSiAARCjXbUHMCRMjZqBQiQIRCzTbUnAARcjYqhQgQoVCzDTUnQIScjUohAkQo1GxDzQkQIWejUogAEQo121BzAkTI2agUIkCEQs021JwAEXI2KoUIEKFQsw01J0CEnI1KIQJEKNRsQ80JECFno1KIABEKNdtQcwJEyNmoFCJAhELNNtScABFyNiqFCBChULMNNSdAhJyNSiECRCjUbEPNCRAhZ6NSiAARCjXbUHMCRMjZqBQiQIRCzTbUnAARcjYqhQgQoVCzDTUnQIScjUohAkQo1GxDzQkQIWejUogAEQo121BzAkTI2agUIkCEQs021JwAEXI2KoUIEKFQsw01J0CEnI1KIQJEKNRsQ80JECFno1KIABEKNdtQcwJEyNmoFCJAhELNNtScABFyNiqFCBChULMNNSdAhJyNSiEC/wGgKKC4YMA4TAAAAABJRU5ErkJggg=="
      />
    </div>
    <SimplePreview ref="previewRef">
      <div class="vp-wrap">
        <video
          autoplay
          :src="state.url"
          ref="videoRef"
          preload="auto"
          controlsList="nodownload"
          playsinline="isiPhoneShowPlaysinline"
          webkit-playsinline="isiPhoneShowPlaysinline"
          x-webkit-airplay
          x5-video-player-type="h5-page"
        >
          您的浏览器不支持 video 标签
        </video>
      </div>
    </SimplePreview>
    <SimplePreview ref="linkRef">
      <iframe X-Frame-Options="sameorigin" :src="state.url"></iframe>
    </SimplePreview>
  </div>
</template>

<script setup>
import { computed, reactive, shallowRef } from 'vue'
import pdfImg from '@/assets/imgs/pdf.png'
import pptImg from '@/assets/imgs/ppt.png'
import workImg from '@/assets/imgs/word.png'
import excelImg from '@/assets/imgs/excel.png'
import defaultImg from '@/assets/imgs/default_file.png'

import SimplePreview from '@/components/basic/preview'
import { MessageTypeEnum as TypeEnum } from '@/enums/MessageTypeEnum'

const props = defineProps({
  item: {
    type: Object,
    default: () => ({})
  },
  msgType: {
    type: [String, Number]
  }
})

const state = reactive({
  url: null
})

const previewRef = ref()
const linkRef = ref()
const videoRef = shallowRef()

const bem = computed(() => `${TypeEnum[props.msgType]}-card`)

const isCurrentType = (type) => +props.msgType === type

const getFileIconByType = (msg) => {
  let url = msg.url
  if (/.pdf$/i.test(url)) {
    return pdfImg
  } else if (/.(docx?)$/i.test(url)) {
    return workImg
  } else if (/.(xlsx?)$/i.test(url)) {
    return excelImg
  } else if (/.(pptx?)$/i.test(url)) {
    return pptImg
  }
  return defaultImg
}

const handlePreviewVideo = (item) => {
  state.url = item.msg.url || item.msg.channel_url
  previewRef.value.onOpen()
}

const handleOpenLink = (item) => {
  console.log(item)
  state.url = item.msg.url
  linkRef.value.onOpen()
  // const view = new BrowserWindow()
  // view.webContents.loadURL(item.msg.url)
}
</script>

<style lang="less" scoped>
.message-card-wrapper {
  box-sizing: border-box;
  .btn-click() {
    box-sizing: border-box;
    cursor: pointer;
    &:active {
      opacity: 0.8;
    }
  }
  .link-card {
    width: 142px;
    min-height: 67px;
    padding: 6px 8px;
    overflow: hidden;
    position: relative;
    background: #eeeeee;
    border-radius: 6px;
    .btn-click;
    .link-title {
      font-size: 12px;
      white-space: nowrap;
      color: #000;
      overflow: hidden;
      margin-left: -5px;
      text-overflow: ellipsis;
      transform: scale(0.9);
    }
    > p {
      transform: scale(0.7);
      margin-bottom: 0;
      margin-left: -22px;
      color: rgba(0, 0, 0, 0.4);
    }
    .img {
      position: absolute;
      bottom: 6px;
      right: 8px;
      width: 30px;
      height: 30px;
    }
  }
  .image-card {
    width: 120px;
    height: 120px;
    background: #d9d9d9;
    border-radius: 6px;
    overflow: hidden;
    .btn-click;
    :deep(.ant-image) {
      height: 100%;
      width: 100%;
      img {
        width: 100%;
        height: 100%;
        object-fit: cover;
      }
    }
    .default-img {
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.04);
      border-radius: 6px;
    }
  }
  .mini-card {
    width: 142px;
    background: rgba(238, 238, 238, 1);
    border-radius: 6px;
    padding: 8px;
    overflow: hidden;
    .btn-click;
    .mini-head {
      text-align: left;
      width: 100%;
      > p {
        width: 100%;
        display: flex;
        position: relative;
        align-items: center;
        margin-bottom: 0px;
        > img {
          width: 12px;
          height: 12px;
          margin-right: 4px;
          border-radius: 50%;
        }
        span {
          transform: scale(0.8);
          text-overflow: ellipsis;
          overflow: hidden;
          white-space: nowrap;
          position: absolute;
          left: 6px;
          width: 120px;
        }
      }
      > span {
        transform: scale(0.8);
        margin-bottom: 1px;

        &:last-child {
          margin-left: -9px;
        }
      }
    }
    > p {
      margin-bottom: 0px;
      display: flex;
      align-items: center;
      > span {
        margin-left: 0px;
        transform: scale(0.8);
      }
    }
    .mini-content {
      height: 98px;
      > img {
        width: 100%;
        height: 100%;
      }
      .deafult-box {
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        background: rgba(0, 0, 0, 0.04);
      }
    }
  }
  .file-card {
    .btn-click;
    .icon {
      margin-right: 5px;
      width: 20px;
      height: 20px;
    }
  }
  .voice-card {
    height: 44px;
    width: 111px;
    .btn-click;
    > img {
      width: 100%;
      height: 100%;
      cursor: pointer;
    }
  }

  .video-card {
    position: relative;
    padding: 6px;
    width: 120px;
    height: 80px;
    border-radius: 6px;
    background: #eeeeee linear-gradient(360deg, rgba(0, 0, 0, 0.5) 0%, rgba(0, 0, 0, 0) 100%);
    .btn-click;
    .play-btn {
      position: absolute;
      width: 32px;
      height: 32px;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      cursor: pointer;
      &:hover {
        color: #eee;
      }
    }
  }

  .video_num-card {
    width: 126px;
    height: 168px;
    background: #eeeeee linear-gradient(360deg, rgba(0, 0, 0, 0.5) 0%, rgba(0, 0, 0, 0) 100%);
    border-radius: 6px;
    padding: 6px;
    position: relative;
    .btn-click;
    .play-btn {
      position: absolute;
      width: 36px;
      height: 36px;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      cursor: pointer;
      &:hover {
        color: #eee;
      }
    }
    .title-bottom {
      position: absolute;
      bottom: 6px;
      left: 6px;
      > img {
        width: 16px;
        height: 16px;
        margin-right: 5px;
      }
      > span {
        color: #fff;
        font-size: 12px;
      }
    }
  }
}
.vp-wrap {
  width: 672px;
  height: 378px;
  border-radius: 6px;
  overflow: hidden;
  .video {
    height: inherit;
    width: inherit;
  }
}
.acement-tag {
  border-radius: 4px;
  display: block;
  height: 22px;
  width: 52px;
  font-size: 12px;
  line-height: 22px;
  text-align: center;
  color: #ffa800;
  margin-bottom: 8px;
  background: #fff6e5;
}
</style>
