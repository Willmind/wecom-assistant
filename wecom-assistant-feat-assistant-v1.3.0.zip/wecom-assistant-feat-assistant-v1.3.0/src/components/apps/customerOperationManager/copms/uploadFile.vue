<template>
  <a-upload name="file" :maxCount="1" :showUploadList="false" :beforeUpload="handleBeforeUpload">
    <slot></slot>
  </a-upload>
</template>
<script setup>
import { defineEmits } from 'vue'
import useMessage from '@/composables/web/useMessage'
import { MessageTypeEnum } from '@/enums/MessageTypeEnum'

const { createMessage } = useMessage()

const props = defineProps({
  data: Object
})

const emit = defineEmits(['change'])

const handleBeforeUpload = (file, fileList) => {
  let { icon: type, msg_type } = props.data
  type = type || MessageTypeEnum[msg_type]
  if (type === 'image') {
    if (!/.(png|jpe?g)/i.test(file.type)) {
      createMessage.warning('只能上传png,jpg,jpeg格式的图片')
      return false
    } else if (file.size > 10 * 1024 * 1024) {
      createMessage.warning('仅支持上传10M内的图片')
      return false
    }
  } else if (type === 'video') {
    if (!/.mp4/i.test(file.type)) {
      createMessage.warning('只能上传MP4格式视频')
      return false
    } else if (file.size > 100 * 1024 * 1024) {
      createMessage.warning('仅支持上传100M内的视频')
      return false
    }
  } else if (type === 'file') {
    if (file.size > 20 * 1024 * 1024) {
      createMessage.warning('仅支持上传20M内的文件')
      return false
    }
  }
  emit('change', file, fileList)
  return false
}
</script>
