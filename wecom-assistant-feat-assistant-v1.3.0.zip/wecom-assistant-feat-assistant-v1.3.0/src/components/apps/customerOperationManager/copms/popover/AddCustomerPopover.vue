<template>
  <a-popover
    overlayClassName="ant-popover-not-arrow"
    v-model:visible="visible"
    trigger="click"
    :disabled="disabled"
    placement="bottomLeft"
    @visibleChange="handleChange"
    :getPopupContainer="
      (triggerNode) => {
        return triggerNode.parentNode || document.body
      }
    "
  >
    <template #content>
      <div class="from-wraper ant-popover-content jz-flex jz-flex-col" style="margin-bottom: 44px">
        <div class="jz-flex-1 jz-flex content">
          <div class="left-box jz-flex jz-flex-col">
            <div class="left-head jz-flex jz-flex-cc">
              <span>筛选</span>
              <div class="jz-flex-1 jz-flex jz-flex-rr jz-flex-cc">
                <a-button
                  type="link"
                  :disabled="!isChangeForm"
                  @click="() => clearFields()"
                  class="gray-color"
                  >清空筛选</a-button
                >
              </div>
            </div>
            <div class="from-box jz-flex-1 jz-flex jz-flex-col">
              <a-form-item v-bind="validateInfos.keyword">
                <a-input v-model:value="form.keyword" allowClear placeholder="关键词搜索">
                  <template #suffix>
                    <search-outlined />
                  </template>
                </a-input>
              </a-form-item>
              <a-form-item v-bind="validateInfos.label_names">
                <CustomTagPopover
                  is-search
                  :data="{ label_id: form.label_names }"
                  @select-change="handleSelectedTag"
                >
                  <span>
                    <rich-input v-model:value="form.label_names" tagMode allowClear placeholder="标签">
                      <template #prefix>
                        <span>{{ label_type_name }}</span>
                      </template>
                      <template #suffix>
                        <down-outlined />
                      </template>
                    </rich-input>
                  </span>
                </CustomTagPopover>
              </a-form-item>
              <a-form-item name="add_time" v-bind="validateInfos.add_time">
                <a-range-picker v-model:value="form.add_time" value-format="YYYY-MM-DD" allowClear />
              </a-form-item>
              <a-form-item v-bind="validateInfos.group_type_text">
                <GroupTypePopover v-model:item="form.group_type" @onChange="handleGroupTypeChange">
                  <a-input
                    class="ant-input-ellipsis"
                    v-model:value="form.group_type_text"
                    allowClear
                    :readonly="true"
                    placeholder="按群查询"
                  >
                    <template #prefix>
                      <label>{{ groupTypeObj.label }}</label>
                    </template>
                    <template #suffix>
                      <down-outlined />
                    </template>
                  </a-input>
                </GroupTypePopover>
              </a-form-item>
              <a-form-item v-bind="validateInfos.is_remark">
                <api-select
                  v-model:value="form.is_remark"
                  allowClear
                  :options="dictMap.is_remark"
                  :replaceFields="dictFields"
                  placeholder="有无企微备注"
                />
              </a-form-item>
              <a-form-item v-bind="validateInfos.is_name">
                <api-select
                  v-model:value="form.is_name"
                  allowClear
                  :options="dictMap.is_name"
                  :replaceFields="dictFields"
                  placeholder="有无称呼"
                />
              </a-form-item>
              <a-form-item v-bind="validateInfos.sex">
                <api-select
                  v-model:value="form.sex"
                  allowClear
                  :options="dictMap.sex"
                  :replaceFields="dictFields"
                  placeholder="性别"
                />
              </a-form-item>
              <a-form-item v-bind="validateInfos.source">
                <api-select
                  v-model:value="form.source"
                  allowClear
                  :options="dictMap.source"
                  :replaceFields="dictFields"
                  placeholder="来源"
                />
              </a-form-item>
              <a-form-item v-bind="validateInfos.friend_status">
                <api-select
                  v-model:value="form.friend_status"
                  allowClear
                  :options="dictMap.friend_status"
                  :replaceFields="dictFields"
                  placeholder="好友关系"
                />
              </a-form-item>
            </div>
          </div>
          <div class="right-box jz-flex jz-flex-1 jz-flex-col">
            <div class="wraper-box jz-flex jz-flex-1 jz-flex-col" style="height: 100%" v-loading="loading">
              <div class="head jz-flex jz-flex-rb jz-flex-cc">
                <span class="head-num">客户{{ state.listCount }}</span>
                <div class="jz-flex jz-flex-1 jz-flex-rr">仅显示已选</div>
                <a-switch class="switch" v-model:checked="state.isSwitch" @change="changeSwitch" />
              </div>
              <template v-if="state.list.length">
                <ul
                  class="group-wraper jz-flex jz-flex-col"
                  v-infinite-scroll="getList"
                  :infinite-scroll-immediate-check="false"
                  :infinite-scroll-disabled="scrollDisabled"
                  :infinite-scroll-watch-disabled="scrollDisabled"
                  :infinite-scroll-distance="10"
                >
                  <li
                    class="item jz-flex jz-flex-center"
                    :class="{ 'item-selected': item.isCheck }"
                    v-for="(item, index) in state.list"
                    :key="index"
                  >
                    <a-checkbox
                      v-model:checked="item.isCheck"
                      :disabled="item.isCheck ? false : isLimit"
                      @change="itemChange"
                    />
                    <div class="jz-flex-1 jz-flex jz-flex-cc">
                      <img :src="item.avatar" alt="" />
                      <div class="jz-flex-1 jz-flex jz-flex-col">
                        <span class="lineClamp1">{{ item.name }}</span>
                        <span class="lineClamp1" :class="!item.wx_type && 'wx-color'"
                          >@ {{ item.wx_type_val }}</span
                        >
                      </div>
                    </div>
                  </li>
                </ul>
              </template>
              <a-empty v-if="!state.list.length && !loading" class="empty" />
            </div>
          </div>
        </div>
        <div class="ant-popover-footer ant-popover-footer-line jz-flex jz-flex-rr">
          <div class="btns">
            <a-button @click="close">取消</a-button>
            <a-button type="primary" @click="handleConfirm">确认</a-button>
          </div>
        </div>
      </div>
    </template>
    <slot></slot>
  </a-popover>
</template>

<script setup>
import datajs from 'dayjs'
import { Form } from 'ant-design-vue'
import { cloneDeep } from 'lodash-es'
import useMessage from '@/composables/web/useMessage'
import CustomTagPopover from '../../../customerManger/comps/CustomTagPopover.vue'
import GroupTypePopover from '../../../customerManger/comps/GroupTypePopover.vue'
import { queryDict } from 'api/common'
import { createHTTP } from '@/composables/common/useCreate'
import { getApiContantList } from 'api/customerOperationManager'
const { createMessage } = useMessage()
const props = defineProps({
  ids: String,
  disabled: Boolean
})
const emit = defineEmits(['success'])
const useForm = Form.useForm
const visible = ref(false)
const label_type_name = ref('')
const groupTypeObj = reactive({
  label: ''
})
const loading = ref(false)
const { data: dictMap, tryFetchData } = createHTTP(queryDict)
const state = reactive({
  page: 1,
  isCheck: false,
  isSwitch: false,
  list: [],
  listCount: 0,
  select_list: '',
  selectedKeys: []
})
// 筛选表单
const form = reactive({
  keyword: '',
  group_ids: undefined,
  add_time: [],
  sex: undefined,
  source: undefined,
  friend_status: undefined,
  is_remark: undefined,
  label_ids: undefined,
  is_name: undefined,
  label_type: undefined,
  label_names: undefined,
  label_type: undefined,
  group_type: undefined,
  group_type_text: ''
})
const rulesRef = reactive({})
const { validateInfos, resetFields } = useForm(form, rulesRef)
const dictFields = computed(() => ({ label: 'val', value: 'key' }))

// computed======================
//  加载完毕
const scrollDisabled = computed(() => state.list.length >= state.listCount)

const isChangeForm = computed(() =>
  Object.keys(form).some((key) =>
    Array.isArray(form[key])
      ? !!form[key].length
      : form[key] !== undefined && form[key] !== null && form[key] !== ''
  )
)

const isLimit = computed(() => state.selectedKeys.length >= 10)

// 获取form参数
const getParams = computed(() => {
  const deepData = cloneDeep(form)
  if (deepData.add_time?.[1]) {
    deepData.add_time[1] += ' 23:59:59'
  }
  return {
    ...deepData,
    add_start_time: deepData?.add_time?.length ? datajs(deepData.add_time[0])?.unix?.() : undefined,
    add_end_time: deepData?.add_time?.length ? datajs(deepData.add_time[1])?.unix?.() : undefined,
    add_time: undefined,
    contact_ids: state.isSwitch ? state.select_list : ''
  }
})

// watch================================

watch(
  () => form,
  () => {
    const params = unref(getParams)
    const queryParams = {}
    Object.keys(params).forEach((key) => {
      if (Array.isArray(params[key])) {
        queryParams[key] = params[key].join(',')
      } else {
        queryParams[key] = params[key]
      }
    })
    search(toRaw(queryParams))
  },
  {
    deep: true
  }
)

// methods===============================

// 关闭
const close = () => {
  clearFields()
  visible.value = false
  state.selectedKeys = []
  state.select_list = ''
  state.list = []
}

// 确认提交
const handleConfirm = () => {
  if (!state.select_list) {
    createMessage.info('请选择客户')
    return
  }
  let _arr = []
  if (state.list.length && state.select_list) {
    state.list.forEach((i) => {
      if (state.select_list.split(',').includes(i.contact_id)) {
        _arr.push(i)
      }
    })
  }
  const params = unref(_arr)
  emit('success', params)
  close()
}

// 选择某一列
const itemChange = () => {
  let ids = state.list.filter((i) => i.isCheck).map((item) => item.contact_id)
  state.selectedKeys = ids
  state.select_list = ids.length ? ids.join(',') : ''
  if (isLimit.value) {
    createMessage.warning('最多添加10个客户')
  }
}

// 滚动加载
const getList = () => {
  if (scrollDisabled.value) return
  const params = unref(getParams)
  search(toRaw(params), true)
}

// 仅显示已选
const changeSwitch = () => {
  state.page = 1
  state.listCount = 0
  state.list = []
  const params = unref(getParams)
  search(toRaw(params))
}

// 搜索
function search(params = {}, isScroll = false) {
  if (loading.value) {
    return
  }
  loading.value = true
  params = Object.assign({}, params, { page: (state.page = isScroll ? state.page : 1) })
  getApiContantList(params)
    .then((res) => {
      if (res.code === 1000) {
        if (res.data.list.length) {
          res.data.list.forEach((i) => {
            i.isCheck = state.isCheck
            if (state.select_list) {
              let arr = state.select_list.split(',')
              if (arr.includes(i.contact_id)) {
                i.isCheck = true
              }
            }
          })
        }
        state.list = isScroll ? [...state.list, ...res.data.list] : res.data.list
        if (!isScroll) {
          state.listCount = res.data.total
        }
        state.page = state.page + 1
      }
    })
    .finally(() => {
      loading.value = false
    })
}

// 展示提示框
const handleChange = (show) => {
  if (props.disabled) {
    visible.value = false
    return
  }
  if (show) {
    tryFetchData()
    if (props.ids) {
      state.select_list = props.ids
    }
    const params = unref(getParams)
    search(toRaw(params))
  } else {
    close()
  }
}

// 清空筛选
const clearFields = () => {
  resetFields()
  form.label_ids = []
  form.label_names = []
  form.group_ids = []
  form.group_type_text = ''
  groupTypeObj.label = ''
  state.isSwitch = false
}

// 标签查询
const handleSelectedTag = ({ type, tags }) => {
  form.label_type = type
  label_type_name.value = type === 2 ? '带有' : type === 3 ? '除开' : '未打标签好友'
  form.label_names = tags.map((tag) => tag.label)
  form.label_ids = tags.map((tag) => tag.value)
}

// 选择按群查询
const handleGroupTypeChange = ({ labelInValue, checkedRows }) => {
  groupTypeObj.label = labelInValue.label
  form.group_type = labelInValue.value
  form.group_ids = checkedRows.map((item) => item.id)
  form.group_type_text = checkedRows.map((item) => item.name).join('、')
}
</script>

<style lang="less" scoped>
.from-wraper {
  width: 657px;
  height: 460px;
  margin-top: -12px;
  .content {
    height: 100%;
    overflow: hidden;
  }
  .gray-color {
    color: @font-minor-color;
    padding-right: 0;
  }
  .left-box {
    width: 256px;
    padding-right: 16px;
    padding-top: 12px;
    border-right: 1px solid #eee;
    .left-head {
      width: 100%;
      height: 22px;
      margin-bottom: 8px;
    }
  }
  .right-box {
    width: 100%;
    padding-top: 12px;
    .head {
      padding: 0 8px;
      color: @font-minor-color;
      padding: 0 16px;
      .switch {
        margin-left: 18px;
      }
    }
    .group-wraper {
      height: 100%;
      margin-top: 10px;
      overflow-y: auto;
      padding: 0 8px;
      .item {
        width: 100%;
        height: 54px;
        min-height: 54px;
        padding: 0 8px;
        cursor: pointer;
        &.item-selected {
          background: #ebf0fe !important;
        }
        > div {
          margin-left: 28px;
          img {
            width: 36px;
            height: 36px;
            border-radius: 6px;
            margin-right: 13px;
          }
          span:first-child {
            font-size: 14px;
          }
          span:last-child {
            font-size: 12px;
            color: #57be6a;
          }
        }
        &:hover {
          background: rgba(0, 0, 0, 0.02);
        }
      }
    }
  }
}
:deep(.ant-form-item) {
  margin-bottom: 8px;
}
.empty {
  margin-top: 20px;
}
.not-more {
  height: 30px;
  line-height: 30px;
  text-align: center;
  color: @font-minor-color;
}
.pop-footer {
  height: 36px;
  padding: 10px 16px 0;
  border-top: 1px solid #eee;
}
.wx-color {
  color: #ed7b2f !important;
}
</style>
