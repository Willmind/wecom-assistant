<template>
  <a-popover
    overlayClassName="ant-popover-not-arrow"
    v-model:visible="visible"
    trigger="click"
    :disabled="disabled"
    placement="bottomLeft"
    @visibleChange="handleChange"
    :getPopupContainer="
      (triggerNode) => {
        return triggerNode.parentNode || document.body
      }
    "
  >
    <template #content>
      <div class="wraper jz-flex jz-flex-col" v-loading="loading">
        <div class="search">
          <a-input v-model:value="keyword" allowClear placeholder="搜索" enter-button @search="search(false)">
            <template #prefix>
              <search-outlined />
            </template>
          </a-input>
        </div>
        <div class="wraper-box jz-flex jz-flex-1 jz-flex-col">
          <div class="head jz-flex jz-flex-rb jz-flex-cc">
            <span class="head-num">客户{{ listCount }}</span>
            <div class="jz-flex jz-flex-1 jz-flex-rr">仅显示已选</div>
            <a-switch class="switch" v-model:checked="isSwitch" @change="changeSwitch" />
          </div>
          <template v-if="state.list.length">
            <ul
              class="group-wraper jz-flex jz-flex-col"
              v-infinite-scroll="getList"
              :infinite-scroll-immediate-check="false"
              :infinite-scroll-disabled="scrollDisabled"
              infinite-scroll-watch-disabled="scrollDisabled"
              :infinite-scroll-distance="10"
            >
              <li
                class="item jz-flex jz-flex-center"
                :class="{ 'item-selected': item.isCheck }"
                v-for="(item, index) in state.list"
                :key="index"
              >
                <a-checkbox
                  v-model:checked="item.isCheck"
                  :disabled="item.isCheck ? false : isLimit"
                  @change="itemChange"
                />
                <div class="jz-flex-1 jz-flex jz-flex-cc">
                  <img :src="item.avatar" alt="" />
                  <div class="jz-flex-1 jz-flex jz-flex-col">
                    <span class="lineClamp1">{{ item.name }}</span>
                    <span class="lineClamp1" :class="!item.wx_type && 'wx-color'"
                      >@ {{ item.wx_type_val }}</span
                    >
                  </div>
                </div>
              </li>
            </ul>
          </template>
          <a-empty v-if="!state.list.length && !loading" class="empty" />
        </div>
      </div>
      <div class="ant-popover-footer ant-popover-footer-line jz-flex jz-flex-rr">
        <div class="btns">
          <a-button @click="close">取消</a-button>
          <a-button type="primary" @click="handleConfirm">确认</a-button>
        </div>
      </div>
    </template>
    <slot></slot>
  </a-popover>
</template>
<script setup>
import { getApiUserList } from 'api/customerOperationManager'
import useMessage from '@/composables/web/useMessage'
import { computed } from 'vue'
const { createMessage } = useMessage()
const props = defineProps({
  ids: String,
  disabled: Boolean
})
const emit = defineEmits(['success'])
const visible = ref(false)
const loading = ref(false)
const listCount = ref(0)
const page = ref(1)
const isSwitch = ref(false)
const isCheck = ref(false)
const state = reactive({
  list: [],
  select_list: '',
  selectedKeys: []
})
const keyword = ref('')

// 确认提交
const handleConfirm = () => {
  if (!state.select_list) {
    createMessage.info('请选择客户')
    return
  }
  let _arr = []
  if (state.list.length && state.select_list) {
    state.list.forEach((i) => {
      if (state.select_list.split(',').includes(i.contact_id)) {
        _arr.push(i)
      }
    })
  }
  const params = unref(_arr)
  emit('success', params)
  close()
}

// 选择某一列
const itemChange = () => {
  let ids = state.list.filter((i) => i.isCheck).map((item) => item.contact_id)
  state.selectedKeys = ids
  state.select_list = ids.length ? ids.join(',') : ''
  if (isLimit.value) {
    createMessage.warning('最多添加10个企业成员')
  }
}

const isLimit = computed(() => state.selectedKeys.length >= 10)

// 仅显示已选
const changeSwitch = () => {
  page.value = 1
  listCount.value = 0
  state.list = []
  search()
}

// 全选/反选
const checkAll = () => {
  itemChange()
}
// 展示提示框
const handleChange = (show) => {
  if (props.disabled) {
    visible.value = false
    return
  }
  if (show) {
    if (props.ids) {
      state.select_list = props.ids
    }
    search()
  } else {
    close()
  }
}

// 关闭
const close = () => {
  visible.value = false
  state.select_list = ''
  state.selectedKeys = []
  state.list = []
  isSwitch.value = false
}

// 滚动加载
const getList = () => {
  search(true)
}

// 搜索
const search = (isScroll = false) => {
  if (loading.value) {
    return
  }
  loading.value = true
  page.value = isScroll ? page.value : 1
  let _params = {
    page: page.value,
    keyword: keyword.value || '',
    contact_ids: isSwitch.value ? state.select_list : ''
  }
  getApiUserList(_params)
    .then((res) => {
      if (res.code === 1000) {
        if (res.data.list.length) {
          res.data.list.forEach((i) => {
            i.isCheck = isCheck.value
            if (state.select_list) {
              let arr = state.select_list.split(',')
              if (arr.includes(i.contact_id)) {
                i.isCheck = true
              }
            }
          })
        }
        state.list = isScroll ? [...state.list, ...res.data.list] : res.data.list
        if (!isScroll) {
          listCount.value = res.data.total
        }
        page.value = page.value + 1
      }
    })
    .finally(() => {
      loading.value = false
    })
}

//  加载完毕
const scrollDisabled = computed(() => state.list.length >= listCount.value)

// 监听=======
watch(
  () => keyword,
  () => {
    search()
  },
  {
    deep: true
  }
)
</script>
<style lang="less" scoped>
.wraper {
  width: 400px;
  height: 460px;
  padding-bottom: 56px;
  .wraper-box {
    height: 100%;
    overflow: hidden;
    margin-right: -16px;
  }
  .head {
    color: @font-minor-color;
    margin-top: 32px;
    margin-right: 16px;
    .switch {
      margin-left: 18px;
    }
  }
  .group-wraper {
    height: 100%;
    margin-top: 10px;
    overflow-y: auto;
    .item {
      width: 100%;
      height: 54px;
      min-height: 54px;
      padding: 0 8px;
      cursor: pointer;
      &.item-selected {
        background: #ebf0fe !important;
      }
      > div {
        margin-left: 28px;
        img {
          width: 36px;
          height: 36px;
          border-radius: 6px;
          margin-right: 13px;
        }
        span:first-child {
          font-size: 14px;
        }
        span:last-child {
          font-size: 12px;
          color: #57be6a;
        }
      }
      &:hover {
        background: rgba(0, 0, 0, 0.02);
      }
    }
  }
}
.empty {
  margin-top: 20px;
}
.not-more {
  height: 30px;
  line-height: 30px;
  text-align: center;
  color: @font-minor-color;
}
.wx-color {
  color: #ed7b2f !important;
}
</style>
