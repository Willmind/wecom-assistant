<template>
  <a-popover
    overlayClassName="emoji-ant-popover"
    v-model:visible="visible"
    :trigger="trigger"
    :placement="placement"
  >
    <template #content>
      <div class="emoji-wrapper">
        <div class="emoji-header jz-flex jz-flex-cc" v-if="title">
          <label>{{ title }}</label>
        </div>
        <EmojiPanel :dataList="emojis" @select="handleSelected" />
      </div>
    </template>
    <slot></slot>
  </a-popover>
</template>

<script setup>
import { ref } from 'vue'

defineProps({
  emojis: Array,
  title: String,
  trigger: {
    type: String,
    default: 'click'
  },
  placement: {
    type: String,
    default: 'bottomLeft'
  }
})

const emit = defineEmits(['select'])

const visible = ref(false)
const handleSelected = (item) => {
  emit('select', item)
  onClose()
}

const onClose = () => {
  visible.value = false
}
</script>

<style lang="less" scoped>
.emoji-wrapper {
  width: 450px;
  max-height: 240px;
  min-height: 60px;
  margin-right: -12px;
  .emoji-header {
    width: 100%;
  }
}
</style>
<style lang="less">
.emoji-ant-popover {
  .ant-popover-inner {
    background: rgba(0, 0, 0, 0.75);
  }
  .ant-popover-inner-content {
    color: #fff !important;
  }
  .weemoji-panel {
    background: none;
  }
}
</style>
