<template>
  <a-dropdown v-model:visible="visible" :disabled="disabled" placement="bottomLeft">
    <slot name="adduction"></slot>
    <template #overlay>
      <a-menu>
        <slot name="insert-item"></slot>
        <a-menu-item
          v-for="item in allMenuOptions"
          :key="item.icon"
          @click="handleSelectMenu(item, item.key)"
        >
          <div class="menu-item jz-flex jz-flex-cc" style="padding: 4px 0">
            <UploadFile :data="selectedItem" v-if="isResMsg(item)" @change="handleSelectUploadFile">
              <div class="jz-flex jz-flex-cc">
                <svg-icon :icon-name="`ic_${item.icon}`" :iconSize="16" style="margin-right: 8px" />
                <span>{{ item.label }}</span>
              </div>
            </UploadFile>
            <template v-else>
              <svg-icon :icon-name="`ic_${item.icon}`" :iconSize="16" style="margin-right: 8px" />
              <span>{{ item.label }}</span>
            </template>
          </div>
        </a-menu-item>
      </a-menu>
    </template>
  </a-dropdown>
</template>

<script setup>
import { ref, unref } from 'vue'
import { isResMsg } from './utils'
import UploadFile from '../uploadFile.vue'
import { MessageTypeEnum } from '@/enums/MessageTypeEnum'
import { cloneDeep } from 'lodash-es'

const emit = defineEmits(['select', 'select-file'])

const props = defineProps({
  menus: {
    type: Array,
    default: () => []
  },
  segmentation: {
    type: Boolean,
    default: () => true
  },
  disabled: Boolean
})

const visible = ref(false)

const menuOptions = ref([
  {
    label: '文字',
    icon: 'text',
    key: MessageTypeEnum.text
  },
  {
    label: '图片',
    icon: 'image',
    key: MessageTypeEnum.image
  },
  {
    label: '视频',
    icon: 'video',
    key: MessageTypeEnum.video
  },
  {
    label: '语音',
    icon: 'voice',
    key: MessageTypeEnum.voice
  },
  {
    label: '文件',
    icon: 'file',
    key: MessageTypeEnum.file
  },
  {
    label: '链接',
    icon: 'link',
    key: MessageTypeEnum.link
  },
  {
    label: '小程序',
    icon: 'mini',
    key: MessageTypeEnum.mini
  },
  {
    label: '视频号',
    icon: 'video_num',
    key: MessageTypeEnum.video_num
  },
  {
    label: '素材库',
    icon: 'media',
    key: MessageTypeEnum.media
  }
])
//当只能发送一条信息的时候，去除文字添加选项
const allMenuOptions = computed(() => [
  ...(props.segmentation ? unref(menuOptions) : cloneDeep(unref(menuOptions)).slice(1)),
  ...props.menus
])

const selectedItem = ref({})

const handleSelectUploadFile = (file) => {
  emit('select-file', { file, item: unref(selectedItem) })
}

const handleSelectMenu = (item, key) => {
  if (isResMsg(item)) {
    selectedItem.value = { ...item }
    return
  }
  visible.value = false
  emit('select', item, key)
  return false
}
</script>
<style lang="less" scoped>
.menu-item {
  min-width: 144px;
}
</style>
