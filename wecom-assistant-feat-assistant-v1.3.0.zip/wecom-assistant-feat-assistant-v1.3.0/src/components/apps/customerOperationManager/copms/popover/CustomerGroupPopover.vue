<template>
  <a-popover
    overlayClassName="ant-popover-not-arrow"
    v-model:visible="visible"
    trigger="click"
    :disabled="disabled"
    placement="bottomLeft"
    @visibleChange="handleChange"
    :getPopupContainer="
      (triggerNode) => {
        return triggerNode.parentNode || document.body
      }
    "
  >
    <template #content>
      <div class="pop ant-popover-content jz-flex jz-flex-col" style="margin-bottom: 44px">
        <div class="pop-content jz-flex-1 jz-flex" v-loading="loading">
          <div class="form-wraper">
            <a-form class="editor-form ant-form-small">
              <div class="ant-form-head jz-flex jz-flex-rb jz-flex-cc">
                <span class="wecom-title">筛选</span>
                <a-button type="link" @click="clearForm" style="padding-right: 0px; padding-top: 0px"
                  >清空筛选</a-button
                >
              </div>
              <a-form-item v-bind="validateInfos.keywork">
                <a-input v-model:value="form.keywork" allowClear placeholder="关键词筛选">
                  <template #suffix>
                    <search-outlined />
                  </template>
                </a-input>
              </a-form-item>
              <a-form-item v-bind="validateInfos.type">
                <a-select
                  v-model:value="form.type"
                  :options="state.typeList"
                  placeholder="是否群主/群管理员"
                />
              </a-form-item>
              <div class="group-num">选择群人数</div>
              <div class="jz-flex jz-flex-center">
                <a-form-item v-bind="validateInfos.scope" style="margin-right: 10px">
                  <a-input-number v-model:value="form.min" :min="1" :max="100" placeholder="最小值" />
                </a-form-item>
                <a-form-item v-bind="validateInfos.max">
                  <a-input-number v-model:value="form.max" :min="1" :max="100" placeholder="最大值" />
                </a-form-item>
              </div>
            </a-form>
          </div>
          <div class="list-wraper jz-flex-1 jz-flex-col jz-flex jz-flex-col">
            <div class="head jz-flex jz-flex-rb jz-flex-cc">
              <span class="head-num">客户群 {{ listCount }}</span>
              <div class="jz-flex jz-flex-1 jz-flex-rr">仅显示已选</div>
              <a-switch class="switch" v-model:checked="isSwitch" @change="changeSwitch" />
            </div>
            <template v-if="state.list.length">
              <ul
                class="group-wraper jz-flex jz-flex-col"
                v-infinite-scroll="getList"
                :infinite-scroll-immediate-check="false"
                :infinite-scroll-disabled="scrollDisabled"
                :infinite-scroll-watch-disabled="scrollDisabled"
                :infinite-scroll-distance="10"
              >
                <li
                  class="item jz-flex jz-flex-center"
                  :class="{ 'item-selected': item.isCheck }"
                  v-for="(item, index) in state.list"
                  :key="index"
                >
                  <a-checkbox
                    v-model:checked="item.isCheck"
                    :disabled="item.isCheck ? false : isLimit"
                    @change="itemChange"
                  />
                  <div class="jz-flex-1 jz-flex jz-flex-cc">
                    <img :src="item.avatar" alt="" />
                    <div class="jz-flex-1 jz-flex jz-flex-col">
                      <span class="lineClamp1">{{ item.name }}</span>
                      <span class="lineClamp1">群成员{{ item.room_members }}</span>
                    </div>
                  </div>
                </li>
              </ul>
            </template>
            <a-empty v-if="!state.list.length && !loading" class="empty" />
          </div>
        </div>
        <div class="ant-popover-footer ant-popover-footer-line jz-flex jz-flex-rr">
          <div class="btns">
            <a-button @click="close">取消</a-button>
            <a-button type="primary" @click="handleConfirm">确认</a-button>
          </div>
        </div>
      </div>
    </template>
    <slot></slot>
  </a-popover>
</template>
<script setup>
import { Form } from 'ant-design-vue'
import { computed, reactive, ref, unref } from 'vue'
import { cloneDeep } from 'lodash-es'
import { getApiGroupList } from 'api/customerOperationManager'
import useMessage from '@/composables/web/useMessage'
const { createMessage } = useMessage()
const emit = defineEmits(['success'])
const useForm = Form.useForm
const visible = ref(false)
const loading = ref(false)
const listCount = ref(0)
const page = ref(1)
const isSwitch = ref(false)
const isCheck = ref(false)
const props = defineProps({
  ids: [String, Number],
  disabled: Boolean
})
const state = reactive({
  list: [],
  select_list: '',
  selectedKeys: [],
  typeList: [
    { label: '仅群主', value: 1 },
    { label: '仅群管理员', value: 2 },
    { label: '群主/群管理员', value: 3 },
    { label: '群成员', value: 4 }
  ]
})
// 筛选表单
const form = reactive({
  keywork: '',
  type: [],
  max: '',
  min: '' // 范围
})
const rulesRef = reactive({})
const { validateInfos, resetFields } = useForm(form, rulesRef)

const isLimit = computed(() => state.selectedKeys.length >= 100)

// 选择某一列
const itemChange = () => {
  state.select_list = state.list.filter((i) => i.isCheck)
  let ids = state.list.filter((i) => i.isCheck).map((item) => item.id)
  state.selectedKeys = ids
  state.select_list = ids.length ? ids.join(',') : ''
  if (isLimit.value) {
    createMessage.warning('最多添加100个群')
  }
}

// 仅显示已选
const changeSwitch = () => {
  page.value = 1
  listCount.value = 0
  state.list = []
  const params = unref(getParams)
  search(unref(params))
}

// 清空表单
const clearForm = () => {
  resetFields()
}
// 确认提交
const handleConfirm = () => {
  if (!state.select_list) {
    createMessage.info('请选择客户')
    return
  }
  let _arr = []
  if (state.list.length && state.select_list) {
    state.list.forEach((i) => {
      if (state.select_list.split(',').includes(i.id + '')) {
        _arr.push(i)
      }
    })
  }
  const params = unref(_arr)
  emit('success', params)
  close()
}

// 展示提示框
const handleChange = (show) => {
  if (props.disabled) {
    visible.value = false
    return
  }
  if (show) {
    if (props.ids) {
      state.select_list = props.ids
    }
    const params = unref(getParams)
    search(unref(params))
  } else {
    resetFields()
    page.value = 1
    state.list = []
    isSwitch.value = false
  }
}

// 关闭
const close = () => {
  visible.value = false
  page.value = 1
  state.list = []
  isSwitch.value = false
  state.select_list = ''
  state.selectedKeys = []
}

// 滚动加载
const getList = () => {
  if (scrollDisabled.value) return
  const params = unref(getParams)
  search(toRaw(params), true)
}

// 搜索
const search = (vals, isScroll = false) => {
  if (loading.value) {
    return
  }
  loading.value = true
  page.value = isScroll ? page.value : 1
  let _params = {
    page: page.value,
    type: !Array.isArray(vals.type) ? vals.type : '',
    keyword: vals.keywork ?? '',
    num: vals.min && vals.max ? `${vals.min},${vals.max}` : '',
    group_ids: state.select_list || '',
    is_show_selected: isSwitch.value ? 1 : 0
  }
  getApiGroupList(_params)
    .then((res) => {
      if (res.code === 1000) {
        if (res.data.data.length) {
          res.data.data.forEach((i) => {
            i.isCheck = isCheck.value
            if (state.select_list) {
              let arr = state.select_list.split(',')
              if (arr.includes(i.id + '')) {
                i.isCheck = true
              }
            }
          })
        }
        state.list = isScroll ? [...state.list, ...res.data.data] : res.data.data
        if (!isScroll) {
          listCount.value = res.data.total
        }
        page.value = page.value + 1
      }
    })
    .finally(() => {
      loading.value = false
    })
}

// 获取form参数
const getParams = computed(() => {
  const deepData = cloneDeep(form)
  return {
    ...deepData
  }
})

//  加载完毕
const scrollDisabled = computed(() => state.list.length >= listCount.value)

// 监听=======
watch(
  () => form,
  () => {
    const params = unref(getParams)
    search(unref(params))
  },
  {
    deep: true
  }
)
</script>
<style lang="less" scoped>
.pop {
  width: 657px;
  height: 460px;
  overflow: hidden;
  margin-top: -12px;
  .group-num {
    padding-bottom: 10px;
    text-align: center;
  }
  .pop-content {
    height: 100%;
    overflow: hidden;
    .form-wraper {
      width: 240px;
      height: 100%;
      padding-top: 12px;
      padding-right: 16px;
      border-right: 1px solid #eee;
      .ant-form-head {
        height: 22px;
        line-height: 22px;
        margin-bottom: 8px;
      }
    }
    .list-wraper {
      width: 100%;
      padding-top: 12px;
      height: 100%;
      .head {
        color: @font-minor-color;
        padding-right: 8px;
        padding-left: 12px;
        .switch {
          margin-left: 18px;
        }
      }
      .group-wraper {
        height: 100%;
        margin-top: 10px;
        overflow-y: auto;
        .item {
          width: 100%;
          height: 54px;
          padding: 0 12px;
          cursor: pointer;
          &.item-selected {
            background: #ebf0fe !important;
          }
          > div {
            margin-left: 28px;
            img {
              width: 36px;
              height: 36px;
              border-radius: 6px;
              margin-right: 13px;
            }
            span:first-child {
              font-size: 14px;
            }
            span:last-child {
              font-size: 12px;
              color: @font-minor-color;
            }
          }
          &:hover {
            background: rgba(0, 0, 0, 0.02);
          }
        }
      }
    }
  }
}
.empty {
  margin-top: 20px;
}
.not-more {
  height: 30px;
  line-height: 30px;
  text-align: center;
  color: @font-minor-color;
}
:deep(.ant-popover) {
  box-shadow: none;
}
</style>
