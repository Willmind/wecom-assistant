<template>
  <div class="app-home">
    <span class="title">全部功能</span>
    <ul class="tab-list jz-flex jz-flex-wrap">
      <li
        v-for="(item, index) in state.list.filter((i) => !i.isHide)"
        :key="index"
        class="jz-flex jz-flex-center"
        @click="changeTab(item)"
      >
        <svg-icon :icon-name="item.icon" class="li-icon" />
        <div class="jz-flex-1 sum jz-flex jz-flex-ct jz-flex-col lineClamp1">
          <span class="name lineClamp1">{{ item.name }}</span>
          <span class="desc ineClamp1">{{ item.desc }}</span>
        </div>
        <svg-icon
          class="li-star"
          @click.stop.prevent="handleStick(item.id)"
          :icon-name="item.isStick ? 'ic_collect' : 'ic_gray_collect'"
          style="color: #fff"
        />
      </li>
    </ul>
  </div>
</template>

<script setup>
import toolData from '@/assets/js/toolConfig'
import { applyStore } from '@/store/modules/apply'
import useMessage from '@/composables/web/useMessage'
const { createMessage } = useMessage()
const store = applyStore()
const { currentId } = storeToRefs(store)
const state = reactive({
  list: toolData
})

const changeTab = (item) => {
  if (item.id === currentId) return
  store.changeComponent(item)
}

const handleStick = (id) => {
  if (id === 1) return
  let _index = state.list.findIndex((i) => i.id === id)
  state.list[_index].isStick = !state.list[_index].isStick
  createMessage.success(state.list[_index].isStick ? '已置顶' : '已取消置顶')
}
</script>

<style lang="less" scoped>
.app-home {
  width: 100%;
  height: 100%;
  padding: 48px 32px;
  .title {
    font-size: 20px;
    font-weight: 600;
    margin-bottom: 24px;
    display: block;
  }
  .tab-list {
    li {
      width: 250px;
      height: 80px;
      cursor: pointer;
      margin-bottom: 16px;
      background: #fff;
      margin-right: 16px;
      padding: 0 14px;
      border-radius: 12px;
      transition: all 0.2s;
      .li-star {
        opacity: 0;
        width: 20px !important;
        height: 20px !important;
      }
      .li-icon {
        width: 40px !important;
        height: 40px !important;
        margin-right: 12px;
        color: #fff !important;
      }
      .sum {
        width: 100%;
        font-size: 12px;
        .name {
          font-weight: 600;
          font-size: 14px;
        }
        .desc {
          color: rgba(0, 0, 0, 0.4);
        }
      }
      &:hover {
        box-shadow: 0px 6px 20px 0px rgba(0, 0, 0, 0.08);
        .li-star {
          opacity: 1;
        }
      }
    }
  }
}
</style>
