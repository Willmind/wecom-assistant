import { MessageTypeEnum } from '@/enums/MessageTypeEnum.js'

const isincludes = (val, arrays) => arrays.includes(val)

export const isResMsg = (item) => {
  let isTrue = item.icon === 'image' || item.icon === 'video' || item.icon === 'file'
  if (!isTrue) {
    return isincludes(item.msg_type, [MessageTypeEnum.image, MessageTypeEnum.video, MessageTypeEnum.file])
  }
  return isTrue
}

export const isWechatMsg = (item) => {
  let isTrue = item.icon === 'mini' || item.icon === 'voice' || item.icon === 'video_num'
  if (!isTrue) {
    return isincludes(item.msg_type, [MessageTypeEnum.mini, MessageTypeEnum.voice, MessageTypeEnum.video_num])
  }
  return isTrue
}
