<template>
  <a-popover
    destroyTooltipOnHide
    overlayClassName="ant-popover-not-arrow range-popover"
    v-model:visible="visible"
    trigger="click"
    :disabled="disabled"
    :overlayStyle="{ padding: 0 }"
    placement="bottomLeft"
    @visibleChange="handleChange"
    :getPopupContainer="
      (triggerNode) => {
        return triggerNode.parentNode || document.body
      }
    "
  >
    <template #content>
      <div class="pop ant-popover-content jz-flex jz-flex-col" style="margin-bottom: 48px">
        <div class="pop-content jz-flex-1 jz-flex">
          <div class="list-wraper jz-flex-1 jz-flex-col jz-flex jz-flex-col">
            <div class="head jz-flex jz-flex-rb jz-flex-cc">
              <span class="head-num">已选区</span>
            </div>
            <div class="jz-flex select-list">
              <div class="select-list-item" v-for="item in selectData" :key="randomUUID()">
                {{ item.name || item.username }}
                <svg-icon @click="cancelTreeItem(item)" icon-name="jz_close" class="close-icon" />
                <!--                <close-outlined @click="cancelTreeItem(item)" class="close-icon" />-->
              </div>
            </div>
            <a-menu class="menu-list" v-model:selectedKeys="current" mode="horizontal">
              <a-menu-item key="department"> 部门</a-menu-item>
              <a-menu-item key="staff"> 员工</a-menu-item>
            </a-menu>

            <div class="jz-flex jz-flex-dir-col select-content">
              <template v-if="!isDepartment">
                <div class="jz-flex search-list">
                  <a-input
                    class="keywork-search-input"
                    style="flex: 1"
                    v-model:value="searchParams.name"
                    allowClear
                    placeholder="员工姓名/职位"
                  >
                    <template #suffix v-if="!searchParams.name">
                      <svg-icon icon-name="ic_search" />
                    </template>
                  </a-input>
                  <a-cascader
                    allowClear
                    v-model:value="searchParams.dept_ids"
                    change-on-select
                    style="margin-left: 15px; flex: 1"
                    :field-names="{ label: 'name', value: 'id', children: 'child' }"
                    :options="treeData"
                    placeholder="部门"
                  />
                  <a-select
                    style="margin-left: 15px; flex: 1"
                    v-model:value="searchParams.status"
                    :options="state.typeList"
                    placeholder="在职"
                  />
                </div>
                <div class="jz-flex-1" style="overflow: auto; padding: 0 8px; margin: 0 2px">
                  <a-table
                    class="range-table"
                    rowKey="id"
                    :columns="columns"
                    :dataSource="state.list"
                    :rowSelection="rowSelection"
                    :bordered="false"
                    :pagination="false"
                    :loading="state.loading"
                    v-infinite-scroll="getDebounceSearch"
                    :infinite-scroll-immediate-check="false"
                    :infinite-scroll-disabled="state.isFinished"
                    :infinite-scroll-watch-disabled="state.isFinished"
                    :infinite-scroll-distance="10"
                  >
                    <template #bodyCell="{ record, column }">
                      <template v-if="column.key === 'name'">
                        <div class="item-cell">
                          {{ record.name || record.username }}
                        </div>
                      </template>
                      <template v-if="column.key === 'position'">
                        <div class="item-cell">
                          {{ record.position }}
                        </div>
                      </template>
                      <template v-if="column.key === 'dept_name'">
                        <div class="item-cell">
                          {{ record.dept_name }}
                        </div>
                      </template>
                      <template v-if="column.key === 'status_text'">
                        <div class="item-cell">
                          {{ record.status_text }}
                        </div>
                      </template>
                    </template>
                    <template #emptyText>
                      <div class="not-more jz-flex jz-flex-center jz-flex-col">
                        <img src="@/assets/imgs/not_more.png" alt="" />
                        <span>无内容</span>
                      </div>
                    </template>
                  </a-table>
                </div>
              </template>
              <template v-else>
                <div class="jz-flex search-list">
                  <a-input
                    class="keywork-search-input"
                    @change="searchValueWatch"
                    v-model:value="searchValue"
                    allowClear
                    placeholder="搜索部门名称"
                  >
                    <template #suffix v-if="!searchValue">
                      <svg-icon icon-name="ic_search" />
                    </template>
                  </a-input>
                </div>
                <div class="jz-flex-1" style="overflow: auto; padding: 0 8px 10px 8px; margin: 0 2px">
                  <a-tree
                    checkStrictly
                    @check="getTreeCheck"
                    checkable
                    defaultExpandAll
                    :auto-expand-parent="autoExpandParent"
                    :expanded-keys="expandedKeys"
                    @expand="onExpand"
                    :tree-data="treeData"
                    v-model:checkedKeys="checkedTreeKeys"
                    :field-names="{ title: 'name', key: 'id', children: 'child' }"
                  >
                    <template #title="{ name }">
                      <span v-if="name.indexOf(searchValue) > -1">
                        {{ name.substr(0, name.indexOf(searchValue)) }}
                        <span style="color: #f50">{{ searchValue }}</span>
                        {{ name.substr(name.indexOf(searchValue) + searchValue.length) }}
                      </span>
                      <span v-else>{{ name }}</span>
                    </template>
                  </a-tree>
                </div>
              </template>
            </div>
          </div>
        </div>
        <div class="ant-popover-footer jz-flex jz-flex-rr">
          <div class="btns">
            <a-button @click="close">取消</a-button>
            <a-button type="primary" :disabled="computedBtn" @click="handleConfirm">确定</a-button>
          </div>
        </div>
      </div>
    </template>
    <slot></slot>
  </a-popover>
</template>
<script setup>
import { computed, reactive, ref, unref } from 'vue'
import useMessage from '@/composables/web/useMessage'
import { getStaffListApi } from 'api/common'
import { randomUUID } from 'crypto'
import { debounce } from 'lodash-es'

const { createMessage } = useMessage()
const emit = defineEmits(['success'])
const visible = ref(false)
const page = ref(1)
const isSwitch = ref(false)
const props = defineProps({
  ids: [String, Number],
  rangeList: Array,
  treeData: Array,
  disabled: Boolean
})

const searchParams = reactive({
  name: '',
  dept_ids: [],
  status: 1,
  page: 1,
  limit: 1000,
  dept_id: null
})

const columns = [
  { title: '姓名', key: 'name', width: '100px' },
  { title: '职务', key: 'position', width: '100px' },
  { title: '部门', key: 'dept_name', width: '100px' },
  { title: '状态', key: 'status_text', width: '100px' }
]

const state = reactive({
  isFinished: false,
  list: [],
  select_list: '',
  selectedKeys: [],
  typeList: [
    { label: '在职', value: 1 },
    { label: '离职', value: 0 }
  ],
  loading: false,
  paginationParams: {
    total: 0,
    current: 1,
    showSizeChanger: false
  }
})
const current = ref(['department'])
const isDepartment = computed(() => current.value.some((item) => item === 'department'))

/**
 * 树结构
 * @type {{children: string, title: string}}
 */
const treeData = ref([])
const checkedTreeKeys = ref([])
const selectData = ref([])
const treeCheckedNodes = ref([])

//item close回调
const cancelTreeItem = (item) => {
  let index = null
  if (item.type === 'dept') {
    index = selectData.value.findIndex((x) => x.type === 'dept' && x.id === item.id)
  } else {
    index = selectData.value.findIndex((x) => x.type === 'admin' && x.id === item.id)
  }
  selectData.value.splice(index, 1)

  //树
  let tempTreeIds = selectData.value
    .filter((item) => {
      return item.type === 'dept'
    })
    .map((i) => i.id)

  let tempTreeIds2 = selectData.value
    .filter((item) => {
      return item.type === 'admin'
    })
    .map((i) => i.id)

  unref(selectionRowsPlus).splice(
    unref(selectionRowsPlus).findIndex((x) => x.id === item.id),
    1
  )

  checkedTreeKeys.value = tempTreeIds
  checkedTableKeys.value = tempTreeIds2
}

//树结构搜索、回显=======================
const getTreeCheck = (checkedKeys, e) => {
  let { checkedNodes } = e
  treeCheckedNodes.value = checkedNodes
  treeCheckedNodes.value.forEach((i) => (i.type = 'dept'))
  if (checkedTableKeys.value.length > 0) {
    selectData.value = unref(selectionRowsPlus).concat(treeCheckedNodes.value)
  } else {
    selectData.value = treeCheckedNodes.value
  }
}
const getParentKey = (key, tree) => {
  let parentKey
  for (let i = 0; i < tree.length; i++) {
    const node = tree[i]
    if (node.child) {
      if (node.child.some((item) => item.id === key)) {
        parentKey = node.id
      } else if (getParentKey(key, node.child)) {
        parentKey = getParentKey(key, node.child)
      }
    }
  }
  return parentKey
}
const generateList = (data) => {
  for (let i = 0; i < data.length; i++) {
    const node = data[i]
    dataList.push({
      name: data[i].name,
      id: data[i].id
    })

    if (node.child) {
      generateList(node.child)
    }
  }
}
const expandedKeys = ref([])
const autoExpandParent = ref(true)
const dataList = []
const searchValue = ref('')
const setStyleDisplay = (key, nodes) => {
  let nums = 0
  for (let data of nodes) {
    let bl = false
    if (data.name.indexOf(key) > -1) {
      bl = true
      nums += 1
    }
    if (!!data.child) {
      if (data.child.length > 0) {
        let count = setStyleDisplay(key, data.child)
        // 如果想 子节点有key 即使父节点没有key也显示的话 添加下面的语句
        // nums += count
        if (!bl && count === 0) {
          bl = false
        } else {
          bl = true
        }
      }
    }
    if (bl) {
      delete data['style']
    } else {
      data['style'] = 'display: none'
    }
  }
  return nums
}

const getExpand = (value) => {
  if (!dataList.length) {
    generateList(treeData.value)
  }
  const expanded = dataList
    .map((item) => {
      if (item.name.indexOf(value) > -1) {
        return getParentKey(item.id, treeData.value)
      }
      return null
    })
    .filter((item, i, self) => item && self.indexOf(item) === i)
  expandedKeys.value = expanded
  autoExpandParent.value = true
}
const searchValueWatch = (e) => {
  const value = e.target.value
  getExpand(value)
  setStyleDisplay(value, treeData.value)
}
const onExpand = (keys) => {
  expandedKeys.value = keys
  autoExpandParent.value = false
}
//树结构搜索、回显=======================

const computedBtn = computed(() => {
  let lock = true
  if (selectData.value?.length) {
    lock = false
  }
  return lock
})

const getDebounceSearch = () => {
  debounceSearch(toRaw(unref(getParams)))
}

/**
 * 员工列表
 * @returns {Promise<void>}
 */
const checkedTableKeys = ref([])
const selectionRowsPlus = ref([])
const rowSelection = computed(() => ({
  selectedRowKeys: checkedTableKeys.value,
  hideSelectAll: true,
  onChange: (selectedRowKeys) => {
    setTimeout(() => {
      checkedTableKeys.value = selectedRowKeys
    })
  },
  onSelect: (record, selected) => {
    selected
      ? unref(selectionRowsPlus).push({
          id: record.id,
          name: record.name,
          type: 'admin'
        })
      : unref(selectionRowsPlus).splice(
          unref(selectionRowsPlus).findIndex((x) => x.id === record.id),
          1
        )

    //获取树已选数据
    let treeSelectData = selectData.value.filter((item) => {
      return item.type === 'dept'
    })

    if (treeSelectData.length > 0) {
      selectData.value = treeSelectData.concat(selectionRowsPlus.value)
    } else {
      selectData.value = selectionRowsPlus.value
    }
  }
}))

// 确认提交
const handleConfirm = () => {
  console.log(selectData.value)
  if (selectData.value.length === 0) {
    createMessage.info('请选择部门/人员')
    return
  }
  close()
  setTimeout(() => {
    const params = unref(selectData)
    emit('success', params)
  }, 300)
}

// 展示提示框
const handleChange = (show) => {
  if (props.disabled) {
    visible.value = false
    return
  }
  if (show) {
    selectionRowsPlus.value = []
    checkedTableKeys.value = []
    if (props.ids) {
      state.select_list = props.ids
    }

    if (props.rangeList) {
      selectData.value = props.rangeList
      let _checkedTableKeys = []
      let _checkedTreeKeys = []
      for (let item of unref(selectData)) {
        if (item.type === 'admin') {
          _checkedTableKeys.push(item.id)
          unref(selectionRowsPlus).push(item)
        } else {
          _checkedTreeKeys.push(item.id)
        }
      }
      checkedTableKeys.value = _checkedTableKeys
      checkedTreeKeys.value = _checkedTreeKeys
    }
    getExpand('')
  } else {
    page.value = 1
    state.list = []
    isSwitch.value = false

    searchParams.name = ''
    searchParams.dept_ids = []
    searchParams.status = 1
    searchParams.page = 1
    searchParams.limit = 1000
    selectionRowsPlus.value = []
    checkedTableKeys.value = []
  }
}

// 获取form参数
const getParams = computed(() => {
  return {
    name: searchParams.name,
    dept_id: searchParams.dept_ids ? searchParams.dept_ids[searchParams.dept_ids.length - 1] : null,
    status: searchParams.status,
    page: state.paginationParams.current,
    limit: 10
  }
})

// 关闭
const close = () => {
  visible.value = false
}

/**
 * 员工列表搜索
 * @param params
 * @returns {Promise<boolean>}
 */
const querySearch = async (params) => {
  state.loading = true
  if (state.isFinished) {
    state.loading = false
    return false
  }
  let { data } = await getStaffListApi(params)
  if (data.total === 0) {
    state.list = []
  } else if (data.data.length) {
    let ids = selectData.value.filter((i) => i.type === 'admin').map((i) => i.id)
    checkedTableKeys.value = ids || []
    data.data.forEach((i) => {
      if (ids.includes(i.id)) {
        i.isCheck = true
      } else {
        i.isCheck = false
      }
    })
    state.list = [...state.list, ...data.data]
    state.paginationParams.total = data.total
    state.paginationParams.current += 1
  } else {
    state.isFinished = true
  }
  state.loading = false
}
const debounceSearch = debounce(querySearch, 350)

// 监听=======

watch(
  () => searchParams,
  () => {
    if (searchParams.dept_ids && searchParams.dept_ids.length > 0) {
      searchParams.dept_id = searchParams.dept_ids[searchParams.dept_ids.length - 1]
    } else {
      searchParams.dept_id = null
    }
    state.list = []
    state.paginationParams.current = 1
    state.isFinished = false
    debounceSearch(toRaw(unref(getParams)))
  },
  {
    deep: true
  }
)

onMounted(async () => {
  treeData.value = props.treeData //获取部门树结构
  getDebounceSearch() //获取员工列表
})
</script>

<style lang="less" scoped>
.pop {
  width: 448px;
  height: 460px;
  overflow: hidden;
  margin-top: -12px;

  .group-num {
    padding-bottom: 10px;
    text-align: center;
  }

  .pop-content {
    height: 100%;
    overflow: hidden;

    .form-wraper {
      width: 240px;
      height: 100%;
      padding-top: 12px;
      padding-right: 16px;
      border-right: 1px solid #eee;

      .ant-form-head {
        height: 22px;
        line-height: 22px;
        margin-bottom: 8px;
      }
    }

    .list-wraper {
      width: 100%;
      padding-top: 16px;
      height: 100%;

      .select-list {
        background: #fafafa;
        border-radius: 6px 6px 6px 6px;
        padding: 5px;
        flex-wrap: wrap;
        height: 64px;
        overflow: auto;
        margin: 0 11px;

        .select-list-item {
          background: #f0f0f0;
          border-radius: 4px 4px 4px 4px;
          padding: 6px 12px;
          font-size: 12px;
          font-weight: 400;
          color: #000000;
          margin-right: 5px;
          margin-bottom: 5px;
          height: 22px;
          display: flex;
          justify-content: space-between;
          align-items: center;

          .close-icon {
            cursor: pointer;
            margin-left: 4px;

            &:hover {
              opacity: 0.5;
            }
          }
        }
      }

      .select-content {
        margin: 16px 0 0 0;
        flex: 1;
        overflow: auto;

        .search-list {
          margin: 0 16px 24px 16px;
        }
      }

      .menu-list {
        height: 48px;
        margin: 16px 16px 0 16px;
      }

      .ant-menu {
        :deep(.ant-menu-item) {
          padding-left: 0px;
          margin-right: 20px;
          color: #999999;

          &:hover {
            color: #3165f5;
          }

          &::after {
            left: 0px;
          }

          &:hover {
            &::after {
              border-bottom: 2px solid transparent;
            }
          }
        }

        :deep(.ant-menu-item-selected) {
          &:hover {
            &::after {
              border-bottom: 2px solid #3165f5;
            }
          }

          .ant-menu-title-content {
            color: #3165f5;
          }
        }
      }

      .head {
        color: @font-minor-color;
        padding-right: 8px;
        margin-bottom: 8px;
        padding-top: 7px;
        padding-left: 16px;

        .switch {
          margin-left: 18px;
        }
      }

      .group-wraper {
        height: 100%;
        margin-top: 10px;
        overflow-y: auto;

        .item {
          width: 100%;
          height: 54px;
          padding: 0 12px;
          cursor: pointer;

          &.item-selected {
            background: #ebf0fe !important;
          }

          > div {
            margin-left: 28px;

            img {
              width: 36px;
              height: 36px;
              border-radius: 6px;
              margin-right: 13px;
            }

            span:first-child {
              font-size: 14px;
            }

            span:last-child {
              font-size: 12px;
              color: @font-minor-color;
            }
          }

          &:hover {
            background: rgba(0, 0, 0, 0.02);
          }
        }
      }
    }
  }
}

.empty {
  margin-top: 20px;
}

.not-more {
  height: 30px;
  line-height: 30px;
  text-align: center;
  color: @font-minor-color;
}

:deep(.ant-popover) {
  box-shadow: none;
}
</style>

<style lang="less">
.range-popover {
  .ant-popover-inner-content {
    padding: 0;
  }
}

.range-table {
  .not-more {
    img {
      width: 110px;
      height: 110px;
      margin-bottom: 4px;
    }
    span {
      font-size: 12px;
    }
  }
  .ant-table-tbody > tr > td {
    min-width: 50px;
    max-width: 100px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    word-wrap: break-word;
    word-break: break-all;
  }

  .ant-table-cell {
    padding: 10.5px 16px;

    &::before {
      display: none;
    }
  }

  .ant-table-thead {
    position: sticky;
    top: 0;
    z-index: 1;
    .ant-table-cell {
      color: #999999;
    }
  }
}
</style>
