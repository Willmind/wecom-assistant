<template>
  <BasicDrawer
    v-bind="$attrs"
    showFooter
    :register="registerDrawer"
    :showCancelBtn="false"
    :showClose="false"
    okText="确定"
    classes="editor-drawer"
    :loading="state.loading"
    :confirmLoading="state.isSubmiting"
    :mask="props.mask"
    :showForehead="props.showForehead"
    :innerPage="props.innerPage"
    width="864px"
    :get-container="props.getContainer"
  >
    <template #title>
      <div class="head jz-flex jz-flex-cc" :style="{ height: props.headHeight }">
        <a-tooltip placement="top" style="background: red">
          <template #title>
            <span>返回</span>
          </template>
          <span class="back-btn jz-flex jz-flex-center jz-pointer" @click="closeDrawer">
            <svg-icon icon-name="login_back" style="width: 32px; height: 32px" />
          </span>
        </a-tooltip>
        <span class="tit">{{ getTitle }} </span>
      </div>
    </template>
    <div class="wrapper jz-flex jz-flex-col">
      <a-form class="editor-form" :colon="false" v-bind="formLayout">
        <a-form-item label="素材标题">
          <div class="jz-flex jz-flex-cc">
            <a-input
              v-model:value="state.form.title"
              :maxlength="15"
              placeholder="请输入主题，用于标识"
              style="width: 226px; margin-right: 8px"
            />
            <span style="color: #999">{{ state.form.title.length }}/15</span>
          </div>
        </a-form-item>

        <a-form-item label="可见范围" style="margin-bottom: 12px">
          <div class="jz-flex-1 jz-input jz-flex jz-flex-rl">
            <a-radio-group v-model:value="state.form.type">
              <a-radio :value="1">仅自己可见</a-radio>
              <a-radio :value="2">部门可见，同时添加到团队素材</a-radio>
            </a-radio-group>
          </div>
          <div></div>
        </a-form-item>

        <div
          class="jz-flex jz-flex-cc"
          style="margin-left: 114px"
          v-if="state.form.type === 2 && isLoadRange"
        >
          <div class="jz-flex select-list">
            <div class="select-list-item" v-for="item in state.form.rangeList" :key="randomUUID()">
              {{ item.name || item.username }}
              <svg-icon @click="cancelItem(item)" icon-name="jz_close" class="close-icon" />
            </div>

            <!--            rangeList为总数据-->
            <!--            treeData为树结构数据-->
            <RangePopover :rangeList="state.form.rangeList" :treeData="treeData" @success="handleStaffData">
              <a-button
                class="add-btn"
                type="info"
                size="large"
                :disabled="isUpperLimitWithType('group_data')"
              >
                <template #icon>
                  <SvgIcon icon-name="ic_add_btn" :iconSize="28" />
                </template>
                添加部门/人员
              </a-button>
            </RangePopover>
          </div>
        </div>

        <a-form-item label="他人操作权限" style="padding-top: 12px">
          <div class="jz-flex-1 jz-input jz-flex jz-flex-rl">
            <a-checkbox-group v-model:value="state.form.permission">
              <a-checkbox :value="1">可导入</a-checkbox>
              <a-checkbox :value="2">可复制</a-checkbox>
              <a-checkbox :value="4">可编辑</a-checkbox>
            </a-checkbox-group>
          </div>
        </a-form-item>

        <a-form-item label="素材内容">
          <div class="card-list jz-flex jz-flex-col">
            <draggable
              handle=".menu-handle"
              itemKey="uid"
              :component-data="{
                tag: 'div',
                type: 'transition-group',
                name: !state.isDrag ? 'flip-list' : null
              }"
              v-model="modelRef.media_content"
              v-bind="dragOptions"
              @start="state.isDrag = true"
              @end="state.isDrag = false"
            >
              <template #item="{ element: item, index }">
                <div class="card-item-wrap jz-flex jz-flex-cc" :key="index">
                  <a-dropdown :trigger="['click']">
                    <a-tooltip title="长按拖拽 点击打开菜单">
                      <menu-outlined class="menu-handle" />
                    </a-tooltip>
                    <template #overlay>
                      <a-menu class="menu-list">
                        <a-menu-item
                          v-for="option in state.operateOptions"
                          :disabled="getDisableOperate(option, index)"
                          :key="option.icon"
                          @click="handleRemoveOperation(option, index)"
                        >
                          <div class="menu-item jz-flex jz-flex-cc" style="padding: 4px 0">
                            <svg-icon :icon-name="`ic_${option.icon}`" style="margin-right: 8px" />
                            <span>{{ option.label }}</span>
                          </div>
                        </a-menu-item>
                      </a-menu>
                    </template>
                  </a-dropdown>
                  <div class="card-item jz-flex">
                    <div class="card-num jz-flex jz-flex-center">{{ getMsgNumber(index) }}</div>
                    <div class="card-content">
                      <MessageCardWithType :item="item" :msgType="item.msg_type" />
                    </div>
                    <div class="card-extra jz-flex">
                      <div class="operate-btns jz-flex jz-flex-cc">
                        <UploadFile
                          :data="item"
                          v-if="isResMsg(item)"
                          class="jz-flex jz-flex-cc"
                          @change="(file) => handleSelectedFile({ file, item }, index, 'update')"
                        >
                          <a-tooltip title="编辑">
                            <svg-icon icon-name="ic_edit" />
                          </a-tooltip>
                        </UploadFile>
                        <a-tooltip title="编辑" v-else>
                          <SvgIcon icon-name="ic_edit" @click="handleCurdOperate('edit', item, index)" />
                        </a-tooltip>
                        <MessageTypeDropdown
                          :disabled="isUpperLimitWithType('addContent')"
                          @select="(item) => handleSelectMenu(item, index, 'insert')"
                          @select-file="(res) => handleSelectedFile(res, index, 'insert')"
                        >
                          <template #insert-item>
                            <p style="color: rgba(0, 0, 0, 0.4); padding: 8px 0 8px 8px">下方新增一条</p>
                          </template>
                          <template #adduction>
                            <SvgIcon icon-name="ic_add" />
                          </template>
                        </MessageTypeDropdown>
                        <a-tooltip title="删除">
                          <SvgIcon icon-name="ic_delete" @click="handleCurdOperate('delete', item, index)" />
                        </a-tooltip>
                      </div>
                    </div>
                  </div>
                </div>
              </template>
            </draggable>
          </div>
          <div class="add-content jz-flex jz-flex-cc">
            <MessageTypeDropdown
              :disabled="isUpperLimitWithType('addContent')"
              @select="handleSelectMenu"
              @select-file="handleSelectedFile"
            >
              <template #adduction>
                <div class="jz-flex jz-flex-cc">
                  <plus-circle-filled class="add-icon" />
                  <a-button type="link">添加内容</a-button>
                </div>
              </template>
            </MessageTypeDropdown>
            <span class="desc">{{ modelRef.media_content?.length || 0 }}/20</span>
          </div>
        </a-form-item>
      </a-form>
      <EditorTextModal ref="textRef" @success="handleMsgMoadlCallback" />
      <EditorLinkModal ref="linkRef" @success="handleMsgMoadlCallback" />
      <EditorResourceModal ref="resRef" @success="handleMsgMoadlCallback" />
      <EditorMediaModal
        :media_length="modelRef.media_content?.length || 0"
        ref="mediaRef"
        @success="handleMediaMoadCallback"
      />
    </div>
    <template #footer>
      <div class="jz-flex jz-flex-rr">
        <a-button style="margin-right: 10px" @click="onClose">取消</a-button>
        <a-button type="primary" :disabled="computedBtn" @click="handleConfirm">保存</a-button>
      </div>
    </template>
  </BasicDrawer>
</template>
<script setup>
import { randomUUID } from 'crypto'
import { Form } from 'ant-design-vue'
import { cloneDeep } from 'lodash-es'
import draggable from 'vuedraggable'
import useMessage from '@/composables/web/useMessage'
import { computed, reactive, ref, toRef, unref } from 'vue'
import { useDrawerInner } from '@/components/basic/drawer'
import { MessageTypeEnum } from '@/enums/MessageTypeEnum'
import SvgIcon from '@/components/SvgIcon/index.vue'
import { getDeptTreeApi, uploadFile, uploadImage, uploadVideo } from '@/api/common'
import RangePopover from './popover/RangePopover.vue'
import { addMedia } from 'api/material'
import { isWechatMsg, isResMsg } from './popover/utils'
import { apiGetUserInfo } from 'api/login'

const { createConfirm } = useMessage()

const props = defineProps({
  register: Function,
  mask: Boolean,
  showForehead: Boolean,
  getContainer: Boolean,
  innerPage: Boolean,
  headHeight: String
})
const useForm = Form.useForm
const isCopy = ref(false)
const isLoadRange = ref(false)
const copyMedia = ref([])

const state = reactive({
  isSubmiting: false,
  isUpdate: false,

  form: {
    title: '',
    permission: [1],
    type: 2,
    rangeList: [],
    admin_ids: [],
    dept_ids: [],
    name: '方案1',
    id: undefined,
    media_content: []
  },

  rulesRef: {
    name: [{ required: true }]
  },
  selectedTagList: [],
  timeOptions: [
    { label: '秒', value: 1 },
    { label: '分', value: 2 },
    { label: '时', value: 3 }
  ],
  operateOptions: [
    { label: '置顶', icon: 'top', key: 1 },
    { label: '上移一条', icon: 'up', key: 2 },
    { label: '下移一条', icon: 'down', key: 3 },
    { label: '置底', icon: 'bottom', key: 4 }
  ],
  remarkOptions: ['微信昵称', '性别', '添加日期'],
  isDrag: false,
  loading: false
})
const textRef = ref()
const linkRef = ref()
const resRef = ref()
const mediaRef = ref()

const modelRef = toRef(state, 'form')

const emit = defineEmits(['success'])

const formLayout = {
  labelCol: { span: 4 },
  wrapperCol: { span: 20 }
}

const { createMessage } = useMessage()
const { validate } = Form.useForm(modelRef, state.rulesRef)

const [registerDrawer, { closeDrawer }] = useDrawerInner((res) => {
  resetData()
  state.isUpdate = res.isUpdate
  state.form.id = res?.data?.id
  loadRangeData().then(() => {
    /**
     * 复制素材
     */
    if (res.isCopy) {
      isCopy.value = true
      copyMedia.value = res?.data?.media_content
      setTimeout(() => {
        unref(modelRef).media_content = res.data.media_content
        unref(modelRef).title = res.data.title
      }, 100)
    } else {
      isCopy.value = false
      if (res.isUpdate) {
        setTimeout(() => {
          state.form = res.data
          handleRangeData()
        }, 100)
      } else {
        //新增素材的时候默认选中自己部门
        state.form.type = 2
        getDefaultDept()
      }
    }
    isLoadRange.value = true
  })
})

const resetData = () => {
  state.form = {
    title: '',
    permission: [1],
    type: 1,
    rangeList: [],
    admin_ids: [],
    dept_ids: [],
    id: undefined,
    media_content: []
  }
}

// 上限判断
const isUpperLimitWithType = (type) => {
  if (type === 'addContent') {
    return unref(modelRef).media_content?.length >= 20
  }
}

//素材库信息
const handleMediaMoadCallback = (data) => {
  for (let item of data) {
    unref(modelRef).media_content.push(item)
  }

  createMessage.success('导入成功')
}

const handleStaffData = (items = []) => {
  state.form.rangeList = [...items]
  state.form.admin_ids = state.form.rangeList.filter((i) => i.type === 'admin').map((el) => el.id)
  state.form.dept_ids = state.form.rangeList.filter((i) => i.type === 'dept').map((el) => el.id)
}

/**
 * 获取默认部门
 * @returns {Promise<void>}
 */
const getDefaultDept = async () => {
  let { code, data } = await apiGetUserInfo()
  if (code === 1000) {
    state.form.rangeList.push({
      id: data.department_id,
      type: 'dept',
      name: data.position.substring(data.position.lastIndexOf('\/') + 1, data.position.length) //截取最后一个斜杆后面的字符
    })
    state.form.admin_ids = state.form.rangeList.filter((i) => i.type === 'admin').map((el) => el.id)
    state.form.dept_ids = state.form.rangeList.filter((i) => i.type === 'dept').map((el) => el.id)
  }
}

const cancelItem = (item) => {
  let index
  if (item.hasOwnProperty('child')) {
    index = state.form.rangeList.findIndex((i) => {
      return i.id === item.id && item.hasOwnProperty('child')
    })
    state.form.rangeList.splice(index, 1)
  } else {
    index = state.form.rangeList.findIndex((i) => {
      return i.id === item.id
    })
    state.form.rangeList.splice(index, 1)
    state.form.admin_ids = state.form.rangeList.filter((i) => i.type === 'admin').map((el) => el.id)
    state.form.dept_ids = state.form.rangeList.filter((i) => i.type === 'dept').map((el) => el.id)
  }
}

// ------------------------自动发消息----------------
// 拖动动效
const dragOptions = ref({
  animation: 200,
  disabled: false,
  ghostClass: 'ghost'
})

const currMessageItemIndex = ref(-1)
// 删除/修改操作
const handleCurdOperate = (operType, item, index) => {
  let { msg_type } = item
  currMessageItemIndex.value = index
  switch (operType) {
    case 'edit':
      handleOpenMsgModal(MessageTypeEnum[msg_type], item, true)
      break
    case 'delete':
      unref(modelRef).media_content.splice(index, 1)
      break
  }
}

// 添加消息内容
const handleSelectMenu = (item, index, operType) => {
  let { icon: type } = item
  currMessageItemIndex.value = index
  handleOpenMsgModal(type, item, false, operType)
}

const handleOpenMsgModal = (type, item = {}, isUpdate, operType) => {
  const { key, msg_type } = item
  switch (type) {
    case 'media':
      mediaRef.value.openModal({
        isUpdate,
        operType,
        data: cloneDeep(item),
        media_length: unref(modelRef).media_content.length //传入当前素材长度
      })
      break
    case 'text':
      textRef.value.openModal({
        isUpdate,
        operType,
        data: cloneDeep(item)
      })
      break
    case 'link':
      linkRef.value.openModal({
        isUpdate,
        operType,
        data: cloneDeep(item)
      })
      break
    default:
      if (isWechatMsg(item)) {
        resRef.value.openModal({
          isUpdate,
          operType,
          title: item.label,
          data: {
            ...cloneDeep(item),
            msg_type: key || msg_type
          }
        })
      }
      break
  }
}

// 保存消息成功回调处理
const handleMsgMoadlCallback = (_, { isUpdate, data, operType }) => {
  if (Array.isArray(data)) {
    let textList = data.map((row) => ({ ...row, wait: row.wait || 10, time_type: row.time_type || 1 }))
    if (operType === 'insert') {
      unref(modelRef).media_content.splice(currMessageItemIndex.value + 1, 0, ...textList)
    } else {
      unref(modelRef).media_content.push(...textList)
    }
    return
  }
  const params = {
    ...data,
    wait: data.wait || 10,
    time_type: data.time_type || 1
  }
  if (isUpdate && ~currMessageItemIndex.value) {
    unref(modelRef).media_content[unref(currMessageItemIndex)] = params
  } else {
    if (operType === 'insert') {
      unref(modelRef).media_content.splice(currMessageItemIndex.value + 1, 0, params)
    } else {
      unref(modelRef).media_content.push(params)
    }
  }
  currMessageItemIndex.value = -1
}

// 上传图片/文件/文档
const handleSelectedFile = async ({ file, item: { key, msg_type } }, updateIndex, operType) => {
  key = key ?? msg_type
  if (file) {
    let index = -1
    if (updateIndex !== undefined && updateIndex > -1) {
      if (operType !== 'insert') {
        const editItem = unref(modelRef).media_content[updateIndex]
        if (editItem) {
          editItem.msg.url = ''
          editItem.msg.name = file.name
          editItem.uploading = true
        }
      }
      index = operType === 'insert' ? updateIndex + 1 : updateIndex
    } else {
      index = unref(modelRef).media_content.push(addNewMsg()) - 1
    }
    try {
      const uploadRequest =
        key === MessageTypeEnum.image ? uploadImage : key === MessageTypeEnum.video ? uploadVideo : uploadFile
      const { data } = await uploadRequest({ file })
      if (operType === 'insert') {
        unref(modelRef).media_content.splice(index, 0, addNewMsg())
      } else {
        unref(modelRef).media_content[index].msg.url = data.url
      }
      createMessage.success('上传成功')
    } catch (err) {
      unref(modelRef).media_content.splice(index, 1)
    } finally {
      unref(modelRef).media_content[index].uploading = false
    }
  }

  function addNewMsg() {
    return {
      msg_type: key,
      wait: 10,
      time_type: 1,
      msg: {
        name: file.name,
        url: ''
      },
      uploading: true
    }
  }
}

const getDisableOperate = (item, index) => {
  let { icon: key } = item
  let isDisabled = false
  switch (key) {
    case 'top':
    case 'up':
      isDisabled = index === 0
      break
    case 'bottom':
    case 'down':
      isDisabled = index === unref(modelRef).media_content.length - 1
      break
  }
  return isDisabled
}

// 移动操作
const handleRemoveOperation = (item, index) => {
  let isDisabled = getDisableOperate(item, index)
  if (isDisabled) return

  const { icon: key } = item
  const [removeItem] = unref(modelRef).media_content.splice(index, 1)
  switch (key) {
    case 'top':
    case 'bottom':
      unref(modelRef).media_content[key === 'top' ? 'unshift' : 'push'](removeItem)
      break
    case 'up':
    case 'down':
      let idx = key === 'up' ? index - 1 : index + 1
      unref(modelRef).media_content.splice(idx, 0, removeItem)
      break
  }
}

const getTitle = computed(() => (state.isUpdate ? '素材编辑' : '新建素材'))

// 按钮禁止提交
const computedBtn = computed(() => {
  let lock = true
  if (state.form.type === 2) {
    if (state.form.title && state.form.media_content?.length && state.form.rangeList?.length) {
      lock = false
    }
  } else {
    if (state.form.title && state.form.media_content?.length) {
      lock = false
    }
  }

  return lock
})

// 确定提交操作
const handleConfirm = () => {
  validate().then(async () => {
    //复制素材 id不传
    if (isCopy.value) {
      state.form.id = undefined
    }

    const params = toRaw(getTranformParams(state.form))
    try {
      state.isSubmiting = true
      await addMedia({ ...params })
      createMessage.success('保存成功')
      emitSuccess()
    } finally {
      state.isSubmiting = false
    }
  })
}

const getMsgNumber = (index) => {
  return +index + 1 < 10 ? `0${index + 1}` : index + 1
}

// 转换数据
const getTranformParams = (params = {}) => {
  const { media_content } = cloneDeep(params)
  params.media_content = media_content ? media_content.map((row) => ({ ...row, uploading: undefined })) : []
  return {
    ...params
  }
}

const emitSuccess = () => {
  emit('success')
  closeDrawer()
}

const onClose = () => {
  createConfirm({
    content: `取消后编辑的内容不会保存，是否确认取消？`,
    async onOk() {
      isCopy.value = false
      closeDrawer()
    }
  })
}

//处理范围数据
const handleRangeData = () => {
  function readNodes(tree, arr) {
    for (let item of tree) {
      arr.push(item)
      if (item.child && item.child.length) readNodes(item.child, arr)
    }
    return arr
  }

  unref(modelRef).rangeList = []
  let tempData = []
  for (let item of unref(modelRef).admin_data) {
    unref(modelRef).rangeList.push({ ...item, type: 'admin' })
  }

  //遍历树结构
  // child
  // id
  // name
  readNodes(unref(treeData), tempData)
  for (let item of unref(modelRef).dept_ids) {
    let tempObj = {
      id: item,
      name: unref(modelRef).dept_data[item],
      type: 'dept'
    }
    unref(modelRef).rangeList.push(tempObj)
  }
}

//获取范围数据
const loadRangeData = async () => {
  await getDeptTree()
}

const treeData = ref([])
const getDeptTree = async () => {
  let { code, data } = await getDeptTreeApi()
  if (code === 1000) {
    treeData.value = data
  }
}
</script>
<style lang="less" scoped>
.head {
  position: relative;
  //padding-bottom: 20px;
  .tit {
    font-size: 20px;
    font-weight: bold;
  }

  .back-btn {
    margin-right: 8px;
    border-radius: 4px;
    padding-left: 0px;
    position: relative;
    width: 32px;
    height: 32px;

    .svg-icon {
      position: absolute;
      left: 8px;
    }
  }

  .line {
    width: 100%;
    height: 1px;
    background-color: #eee;
    transform: scaleY(0.6);
    position: absolute;
    left: 0;
    bottom: 0;
    right: 0;
  }
}

.wrapper {
  height: 100%;
  padding: 0 32px;

  :deep(.add-btn) {
    border-style: dashed;
    height: 32px;
    box-sizing: border-box;
    padding: 0 10px;
    margin-bottom: 5px;
    display: flex;
    align-items: center;

    span {
      //padding-left: 7px;
      font-size: 14px;
    }
  }

  .editor-form {
    padding-right: 0px;
    padding-left: 0px;

    .select-list {
      padding: 5px 5px 5px 0px;
      flex-wrap: wrap;

      .select-list-item {
        background: #f0f0f0;
        border-radius: 4px 4px 4px 4px;
        padding: 6px 12px;
        font-size: 12px;
        font-weight: 400;
        color: #000000;
        margin: 0 5px 5px 0;
        height: 32px;
        display: flex;
        justify-content: center;
        align-items: center;

        .close-icon {
          cursor: pointer;

          &:hover {
            opacity: 0.5;
          }
        }
      }
    }

    .auto-label {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      padding-top: 8px;

      > p {
        color: rgba(0, 0, 0, 0.4);
        margin-top: 10px;
      }
    }

    .tag-group {
      .label {
        margin-right: 16px;
        font-size: 14px;
        color: #000000;
      }
    }

    .customer-group,
    .group-item,
    .tag-group {
      .ant-tag-plain {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 8px;
        max-width: 145px;
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;

        img {
          width: 28px;
          height: 28px;
          border-radius: 6px;
          margin-right: 8px;
        }
      }
    }

    .card-list {
      width: 100%;

      .card-item-wrap {
        width: 100%;

        &:hover {
          .card-item .card-extra .operate-btns {
            visibility: visible;

            .svg-icon {
              width: 24px !important;
              height: 24px !important;
              padding: 4px;

              &:hover {
                background: rgba(0, 0, 0, 0.04);
                border-radius: 4px;
              }
            }
          }

          :deep(.anticon-menu) {
            visibility: visible;
          }
        }

        :deep(.anticon-menu) {
          margin-right: 12px;
          padding-top: 3px;
          visibility: hidden;

          :hover {
            color: @primary-color;
          }
        }

        .card-item {
          flex: auto;
          min-height: 56px;
          padding: 12px;
          background: rgba(0, 0, 0, 0.04);
          border-radius: 6px;
          box-sizing: border-box;

          .card-num {
            width: 24px;
            height: 24px;
            align-items: center;
            border-radius: 50%;
            background: #eeeeee;
            color: #000000;
            font-size: 12px;
            margin-right: 16px;
          }

          .card-content {
            flex: auto;
          }

          .card-extra {
            flex: none;
            display: flex;
            align-items: flex-start;

            .operate-btns {
              height: 32px;
              visibility: hidden;

              > * {
                margin-right: 16px;
                cursor: pointer;
              }
            }

            .time-bar {
              > span {
                margin-right: 12px;
                color: rgba(0, 0, 0, 0.4);
              }

              .time-input {
                :deep(.ant-input-number-input-wrap) {
                  width: 56px;
                }
              }
            }
          }
        }

        + .card-item-wrap {
          margin-top: 12px;
          margin-bottom: 12px;
        }

        + .add-content {
          margin-top: 16px;
        }
      }
    }

    .rich-input {
      margin-top: 16px;
    }

    .add-content {
      .add-icon {
        font-size: 16px;
        color: @primary-color;
      }

      .decs {
        margin-left: 8px;
        color: rgba(0, 0, 0, 0.4);
      }
    }

    .auto-create-box {
      .sub-form-item {
        width: 100%;

        .input-area {
          width: 100%;
          margin-top: 10px;

          .ant-input {
            flex: 0 0 220px;
          }

          > span {
            margin-left: 16px;
          }

          .ant-input-number {
            margin-left: 8px;
          }
        }
      }
    }

    .news-group-box {
      .label {
        margin-bottom: 10px;
      }

      .group-item {
        flex-wrap: wrap;

        + .group-item {
          margin-top: 8px;
        }
      }
    }

    .tip-desc {
      color: rgba(0, 0, 0, 0.4);
      margin-top: 10px;
    }

    .min-tip {
      color: rgba(0, 0, 0, 0.4);
      margin-top: 6px !important;
    }

    :deep(.ant-form-item) {
      // &.form-item-auto-msg {
      //   .ant-form-item-control {
      //     margin-left: -25px;
      //   }
      // }
      .ant-form-item-label {
        flex: 0 0 100px;
        max-width: 100px;
        display: inline-flex;

        > label {
          width: 95px;
          font-weight: 550;
          font-size: 14px;
          color: #000;
          justify-content: flex-end;
        }
      }
    }
  }

  .flip-list-move {
    transition: transform 0.5s;
  }

  .no-move {
    transition: transform 0s;
  }

  .ghost {
    opacity: 0.5;
    background: rgba(0, 0, 0, 0.05);
  }
}
</style>
<style lang="less">
.editor-drawer {
  .ant-drawer-content {
    box-shadow: none;
  }
}
</style>
