<template>
  <a-modal
    ref="modalRef"
    v-model:visible="visible"
    centered
    destroyOnClose
    title="群发素材"
    class="text-modal"
    @cancel="onClose"
  >
    <div class="wrapper">
      <div class="topic">选择使用“{{ selectData.title }}”的群发类型</div>
      <div style="margin-top: 10px">
        <a-radio-group v-model:value="send_type">
          <a-radio :value="1">新建高级群发</a-radio>
          <a-radio :value="2">新建群公告</a-radio>
        </a-radio-group>
      </div>
    </div>
    <template #footer>
      <div class="modal-footer jz-flex jz-flex-rb">
        <div class="left-extra"></div>
        <div class="right-extra">
          <a-button type="info" @click="onClose">取消</a-button>
          <a-button type="primary" @click="handleConfirm">确定</a-button>
        </div>
      </div>
    </template>
  </a-modal>
</template>

<script setup>
import { Form } from 'ant-design-vue'
import { reactive, ref, defineExpose, toRaw, computed, toRef, unref } from 'vue'
import { MessageTypeEnum } from '@/enums/MessageTypeEnum'
import { useDrawer } from '@/components/basic/drawer'

const emit = defineEmits(['success'])
const props = defineProps({
  selectData: {}
})
const modalRef = ref()
const editRef = ref()
const tags = [
  // { label: '称呼/昵称', value: 2 },
  { label: '随机表情', value: 3 },
  { label: '称呼一', value: 4 },
  { label: '称呼二', value: 5 }
]

const send_type = ref(1)

const visible = ref(false)
const state = reactive({
  model: {
    msg: {
      text: ''
    },
    msg_type: MessageTypeEnum.text
  },
  operType: null,
  isUpdate: false,
  imageUrl: '',
  tagList: [],
  is_section: false,
  uploading: false
})
const model = toRef(state, 'model')
const rules = ref({
  text: [{ reuqired: true, message: '请输入内容' }]
})

const { validate, resetFields, validateInfos } = Form.useForm(model, rules)

const handleConfirm = () => {
  emit('success', unref(send_type))
  onClose()
}
const onOpen = (params) => {
  visible.value = true
}

const onClose = () => {
  visible.value = false
  state.isUpdate = false
  state.imageUrl = ''
  state.is_section = false
  state.tagList = []
  resetFields()
  visible.value = false
}

defineExpose({
  modalRef: modalRef.value,
  closeModal: onClose,
  openModal: onOpen
})
</script>

<style lang="less" scoped>
.wrapper {
  .content {
    margin-top: 16px;
  }

  .bg-rich-input {
    :deep(.basic-input-wrap) {
      border: none;
      padding: 12px !important;
      background: rgba(0, 0, 0, 0.02);
    }
  }

  .emoji-icon {
    height: 32px !important;
    width: 32px !important;
    margin-right: 8px;
    cursor: pointer;

    &:hover {
      color: @primary-color;
    }

    &:focus {
      border: none !important;
      color: @primary-color;
    }
  }
}

.modal-footer {
  align-items: center;
  color: rgba(0, 0, 0, 0.2);

  .left-extra {
    :deep(.anticon-question-circle) {
      color: rgba(0, 0, 0, 0.4);
    }
  }
}
</style>
<style lang="less">
.text-modal {
  .ant-modal-content {
    .ant-modal-body {
      padding-bottom: 0;
    }
  }
}

.contenteditor {
  box-sizing: border-box;
  padding: 0;

  &:focus {
    outline: none;
    border: none;
  }

  .text {
    text-indent: 0;
    word-break: break-word;
    white-space: pre-wrap;
    line-height: 1.5;
  }

  img {
    width: 150px;
    height: 100%;
  }
}
</style>
