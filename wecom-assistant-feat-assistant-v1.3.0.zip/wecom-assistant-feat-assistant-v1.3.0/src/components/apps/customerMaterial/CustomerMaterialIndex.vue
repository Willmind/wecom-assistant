<template>
  <div class="page-wrapper">
    <div class="left-content">
      <div class="plan-header jz-flex jz-flex jz-flex-cc">
        <span class="plan-header-num">素材库</span>
        <div class="jz-flex-1 jz-flex jz-flex-rr">
          <a-button type="primary" @click="handleNewMaterialDrawer()">
            <plus-outlined />
            新增
          </a-button>
        </div>
      </div>
      <a-menu @click="changeMenu" class="menu-list" v-model:selectedKeys="current" mode="horizontal">
        <a-menu-item key="myself"> 我的素材</a-menu-item>
        <a-menu-item key="group"> 团队素材</a-menu-item>
      </a-menu>
      <div class="search-list">
        <a-input
          style="width: 186px; margin-right: 16px"
          class="keywork-search-input"
          v-model:value="searchParams.title"
          allowClear
          placeholder="请输入关键词"
        >
          <template #suffix>
            <svg-icon icon-name="ic_search" />
          </template>
        </a-input>
        <api-select
          mode="multiple"
          style="width: 186px; margin-right: 16px"
          allowClear
          v-model:value="searchParams.msg_type"
          :options="dictMap.media_msg_type"
          :replaceFields="dictFields"
          placeholder="请选择类型"
        />
        <a-cascader
          v-if="isGroup"
          v-model:value="searchParams.dept_ids"
          style="width: 186px"
          overlayClassName="cascader-class"
          change-on-select
          :field-names="{ label: 'name', value: 'id', children: 'child' }"
          :options="deptTree"
          placeholder="组织部门"
        />
      </div>
      <div
        class="jz-flex jz-flex-dir-col jz-flex-1 material-list"
        style="width: 100%; overflow: auto"
        v-if="state.list.length > 0"
      >
        <div class="jz-flex-cc jz-flex table-tip">
          <!--        <exclamation-circle-filled class="nav-icon" />-->
          <svg-icon style="width: 20px; height: 20px" icon-name="info-circle-fill" />
          <div class="nav-text">
            {{
              isGroup
                ? '团队素材仅显示你所在部门可见的共享素材，可选中预览或在素材右上角进行更多操作。'
                : '素材的创建人如果修改了可见范围或删除了素材，则“我的素材”中也不再显示该素材。'
            }}
          </div>
        </div>
        <a-row
          v-infinite-scroll="debounceSearch"
          :infinite-scroll-immediate-check="false"
          :infinite-scroll-disabled="state.isFinished"
          :infinite-scroll-watch-disabled="state.isFinished"
          :infinite-scroll-distance="10"
          class="content-list"
        >
          <a-col :span="spanNum" v-for="(item, index) in state.list">
            <li class="li-box">
              <div
                class="content-box"
                :class="isSelectIndex === index ? 'active' : ''"
                :key="item.id"
                @click="selectItem(item, index)"
                @mouseenter="(e) => handleMouse(e, index)"
                @mouseleave="(e) => handleMouse(e, index)"
              >
                <div class="content-box-header jz-flex jz-flex-rb">
                  <div class="content-box-header-title">
                    {{ item.title }}
                  </div>
                  <div class="content-box-header-tool" v-if="item.visible">
                    <a-tooltip v-if="item.can_move">
                      <template #title>移出我的素材</template>
                      <svg-icon
                        @click.stop="moveMediaFun(item)"
                        icon-name="add_material"
                        style="width: 24px; height: 24px"
                      />
                    </a-tooltip>
                    <a-tooltip v-if="isGroup && item.can_join">
                      <template #title>加入我的素材</template>
                      <svg-icon
                        @click.stop="collectMediaFun(item)"
                        icon-name="add_media"
                        style="width: 24px; height: 24px"
                      />
                    </a-tooltip>

                    <a-dropdown
                      :getPopupContainer="
                        (triggerNode) => {
                          return triggerNode.parentNode || document.body
                        }
                      "
                      v-if="item.can_import || item.can_edit || item.can_copy || item.can_delete"
                    >
                      <svg-icon icon-name="jz_more" style="width: 24px; height: 24px; margin-left: 14px" />
                      <template #overlay>
                        <a-menu>
                          <a-menu-item v-if="item.can_import">
                            <a href="javascript:;" @click="handleMassMediaModel(item)">群发素材</a>
                          </a-menu-item>
                          <a-menu-item v-if="item.can_edit">
                            <a href="javascript:;" @click="handleNewMaterialDrawer(item)">编辑素材</a>
                          </a-menu-item>
                          <a-menu-item v-if="item.can_copy">
                            <a href="javascript:;" @click="copyMedia(item)">复制素材</a>
                          </a-menu-item>
                          <a-menu-item v-if="item.can_delete">
                            <a href="javascript:;" @click="handleDelete(item)">删除</a>
                          </a-menu-item>
                        </a-menu>
                      </template>
                    </a-dropdown>
                  </div>
                </div>
                <div class="content-box-main">
                  <div
                    class="content-box-item jz-flex jz-flex-cc"
                    v-for="(msgItem, msgIndex) in item.media_content"
                  >
                    <div class="box-serial">{{ addZero(msgIndex + 1) }}</div>
                    <!--              消息类型 2文本，13链接，14图片，15文件，16语音，23视频，29gif动画，41名片，78小程序，141视频号-->
                    <!--文本类型-->
                    <div class="jz-flex-1 text-type" v-if="+msgItem.msg_type === 2">
                      {{ msgItem.msg.text }}
                    </div>
                    <!--图片类型-->
                    <div class="jz-flex-1 img-type" v-if="+msgItem.msg_type === 14">
                      <img :src="msgItem.msg.url" alt="" />
                    </div>
                    <!--视频类型-->
                    <div class="jz-flex-1 video-type" v-if="+msgItem.msg_type === 23">
                      <video :src="msgItem.msg.url"></video>
                      <svg-icon icon-name="ic_msg_video" />
                    </div>
                    <!--文件类型-->
                    <div class="jz-flex-1 file-type jz-flex jz-flex-cc" v-if="+msgItem.msg_type === 15">
                      <svg-icon icon-name="ic_msg_pdf" />
                      <span class="lineClamp1">{{ msgItem.msg.name }}</span>
                    </div>
                    <!--链接类型-->
                    <div class="link-type jz-flex jz-flex-cc jz-flex-col" v-if="+msgItem.msg_type === 13">
                      <div class="link-tit">{{ msgItem.msg.title }}</div>
                      <div class="desc jz-flex jz-flex-1">
                        <div class="desc-text jz-flex-1">{{ msgItem.msg.des }}</div>
                        <img :src="msgItem.msg.thumb_url" alt="" />
                      </div>
                    </div>
                    <!--小程序类型-->
                    <div class="wx-type jz-flex jz-flex-cc jz-flex-col" v-if="+msgItem.msg_type === 78">
                      <div class="logo-box jz-flex jz-flex-cc">
                        <img :src="msgItem.msg.headimg" alt="" />
                        <span>{{ msgItem.msg.title }}</span>
                      </div>
                      <div class="wx-bg jz-flex-1 jz-flex jz-flex-center">
                        <img :src="msgItem.msg.icon_url" alt="" />
                      </div>
                      <span class="wx-name">小程序</span>
                    </div>
                    <!--语音类型-->
                    <div class="audio-type jz-flex jz-flex-cc" v-if="+msgItem.msg_type === 16">
                      <svg-icon icon-name="ic_msg_audio" />
                    </div>
                    <!--视频号类型-->
                    <div
                      class="wx-video-type jz-flex jz-flex-cc jz-flex-col"
                      v-if="+msgItem.msg_type === 141"
                    >
                      <div class="jz-flex-1 head">
                        <img :src="msgItem.msg.head_img_url" alt="" />
                        <svg-icon icon-name="ic_msg_video" />
                      </div>
                      <div class="wx-tit jz-flex jz-flex-cc">
                        <img src="@/assets/imgs/sph.png" alt="" /> 简知科技
                      </div>
                    </div>
                  </div>
                </div>
                <div class="content-box-footer jz-flex jz-flex-rb">
                  <div>{{ item.update_time }}</div>
                  <div>共 {{ item.media_content.length }} 条</div>
                </div>
              </div>
            </li>
          </a-col>
        </a-row>
      </div>
      <div v-else class="content-none">
        <img src="@/assets/imgs/jz_none.png" alt="" />
        <div>无内容</div>
      </div>
    </div>
    <template v-if="state.list.length > 0">
      <div v-if="isSelect" class="right-content jz-flex-rb">
        <div>
          <div class="right-content-header">
            <div class="right-content-header-left">预览-{{ selectData.title }}</div>

            <a-tooltip
              arrow-point-at-center
              placement="bottom"
              overlayClassName="range_tooltip"
              v-if="selectData && selectData.admin_data.concat(selectData.dept_ids).length > 0"
            >
              <template #title>{{ rangeData }}</template>
              <a-button class="right-content-header-right" type="link">可见范围</a-button>
            </a-tooltip>
          </div>
          <div class="right-content-describe">
            <div class="describe-creatInfo">
              <svg-icon :icon-name="`ic_image2`" :iconSize="16" color="#999999" style="margin-right: 8px" />
              <span>{{ selectDataImageNum(selectData) }}</span>
              <svg-icon :icon-name="`ic_text2`" :iconSize="16" color="#999999" style="margin-right: 8px" />
              <span>{{ selectDataTextNum(selectData) }}</span>
            </div>
            <div class="describe-creatInfo">
              {{ selectData.create_time }} 由 {{ selectData.create_user }} 创建
            </div>
          </div>
          <div class="describe-line"></div>
        </div>
        <div class="right-content-main">
          <div class="right-content-main-box" v-for="(msgItem, msgIndex) in selectData.media_content">
            <div class="box-serial">{{ addZero(msgIndex + 1) }}</div>
            <!--              消息类型 2文本，13链接，14图片，15文件，16语音，23视频，29gif动画，41名片，78小程序，141视频号-->
            <!--文本类型-->
            <div class="jz-flex-1 text-type" v-if="+msgItem.msg_type === 2">
              {{ msgItem.msg.text }}
            </div>
            <!--图片类型-->
            <div class="jz-flex-1 img-type" v-if="+msgItem.msg_type === 14">
              <img :src="msgItem.msg.url" alt="" />
            </div>
            <!--视频类型-->
            <div class="jz-flex-1 video-type" v-if="+msgItem.msg_type === 23">
              <video :src="msgItem.msg.url"></video>
              <svg-icon icon-name="ic_msg_video" />
            </div>
            <!--文件类型-->
            <div class="jz-flex-1 file-type jz-flex jz-flex-cc" v-if="+msgItem.msg_type === 15">
              <svg-icon icon-name="ic_msg_pdf" />
              <span class="lineClamp1">{{ msgItem.msg.name }}</span>
            </div>
            <!--链接类型-->
            <div class="link-type jz-flex jz-flex-cc jz-flex-col" v-if="+msgItem.msg_type === 13">
              <div class="link-tit">{{ msgItem.msg.title }}</div>
              <div class="desc jz-flex jz-flex-1">
                <div class="desc-text jz-flex-1">{{ msgItem.msg.des }}</div>
                <img :src="msgItem.msg.thumb_url" alt="" />
              </div>
            </div>
            <!--小程序类型-->
            <div class="wx-type jz-flex jz-flex-cc jz-flex-col" v-if="+msgItem.msg_type === 78">
              <div class="logo-box jz-flex jz-flex-cc">
                <img :src="msgItem.msg.headimg" alt="" />
                <span>{{ msgItem.msg.title }}</span>
              </div>
              <div class="wx-bg jz-flex-1 jz-flex jz-flex-center">
                <img :src="msgItem.msg.icon_url" alt="" />
              </div>
              <span class="wx-name">小程序</span>
            </div>
            <!--语音类型-->
            <div class="audio-type jz-flex jz-flex-cc" v-if="+msgItem.msg_type === 16">
              <svg-icon icon-name="ic_msg_audio" />
            </div>
            <!--视频号类型-->
            <div class="wx-video-type jz-flex jz-flex-cc jz-flex-col" v-if="+msgItem.msg_type === 141">
              <div class="jz-flex-1 head">
                <img :src="msgItem.msg.head_img_url" alt="" />
                <svg-icon icon-name="ic_msg_video" />
              </div>
              <div class="wx-tit jz-flex jz-flex-cc"><img src="@/assets/imgs/sph.png" alt="" /> 简知科技</div>
            </div>
          </div>
        </div>
        <div class="right-content-footer">
          <a-button :disabled="!selectData.can_delete" @click="handleDelete">删除</a-button>
          <a-button :disabled="!selectData.can_copy" @click="copyMedia(selectData)">复制素材</a-button>
          <a-button :disabled="!selectData.can_edit" @click="handleNewMaterialDrawer(selectData)"
            >编辑素材
          </a-button>
          <a-button :disabled="!selectData.can_import" type="primary" @click="handleMassMediaModel()"
            >群发素材
          </a-button>
        </div>
      </div>
      <div v-else class="right-content jz-flex-rb"></div>
    </template>

    <NewMaterialDrawer
      :register="registerNewMaterialDrawer"
      @success="() => reset()"
      :mask="false"
      :showForehead="true"
      :innerPage="true"
      :getContainer="false"
      headHeight="60px"
    />
    <MassMediaModel ref="massRef" :selectData="selectData" @success="handleMassMediaCallback" />
    <AdvancedMassSendDrawer :mediaData="select_media_content" :register="registerAdvancedMassSendDrawer" />
    <GroupAnnouncementDrawer :mediaData="select_media_content" :register="groupAnnouncementDrawer" />
  </div>
</template>
<script setup>
import { computed, onUnmounted, ref, toRef, watch } from 'vue'
import { useDrawer } from '@/components/basic/drawer'
import { collectMedia, deleteMedia, getMediaList, moveMedia } from 'api/material'
import { debounce } from 'lodash-es'
import useMessage from '@/composables/web/useMessage'
import { dictStore } from '@/store/modules/dict'
import { getDeptTreeApi } from 'api/common'

const { createConfirm } = useMessage()
const [registerAdvancedMassSendDrawer, { openDrawer: openAdvancedMassSendDrawer }] = useDrawer()
const [groupAnnouncementDrawer, { openDrawer: openGroupAnnouncementDrawer }] = useDrawer()
const [registerNewMaterialDrawer, { openDrawer: openNewMaterialDrawer }] = useDrawer()
const current = ref(['myself'])
const isGroup = computed(() => current.value.some((item) => item === 'group'))
const isSelectIndex = ref(null)
const { createMessage } = useMessage()

const state = reactive({
  list: [],
  isFinished: false,
  page: 1,
  count: 0,
  loading: false
})
const searchParams = reactive({
  title: '',
  type: null,
  msg_type: [],
  dept_id: null,
  dept_ids: [],
  page: 1,
  limit: 10
})

const store = dictStore()
const dictMap = toRef(store, 'dictMap')
store.tryFetchData()
const dictFields = computed(() => ({ label: 'val', value: 'key' }))

//数字前补零
const addZero = (num) => {
  if (num < 10) {
    return '0' + num
  } else {
    return num
  }
}

// 鼠标移入移出
const handleMouse = (e, index) => {
  state.list[index].visible = !state.list[index].visible
}

//点击素材元素
const selectData = ref({
  media_content: []
})
const isSelect = ref(false)

const selectDataImageNum = (item) => {
  return item.media_content.filter((item2) => {
    return item2.msg_type === 14
  }).length
}

const selectDataTextNum = (item) => {
  return item.media_content.filter((item2) => {
    return item2.msg_type === 2
  }).length
}

const selectItem = async (item, index) => {
  isSelect.value = true
  isSelectIndex.value = index
  selectData.value = item
}

// 删除
const handleDelete = (item) => {
  createConfirm({
    content: `是否确认删除该素材？`,
    async onOk() {
      let { code } = await deleteMedia({
        id: item.id || selectData.value.id
      })
      if (code === 1000) {
        state.isFinished = false
        state.list = []
        state.page = 1
        getMediaListData()
        isSelect.value = false
      }
    }
  })
}

const massRef = ref()
const isClickFooter = ref(false) //判断是否通过点击底部进入新建群发/新建群公告页面
const select_media_content = ref([])
const handleMassMediaModel = (item) => {
  if (item) {
    select_media_content.value = item.media_content
  } else {
    select_media_content.value = unref(selectData).media_content
  }

  // if (item) {
  //   unref(select_media_data) = item.media_content;
  // } else {
  //   unref(select_media_data) = unref(selectData).media_content;
  // }
  massRef.value.openModal()
}
const handleMassMediaCallback = (val) => {
  if (val === 1) {
    console.log(selectData.value)
    openAdvancedMassSendDrawer()
  } else {
    openGroupAnnouncementDrawer()
  }
}

const changeMenu = () => {
  isSelect.value = false
  isSelectIndex.value = null
  selectData.value = {
    media_content: []
  }
  searchParams.dept_id = null
  searchParams.dept_ids = []
}

//获取素材列表
const getMediaListData = async () => {
  if (state.isFinished) return false
  state.loading = true
  let { code, data } = await getMediaList({
    title: searchParams.title,
    type: isGroup.value ? 2 : 1,
    msg_type: searchParams.msg_type,
    dept_id: searchParams.dept_ids ? searchParams.dept_ids[searchParams.dept_ids.length - 1] : null,
    page: state.page,
    limit: 10
  })
  if (code === 1000) {
    data.data.forEach((item) => {
      item.visible = false
    })
    if (data.data.length) {
      state.list = [...state.list, ...data.data]
      state.page += 1
    } else {
      state.isFinished = true
    }
  }

  if (state.list.length > 0) {
    selectItem(state.list[0], 0)
  } else {
    isSelect.value = false
  }
}
const debounceSearch = debounce(getMediaListData, 350)

/**
 * 复制素材
 */
const copyMedia = (row) => {
  openNewMaterialDrawer({
    data: { ...row },
    isUpdate: false,
    isCopy: true
  })
}

const handleNewMaterialDrawer = (row) => {
  openNewMaterialDrawer({
    data: { ...row },
    isCopy: false,
    isUpdate: row && row.id ? true : false
  })
}

const moveMediaFun = async (item) => {
  createConfirm({
    content: `是否确认移出该素材？`,
    async onOk() {
      let { code } = await moveMedia({
        id: item.id
      })
      if (code === 1000) {
        createMessage.success('移出成功')
        state.isFinished = false
        state.list = []
        state.page = 1
        getMediaListData()
      }
    }
  })
}

const collectMediaFun = async (item) => {
  createConfirm({
    content: `是否加入到我的素材？`,
    async onOk() {
      let { code } = await collectMedia({
        id: item.id
      })
      if (code === 1000) {
        createMessage.success('加入成功')
        state.isFinished = false
        state.list = []
        state.page = 1
        getMediaListData()
      }
    }
  })
}

const spanNum = ref(8)
const handleResize = () => {
  let _w = document.documentElement.clientWidth || document.body.clientWidth
  if (_w < 1400) {
    spanNum.value = 12
  } else if (_w > 1400 && _w < 1876) {
    spanNum.value = 8
  } else {
    spanNum.value = 6
  }
}

const reset = () => {
  searchParams.title = ''
  searchParams.msg_type = []
  searchParams.type = null
  searchParams.dept_id = null
  searchParams.dept_ids = []
  searchParams.page = 1
  searchParams.limit = 1000
}

const deptTree = ref([])
const getDeptTree = async () => {
  let { code, data } = await getDeptTreeApi()
  if (code === 1000) {
    deptTree.value = data
  }
}

const rangeData = computed(() => {
  let tempData1 = selectData.value.admin_data.map((item) => {
    return item.name || item.username
  })
  let tempData2 = selectData.value.dept_ids.map((item) => {
    return selectData.value.dept_data[item]
  })
  return tempData1.concat(tempData2).toString()
})

const loadData = async () => {
  await getMediaListData()
  await getDeptTree()
}

onMounted(() => {
  handleResize()
  window.addEventListener('resize', debounce(handleResize))
  loadData()
})
onUnmounted(() => {
  window.removeEventListener('resize', handleResize)
})

watch(
  () => searchParams,
  () => {
    state.isFinished = false
    state.list = []
    state.page = 1
    debounceSearch()
  },
  {
    deep: true
  }
)
</script>

<style lang="less" scoped>
.page-wrapper {
  height: 100%;
  width: 100%;
  display: flex;

  .left-content {
    flex: 1;
    height: 100%;
    display: flex;
    flex-direction: column;

    .left-content-header {
      height: 60px;

      .left-content-header-title {
        font-weight: 550;
        color: #000000;
        font-size: 20px;
      }
    }

    .plan-header {
      width: 100%;
      height: 60px;
      padding: 0 32px;
      margin-top: 32px;

      &-num {
        font-size: 20px;
        font-weight: 600;
      }
    }

    .ant-menu {
      margin-left: 32px;

      :deep(.ant-menu-item) {
        padding-left: 0px;
        margin-right: 60px;
        color: #999999;

        &:hover {
          color: #3165f5;
        }

        &::after {
          left: 0px;
        }

        &:hover {
          &::after {
            border-bottom: 2px solid transparent;
          }
        }
      }

      :deep(.ant-menu-item-selected) {
        &:hover {
          &::after {
            border-bottom: 2px solid #3165f5;
          }
        }

        .ant-menu-title-content {
          color: #3165f5;
        }
      }
    }

    .search-list {
      padding: 24px 32px;
    }
    .material-list {
      // 修改滚动条
      &:hover {
        &::-webkit-scrollbar-thumb {
          visibility: visible;
        }
      }
      &::-webkit-scrollbar {
        width: 2px;
      }
      &::-webkit-scrollbar-thumb {
        visibility: hidden;
        transition: all 0.28s;
      }
    }

    .table-tip {
      padding: 0 32px;

      .nav-icon {
        color: #ed7b2f;
        margin-right: 10px;
        font-size: 20px;
      }

      .nav-text {
        color: #ed7b2f;
        margin-left: 10px;
        white-space: nowrap;
      }
    }

    .content-list {
      display: flex;
      width: 100%;
      //overflow: auto;
      padding: 12px 24px;
      //min-height: 410px;
      //flex: 1;

      .li-box {
        margin: 8px;

        .content-box {
          background: #ffffff;
          box-shadow: 0px 0px 8px 0px rgba(0, 0, 0, 0.05);
          border-radius: 12px 12px 12px 12px;
          opacity: 1;
          border: 1px solid #eeeeee;
          transition: all 0.2s;

          &:hover {
            cursor: pointer;
            box-shadow: 0px 12px 48px 0px rgba(0, 0, 0, 0.15);
          }

          //&:active {
          //  border: 1px solid #3165F5;
          //}

          .content-box-header {
            color: rgba(0, 0, 0, 0.9);
            font-weight: 550;
            padding: 16px;
            height: 60px;

            .content-box-header-title {
              width: 174px;
              overflow: hidden;
              text-overflow: ellipsis;
              white-space: nowrap;
            }

            .content-box-header-tool {
              white-space: nowrap;
              svg {
                transition: 0.2s all;
              }

              svg:hover {
                background-color: #f5f5f5;
                border-radius: 4px;
              }
            }
          }

          .content-box-main {
            padding: 8px 16px 16px 16px;
            overflow: hidden;
            height: 129px;

            .content-box-item {
              margin-bottom: 12px;
              font-size: 14px;

              .box-serial {
                font-size: 12px;
                font-weight: 400;
                color: #999999;
                line-height: 14px;
                background: #eeeeee;
                width: 24px;
                height: 24px;
                display: flex;
                justify-content: center;
                align-items: center;
                border-radius: 50%;
                margin-right: 16px;
              }

              .text-type {
                color: #000;
                font-size: 12px;
              }

              .img-type {
                img {
                  width: 48px;
                  height: 48px;
                  border-radius: 4px;
                }
              }

              .video-type {
                position: relative;

                > video {
                  width: 48px;
                  height: 32px;
                  object-fit: cover;
                }

                .svg-icon {
                  position: absolute;
                  left: 15px;
                  top: 10px;
                  color: #fff;
                  width: 16px !important;
                  height: 16px !important;
                }
              }

              .file-type {
                .svg-icon {
                  width: 20px !important;
                  height: 20px !important;
                  min-width: 20px;
                  min-height: 20px;
                  margin-right: 4px;
                }
              }

              .link-type {
                width: 90px;
                height: 42px;
                background: #eee;
                position: relative;
                padding: 5px;
                border-radius: 4px;

                &::before {
                  content: '';
                  width: 0;
                  height: 0;
                  left: -7px;
                  top: 10px;
                  position: absolute;
                  border-right: 5px solid transparent;
                  border-left: 5px solid transparent;
                  border-bottom: 5px solid #eee;
                  transform: rotate(-90deg);
                }

                .link-tit {
                  font-size: 6px;
                  color: #000;
                  display: -webkit-box;
                  -webkit-box-orient: vertical;
                  -webkit-line-clamp: 2;
                  overflow: hidden;
                  line-height: 7px;
                  text-align: left;
                  width: 100%;
                }

                .desc {
                  width: 100%;

                  &-text {
                    font-size: 5px;
                    color: @font-minor-color;
                    overflow: hidden;
                  }

                  img {
                    width: 18px;
                    height: 18px;
                  }
                }
              }

              .wx-type {
                width: 90px;
                height: 100px;
                background: #eee;
                position: relative;
                padding: 5px;
                border-radius: 4px;

                &::before {
                  content: '';
                  width: 0;
                  height: 0;
                  left: -7px;
                  top: 10px;
                  position: absolute;
                  border-right: 5px solid transparent;
                  border-left: 5px solid transparent;
                  border-bottom: 5px solid #eee;
                  transform: rotate(-90deg);
                }

                .logo-box {
                  width: 100%;
                  font-size: 8px;
                  color: @font-minor-color;
                  margin-bottom: 2px;

                  img {
                    width: 8px;
                    height: 8px;
                    border-radius: 50%;
                    margin-right: 5px;
                  }
                }

                .wx-bg {
                  width: 100%;
                  height: 100%;

                  img {
                    width: 100%;
                    height: 100%;
                  }
                }

                .wx-name {
                  font-size: 6px;
                  margin-top: 3px;
                  display: block;
                  width: 100%;
                  display: flex;
                }
              }

              .audio-type {
                .svg-icon {
                  width: 58px !important;
                  height: 24px !important;
                }
              }

              .voice-type {
                width: 58px;
                height: 24px;
                background: #eeeeee;
                border-radius: 4px;
              }

              .wx-video-type {
                width: 83px;
                height: 110px;
                position: relative;
                border-radius: 4px;
                background: #eeeeee linear-gradient(360deg, rgba(0, 0, 0, 0.5) 0%, rgba(0, 0, 0, 0) 100%);

                .head {
                  width: 100%;
                  height: 100%;
                  position: relative;

                  .svg-icon {
                    width: 16px !important;
                    height: 16px !important;
                    left: 50%;
                    top: 50%;
                    position: absolute;
                    color: #fff;
                    margin-left: -8px;
                  }

                  img {
                    width: 100%;
                    height: 100%;
                    border-radius: 4px;
                  }
                }

                .wx-tit {
                  font-size: 6px;
                  color: #fff;
                  position: absolute;
                  left: 0;
                  bottom: 0px;
                  right: 0;
                  padding-left: 4px;

                  img {
                    width: 10px;
                    height: 10px;
                    margin-right: 3px;
                  }
                }
              }
            }
          }

          .content-box-footer {
            font-weight: 400;
            color: #999999;
            line-height: 16px;
            font-size: 14px;
            border-top: 1px solid #f5f5f5;
            padding: 16px;
          }
        }

        .active {
          border: 1px solid #3165f5;
        }
      }

      //.content-box::before {
      //  counter-increment: items;
      //  content: counter(items);
      //}
      .content-box:nth-child(3n + 1) {
        order: 1;
      }

      .content-box:nth-child(3n + 2) {
        order: 2;
      }

      .content-box:nth-child(3n) {
        order: 3;
      }
    }

    .content-none {
      height: 300px;
      display: flex;
      align-items: center;
      flex-direction: column;
      padding-top: 120px;

      > div {
        font-weight: 400;
        color: #999999;
        font-size: 12px;
        margin-top: 2px;
      }

      img {
        width: 110px;
        height: 110px;
      }
    }
  }

  .right-content {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    height: 100%;
    width: 400px;
    padding: 0 32px;
    border-left: 1px solid #eeeeee;

    .right-content-header {
      display: flex;
      margin-top: 32px;
      margin-bottom: 8px;
      justify-content: space-between;
      align-items: center;
      padding: 16px 0;

      .right-content-header-left {
        font-size: 20px;
        font-weight: 550;
        color: #000000;
        line-height: 23px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .right-content-header-right {
        font-weight: 400;
        color: #3165f5;
        font-size: 14px;
      }
    }

    .right-content-describe {
      .describe-creatInfo {
        font-weight: 400;
        color: #999999;
        line-height: 16px;
        font-size: 14px;
        display: flex;
        align-items: center;

        > span {
          margin-right: 24px;
        }

        &:last-child {
          margin-top: 6px;
        }
      }
    }

    .describe-line {
      height: 1px;
      background-color: #eeeeee;
      margin: 16px 0;
    }

    .right-content-main {
      flex: 1;
      overflow: auto;
      // 修改滚动条
      &:hover {
        &::-webkit-scrollbar-thumb {
          visibility: visible;
        }
      }
      &::-webkit-scrollbar {
        width: 2px;
      }
      &::-webkit-scrollbar-thumb {
        visibility: hidden;
        transition: all 0.28s;
      }

      .right-content-main-box {
        background: #f5f5f5;
        border-radius: 6px 6px 6px 6px;
        padding: 12px;
        display: flex;
        margin-bottom: 12px;

        .box-serial {
          font-size: 12px;
          font-weight: 400;
          color: #999999;
          line-height: 14px;
          background: #eeeeee;
          width: 24px;
          height: 24px;
          display: flex;
          justify-content: center;
          align-items: center;
          border-radius: 50%;
          margin-right: 16px;
        }

        .text-type {
          color: #000;
          font-size: 12px;
        }

        .img-type {
          img {
            width: 120px;
            height: 120px;
            border-radius: 4px;
          }
        }

        .video-type {
          position: relative;

          > video {
            width: 120px;
            height: 120px;
            object-fit: cover;
            border-radius: 4px;
          }

          .svg-icon {
            position: absolute;
            left: 15px;
            top: 10px;
            color: #fff;
            width: 16px !important;
            height: 16px !important;
          }
        }

        .file-type {
          .svg-icon {
            width: 20px !important;
            height: 20px !important;
            min-width: 20px;
            min-height: 20px;
            margin-right: 4px;
          }
        }

        .link-type {
          width: 90px;
          height: 42px;
          background: #eee;
          position: relative;
          padding: 5px;
          border-radius: 4px;

          &::before {
            content: '';
            width: 0;
            height: 0;
            left: -7px;
            top: 10px;
            position: absolute;
            border-right: 5px solid transparent;
            border-left: 5px solid transparent;
            border-bottom: 5px solid #eee;
            transform: rotate(-90deg);
          }

          .link-tit {
            font-size: 6px;
            color: #000;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 2;
            overflow: hidden;
            line-height: 7px;
            text-align: left;
            width: 100%;
          }

          .desc {
            width: 100%;

            &-text {
              font-size: 5px;
              color: @font-minor-color;
              overflow: hidden;
            }

            img {
              width: 18px;
              height: 18px;
            }
          }
        }

        .wx-type {
          width: 90px;
          height: 100px;
          background: #eee;
          position: relative;
          padding: 5px;
          border-radius: 4px;

          &::before {
            content: '';
            width: 0;
            height: 0;
            left: -7px;
            top: 10px;
            position: absolute;
            border-right: 5px solid transparent;
            border-left: 5px solid transparent;
            border-bottom: 5px solid #eee;
            transform: rotate(-90deg);
          }

          .logo-box {
            width: 100%;
            font-size: 8px;
            color: @font-minor-color;
            margin-bottom: 2px;

            img {
              width: 8px;
              height: 8px;
              border-radius: 50%;
              margin-right: 5px;
            }
          }

          .wx-bg {
            width: 100%;
            height: 100%;

            img {
              width: 100%;
              height: 100%;
            }
          }

          .wx-name {
            font-size: 6px;
            margin-top: 3px;
            display: block;
            width: 100%;
            display: flex;
          }
        }

        .audio-type {
          .svg-icon {
            width: 58px !important;
            height: 24px !important;
          }
        }

        .voice-type {
          width: 58px;
          height: 24px;
          background: #eeeeee;
          border-radius: 4px;
        }

        .wx-video-type {
          width: 83px;
          height: 110px;
          position: relative;
          border-radius: 4px;
          background: #eeeeee linear-gradient(360deg, rgba(0, 0, 0, 0.5) 0%, rgba(0, 0, 0, 0) 100%);

          .head {
            width: 100%;
            height: 100%;
            position: relative;

            .svg-icon {
              width: 16px !important;
              height: 16px !important;
              left: 50%;
              top: 50%;
              position: absolute;
              color: #fff;
              margin-left: -8px;
            }

            img {
              width: 100%;
              height: 100%;
              border-radius: 4px;
            }
          }

          .wx-tit {
            font-size: 6px;
            color: #fff;
            position: absolute;
            left: 0;
            bottom: 0px;
            right: 0;
            padding-left: 4px;

            img {
              width: 10px;
              height: 10px;
              margin-right: 3px;
            }
          }
        }

        .box-content {
          flex: 1;
          font-weight: 400;
          color: #000000;
          line-height: 22px;
          font-size: 14px;
        }
      }
    }

    .right-content-footer {
      display: flex;
      justify-content: flex-end;
      padding: 16px 0;

      button {
        margin-left: 10px;
      }
    }
  }
}
</style>
<style lang="less">
.range_tooltip {
  width: 140px;
}
.ant-cascader-menu {
  padding: 8px;
}
.ant-cascader-menu-item {
  width: 186px;
  border-radius: 4px;
  padding: 8px 12px;
}
</style>
