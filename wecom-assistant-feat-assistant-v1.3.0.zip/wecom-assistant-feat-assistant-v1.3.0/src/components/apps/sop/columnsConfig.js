// SOP首页columns
export const getSopIndexColumns = () => [
  { title: 'ID', dataIndex: 'id', width: 100 },
  { title: '模板名称', key: 'name' },
  { title: '创建时间', key: 'create_time' },
  { title: '更新时间', dataIndex: 'update_time' },
  { title: '操作', key: 'action', width: 250 }
]
