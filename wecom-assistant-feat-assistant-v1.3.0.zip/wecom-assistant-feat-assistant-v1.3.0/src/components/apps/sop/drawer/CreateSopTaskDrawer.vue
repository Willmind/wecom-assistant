<template>
  <BasicDrawer
    @visible-change="handelVisibleChange"
    :register="registerDrawer"
    :showFooter="false"
    :showClose="false"
    innerPage
    showForehead
    :loading="state.loading"
    classes="editor-drawer"
    :mask="false"
    :get-container="false"
  >
    <template #title>
      <div class="head jz-flex jz-flex-cc">
        <a-tooltip placement="top">
          <template #title>
            <span>返回</span>
          </template>
          <span class="back-btn jz-flex jz-flex-center jz-pointer" @click="closeTagDrawer()">
            <svg-icon icon-name="login_back" style="width: 32px; height: 32px" />
          </span>
        </a-tooltip>
        <span class="tit">创建任务</span>
        <div class="line"></div>
      </div>
    </template>
    <div class="container jz-flex" id="container">
      <div
        class="left-content jz-flex jz-flex-dir-col"
        :style="{
          marginLeft: collapsed ? '-617px' : '0px'
        }"
      >
        <div
          class="page-side-fold jz-flex jz-flex-center"
          :class="{ 'is-expand': !collapsed }"
          @click="toggleFold"
        >
          <left-outlined v-if="!collapsed" />
          <right-outlined v-else />
        </div>
        <a-menu v-model:selectedKeys="current" mode="horizontal">
          <a-menu-item key="myself"> 我的客户 </a-menu-item>
          <a-menu-item key="group"> 客户群 </a-menu-item>
        </a-menu>
        <div class="form-content jz-flex-1" style="height: calc(100% - 48px)">
          <div v-show="isMyself">
            <SopCustomerList @success="getCustomerCheckList" ref="SopCustomerListRef" />
          </div>
          <div v-show="!isMyself">
            <SopGroupList @success="getGroupCheckList" ref="SopGroupListRef" />
          </div>
        </div>
      </div>
      <div class="right-content jz-flex jz-flex-dir-col">
        <div class="tit">选择 SOP 模版</div>
        <a-form
          class="jz-flex-1 jz-flex jz-flex-dir-col"
          style="overflow: auto"
          :colon="false"
          v-bind="formLayout"
        >
          <a-form-item label="模版名称">
            <div class="jz-flex jz-flex-cc">
              <a-select
                v-model:value="state.form.temp_id"
                show-search
                placeholder="请输入名称/ID"
                style="width: 200px"
                :options="state.form.template_list"
                :filter-option="filterOption"
                @change="handleChange"
                @search="handleSearch"
              />
            </div>
          </a-form-item>
          <a-tabs class="jz-flex-1" v-model:activeKey="activeKey" :tab-position="mode">
            <a-tab-pane v-for="item in selectData.temp_content" :key="item.id" :tab="`第${item.day}天`">
              <div v-if="item.type === 1">立即开始发送第 1 条</div>
              <div v-else>{{ item.start_time }} - {{ item.end_time }} 内随机开始发送第 1 条</div>
              <div class="jz-flex jz-flex-cc table-tip">
                <svg-icon style="width: 20px; height: 20px" icon-name="info-circle-fill" />
                <div class="nav-text">如超过第 1 天的发送时间，则第 1 天会改为明天。</div>
              </div>
              <div class="auto-message-list jz-flex-1">
                <div
                  class="auto-message-item jz-flex jz-flex-cc"
                  v-for="(msgItem, index) in item.content"
                  :key="index"
                >
                  <div class="box-serial">{{ +index + 1 < 10 ? `0${index + 1}` : index + 1 }}</div>
                  <div class="jz-flex-1 text-type" v-if="msgItem.msg_type === 2">
                    {{ msgItem.msg.text }}
                  </div>
                  <!--图片类型-->
                  <div class="jz-flex-1 img-type" v-if="+msgItem.msg_type === 14">
                    <img :src="msgItem.msg.url" alt="" />
                  </div>
                  <!--视频类型-->
                  <div class="jz-flex-1 video-type" v-if="+msgItem.msg_type === 23">
                    <video :src="msgItem.msg.url"></video>
                    <svg-icon icon-name="ic_msg_video" />
                  </div>
                  <!--文件类型-->
                  <div class="jz-flex-1 file-type jz-flex jz-flex-cc" v-if="+msgItem.msg_type === 15">
                    <svg-icon icon-name="ic_msg_pdf" />
                    <span class="lineClamp1">{{ msgItem.msg.name }}</span>
                  </div>
                  <!--链接类型-->
                  <div class="link-type jz-flex jz-flex-cc jz-flex-col" v-if="+msgItem.msg_type === 13">
                    <div class="link-tit">{{ msgItem.msg.title }}</div>
                    <div class="desc jz-flex jz-flex-1">
                      <div class="desc-text jz-flex-1">{{ msgItem.msg.des }}</div>
                      <img :src="msgItem.msg.thumb_url" alt="" />
                    </div>
                  </div>
                  <!--小程序类型-->
                  <div class="wx-type jz-flex jz-flex-cc jz-flex-col" v-if="+msgItem.msg_type === 78">
                    <div class="logo-box jz-flex jz-flex-cc">
                      <img :src="msgItem.msg.headimg" alt="" />
                      <span>{{ msgItem.msg.title }}</span>
                    </div>
                    <div class="wx-bg jz-flex-1 jz-flex jz-flex-center">
                      <img :src="msgItem.msg.icon_url" alt="" />
                    </div>
                    <span class="wx-name">小程序</span>
                  </div>
                  <!--语音类型-->
                  <div class="audio-type jz-flex jz-flex-cc" v-if="+msgItem.msg_type === 16">
                    <svg-icon icon-name="ic_msg_audio" />
                  </div>
                  <!--视频号类型-->
                  <div class="wx-video-type jz-flex jz-flex-cc jz-flex-col" v-if="+msgItem.msg_type === 141">
                    <div class="jz-flex-1 head">
                      <img :src="msgItem.msg.head_img_url" alt="" />
                      <svg-icon icon-name="ic_msg_video" />
                    </div>
                    <div class="wx-tit jz-flex jz-flex-cc">
                      <img src="@/assets/imgs/sph.png" alt="" /> 简知科技
                    </div>
                  </div>

                  <!--群邀请-->
                  <div class="jz-flex-1" v-if="+msgItem.msg_type === 50002">
                    <div class="jz-flex jz-flex-rc jz-flex-cc group-invite-box">群邀请</div>
                    <div class="group-invite-text" v-for="(invite, index) in msgItem.msg?.data" :key="index">
                      {{ invite.text }}
                    </div>
                  </div>
                  <!--群公告-->
                  <div class="jz-flex-1" v-if="+msgItem.msg_type === 50001">
                    <div class="jz-flex jz-flex-rc jz-flex-cc group-notice-box">群公告</div>
                    <div>
                      <template v-for="(acement, index) in msgItem.msg?.data" :key="index">
                        <a-tag class="ant-tag-plain ang-tag-big" v-if="acement.type === 2">
                          {{ acement.text }}
                        </a-tag>
                        <span v-else>&nbsp;{{ acement.desc }}</span>
                      </template>
                    </div>
                  </div>

                  <div class="auto-message-item-time">停留 {{ msgItem.wait }} {{timeOptions[msgItem.time_type]}}后发送</div>
                </div>
              </div>
            </a-tab-pane>
          </a-tabs>
        </a-form>

        <div class="footer-btn jz-flex jz-flex-rr jz-flex-cc">
          <a-button @click="handleCancel">取消</a-button>
          <a-button :disabled="computedBtn" type="primary" @click="handleConfirm()">确定</a-button>
        </div>
      </div>
    </div>
    <a-modal
      centered
      :bodyStyle="{ padding: '16px 32px' }"
      v-model:visible="state.sendVisible"
      title="提示"
      class="created-sop-modal"
    >
      <div class="jz-flex jz-flex-col">
        <div class="tip">以下 {{ state.filterList.length }} 个对象已有正在进行中的该模板任务。</div>
        <div class="txt">发送对象</div>
        <div class="send-list jz-flex jz-flex-wrap">
          <div
            class="send-item jz-flex jz-flex-center"
            v-for="(item, index) in state.filterList"
            :key="index"
          >
            <img :src="item.avatar" alt="" />
            {{ item.name }}
          </div>
        </div>
      </div>
      <template #footer>
        <div class="modal-footer jz-flex jz-flex-rb">
          <div></div>
          <div class="right-extra">
            <a-button type="info" @click="handleSendOk">继续编辑</a-button>
            <a-button type="primary" @click="creatTask">过滤并创建</a-button>
          </div>
        </div>
      </template>
    </a-modal>
  </BasicDrawer>
</template>

<script setup>
/**
 * data
 */
// 抽屉参数
import { useDrawerInner } from '@/components/basic/drawer'
import { reactive, ref, unref } from 'vue'
import { createSopTask, getFilterMember, getSopTempInfo, getSopTempList } from 'api/sop'
import useMessage from '@/composables/web/useMessage'
import { customerStore } from '@/store/modules/customer'
const { createMessage, createConfirm } = useMessage()
const store2 = customerStore()
const emit = defineEmits(['close'])

const [registerDrawer, { closeDrawer }] = useDrawerInner(async (res) => {
  await fetchData()
  if (res.id) {
    state.form.temp_id = res.id
    handleChange(res.id)
  }
})
defineProps({
  register: Function
})
const formLayout = {
  labelCol: { span: 4 },
  wrapperCol: { span: 20 }
}
const timeOptions = {
  1: '秒',
  2: '分',
  3: '时'
}
const current = ref(['myself'])
const isMyself = computed(() => current.value.some((item) => item === 'myself'))

const collapsed = ref(false)
const toggleFold = () => {
  collapsed.value = !unref(collapsed)
}
const activeKey = ref(1)
const mode = ref('top')
const cids = ref([])
const group_ids = ref([])

const state = reactive({
  sendVisible: false,
  filterList: [],
  loading: false,
  activeKey: '1',
  form: {
    title: '',
    template_list: [],
    template_map: {},
    temp_id: null,
    selectData: {}
  }
})

const selectData = ref({})

/**
 * methods
 * @param val
 */
const handleSendOk = () => {
  state.sendVisible = false
}
// 抽屉展示关闭
const handelVisibleChange = (val) => {
  if (!val) {
    current.value = ['myself']
    store2.customerSelectCount = 0
    store2.groupsSelectCount = 0
    group_ids.value = []
    selectData.value = {}
    collapsed.value = false
    cids.value = []
    state.form.temp_id = null
    emit('close')
  } else {
  }
}

// 返回
const SopGroupListRef = ref()
const SopCustomerListRef = ref()

const closeTagDrawer = () => {
  SopGroupListRef.value.clearFields()
  SopCustomerListRef.value.clearFields()
  closeDrawer()
}

const handleCloseExclude = () => {}

// 取消发送
const handleCancel = () => {
  createConfirm({
    content: `取消后编辑的内容不会保存，是否确认取消？`,
    onOk() {
      closeTagDrawer()
    }
  })
}

const sendParams = computed(() => {
  return {
    temp_id: state.form.temp_id,
    cids: unref(cids).join(','),
    group_ids: unref(group_ids).join(',')
  }
})

const creatTask = async () => {
  let { code } = await createSopTask(unref(sendParams))
  if (code === 1000) {
    emit('close')
    createMessage.success('创建任务成功')
    closeTagDrawer()
  }
}

const handleConfirm = async () => {
  let { code, data } = await getFilterMember(unref(sendParams))
  if (code === 1000 && data.total === 0) {
    await creatTask()
  } else {
    state.filterList = [...data.contact, ...data.group]

    state.sendVisible = true
  }
}

const fetchData = async () => {
  const { data } = await getSopTempList({
    type: 0,
    limit: 100
  })
  data.data.forEach((item) => {
    item.value = item.id
    item.label = item.name
  })
  state.form.template_list = data.data
}

const filterOption = (input, option) => {
  return (
    option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0 ||
    option.value.toString().toLowerCase().indexOf(input.toLowerCase()) >= 0
  )
}

const getCustomerCheckList = (value) => {
  cids.value = value.map((i) => i.cid)
}

const getGroupCheckList = (value) => {
  group_ids.value = value
}

const handleChange = async (value) => {
  let { data } = await getSopTempInfo({
    id: value
  })
  selectData.value = data
  activeKey.value = data.temp_content[0].id
}

const handleSearch = async (val) => {
  const { data } = await getSopTempList({
    type: 0,
    limit: 100,
    name: val
  })
  data.data.forEach((item) => {
    item.value = item.id
    item.label = item.name
  })
  state.form.template_list = data.data
}

// 按钮禁止提交
const computedBtn = computed(() => {
  let lock = true
  if (state.form.temp_id && store2.customerSelectCount + store2.groupsSelectCount > 0) {
    lock = false
  }
  return lock
})

onMounted(async () => {})

/**
 * watch / hooks
 */
</script>

<style lang="less" scoped>
:deep(.ant-drawer-header) {
  padding: 32px 32px 0 32px;
}

.head {
  position: relative;
  height: 60px;

  .tit {
    font-size: 20px;
    font-weight: bold;
  }

  .back-btn {
    margin-right: 8px;
    border-radius: 4px;
    padding-left: 0px;
    position: relative;
    width: 32px;
    height: 32px;

    .svg-icon {
      position: absolute;
      left: 8px;
    }
  }

  .line {
    width: 100%;
    height: 1px;
    background-color: #eee;
    transform: scaleY(0.6);
    position: absolute;
    left: 0;
    bottom: 0;
    right: 0;
  }
}

.container {
  width: 100%;
  height: 100%;

  .left-content {
    height: 100%;
    width: 617px;
    border-right: 1px solid rgba(238, 238, 238, 0.6);
    visibility: visible;
    transition: all 0.2s;
    .page-side-fold {
      position: fixed;
      top: 200px;
      left: 0px;
      width: 16px;
      height: 58px;
      background: #eeeeee;
      border-top-left-radius: 0;
      border-bottom-left-radius: 0;
      border-top-right-radius: 6px;
      border-bottom-right-radius: 6px;
      cursor: pointer;
      transition: left 0.28s;
      z-index: 1;

      &.is-expand {
        left: 608px;
        border-radius: 24px;
        opacity: 0;
      }

      .anticon {
        font-size: 12px;
        cursor: pointer;
        color: rgba(0, 0, 0, 0.2);
      }
    }

    &:hover {
      .page-side-fold.is-expand {
        opacity: 1;
      }
    }

    .ant-menu {
      height: 48px;
      margin-left: 32px;
      :deep(.ant-menu-item) {
        padding-left: 0px;
        margin-right: 60px;
        color: #999999;
        &:hover {
          color: #3165f5;
        }
        &::after {
          left: 0px;
        }
        &:hover {
          &::after {
            border-bottom: 2px solid transparent;
          }
        }
      }
      :deep(.ant-menu-item-selected) {
        &:hover {
          &::after {
            border-bottom: 2px solid #3165f5;
          }
        }
        .ant-menu-title-content {
          color: #3165f5;
        }
      }
    }
    .ant-menu-horizontal {
      border-bottom: 1px solid rgba(238, 238, 238, 0.6);
    }
    .form-content {
      > div {
        height: 100%;
      }
    }
  }
  .right-content {
    height: 100%;
    flex: 1;
    padding: 32px 32px 0 32px;
    overflow: auto;
    .tit {
      font-size: 20px;
      font-weight: bold;
      margin-bottom: 32px;
    }
    :deep(.ant-form-item) {
      .ant-form-item-label {
        flex: 0 0 80px;
        max-width: 80px;
        display: inline-flex;

        > label {
          width: 90px;
          font-weight: 550;
          font-size: 14px;
          color: #000;
        }
      }
    }
    :deep(.ant-tabs-content-holder) {
      height: 100%;
    }
    :deep(.ant-tabs-content) {
      height: 100%;
      .ant-tabs-tabpane {
        height: 100%;
        display: flex;
        flex-direction: column;
      }
    }

    .table-tip {
      margin: 8px 0 16px 0;
      .nav-text {
        color: #ed7b2f;
        margin-left: 10px;
        white-space: nowrap;
      }
    }
    .auto-message-list {
      overflow: auto;
      padding-right: 6px;
      // 修改滚动条
      &:hover {
        &::-webkit-scrollbar-thumb {
          visibility: visible;
        }
        .page-side-fold.is-expand {
          opacity: 1;
        }
      }
      &::-webkit-scrollbar {
        width: 2px;
      }
      &::-webkit-scrollbar-thumb {
        visibility: hidden;
        transition: all 0.28s;
      }
      .auto-message-item {
        padding: 12px;
        background: #f5f5f5;
        border-radius: 6px 6px 6px 6px;
        margin-bottom: 12px;
        &:last-child {
          margin-bottom: 0px;
        }
        .box-serial {
          font-size: 12px;
          font-weight: 400;
          color: #999999;
          line-height: 14px;
          background: #eeeeee;
          width: 24px;
          height: 24px;
          display: flex;
          justify-content: center;
          align-items: center;
          border-radius: 50%;
          margin-right: 16px;
        }
        .text-type {
          color: #000;
          font-size: 14px;
        }

        .img-type {
          img {
            width: 120px;
            height: 120px;
            border-radius: 4px;
          }
        }

        .video-type {
          position: relative;

          > video {
            width: 120px;
            height: 120px;
            object-fit: cover;
            border-radius: 4px;
          }

          .svg-icon {
            position: absolute;
            left: 15px;
            top: 10px;
            color: #fff;
            width: 16px !important;
            height: 16px !important;
          }
        }

        .file-type {
          .svg-icon {
            width: 20px !important;
            height: 20px !important;
            min-width: 20px;
            min-height: 20px;
            margin-right: 4px;
          }
        }

        .link-type {
          width: 90px;
          height: 42px;
          background: #eee;
          position: relative;
          padding: 5px;
          border-radius: 4px;

          &::before {
            content: '';
            width: 0;
            height: 0;
            left: -7px;
            top: 10px;
            position: absolute;
            border-right: 5px solid transparent;
            border-left: 5px solid transparent;
            border-bottom: 5px solid #eee;
            transform: rotate(-90deg);
          }

          .link-tit {
            font-size: 6px;
            color: #000;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 2;
            overflow: hidden;
            line-height: 7px;
            text-align: left;
            width: 100%;
          }

          .desc {
            width: 100%;

            &-text {
              font-size: 5px;
              color: @font-minor-color;
              overflow: hidden;
            }

            img {
              width: 18px;
              height: 18px;
            }
          }
        }

        .wx-type {
          width: 90px;
          height: 100px;
          background: #eee;
          position: relative;
          padding: 5px;
          border-radius: 4px;

          &::before {
            content: '';
            width: 0;
            height: 0;
            left: -7px;
            top: 10px;
            position: absolute;
            border-right: 5px solid transparent;
            border-left: 5px solid transparent;
            border-bottom: 5px solid #eee;
            transform: rotate(-90deg);
          }

          .logo-box {
            width: 100%;
            font-size: 8px;
            color: @font-minor-color;
            margin-bottom: 2px;

            img {
              width: 8px;
              height: 8px;
              border-radius: 50%;
              margin-right: 5px;
            }
          }

          .wx-bg {
            width: 100%;
            height: 100%;

            img {
              width: 100%;
              height: 100%;
            }
          }

          .wx-name {
            font-size: 6px;
            margin-top: 3px;
            display: block;
            width: 100%;
            display: flex;
          }
        }

        .audio-type {
          .svg-icon {
            width: 58px !important;
            height: 24px !important;
          }
        }

        .voice-type {
          width: 58px;
          height: 24px;
          background: #eeeeee;
          border-radius: 4px;
        }

        .wx-video-type {
          width: 83px;
          height: 110px;
          position: relative;
          border-radius: 4px;
          background: #eeeeee linear-gradient(360deg, rgba(0, 0, 0, 0.5) 0%, rgba(0, 0, 0, 0) 100%);

          .head {
            width: 100%;
            height: 100%;
            position: relative;

            .svg-icon {
              width: 16px !important;
              height: 16px !important;
              left: 50%;
              top: 50%;
              position: absolute;
              color: #fff;
              margin-left: -8px;
            }

            img {
              width: 100%;
              height: 100%;
              border-radius: 4px;
            }
          }

          .wx-tit {
            font-size: 6px;
            color: #fff;
            position: absolute;
            left: 0;
            bottom: 0px;
            right: 0;
            padding-left: 4px;

            img {
              width: 10px;
              height: 10px;
              margin-right: 3px;
            }
          }
        }

        .group-invite-box {
          background: #fdeee4;
          color: #ed7b2f;
          width: 52px;
          height: 22px;
          border-radius: 4px 4px 4px 4px;
          font-size: 12px;
        }
        .group-notice-box {
          background: #fff6e5;
          color: #ffa800;
          width: 52px;
          height: 22px;
          border-radius: 4px 4px 4px 4px;
          font-size: 12px;
          margin-bottom: 6px;
        }
        .group-invite-text {
          margin-top: 6px;
          color: #ed7b2f;
        }

        .auto-message-item-time {
          color: #999999;
          margin-left: 16px;
        }
      }
    }
    .footer-btn {
      width: 100%;
      height: 64px;

      .ant-btn {
        margin-right: 10px;

        &:last-child {
          margin-right: 0;
        }
      }
    }
  }
}
</style>

<style lang="less">
.created-sop-modal {
  .ant-modal-footer {
    border-top: 1px solid rgba(238, 238, 238, 0.6);
  }
  .tip {
    color: #999999;
  }
  .txt {
    margin-top: 24px;
  }
  .send-list {
    margin-top: 8px;
    .send-item {
      background: #f5f5f5;
      border-radius: 6px 6px 6px 6px;
      padding: 10px 16px 10px 10px;
      font-size: 14px;
      margin-right: 8px;
      margin-bottom: 8px;
      img {
        width: 28px;
        height: 28px;
        border-radius: 4px;
        margin-right: 8px;
      }
    }
  }
}
</style>
