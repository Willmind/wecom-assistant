<template>
  <BasicDrawer :register="registerDrawer" showFooter width="560px" title="批量修改时间间隔">
    <div class="container">
      <div class="edit-box jz-flex jz-flex-col">
        <div class="tip-box jz-flex jz-flex-cc">
          <exclamation-circle-filled style="color: #ed7b2f; font-size: 20px" />
          <div class="tip-box__txt">保存修改后，设置的时间间隔页将生效于新添加的内容。</div>
        </div>
        <div class="info jz-flex-1 jz-flex jz-flex-col">
          <div class="item jz-flex">
            <span class="label jz-flex jz-flex-rr jz-flex-cc" style="font-weight: 600">
              随机发送时间间隔
            </span>
            <div class="jz-flex-1 jz-input jz-flex jz-flex-rl">
              <a-input-number
                v-model:value="state.time"
                :min="1"
                :controls="false"
                @input="handleInputTime"
              />
              <a-select v-model:value="state.type" :options="state.typeList" />
              <a-button class="ref-btn" :disabled="computedBtn" @click="resetData">恢复推荐值</a-button>
            </div>
          </div>
          <div class="item jz-flex">
            <span class="label jz-flex jz-flex-rr jz-flex-cc" style="font-weight: 600"> 生效范围 </span>
            <div class="jz-flex-1 jz-input jz-flex jz-flex-rl">
              <a-radio-group v-model:value="state.range" :options="state.rangeOptions" />
            </div>
          </div>
        </div>
      </div>
    </div>
    <template #footer>
      <div class="jz-flex jz-flex-rr">
        <a-button style="margin-right: 10px" @click="closeDrawer">取消</a-button>
        <a-button type="primary" @click="onsubmit">保存</a-button>
      </div>
    </template>
  </BasicDrawer>
</template>
<script setup>
import { useDrawerInner } from '@/components/basic/drawer'
import { cloneDeep } from 'lodash-es'
import { computed, reactive } from 'vue'
const emit = defineEmits(['success'])
const state = reactive({
  time: 10, // 时间
  type: 1, // 时间tag
  range: 1, // 生效范围
  typeList: [
    { label: '时', value: 3 },
    { label: '分', value: 2 },
    { label: '秒', value: 1 }
  ],
  rangeOptions: [
    { label: '仅修改当前天数', value: 1 },
    { label: '修改所有天数', value: 2 }
  ]
})

defineProps({
  register: Function
})

const computedBtn = computed(() => {
  return state.type === 3 && state.time === 10
})

// 抽屉参数
const [registerDrawer, { closeDrawer }] = useDrawerInner()

// ========================methods

// 设置时间
const handleInputTime = (val) => {
  let str = val + ''
  if (str.length >= 4) {
    nextTick(() => {
      state.time = val.slice(0, 3)
    })
  }
}

// 重置数据
const resetData = () => {
  state.time = 10
  state.type = 1
}

// 提交
const onsubmit = () => {
  let { range, type, time } = state
  emit('success', cloneDeep({ range, type, time }))
  state.range = 1
  resetData()
  closeDrawer()
}
</script>
<style lang="less" scoped>
.edit-box {
  padding: 0px 32px 20px;
  width: 100%;
  height: 100%;
  position: relative;
  font-size: 14px;
  .ref-btn {
    margin-left: 32px;
  }
  .tip-box {
    color: #ed7b2f;
    > div {
      margin-left: 10px;
      padding-right: 46px;
    }
  }
  .example {
    width: 80px;
    height: 32px;

    border-radius: 6px;
    text-align: center;
    line-height: 32px;
    color: #3165f5;
    margin-left: 12px;
    cursor: pointer;
    &:hover {
      background: #eaf0fe;
    }
  }
  .tip-popover {
    width: 248px;
    height: 412px;
    img {
      width: 100%;
      height: 100%;
    }
  }
  .tit {
    margin-bottom: 8px;
    color: @font-minor-color;
  }
  .dot {
    width: 16px;
    height: 100%;
    color: #999;
  }
  .color-gray {
    color: @font-minor-color;
  }
  .info {
    .item {
      width: 100%;
      margin-top: 32px;
      position: relative;
      .label {
        font-weight: 500;
        margin-right: 32px;
        width: 120px;
        text-align: right;
        position: relative;
        color: @font-body-color;
      }
      .ask {
        position: absolute;
        right: -20px;
        color: #999;
      }
    }
    .line {
      margin: 48px 0;
      width: 100%;
      height: 0.5px;
      background: #eee;
    }
  }
}

:deep(.ant-select) {
  .ant-select-selector {
    width: 56px;
    border-radius: 0 6px 6px 0;
    border-left: 0px;
  }
}
:deep(.ant-input-number) {
  width: 65px;
  border-radius: 6px 0 0 6px;
}
:deep(.ant-input-number-input) {
  border-radius: 6px;
  text-align: center;
}
:deep(.ant-input-number-input:hover) {
  border-radius: 6px;
  border-color: #3165f5;
}
:deep(.ant-radio-inner) {
  border-color: rgba(0, 0, 0, 0.1);
}
:deep(.ant-radio-checked .ant-radio-inner) {
  border-color: #3165f5;
}
:deep(.ant-radio-inner::after) {
  background-color: #3165f5;
}
:deep(.ant-drawer-header) {
  padding: 32px 32px 16px 32px !important;
}
:deep(.ant-popover-arrow) {
  opacity: 0;
}
</style>
