<template>
  <BasicDrawer
    :register="registerDrawer"
    innerPage
    showForehead
    :loading="loading"
    :mask="false"
    :showClose="false"
    :showFooter="false"
    :push="false"
    @visible-change="handelVisibleChange"
    classes="editor-drawer"
    :cancelBtnProps="{ disabled: false }"
    :get-container="false"
  >
    <template #title>
      <div class="head jz-flex jz-flex-cc">
        <a-tooltip placement="top" style="background: red">
          <template #title>
            <span>返回</span>
          </template>
          <span class="back-btn jz-flex jz-flex-center jz-pointer" @click="onClose">
            <svg-icon icon-name="login_back" style="width: 32px; height: 32px" />
          </span>
        </a-tooltip>
        <span class="tit">{{ state.isEdit ? '编辑' : '新建' }} SOP 模版</span>
      </div>
    </template>
    <div class="sop-wrapper jz-flex jz-flex-col">
      <div class="sop-cell jz-flex jz-flex-cc">
        <label>模板名称</label>
        <div class="sop-cell-content">
          <a-input style="width: 296px" v-model:value="state.name" :maxlength="20" placeholder="请输入名称" />
          <span style="color: #999; margin-left: 10px">{{ state.name.length }}/20</span>
        </div>
      </div>
      <div class="sop-cell jz-flex">
        <label>可见范围</label>
        <div class="sop-cell-content jz-flex jz-flex-col">
          <a-radio-group v-model:value="state.type" :options="state.typeOptions" />
          <div class="jz-flex select-list" v-if="state.type === 2 && !loading">
            <div class="select-list-item" v-for="(item, index) in state.rangeList" :key="index">
              {{ item.name || item.username }}
              <svg-icon @click="cancelItem(item)" icon-name="jz_close" class="close-icon" />
            </div>
            <RangePopover :rangeList="state.rangeList" :treeData="treeData" @success="handleStaffData">
              <a-button class="add-btn" type="info" size="large">
                <template #icon>
                  <SvgIcon icon-name="ic_add_btn" :iconSize="28" />
                </template>
                添加部门/人员
              </a-button>
            </RangePopover>
          </div>
        </div>
      </div>
      <div class="sop-cell jz-flex jz-flex-cc">
        <label>他人复制权限</label>
        <div class="sop-cell-content">
          <a-switch v-model:checked="state.isRule" :checkedValue="2" :unCheckedValue="1" />
        </div>
      </div>
      <div class="sop-cell jz-flex" style="padding-bottom: 60px">
        <label style="padding-top: 12px">素材内容</label>
        <div class="sop-cell-content">
          <SopTabs ref="sopTab" />
        </div>
      </div>
    </div>
    <a-modal
      v-model:visible="state.visible"
      :footer="null"
      centered
      :closable="false"
      :bodyStyle="{ padding: '24px 24px 16px' }"
      width="416px"
    >
      <div class="jz-flex jz-flex-col send-box">
        <div class="tip jz-flex jz-flex-cc">
          <exclamation-circle-filled style="color: #ed7b2f; font-size: 20px" />
          <div style="margin-left: 10px">是否将修改后的 SOP 模板应用至已有任务？</div>
        </div>
        <div style="color: #999; margin: 16px 0px 4px">
          如果应用，则将对「本企微号」或「同企业所有企微号」所调用该模板的未发送任务内容进行替换
        </div>
        <div style="color: #ed7b2f">提示: 完成替换需要一定时间，具体视替换任务多少而定。</div>
        <div class="jz-flex jz-flex-cc jz-flex-rr" style="margin-top: 40px">
          <a-button style="margin-right: 10px" @click="handleTaskType(0)">不应用</a-button>
          <a-button style="margin-right: 10px" @click="handleTaskType(1)">应用所有号</a-button>
          <a-button type="primary" @click="handleTaskType(2)">仅应用本号</a-button>
        </div>
      </div>
    </a-modal>
    <div class="footer-btn jz-flex jz-flex-rr jz-flex-cc" v-if="state.showFooter">
      <a-button @click="handleCancel" style="margin-right: 10px">取消</a-button>
      <a-button type="primary" :disabled="!state.name" @click="handleConfirm" :loading="isSubmiting">
        确定
      </a-button>
    </div>
  </BasicDrawer>
</template>

<script setup>
import { sopEdit, getSopTempInfo } from '@/api/sop'
import { useDrawerInner } from '@/components/basic/drawer'
import { reactive, toRaw } from 'vue'
import { getDeptTreeApi } from '@/api/common'
import useMessage from '@/composables/web/useMessage'
import { apiGetUserInfo } from 'api/login'
const { createConfirm, createMessage } = useMessage()

defineProps({
  register: Function
})
const [registerDrawer, { closeDrawer }] = useDrawerInner(async (res) => {
  state.id = res?.record?.id
  if (state.id) {
    let { data } = await getSopTempInfo({ id: state.id })
    state.has_task = data.has_task ?? 0
    initData(data)
  }
  state.isEdit = res?.isEdit ?? false
  await getDeptTree()

  if (!state.isEdit) {
    //新增模板的时候默认选中自己部门
    state.type = 2
    getDefaultDept()
  }
  loading.value = false
})

const loading = ref(true)
const isSubmiting = ref(false)
const treeData = ref([])
const sopTab = ref(null)

const state = reactive({
  id: null, // 编辑id

  isEdit: false, // 是否编辑

  isLock: false,

  visible: false,

  showFooter: false,

  has_task: 0, // 是否有正在执行的任务

  apply_task_type: 0, // 应用模板类型

  type: 1, // 可见范围类型

  name: '', // 模板名称

  admin_ids: [], // 部门admin

  dept_ids: [], // 部门dept

  rangeList: [],

  isRule: 2, // 是否复制权限

  typeOptions: [
    { label: '仅自己可见', value: 1 },
    { label: '部门可见，他人可在团队素材中调用', value: 2 }
  ]
})
const emit = defineEmits(['success'])
// computed============================

// methods============================

const handelVisibleChange = (val) => {
  state.showFooter = val
}

// 回填数据
const initData = (res) => {
  let _depData =
    res.dept_data?.map((i) => {
      return { ...i, type: 'dept' }
    }) ?? []
  let _adminData =
    res.admin_data?.map((i) => {
      return { ...i, type: 'admin' }
    }) ?? []

  state.rangeList = [..._depData, ..._adminData]
  state.admin_ids = state.rangeList.filter((i) => i.type === 'admin').map((el) => el.id)
  state.dept_ids = state.rangeList.filter((i) => i.type === 'dept').map((el) => el.id)
  let { name, type } = res
  state.type = type
  state.name = name
  state.isRule = res.permission.length ? 2 : 1
  nextTick(() => {
    sopTab.value?.setPre(res.temp_content)
  })
}

// 取消发送
const handleCancel = () => {
  createConfirm({
    content: `取消后编辑的内容不会保存，是否确认取消？`,
    onOk() {
      onClose()
    }
  })
}
/**
 * 获取默认部门
 * @returns {Promise<void>}
 */
const getDefaultDept = async () => {
  let { code, data } = await apiGetUserInfo()
  if (code === 1000) {
    state.rangeList.push({
      id: data.department_id,
      type: 'dept',
      name: data.position.substring(data.position.lastIndexOf('\/') + 1, data.position.length) //截取最后一个斜杆后面的字符
    })
    state.admin_ids = state.rangeList.filter((i) => i.type === 'admin').map((el) => el.id)
    state.dept_ids = state.rangeList.filter((i) => i.type === 'dept').map((el) => el.id)
  }
}

const cancelItem = (item) => {
  let index
  if (item.hasOwnProperty('child')) {
    index = state.rangeList.findIndex((i) => {
      return i.id === item.id && item.hasOwnProperty('child')
    })
    state.rangeList.splice(index, 1)
  } else {
    index = state.rangeList.findIndex((i) => {
      return i.id === item.id
    })
    state.rangeList.splice(index, 1)
    state.admin_ids = state.rangeList.filter((i) => i.type === 'admin').map((el) => el.id)
    state.dept_ids = state.rangeList.filter((i) => i.type === 'dept').map((el) => el.id)
  }
}

/**
 * @desc 部门组件回调
 * @param items 已选部门参数
 */
const handleStaffData = (items = []) => {
  state.rangeList = [...items]
  state.admin_ids = state.rangeList.filter((i) => i.type === 'admin').map((el) => el.id)
  state.dept_ids = state.rangeList.filter((i) => i.type === 'dept').map((el) => el.id)
}

/**
 * @desc 获取部门结构
 */
const getDeptTree = async () => {
  let { code, data } = await getDeptTreeApi()
  if (code === 1000) {
    treeData.value = data
  }
}

// 关闭抽屉
const onClose = () => {
  state.id = null // 编辑id

  state.isEdit = false // 是否编辑

  state.type = 1 // 可见范围类型

  state.name = '' // 模板名称

  state.admin_ids = [] // 部门admin

  state.dept_ids = [] // 部门dept

  state.rangeList = []

  state.isRule = 2 // 是否复制权限

  sopTab.value?.resetPre()
  closeDrawer()
}

// 处理数据格式错误提示
const handleError = (arr) => {
  let numArr = arr.map((i) => i.day)
  if (Array.from(new Set(numArr)).length < numArr.length) {
    createMessage.warn('存在重复天数，请检查')
    return false
  }
  for (let index = 0; index < arr.length; index++) {
    if (!arr[index].content.length) {
      createMessage.warn('每一天对应的素材内容不能为空，请检查')
      return false
    }
    if (arr[index].type === 2 && !arr[index].end_time) {
      createMessage.warn('每一天对应的随机发送时间不能为空，请检查')
      return false
    }
    if (!arr[index].day) {
      createMessage.warn('每一天对应的发送天数不能为空，请检查')
      return false
    }
  }
  return true
}

// 处理应用模板
const handleTaskType = (type = 0) => {
  state.isLock = true
  state.apply_task_type = type
  state.visible = false
  handleConfirm()
}

// 确认提交
const handleConfirm = async () => {
  let arr = sopTab.value?.getPre().map((i) => i.data)
  if (!handleError(arr)) return
  if (state.isEdit && state.has_task && !state.isLock) {
    state.visible = true
    return
  }
  let { name, type, admin_ids, dept_ids } = toRaw(state)
  let params = {
    name,
    type,
    admin_ids,
    dept_ids,
    permission: state.isRule === 2 ? [state.isRule] : [],
    temp_content: arr
  }
  if (state.isEdit) {
    params = Object.assign({ id: state.id, apply_task_type: state.apply_task_type }, params)
  }
  isSubmiting.value = true
  sopEdit({ ...params })
    .then((res) => {
      if (res.code === 1000) {
        createMessage.success(state.isEdit ? '编辑模板成功' : '新建模板成功')
        emit('success')
        onClose()
      }
    })
    .finally(() => {
      isSubmiting.value = false
      state.isLock = false
    })
}
</script>

<style lang="less" scoped>
.head {
  position: relative;
  height: 60px;
  .tit {
    font-size: 20px;
    font-weight: bold;
  }
}
.footer-btn {
  height: 64px;
  min-height: 64px;
  padding-right: 32px;
  left: 0;
  right: 0;
  bottom: 0;
  position: fixed;
  width: 100%;
  background: #fff;
}
.sop-wrapper {
  width: 100%;
  height: 100%;
  font-size: 14px;
  .sop-cell {
    width: 100%;
    margin-bottom: 32px;
    &:last-child {
      margin-bottom: 0;
      padding-bottom: 60px;
    }
    label {
      display: block;
      width: 148px;
      text-align: right;
      padding-right: 32px;
      font-weight: bold;
    }
    &-content {
      width: 100%;
      flex: 1;
      overflow: hidden;
      .tag-box {
        margin-top: 16px;
      }
    }
  }
}
.select-list {
  margin-top: 16px;
  flex-wrap: wrap;
  .select-list-item {
    background: #f0f0f0;
    border-radius: 4px 4px 4px 4px;
    padding: 6px 12px;
    font-size: 12px;
    font-weight: 400;
    color: #000000;
    margin: 0 5px 5px 0;
    height: 32px;
    display: flex;
    justify-content: center;
    align-items: center;

    .close-icon {
      cursor: pointer;

      &:hover {
        opacity: 0.5;
      }
    }
  }
  :deep(.add-btn) {
    border-style: dashed;
    height: 32px;
    box-sizing: border-box;
    padding: 0 10px;
    margin-bottom: 5px;
    display: flex;
    align-items: center;
    span {
      font-size: 14px;
    }
  }
}
</style>
