<template>
  <BasicDrawer
    :register="registerDrawer"
    :showFooter="false"
    :loading="state.loading"
    @visible-change="handelVisibleChange"
    width="1100px"
  >
    <template #title>
      <div class="head jz-flex jz-flex-cc">
        <span class="tit">任务列表</span>
      </div>
    </template>
    <div class="content jz-flex jz-flex-dir-col">
      <div class="search-list jz-flex jz-flex-cc">
        <a-form layout="inline" style="width: 100%">
          <a-form-item style="flex: 2">
            <a-input
              class="keywork-search-input"
              v-model:value="form.temp_keyword"
              allowClear
              placeholder="模板名称/ID"
            >
              <template #suffix v-if="!form.temp_keyword"> <svg-icon icon-name="ic_search" /> </template
            ></a-input>
          </a-form-item>
          <a-form-item style="flex: 2">
            <a-input
              class="keywork-search-input"
              v-model:value="form.member_name"
              allowClear
              placeholder="发送对象"
            >
              <template #suffix v-if="!form.member_name"> <svg-icon icon-name="ic_search" /> </template
            ></a-input>
          </a-form-item>
          <a-form-item style="flex: 2">
            <a-range-picker
              v-model:value="form.time"
              value-format="YYYY-MM-DD"
              :placeholder="['开始时间', '结束时间']"
              allowClear
              :ranges="{
                当天: [dayjs(), dayjs()],
                昨天: [
                  dayjs().startOf('day').subtract(1, 'days'),
                  dayjs().startOf('day').subtract(1, 'days')
                ],
                最近3天: [dayjs().startOf('day').subtract(2, 'days'), dayjs()],
                最近7天: [dayjs().startOf('day').subtract(6, 'days'), dayjs()],
                最近30天: [dayjs().startOf('day').subtract(29, 'days'), dayjs()]
              }"
            />
          </a-form-item>
          <a-form-item style="flex: 1">
            <a-select allowClear v-model:value="form.status" :options="state.typeList" placeholder="状态" />
          </a-form-item>
          <a-form-item style="flex: 1; margin-right: 0px">
            <a-select
              allowClear
              v-model:value="form.member_type"
              :options="state.member_typeList"
              placeholder="客户/客户群"
            />
          </a-form-item>
        </a-form>
      </div>
      <div class="tips jz-flex jz-flex-cc jz-flex-rb">
        <div class="jz-flex jz-flex-cc table-tip">
          <svg-icon style="width: 20px; height: 20px" icon-name="info-circle-fill" />
          <div class="nav-text">仅保留最近 1 个月的任务记录。</div>
        </div>
        <div class="jz-flex jz-flex-cc right-tip">
          <div>仅显示有失败消息</div>
          <a-switch class="switch" v-model:checked="form.isSwitch" />
        </div>
      </div>
      <div class="table-content jz-flex-1" ref="tabBox">
        <a-table
          row-key="id"
          :pagination="false"
          :columns="columns"
          :data-source="state.list"
          class="sop-task-table jz-flex-1"
          :scroll="{ y: state.scrollY }"
          :customRow="rowClick"
        >
          <template #bodyCell="{ column, record }">
            <template v-if="column.key === 'temp_id'">
              <div>{{ record.temp_id }}</div>
            </template>
            <template v-if="column.key === 'name'">
              <div class="avatar jz-flex jz-flex-cc">
                <a-badge :dot="record.fail_num !== 0">
                  <a-avatar :size="40" :src="record.avatar" shape="square" />
                </a-badge>
                <div class="customer-info">
                  <div class="customer-name">{{ record.name }}</div>
                  <div
                    v-if="record.wx_type !== ''"
                    :style="{ color: record.wx_type ? '#57be6a' : '#ed7b2f' }"
                  >
                    @{{ record.wx_type_val }}
                  </div>
                  <div v-else style="color: #999999">群成员: {{ record.number }}</div>
                </div>
              </div>
            </template>
            <template v-if="column.key === 'temp_name'">
              <div>{{ record.temp_name }}</div>
            </template>
            <template v-if="column.key === 'update_time'">
              <div>{{ dayjs(+record.update_time * 1000).format('YYYY-MM-DD HH:mm:ss') }}</div>
            </template>
            <template v-if="column.key === 'create_time'">
              <div>{{ dayjs(+record.create_time * 1000).format('YYYY-MM-DD HH:mm:ss') }}</div>
              <div>创建人 : &nbsp; {{ record.create_user }}</div>
            </template>
            <template v-if="column.key === 'status'">
              <!--           等待中1 / 执行中2 / 已取消4-->
              <template v-if="record.sop_member_status !== 3">
                <a-progress
                  :strokeColor="
                    record.sop_member_status === 2 || record.sop_member_status === 1 ? '#3165F5' : '#999999'
                  "
                  :strokeWidth="4"
                  :percent="Math.floor((record.over_day / record.total_day) * 100)"
                />
                <div
                  :style="{
                    color:
                      record.sop_member_status === 2 || record.sop_member_status === 1 ? '#3165F5' : '#999999'
                  }"
                >
                  第 {{ record.over_day + 1 }} 天 · {{ record.sop_member_status_val }}
                </div>
              </template>

              <!--                已结束3-->
              <div v-else class="status-fail">{{ record.sop_member_status_val }}</div>
            </template>
            <template v-if="column.key === 'operation'">
              <div class="jz-flex">
                <a-button style="padding: 0 12px 0 0" type="link" @click.stop="openSopDetailDrawer(record)"
                  >查看</a-button
                >
                <a-button
                  @click.stop="cancelTask(record)"
                  v-show="record.sop_member_status === 1 || record.sop_member_status === 2"
                  style="padding: 0px"
                  type="link"
                  >取消</a-button
                >
              </div>
            </template>
          </template>
          <template #emptyText>
            <div class="not-more jz-flex jz-flex-center jz-flex-col">
              <img src="@/assets/imgs/not_more.png" alt="" />
              <span>无内容</span>
            </div>
          </template>
        </a-table>
      </div>
      <div class="pagination-box">
        <basic-pagination @change="pageChange" :params="state.paginationParams">
          <template #extra>
            <span class="page-total">共 {{ state.paginationParams.total }} 条</span>
          </template>
        </basic-pagination>
      </div>
    </div>
  </BasicDrawer>
  <SopDetailDrawer :register="registerSopDetailDrawer" @success="getListData()" />
</template>
<script setup>
import dayjs from 'dayjs'

import { useDrawerInner, useDrawer } from '@/components/basic/drawer'
import { computed, onMounted, reactive, unref } from 'vue'
import { cloneDeep, debounce } from 'lodash-es'
import { cancelSopTask, getSopTaskList } from 'api/sop'
import useMessage from '@/composables/web/useMessage'
const [registerSopDetailDrawer, { openDrawer: openSopDetailDrawer }] = useDrawer()
const emit = defineEmits(['close'])
const { createMessage } = useMessage()
const tabBox = ref(null)

const state = reactive({
  loading: false,
  scrollY: 0,
  paginationParams: {
    total: 0,
    current: 1,
    showSizeChanger: false
  },
  typeList: [
    { label: '等待中', value: 1 },
    { label: '执行中', value: 2 },
    { label: '已结束', value: 3 },
    { label: '已取消', value: 4 }
  ],
  member_typeList: [
    { label: '客户', value: 1 },
    { label: '客户群', value: 2 }
  ],
  list: []
})
const columns = [
  { title: '模板ID', key: 'temp_id', width: '80px' },
  { title: '发送对象', key: 'name', width: '173px' },
  { title: '模版名称', key: 'temp_name', width: '173px' },
  { title: '更新时间', key: 'update_time', width: '120px' },
  { title: '创建时间', key: 'create_time', width: '170px' },
  { title: '状态', key: 'status', width: '200px' },
  { title: '操作', key: 'operation', width: '108px' }
]
const form = reactive({
  status: undefined,
  member_type: undefined,
  isSwitch: false,
  time: [],
  temp_keyword: '',
  member_name: ''
})

const rowClick = (record) => {
  return {
    onclick: (event) => {
      openSopDetailDrawer(record)
    }
  }
}

// 抽屉参数
const [registerDrawer] = useDrawerInner()
defineProps({
  register: Function
})

/**
 * computed属性
 * @type {ComputedRef<{[p: string]: *}>}
 */
// 获取form参数
const getParams = computed(() => {
  const deepData = cloneDeep(form)
  return {
    ...deepData,
    create_time_start: deepData?.time?.length ? dayjs(deepData.time[0])?.unix?.() : undefined,
    create_time_end: deepData?.time?.length ? dayjs(deepData.time[1])?.unix?.() + 86400 : undefined,
    time: undefined,
    page: state.paginationParams.current,
    limit: 10,
    fail_num: deepData.isSwitch ? 1 : undefined
  }
})

const querySearch = async (params) => {
  let { data, code } = await getSopTaskList(params)
  if (code === 1000) {
    state.list = data.list
  }
  state.paginationParams.total = data.total
  state.loading = false
}
const debounceSearch = debounce(querySearch, 350)

// 抽屉展示关闭
const handelVisibleChange = (val) => {
  if (val) {
    window.addEventListener('resize', getTableScrollY)
    // 获取tab滚动高度
    getTableScrollY()
    getListData()
    window.TasklocalTime = setInterval(() => {
      const params = unref(getParams)
      debounceSearch(toRaw(params))
    }, 5000)
  } else {
    window.removeEventListener('resize', getTableScrollY)
    handleReset()
    emit('close')
    clearInterval(window.TasklocalTime)
  }
}

const handleReset = () => {
  form.status = undefined
  form.member_type = undefined
  form.time = []
  form.temp_keyword = ''
  form.member_name = ''
  state.paginationParams = {
    total: 0,
    current: 1,
    showSizeChanger: false
  }
  state.loading = false
  state.list = []
}

const getListData = () => {
  state.loading = true
  const params = unref(getParams)
  debounceSearch(toRaw(params))
}

const pageChange = (_params) => {
  state.paginationParams.current = _params.current
  getListData()
}

const cancelTask = async (record) => {
  let { code } = await cancelSopTask({
    id: record.id
  })
  if (code === 1000) {
    createMessage.success('取消成功')
    state.paginationParams.current = 1
    getListData()
  }
}

/**
 * @desc 获取滚动表格滚高
 */
const getTableScrollY = () => {
  console.log(tabBox)
  nextTick(() => {
    state.scrollY = tabBox?.value.clientHeight - 54 ?? 500
  })
}
// 监听=======
watch(
  () => form,
  () => {
    state.paginationParams.current = 1
    getListData()
  },
  {
    deep: true
  }
)

// 消息=========================end
</script>

<style lang="less" scoped>
.head {
  position: relative;
  display: flex;
  padding: 16px 0;
  height: 60px;

  .tit {
    font-size: 20px;
    font-weight: bold;
  }

  .back-btn {
    margin-right: 8px;
    border-radius: 4px;
    padding-left: 0px;
    position: relative;
    width: 32px;
    height: 32px;
    .svg-icon {
      position: absolute;
      left: 8px;
    }
  }

  .line {
    width: 100%;
    height: 1px;
    background-color: #eee;
    transform: scaleY(0.6);
    position: absolute;
    left: 0;
    bottom: 0;
    right: 0;
  }
}

.content {
  height: 100%;
  padding: 0 32px;
  .search-list {
    height: 64px;
  }
  .tips {
    margin: 12px 0;
    .table-tip {
      .nav-text {
        color: #ed7b2f;
        margin-left: 10px;
        white-space: nowrap;
      }
    }
    .right-tip {
      color: #999999;
      > div {
        margin-right: 16px;
      }
    }
  }
  .table-content {
    overflow: auto;
    // 修改滚动条
    :deep(.ant-table-body) {
      &::-webkit-scrollbar {
        width: 0px;
      }
    }
    .not-more {
      img {
        width: 110px;
        height: 110px;
        margin-bottom: 4px;
      }
      span {
        font-size: 12px;
      }
    }
  }
  .sop-task-table {
    .avatar {
      img {
        width: 40px;
        height: 40px;
        border-radius: 8px;
      }
      .customer-info {
        margin-left: 16px;
        .customer-name {
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
          width: 86px;
        }
      }
      .type1 {
        color: #57be6a;
      }
      .type2 {
        color: #ed7b2f;
      }
    }

    .status-fail {
      color: #999999;
    }
  }
  .pagination-box {
    height: 64px;
  }
}
:deep(.ant-table-thead > tr > th) {
  color: @font-minor-color;
  border-bottom: none;
}
::-webkit-scrollbar {
  width: 0px;
  height: 0px;
}
:deep(.ant-table-thead
    > tr
    > th:not(:last-child):not(.ant-table-selection-column):not(.ant-table-row-expand-icon-cell):not([colspan])::before) {
  width: 0;
}
:deep(.ant-progress-text) {
  color: #999999;
}
</style>
