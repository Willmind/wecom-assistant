<template>
  <BasicDrawer
    :register="registerDrawer"
    :showFooter="false"
    :loading="state.loading"
    :showClose="false"
    @visible-change="handelVisibleChange"
    width="1000px"
  >
    <template #title>
      <div class="head jz-flex jz-flex-cc">
        <a-tooltip placement="top">
          <template #title>
            <span>返回</span>
          </template>
          <span class="back-btn jz-flex jz-flex-center jz-pointer" @click="closeDrawer">
            <svg-icon icon-name="login_back" style="width: 32px; height: 32px" />
          </span>
        </a-tooltip>
        <span class="tit">查看SOP</span>
      </div>
    </template>
    <div v-if="!noneData" class="content jz-flex jz-flex-dir-col">
      <a-tabs
        class="jz-flex-1"
        v-model:activeKey="activeKey"
        :tab-position="mode"
        @tabClick="dayChange"
        @tabScroll="callback"
      >
        <a-tab-pane v-for="item in state.list_data.day" :key="item.id">
          <template #tab>
            <span>
              <a-badge :dot="isTaskDetail ? item.fail_num > 0 : false"> 第{{ item.day }}天 </a-badge>
            </span>
          </template>
          <div class="jz-flex jz-flex-rb jz-flex-cc sop-title">
            <div>
              <div class="title">{{ isTaskDetail ? state.list_data.temp.name : state.name }}</div>
              <div>
                <template v-if="isTaskDetail">
                  <span v-if="state.current_Detail.type === 1">立即开始发送第 1 条</span>
                  <span v-else>
                    {{ state.current_Detail.start_time }} -
                    {{ state.current_Detail.end_time }} 内随机开始发送第 1 条</span
                  >
                </template>
                <template v-else>
                  <span v-if="item.type === 1">立即开始发送第 1 条</span>
                  <span v-else> {{ item.start_time }} - {{ item.end_time }} 内随机开始发送第 1 条 </span>
                </template>

                <span v-if="isTaskDetail && state.current_Detail.over_time > 0">
                  , 已于
                  {{ dayjs(+state.current_Detail.over_time * 1000).format('YYYY-MM-DD HH:mm:ss') }}
                  处理完成</span
                >
              </div>
            </div>
            <div class="jz-flex jz-flex-dir-col jz-flex-cb">
              <div>创建人：{{ isTaskDetail ? state.list_data.temp.create_user : state.create_user }}</div>
              <div>
                {{
                  isTaskDetail
                    ? dayjs(+state.list_data.temp.create_time * 1000).format('YYYY-MM-DD HH:mm:ss')
                    : state.create_time
                }}
              </div>
            </div>
          </div>
          <div class="auto-message-list jz-flex-1">
            <div
              class="auto-message-item jz-flex jz-flex-cc"
              v-for="(msgItem, index) in isTaskDetail ? state.current_Detail.content : item.content"
              :key="randomUUID()"
            >
              <div class="box-serial">{{ +index + 1 < 10 ? `0${index + 1}` : index + 1 }}</div>
              <div class="jz-flex-1 text-type" v-if="msgItem.msg_type === 2">
                {{ msgItem.msg.text }}
              </div>
              <!--图片类型-->
              <div class="jz-flex-1 img-type" v-if="+msgItem.msg_type === 14">
                <img :src="msgItem.msg.url" alt="" />
              </div>
              <!--视频类型-->
              <div class="jz-flex-1 video-type" v-if="+msgItem.msg_type === 23">
                <video :src="msgItem.msg.url"></video>
                <svg-icon icon-name="ic_msg_video" />
              </div>
              <!--文件类型-->
              <div class="jz-flex-1 file-type jz-flex jz-flex-cc" v-if="+msgItem.msg_type === 15">
                <svg-icon icon-name="ic_msg_pdf" />
                <span class="lineClamp1">{{ msgItem.msg.name }}</span>
              </div>
              <!--链接类型-->
              <div class="jz-flex-1" v-if="+msgItem.msg_type === 13">
                <div class="link-type jz-flex jz-flex-cc jz-flex-col">
                  <div class="link-tit">{{ msgItem.msg.title }}</div>
                  <div class="desc jz-flex jz-flex-1">
                    <div class="desc-text jz-flex-1">{{ msgItem.msg.des }}</div>
                    <img :src="msgItem.msg.thumb_url" alt="" />
                  </div>
                </div>
              </div>
              <!--小程序类型-->
              <div class="jz-flex-1" v-if="+msgItem.msg_type === 78">
                <div class="wx-type jz-flex jz-flex-cc jz-flex-col" v-if="+msgItem.msg_type === 78">
                  <div class="logo-box jz-flex jz-flex-cc">
                    <img :src="msgItem.msg.headimg" alt="" />
                    <span>{{ msgItem.msg.title }}</span>
                  </div>
                  <div class="wx-bg jz-flex-1 jz-flex jz-flex-center">
                    <img :src="msgItem.msg.icon_url" alt="" />
                  </div>
                  <span class="wx-name">小程序</span>
                </div>
              </div>

              <!--语音类型-->
              <div class="jz-flex-1" v-if="+msgItem.msg_type === 16">
                <div class="audio-type jz-flex jz-flex-cc">
                  <svg-icon icon-name="ic_msg_audio" />
                </div>
              </div>

              <!--视频号类型-->
              <div class="jz-flex-1" v-if="+msgItem.msg_type === 141">
                <div class="wx-video-type jz-flex jz-flex-cc jz-flex-col">
                  <div class="jz-flex-1 head">
                    <img :src="msgItem.msg.head_img_url" alt="" />
                    <svg-icon icon-name="ic_msg_video" />
                  </div>
                  <div class="wx-tit jz-flex jz-flex-cc">
                    <img src="@/assets/imgs/sph.png" alt="" /> 简知科技
                  </div>
                </div>
              </div>

              <!--群邀请-->
              <div class="jz-flex-1" v-if="+msgItem.msg_type === 50002">
                <div class="jz-flex jz-flex-rc jz-flex-cc group-invite-box">群邀请</div>
                <div class="group-invite-text" v-for="(invite, index) in msgItem.msg?.data" :key="index">
                  {{ invite.text }}
                </div>
              </div>
              <!--群公告-->
              <div class="jz-flex-1" v-if="+msgItem.msg_type === 50001">
                <div class="jz-flex jz-flex-rc jz-flex-cc group-notice-box">群公告</div>
                <div>
                  <template v-for="(acement, index) in msgItem.msg?.data" :key="index">
                    <a-tag class="ant-tag-plain ang-tag-big" v-if="acement.type === 2">
                      {{ acement.text }}
                    </a-tag>
                    <span v-else>&nbsp;{{ acement.desc }}</span>
                  </template>
                </div>
              </div>

              <div class="jz-flex jz-flex-center auto-message-item-time">
                <svg-icon v-if="msgItem.status === 1" icon-name="sop_finish" />
                <svg-icon v-if="msgItem.status === 2" icon-name="sop_fail" />
                <svg-icon v-if="msgItem.status === 3" icon-name="sop_wait" />
                <div>停留 {{ msgItem.wait }} {{ timeOptions[msgItem.time_type] }}后发送</div>
              </div>
            </div>
          </div>
        </a-tab-pane>
      </a-tabs>

      <div class="footer-btn jz-flex jz-flex-rr jz-flex-cc">
        <a-button v-if="isTaskDetail&&state.current_Detail.content" :disabled="state.current_Detail.fail_num === 0" @click="resentSopData()"
          >
          <span v-if="state.current_Detail.content.filter(i=>i.status===3).length>0">消息发送中...</span>
          <span v-else>重发失败信息</span>
        </a-button
        >
      </div>
    </div>
    <div v-else class="content-none">
      <img src="@/assets/imgs/jz_none.png" alt="" />
      <div>无内容</div>
    </div>
  </BasicDrawer>
</template>
<script setup>
import dayjs from 'dayjs'
import { randomUUID } from 'crypto'
import { useDrawerInner, useDrawer } from '@/components/basic/drawer'
import { reactive, ref, unref } from 'vue'
import { getDayDetail, getSopTaskDetail, getSopTempInfo, resendSop } from 'api/sop'
import useMessage from '@/composables/web/useMessage'
const { createMessage, createConfirm } = useMessage()
const emit = defineEmits(['success'])
const state = reactive({
  loading: false,
  list_data: [],
  current_Detail: {},
  name: '',
  create_user: '',
  create_time: ''
})
const timeOptions = {
  1: '秒',
  2: '分',
  3: '时'
}
const isTaskDetail = ref(false)
const noneData = ref(false)
// 抽屉参数
const [registerDrawer, { closeDrawer }] = useDrawerInner(async (res) => {
  //判断是任务列表点击
  if (res.hasOwnProperty('sop_member_status')) {
    isTaskDetail.value = true
    fetchData(res)
  } else {
    let { data } = await getSopTempInfo({
      id: res.id
    })

    state.name = data.name
    state.create_user = data.create_user
    state.create_time = data.create_time
    state.list_data.day = data.temp_content
    activeKey.value = data.temp_content[0].id
  }
})
const props = defineProps({
  register: Function
})

const fetchData = async (res) => {
  state.loading = true
  let { data } = await getSopTaskDetail({
    id: res.id
  })
  state.list_data = data
  if (state.list_data.day.length > 0) {
    activeKey.value = state.list_data.day[0].id
    await fetchDayData(state.list_data.day[0].id)
  } else {
    noneData.value = true
    state.loading = false
  }
}

const fetchDayData = async (id) => {
  let { data } = await getDayDetail({
    id: id
  })
  state.current_Detail = data
  state.loading = false
}

const dayChange = async (id) => {
  if (isTaskDetail.value === true) {
    await fetchDayData(id)
  }
}

const activeKey = ref(1)
const mode = ref('top')
const callback = (val) => {}

// 抽屉展示关闭
const handelVisibleChange = (val) => {
  if (!val) {
    isTaskDetail.value = false
    state.list_data = []
    state.current_Detail = {}
    emit('success')
  }
}

const resentSopData = async () => {
  let { code, data } = await resendSop({
    id: unref(activeKey)
  })
  if (code === 1000) {
    createMessage.success('重发消息成功')
    await fetchDayData(unref(activeKey))
  }
}

// 消息=========================end
</script>

<style lang="less" scoped>
.head {
  position: relative;
  display: flex;
  padding: 16px 0;

  .tit {
    font-size: 20px;
    font-weight: bold;
  }

  .back-btn {
    margin-right: 8px;
    border-radius: 4px;
    padding-left: 0px;
    position: relative;
    width: 32px;
    height: 32px;
    .svg-icon {
      position: absolute;
      left: 8px;
    }
  }

  .line {
    width: 100%;
    height: 1px;
    background-color: #eee;
    transform: scaleY(0.6);
    position: absolute;
    left: 0;
    bottom: 0;
    right: 0;
  }
}
.content {
  height: 100%;
  padding: 0 32px;
  .sop-title {
    height: 84px;
    color: #999999;
    margin-bottom: 8px;
    padding-top: 8px;
    .title {
      font-size: 20px;
      color: #000000;
      font-weight: 550;
    }
  }

  :deep(.ant-form-item) {
    .ant-form-item-label {
      flex: 0 0 80px;
      max-width: 80px;
      display: inline-flex;

      > label {
        width: 90px;
        font-weight: 550;
        font-size: 14px;
        color: #000;
      }
    }
  }
  :deep(.ant-tabs-content-holder) {
    height: 100%;
  }
  :deep(.ant-tabs-content) {
    height: 100%;
    .ant-tabs-tabpane {
      height: 100%;
      display: flex;
      flex-direction: column;
    }
  }

  .auto-message-list {
    overflow: auto;
    // 修改滚动条
    &:hover {
      &::-webkit-scrollbar-thumb {
        visibility: visible;
      }
      .page-side-fold.is-expand {
        opacity: 1;
      }
    }
    &::-webkit-scrollbar {
      width: 2px;
    }
    &::-webkit-scrollbar-thumb {
      visibility: hidden;
      transition: all 0.28s;
    }
    .auto-message-item {
      padding: 12px;
      background: #f5f5f5;
      border-radius: 6px 6px 6px 6px;
      margin-bottom: 12px;
      &:last-child {
        margin-bottom: 0px;
      }
      .box-serial {
        font-size: 12px;
        font-weight: 400;
        color: #999999;
        line-height: 14px;
        background: #eeeeee;
        width: 24px;
        height: 24px;
        display: flex;
        justify-content: center;
        align-items: center;
        border-radius: 50%;
        margin-right: 16px;
      }

      .text-type {
        color: #000;
        font-size: 14px;
      }

      .img-type {
        img {
          width: 120px;
          height: 120px;
          border-radius: 4px;
        }
      }

      .video-type {
        position: relative;

        > video {
          width: 120px;
          height: 120px;
          object-fit: cover;
          border-radius: 4px;
        }

        .svg-icon {
          position: absolute;
          left: 15px;
          top: 10px;
          color: #fff;
          width: 16px !important;
          height: 16px !important;
        }
      }

      .file-type {
        .svg-icon {
          width: 20px !important;
          height: 20px !important;
          min-width: 20px;
          min-height: 20px;
          margin-right: 4px;
        }
      }

      .link-type {
        width: 90px;
        height: 42px;
        background: #eee;
        position: relative;
        padding: 5px;
        border-radius: 4px;

        &::before {
          content: '';
          width: 0;
          height: 0;
          left: -7px;
          top: 10px;
          position: absolute;
          border-right: 5px solid transparent;
          border-left: 5px solid transparent;
          border-bottom: 5px solid #eee;
          transform: rotate(-90deg);
        }

        .link-tit {
          font-size: 6px;
          color: #000;
          display: -webkit-box;
          -webkit-box-orient: vertical;
          -webkit-line-clamp: 2;
          overflow: hidden;
          line-height: 7px;
          text-align: left;
          width: 100%;
        }

        .desc {
          width: 100%;

          &-text {
            font-size: 5px;
            color: @font-minor-color;
            overflow: hidden;
          }

          img {
            width: 18px;
            height: 18px;
          }
        }
      }

      .wx-type {
        width: 90px;
        height: 100px;
        background: #eee;
        position: relative;
        padding: 5px;
        border-radius: 4px;

        &::before {
          content: '';
          width: 0;
          height: 0;
          left: -7px;
          top: 10px;
          position: absolute;
          border-right: 5px solid transparent;
          border-left: 5px solid transparent;
          border-bottom: 5px solid #eee;
          transform: rotate(-90deg);
        }

        .logo-box {
          width: 100%;
          font-size: 8px;
          color: @font-minor-color;
          margin-bottom: 2px;

          img {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            margin-right: 5px;
          }
        }

        .wx-bg {
          width: 100%;
          height: 100%;

          img {
            width: 100%;
            height: 100%;
          }
        }

        .wx-name {
          font-size: 6px;
          margin-top: 3px;
          display: block;
          width: 100%;
          display: flex;
        }
      }

      .audio-type {
        .svg-icon {
          width: 58px !important;
          height: 24px !important;
        }
      }

      .voice-type {
        width: 58px;
        height: 24px;
        background: #eeeeee;
        border-radius: 4px;
      }

      .wx-video-type {
        width: 83px;
        height: 110px;
        position: relative;
        border-radius: 4px;
        background: #eeeeee linear-gradient(360deg, rgba(0, 0, 0, 0.5) 0%, rgba(0, 0, 0, 0) 100%);

        .head {
          width: 100%;
          height: 100%;
          position: relative;

          .svg-icon {
            width: 16px !important;
            height: 16px !important;
            left: 50%;
            top: 50%;
            position: absolute;
            color: #fff;
            margin-left: -8px;
          }

          img {
            width: 100%;
            height: 100%;
            border-radius: 4px;
          }
        }

        .wx-tit {
          font-size: 6px;
          color: #fff;
          position: absolute;
          left: 0;
          bottom: 0px;
          right: 0;
          padding-left: 4px;

          img {
            width: 10px;
            height: 10px;
            margin-right: 3px;
          }
        }
      }

      .group-invite-box {
        background: #fdeee4;
        color: #ed7b2f;
        width: 52px;
        height: 22px;
        border-radius: 4px 4px 4px 4px;
        font-size: 12px;
      }
      .group-notice-box {
        background: #fff6e5;
        color: #ffa800;
        width: 52px;
        height: 22px;
        border-radius: 4px 4px 4px 4px;
        font-size: 12px;
        margin-bottom: 6px;
      }
      .group-invite-text {
        margin-top: 6px;
        color: #ed7b2f;
      }
      .auto-message-item-time {
        > div {
          color: #999999;
          margin-left: 12px;
        }
        > svg {
          color: white;
        }
        margin-left: 16px;
      }
    }
  }
  .footer-btn {
    width: 100%;
    height: 64px;

    .ant-btn {
      margin-right: 10px;

      &:last-child {
        margin-right: 0;
      }
    }
  }
}

.content-none {
  display: flex;
  align-items: center;
  flex-direction: column;
  padding-top: 120px;

  > div {
    font-weight: 400;
    color: #999999;
    font-size: 12px;
    margin-top: 2px;
  }

  img {
    width: 110px;
    height: 110px;
  }
}
</style>
