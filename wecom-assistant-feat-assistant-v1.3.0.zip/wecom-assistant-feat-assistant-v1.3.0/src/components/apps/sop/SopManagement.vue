<template>
  <div id="sop-wrapper" class="jz-flex jz-flex-col jz-flex-1">
    <div class="head jz-flex jz-flex-cc">
      <strong>SOP</strong>
      <div class="jz-flex jz-flex-1 jz-flex-rr jz-flex-cc">
        <a-button type="primary" @click="openCreateSopTemDrawer({})">新建 SOP 模板</a-button>
        <a-button type="primary" @click="openCreateSopTaskDrawer({})">创建任务</a-button>
        <a-badge :count="state.taskCount">
          <a-button @click="openSopTaskListDrawer()">任务列表</a-button>
        </a-badge>
      </div>
    </div>
    <div class="nav jz-flex">
      <ul class="jz-flex">
        <li
          @click="changeNav(index)"
          class="jz-pointer"
          :class="state.navIndex === index && 'current'"
          v-for="(item, index) in state.navs"
          :key="index"
        >
          {{ item }}
        </li>
      </ul>
      <i></i>
    </div>
    <div class="form">
      <a-form class="jz-flex">
        <a-form-item>
          <a-input v-model:value="form.name" allowClear placeholder="请输入模板名称/ID">
            <template #suffix v-if="!form.name">
              <svg-icon icon-name="ic_search" />
            </template>
          </a-input>
        </a-form-item>
        <a-form-item>
          <a-range-picker
            v-model:value="form.time"
            value-format="YYYY-MM-DD"
            allowClear
            :ranges="{
              当天: [dayjs(), dayjs()],
              昨天: [dayjs().startOf('day').subtract(1, 'days'), dayjs().startOf('day').subtract(1, 'days')],
              最近3天: [dayjs().startOf('day').subtract(2, 'days'), dayjs()],
              最近7天: [dayjs().startOf('day').subtract(6, 'days'), dayjs()],
              最近30天: [dayjs().startOf('day').subtract(29, 'days'), dayjs()]
            }"
          />
        </a-form-item>
        <a-form-item v-if="state.navIndex">
          <a-cascader
            v-model:value="form.dept_ids"
            overlayClassName="cascader-class"
            change-on-select
            :field-names="{ label: 'name', value: 'id', children: 'child' }"
            :options="deptTree"
            placeholder="组织部门"
          />
        </a-form-item>
      </a-form>
    </div>
    <div class="tip jz-flex jz-flex-cc">
      <exclamation-circle-filled style="color: #ed7b2f; font-size: 20px" />
      <div>可通过手动调用SOP模板来创建执行任务，对指定对象自动执行每天的SOP发送消息。</div>
    </div>
    <div class="jz-flex jz-flex-1 table-wrap" ref="tabBox">
      <a-table
        row-key="id"
        class="sop-table"
        :class="!state.list.length && 'not-table'"
        :columns="state.columns"
        :data-source="state.list"
        :bordered="false"
        :pagination="false"
        :loading="loading"
        :scroll="{ y: state.scrollY }"
        :row-selection="{ selectedRowKeys: state.selectedRowKeys, onChange: onSelectChange }"
      >
        <template #bodyCell="{ column, record }">
          <template v-if="column.key === 'create_time'">
            <div class="jz-flex jz-flex-col">
              <span>{{ record.create_time }}</span>
              <span>{{ record.create_user }}</span>
            </div>
          </template>
          <template v-if="column.key === 'name'">
            <div>
              {{ record.name }}
              <label v-if="record.type === 2" class="team-label">团队</label>
            </div>
          </template>
          <template v-if="column.key === 'action'">
            <a-button type="link" @click="openCreateSopTaskDrawer(record)" style="padding-left: 0px"
              >调用</a-button
            >
            <a-button type="link" v-if="!state.navIndex && record.can_edit" @click="handleEdit(record, true)"
              >编辑</a-button
            >
            <a-button type="link" @click="openSopDetailDrawer(record)">查看</a-button>
            <a-popover
              placement="bottomLeft"
              v-model:visible="record.visible"
              class="popover-wraper"
              :getPopupContainer="
                (triggerNode) => {
                  return triggerNode.parentNode || document.body
                }
              "
            >
              <template #content>
                <p class="jz-pointer popover-p" @click="handleEdit(record, false)" v-if="record.can_copy">
                  复制
                </p>
                <p
                  class="jz-pointer popover-p"
                  v-if="state.navIndex && state.can_join"
                  @click="handelDelOrAdd(record.id)"
                >
                  加入我的模板
                </p>
                <p
                  class="jz-pointer popover-p"
                  v-if="record.can_delete && !state.navIndex"
                  @click="handleDel(record.id)"
                >
                  删除
                </p>
                <p class="jz-pointer popover-p" v-if="record.can_move" @click="handleCancel(record.id)">
                  {{ !state.navIndex ? '移出列表' : '移除模板' }}
                </p>
              </template>
              <svg-icon icon-name="task_pr" class="jz-pointer" />
            </a-popover>
          </template>
        </template>
        <template #emptyText>
          <div class="not-more jz-flex jz-flex-center jz-flex-col">
            <img src="@/assets/imgs/not_more.png" alt="" />
            <span>无内容</span>
          </div>
        </template>
      </a-table>
    </div>
    <div class="pagination-wrap jz-flex jz-flex-cc">
      <a-button :disabled="!state.selectedRowKeys.length" @click="handelDelOrAdd('')">{{
        !state.navIndex ? '批量删除/移除' : '批量加入我的模板'
      }}</a-button>
      <basic-pagination @change="pageChange" :params="state.paginationParams">
        <template #extra>
          <span class="page-total">共 {{ state.paginationParams.total }} 模板</span>
        </template>
      </basic-pagination>
    </div>
    <!--新建SOP模板-->
    <CreateSopTemDrawer :register="registerCreateSopTemDrawer" @success="getSopList" />
    <!--创建任务-->
    <createSopTaskDrawer :register="registerCreateSopTaskDrawer" @close="() => getCount()" />
    <!--任务列表-->
    <SopTaskListDrawer :register="registerSopTaskListDrawer" @close="() => getCount()" />
    <!--查看sop-->
    <SopDetailDrawer :register="registerSopDetailDrawer" />
  </div>
</template>

<script setup>
import dayjs from 'dayjs'
import { sopList, cancelCollect, addCollect, deleteCollect, batchDelete, getTaskCount } from '@/api/sop'
import { onMounted, reactive } from 'vue'
import { cloneDeep } from 'lodash-es'
import { useDrawer } from '@/components/basic/drawer'
import { getSopIndexColumns } from './columnsConfig'
import { getDeptTreeApi } from 'api/common'
import { Form } from 'ant-design-vue'
import useMessage from '@/composables/web/useMessage'
const { createMessage, createConfirm } = useMessage()
// ========================变量
const loading = ref(false)
const tabBox = ref(null)
const state = reactive({
  navIndex: 0,
  scrollY: 0,
  list: [],
  taskCount: 0,
  columns: getSopIndexColumns(),
  navs: ['我的模板', '团队模板'],
  selectedRowKeys: [],
  paginationParams: {
    total: 0,
    current: 1,
    showSizeChanger: false
  }
})
const deptTree = ref([])
// 抽屉配置
const [registerCreateSopTemDrawer, { openDrawer: openCreateSopTemDrawer }] = useDrawer()
const [registerCreateSopTaskDrawer, { openDrawer: openCreateSopTaskDrawer }] = useDrawer()
const [registerSopTaskListDrawer, { openDrawer: openSopTaskListDrawer }] = useDrawer()
const [registerSopDetailDrawer, { openDrawer: openSopDetailDrawer }] = useDrawer()

onMounted(() => {
  // 获取树结构
  getDeptTree()
  window.addEventListener('resize', getTableScrollY)
  // 获取tab滚动高度
  getTableScrollY()
  // 获取模板数据
  getSopList()
  // 获取任务数
  getCount()
})

const useForm = Form.useForm

// 表单
const form = reactive({
  name: '',
  time: [],
  dept_ids: []
})

const { resetFields } = useForm(form)

// watch==============================

watch(
  () => form,
  () => {
    state.paginationParams.current = 1
    const params = unref(getParams)
    getSopList(params)
  },
  {
    deep: true
  }
)

// computed=============================

// 获取表单参数
const getParams = computed(() => {
  const deepData = cloneDeep(form)
  return {
    ...deepData,
    type: state.navIndex + 1,
    page: state.paginationParams.current,
    limit: 10,
    dept_id: deepData.dept_ids ? deepData.dept_ids[deepData.dept_ids.length - 1] : null,
    create_time_start: deepData?.time?.length ? deepData?.time[0] : undefined,
    create_time_end: deepData?.time?.length ? deepData?.time[1] : undefined,
    time: undefined,
    dept_ids: undefined
  }
})

// methods=============================

// 获取任务数量
const getCount = async () => {
  let {
    data: { run }
  } = await getTaskCount()
  state.taskCount = run
}

// 编辑
const handleEdit = (item, isEdit = false) => {
  openCreateSopTemDrawer({ record: item, isEdit })
}

// 移除模板
const handleCancel = async (id) => {
  let { code } = await cancelCollect({ temp_ids: [id] })
  if (code === 1000) {
    createMessage.success('移除模板成功')
    getSopList()
  }
}

/**
 * @desc 删除模板
 * @param id 模板id
 */
const handleDel = (id) => {
  createConfirm({
    content: '是否确认删除？',
    async onOk() {
      let { code } = await deleteCollect({ temp_ids: [id] })
      if (code === 1000) {
        createMessage.success('删除模板成功')
        getSopList()
      }
    }
  })
}

/**
 * @desc 批量删除/移除
 */
const handelDelOrAdd = async (id = '') => {
  let params = {
    temp_ids: id ? [id] : state.selectedRowKeys
  }
  if (!state.navIndex) {
    createConfirm({
      content: '是否确认批量删除/移除？',
      async onOk() {
        let { code } = await batchDelete(params)
        if (code === 1000) {
          createMessage.success('操作成功')
          getSopList()
          state.selectedRowKeys = []
        }
      }
    })
  } else {
    await addCollect(params)
    createMessage.success('加入模板成功')
    getSopList()
    state.selectedRowKeys = []
  }
}

/**
 * @desc 获取模板数据
 */
const getSopList = async () => {
  loading.value = true
  const params = unref(getParams)
  let { code, data } = await sopList(params)
  if (code === 1000) {
    data.data.forEach((i) => (i.visible = false))
    state.list = data.data
    state.paginationParams.total = data.total
  }
  loading.value = false
}

/**
 * @desc 获取树结构
 */
const getDeptTree = async () => {
  let { code, data } = await getDeptTreeApi()
  if (code === 1000) {
    deptTree.value = data
  }
}

/**
 * @desc 获取滚动表格滚高
 */
const getTableScrollY = () => {
  nextTick(() => {
    state.scrollY = tabBox?.value.clientHeight - 54 ?? 400
  })
}

/**
 * @desc 切换模板
 * @param index 索引
 */
const changeNav = (index) => {
  state.navIndex = index
  state.paginationParams.current = 1
  state.list = []
  resetFields()
  state.selectedRowKeys = []
  nextTick(() => {
    getSopList()
  })
}

/**
 * @desc 切换分页
 * @param current 当前页码
 */
const pageChange = ({ current }) => {
  state.paginationParams.current = current
  getSopList()
}

/**
 * @desc 勾选表格
 * @param selectedRowKeys 已选数据
 */
const onSelectChange = (selectedRowKeys) => {
  state.selectedRowKeys = selectedRowKeys
}

onBeforeUnmount(() => {
  window.removeEventListener('resize', getTableScrollY)
})
</script>

<style lang="less" scoped>
#sop-wrapper {
  height: 100%;
  width: 100%;
  position: relative;
  padding: 32px 32px 0;
  background: #fff;
  font-size: 14px;
  .head {
    width: 100%;
    height: 60px;
    strong {
      font-size: 20px;
    }
    .ant-btn {
      margin-right: 8px;
      &:last-child {
        margin-right: 0;
      }
    }
  }
  .nav {
    height: 48px;
    position: relative;
    width: 100%;
    margin-bottom: 8px;
    &:after {
      position: absolute;
      left: 0;
      bottom: 0;
      right: 0;
      width: 100%;
      height: 1px;
      content: '';
      background-color: #eee;
      transform: scaleY(0.6);
    }
    ul {
      height: 100%;
      li {
        color: @font-minor-color;
        padding: 0 24px;
        position: relative;
        height: 48px;
        line-height: 48px;
        &.current {
          color: #3165f5;
        }
        &.current::after {
          content: '';
          width: 100%;
          height: 1px;
          display: block;
          margin: 0 auto;
          border-bottom: 2px solid #3165f5;
        }
        &:first-child {
          padding-left: 0px;
        }
      }
    }
  }
  .form {
    padding: 16px 0;

    .ant-form-item {
      width: 296px;
      margin-right: 16px;
      margin-bottom: 8px;
    }
  }
  .tip {
    color: #ed7b2f;
    margin-bottom: 12px;
    div {
      margin-left: 10px;
    }
  }
  .table-wrap {
    height: 100%;
    overflow: hidden;
    .ant-table-wrapper {
      overflow: hidden;
    }
  }
  .pagination-wrap {
    height: 64px;
    .page-total {
      color: #999;
    }
  }
}
.team-label {
  color: #06d1d1;
  font-size: 12px;
  line-height: 22px;
  text-align: center;
  padding: 3px 8px;
  display: inline-block;
  background: #e6fafa;
  border-radius: 4px 4px 4px 4px;
}

.popover-wraper {
  font-size: 14px;
}
.popover-p {
  height: 40px;
  line-height: 40px;
  margin-bottom: 0px;
  padding: 0 8px;
  width: 130px;
  &:hover {
    background: #f5f5f5;
  }
}
.not-more {
  img {
    width: 110px;
    height: 110px;
    margin-bottom: 4px;
  }
  span {
    font-size: 12px;
  }
}
.not-table {
  :deep(.ant-table-tbody > tr > td) {
    border: none;
  }
}

:deep(.ant-popover-inner) {
  border-radius: 6px;
}
:deep(.ant-popover-arrow) {
  width: 0px;
}
//:deep(.ant-popover-inner-content) {
//  padding: 8px !important;
//}
:deep(.ant-table-thead > tr > th) {
  color: @font-minor-color;
  border-bottom: none;
}
::-webkit-scrollbar {
  width: 0px;
  height: 0px;
}
:deep(.ant-table-thead
    > tr
    > th:not(:last-child):not(.ant-table-selection-column):not(.ant-table-row-expand-icon-cell):not([colspan])::before) {
  width: 0;
}
</style>
<style lang="less">
.sop-table {
  .ant-spin-nested-loading {
    .ant-spin-container {
      .ant-table {
        .ant-table-container {
          .ant-table-body {
            min-height: 300px;
          }
        }
      }
    }
  }
  .ant-table-tbody > tr.ant-table-row-selected > td {
    background: rgba(49, 101, 245, 0.04);
  }
  .ant-table-thead
    > tr
    > th:not(:last-child):not(.ant-table-selection-column):not(.ant-table-row-expand-icon-cell):not([colspan])::before {
    width: 0;
  }
}
</style>
