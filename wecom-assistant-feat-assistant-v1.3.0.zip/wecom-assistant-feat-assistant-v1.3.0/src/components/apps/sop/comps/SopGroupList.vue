<template>
  <div class="sop-customer-list jz-flex">
    <div class="form-box jz-flex jz-flex-dir-col">
      <a-form class="editor-form ant-form-small">
        <div class="ant-form-head jz-flex jz-flex-cc jz-flex-rb">
          <span class="wecom-title">筛选</span>
          <a-button type="link" :disabled="!isChangeForm" @click="() => clearFields()">清空筛选</a-button>
        </div>
        <a-form-item>
          <a-input
            class="keywork-search-input"
            v-model:value="form.keyword"
            allowClear
            placeholder="关键词筛选"
          >
            <template #suffix v-if="!form.keyword">
              <svg-icon icon-name="ic_search" />
            </template>
          </a-input>
        </a-form-item>
        <a-form-item>
          <a-select v-model:value="form.type" :options="state.typeList" placeholder="是否群主/群管理员" />
        </a-form-item>
        <a-form-item>
          <a-popover
            placement="bottom"
            trigger="click"
            v-model:visible="state.visible"
            class="popover-wraper"
            :getPopupContainer="
              (triggerNode) => {
                return triggerNode.parentNode || document.body
              }
            "
          >
            <template #content>
              <div class="count-box jz-flex jz-flex-col">
                <div class="count-input jz-flex jz-flex-center">
                  <a-input-number
                    v-model:value="state.min_count"
                    :min="1"
                    :max="100"
                    placeholder="最小值"
                    :controls="false"
                    style="width: 86px"
                  />
                  <span class="count-line">-</span>
                  <a-input-number
                    v-model:value="state.max_count"
                    :min="1"
                    :max="100"
                    placeholder="最大值"
                    :controls="false"
                    style="width: 86px"
                  />
                </div>
                <div class="count-btn jz-flex jz-flex-rr">
                  <a-button
                    type="primary"
                    :disabled="!(state.max_count && state.min_count)"
                    @click="handlegetGroupNum"
                    >确定
                  </a-button>
                </div>
              </div>
            </template>
            <a-input v-model:value="form.num" allowClear placeholder="群人数">
              <template #suffix>
                <down-outlined />
              </template>
            </a-input>
          </a-popover>
        </a-form-item>
        <a-form-item name="add_time">
          <a-range-picker
            v-model:value="form.add_time"
            value-format="YYYY-MM-DD"
            allowClear
            :ranges="{
              当天: [dayjs(), dayjs()],
              昨天: [dayjs().startOf('day').subtract(1, 'days'), dayjs().startOf('day').subtract(1, 'days')],
              最近3天: [dayjs().startOf('day').subtract(2, 'days'), dayjs()],
              最近7天: [dayjs().startOf('day').subtract(6, 'days'), dayjs()],
              最近30天: [dayjs().startOf('day').subtract(29, 'days'), dayjs()]
            }"
          />
        </a-form-item>
      </a-form>
    </div>
    <div class="list-box jz-flex jz-flex-dir-col" v-loading="state.loading">
      <div class="group-head jz-flex jz-flex-rb">
        <div class="jz-flex">
          <a-checkbox v-model:checked="state.allCheck" @change="handleChange" />
          <selectNum />
        </div>
        <div class="jz-flex jz-flex-1 jz-flex-rr">仅显示已选</div>
        <a-switch class="switch" v-model:checked="state.isSwitch" @change="changeSwitch" />
      </div>
      <div class="tip jz-flex jz-flex-cc">
        <exclamation-circle-filled style="color: #ed7b2f; font-size: 17px" />
        <div>仅展示群主或管理员的客户群。</div>
      </div>
      <ul
        v-infinite-scroll="getGroupList"
        :infinite-scroll-immediate-check="false"
        :infinite-scroll-disabled="state.isFinished"
        :infinite-scroll-watch-disabled="state.isFinished"
        :infinite-scroll-distance="10"
        class="jz-flex-1 group-wraper"
        v-if="state.list.length"
      >
        <li
          class="item jz-flex jz-flex-center"
          :class="{ 'item-selected': item.isCheck }"
          v-for="(item, index) in state.list"
          :key="index"
        >
          <a-checkbox v-model:checked="item.isCheck" @change="selectItem(item)" />
          <div class="jz-flex-1 jz-flex jz-flex-cc">
            <img :src="item.avatar" alt="" />
            <div class="jz-flex-1 jz-flex jz-flex-col">
              <span class="lineClamp1">{{ item.name }}</span>
              <span class="lineClamp1">群成员：{{ item.room_members }}</span>
            </div>
          </div>
        </li>
      </ul>
      <div class="not-more jz-flex jz-flex-col jz-flex-center jz-flex-1" v-else>
        <img src="@/assets/imgs/not_more.png" alt="" />
        <span>无内容</span>
      </div>
      <div class="group-footer">
        <a-button :disabled="state.list.filter((i) => i.isCheck).length === 0" @click="clearGroup"
          >清空已选</a-button
        >
      </div>
    </div>
  </div>
</template>

<script setup>
import dayjs from 'dayjs'
import { computed, defineExpose, reactive, unref } from 'vue'
import { Form } from 'ant-design-vue'
import { dictStore } from '@/store/modules/dict'
import { cloneDeep, debounce } from 'lodash-es'
import { searchGroup } from 'api/common'
import { customerStore } from '@/store/modules/customer'
const emit = defineEmits(['success'])

const state = reactive({
  loading: false,
  list: [],
  all_group_list: [],
  checked_group_list: [], // 已选数据
  count: 0,
  originCount: 0,

  allCheck: false,
  isSwitch: false,
  visible: false,
  min_count: '',
  max_count: '',
  typeList: [
    { label: '仅群主', value: 1 },
    { label: '仅群管理员', value: 2 },
    { label: '群主/群管理员', value: 3 },
    { label: '群成员', value: 4 }
  ]
})
const form = reactive({
  num: '',
  type: [],
  add_time: [],
  keyword: ''
})
const useForm = Form.useForm
const rulesRef = reactive({})
const { resetFields } = useForm(form, rulesRef)
const store = dictStore()
const store2 = customerStore()
store.tryFetchData()

const isChangeForm = computed(() =>
  Object.keys(form).some((key) =>
    Array.isArray(form[key])
      ? !!form[key].length
      : form[key] !== null && form[key] !== undefined && form[key] !== ''
  )
)
// 选择群人数
const handlegetGroupNum = () => {
  state.visible = false
  form.num = `${state.min_count},${state.max_count}`
}

//清除筛选表单数据
const clearFields = () => {
  resetFields()
  state.allCheck = false
  emit('success', [])
}

// 重置群数据
const resetGroup = () => {
  state.page = 1
  state.list = []
  state.count = 0
  store2.groupsCount = 0
  store2.groupsSelectCount = 0
  state.isFinished = false
  state.checked_group_list = []
  state.all_group_list = []
  state.isSwitch = false
}

// 搜索群列表
const querySearch = async (params) => {
  try {
    if (state.isFinished) return false
    state.loading = true
    const { data } = await searchGroup({ ...params, page: state.page || 1, limit: 20 })
    state.loading = false

    if (data.data.length) {
      let ids = state.all_group_list?.map((i) => i.id)
      let checkIds = state.checked_group_list?.map((i) => i.id)

      data.data.forEach((i) => {
        if (state.allCheck) {
          i.isCheck = true
        }
        if (!ids.includes(i.id)) {
          state.all_group_list.push(i)
        }
        if (!checkIds.includes(i.id) && i.isCheck) {
          state.checked_group_list.push(i)
        }
      })
      state.list = [...state.list, ...data.data]
      state.page += 1
    } else {
      state.list = []
      state.isFinished = true
    }
    if (data.total <= 20) {
      state.isFinished = true
    }
    state.count = +data.total
    state.originCount = +data.total
    store2.groupsCount = state.count
  } catch (error) {
    state.loading = false
  } finally {
    // selectedRows.value = []
  }
}
const debounceSearch = debounce(querySearch, 350)

// 获取群列表数据
const getGroupList = () => {
  const params = unref(getParams)
  debounceSearch(toRaw(params))
}

const handleChange = () => {
  state.list.forEach((i) => {
    i.isCheck = state.allCheck
  })
  if (state.allCheck) {
    state.checked_group_list = [...state.list]
    store2.groupsSelectCount = state.checked_group_list.length
  } else {
    state.checked_group_list = []
    store2.groupsSelectCount = 0
  }
  emit(
    'success',
    unref(state.checked_group_list).map((i) => i.id)
  )
}

const selectItem = (i) => {
  let index = unref(state.checked_group_list).findIndex((el) => el.id === i.id)
  if (~index) {
    unref(state.checked_group_list).splice(index, 1)
  } else {
    unref(state.checked_group_list).push(i)
  }
  let checkedNum = state.list.filter((i) => i.isCheck).length
  store2.groupsSelectCount = checkedNum
  state.allCheck = checkedNum === state.list.length
  emit(
    'success',
    unref(state.checked_group_list).map((i) => i.id)
  )
}

// 仅显示已选
const changeSwitch = (val) => {
  state.list = val ? [...state.checked_group_list] : state.all_group_list
}

//回显
const echoData = (data) => {
  clearGroup()
  state.checked_group_list.value = []
  let checkIds = data.map((i) => i.id)
  store2.groupsSelectCount = checkIds.length
  state.list.forEach((i) => {
    if (checkIds.includes(i.id)) {
      unref(state.checked_group_list).push(i)
      i.isCheck = true
    } else {
      i.isCheck = false
    }
  })
  state.isSwitch = store2.groupsSelectCount > 0 ? true : false
  state.list = store2.groupsSelectCount > 0 ? [...state.checked_group_list] : state.all_group_list
  state.page = 1
}

//清空已选
const clearGroup = () => {
  state.allCheck = false
  state.checked_group_list = []
  state.list.forEach((i) => (i.isCheck = false))
  state.list = state.all_group_list
  state.isSwitch = false
  store2.groupsSelectCount = 0
}

/**
 * computed属性
 * @type {ComputedRef<{[p: string]: *}>}
 */
const getParams = computed(() => {
  const deepData = cloneDeep(form)
  deepData.keyword = deepData.keyword === '' ? undefined : deepData.keyword
  if (deepData.add_time?.[1]) {
    deepData.add_time[1] += ' 23:59:59'
  }
  return {
    ...deepData,
    start_time: deepData?.add_time?.length ? dayjs(deepData.add_time[0])?.unix?.() : undefined,
    end_time: deepData?.add_time?.length ? dayjs(deepData.add_time[1])?.unix?.() : undefined,
    add_time: undefined,
    is_admin: 1,
    type: !Array.isArray(deepData.type) ? deepData.type : '',
    num: deepData.num.replace(/\-/g, ',')
  }
})

defineExpose({ clearFields, echoData, resetGroup })

onMounted(async () => {
  await getGroupList()
})

watch(
  () => form,
  async () => {
    await resetGroup()
    await getGroupList()
  },
  {
    deep: true
  }
)
</script>

<style lang="less" scoped>
.sop-customer-list {
  height: 100%;
  .form-box {
    position: relative;
    width: 257px;
    height: 100%;
    padding-right: 2px;
    &::after {
      content: '';
      position: absolute;
      right: 0;
      top: 0;
      bottom: 0;
      width: 1px;
      height: 100%;
      background-color: #eee;
      transform: scaleX(0.6);
    }
    .sop-exclude-box {
      height: 64px;
      font-size: 14px;
      color: #3165f5;
    }
    .editor-form {
      height: 100%;
      flex: 1;
      overflow: auto;
      padding: 0 16px 16px;
      //padding: 27px 16px 16px 16px;
      .ant-form-head {
        margin-bottom: 17px;
        padding-top: 27px;
        top: 0px;
        background-color: white;
        z-index: 2;
        position: sticky;
        .ant-btn-link {
          padding-right: 0px;
        }
      }
      .count-box {
        width: 100%;
        .count-line {
          margin: 0 8px;
        }
        .count-btn {
          margin-top: 28px;
        }
      }
    }
  }
  .list-box {
    flex: 1;
    height: 100%;
    width: 360px;
    .group-head {
      color: #999;
      padding: 0 16px 0 16px;
      margin-top: 32px;
      .switch {
        margin-left: 16px;
      }
    }
    .tip {
      margin: 12px 0 12px 24px;
      color: #ed7b2f;
      > div {
        margin-left: 9px;
      }
    }
    .group-wraper {
      overflow-y: auto;
      height: 100%;
      padding: 0 8px;
      // 修改滚动条
      &:hover {
        &::-webkit-scrollbar-thumb {
          visibility: visible;
        }
        .page-side-fold.is-expand {
          opacity: 1;
        }
      }
      &::-webkit-scrollbar {
        width: 2px;
      }
      &::-webkit-scrollbar-thumb {
        visibility: hidden;
        transition: all 0.28s;
      }
      .item {
        width: 100%;
        height: 54px;
        min-height: 54px;
        padding: 0 8px;
        cursor: pointer;
        &.item-selected {
          background: #ebf0fe !important;
        }
        > div {
          margin-left: 28px;
          img {
            width: 36px;
            height: 36px;
            border-radius: 8px;
            margin-right: 12px;
          }
          span:first-child {
            font-size: 14px;
          }
          span:last-child {
            font-size: 12px;
            color: #999999;
          }
        }
        &:hover {
          background: rgba(0, 0, 0, 0.02);
        }
      }
    }
    .not-more {
      width: 100%;
      img {
        width: 110px;
        height: 110px;
        display: block;
        margin-bottom: 4px;
      }
      span {
        font-size: 12px;
        color: #999;
      }
    }
    .group-footer {
      height: 64px;
      display: flex;
      justify-content: flex-end;
      align-items: center;
      padding-right: 16px;
    }
  }
}
:deep(.ant-popover-content) {
  width: 224px;
}
:deep(.ant-popover-inner-content) {
  padding: 16px 14px;
}
:deep(.ant-input-number-input) {
  text-align: center;
}
:deep(.ant-popover-arrow-content) {
  opacity: 0;
}
:deep(.ant-drawer-header) {
  padding: 32px 32px 0 32px;
}
</style>
