<template>
  <div class="sop-tabs">
    <a-tabs v-model:activeKey="state.activeKey" type="editable-card" hide-add @change="changTab">
      <a-tab-pane :closable="false" v-for="(item, index) in state.panes" :key="item.key">
        <template #tab>
          <span key="33">
            {{ item.title }}
            <SvgIcon
              icon-name="ic_gray_down"
              style="margin-left: 10px"
              class="icon-down"
              :data-id="index"
              @mouseenter="handleTabEnter"
              @mouseleave="handleTabLeave"
            />
          </span>
        </template>
        <div class="tab-content jz-flex jz-flex-1 jz-flex-col" style="height: 100%">
          <div class="time-wrapper jz-flex jz-flex-cc">
            <div class="day-box jz-flex jz-flex-cc">
              <span style="margin-right: 10px">第</span>
              <a-input-number
                :min="1"
                :max="99"
                :class="state.isRepeat && 'error-input'"
                style="width: 56px"
                v-model:value="item.data.day"
                @blur="handleAddDay(item.data.day, index)"
                @pressEnter="handleAddDay(item.data.day, index)"
              />
              <span style="margin-left: 10px; margin-right: 32px">天</span>
              <a-select
                v-model:value="item.data.type"
                :options="state.typeList"
                class="time-select"
                :disabled="item.data.type === 2 && item.data.day !== 1"
              />
              <a-time-range-picker
                v-model:value="item.data.time"
                popupClassName="sop-picker"
                @change="handleTime"
                v-if="item.data.type === 2"
              />
              <span style="color: #999; margin-left: 10px">此时间段内随机开始发送第一条</span>
              <div class="jz-flex jz-flex-1 jz-flex-rr">
                <a-button @click="openBatchTimeDrawer" :disabled="!item.data.content.length"
                  >批量设置时间间隔</a-button
                >
              </div>
              <div class="day-tip" v-if="state.isRepeat">{{ state.errDayMsg }}</div>
            </div>
          </div>
          <div class="msg-wrapper jz-flex jz-flex-1 jz-flex-col">
            <div>
              <draggable
                handle=".menu-handle"
                itemKey="uid"
                :component-data="{
                  tag: 'div',
                  type: 'transition-group',
                  name: !state.isDrag ? 'flip-list' : null
                }"
                v-model="modelRef.auto_message_config"
                v-bind="dragOptions"
                @start="state.isDrag = true"
                @end="state.isDrag = false"
              >
                <template #item="{ element: item, index }">
                  <div class="card-item-wrap jz-flex jz-flex-cc" :key="index">
                    <a-dropdown :trigger="['click']">
                      <a-tooltip title="长按拖拽 点击打开菜单">
                        <menu-outlined class="menu-handle" />
                      </a-tooltip>
                      <template #overlay>
                        <a-menu class="menu-list">
                          <a-menu-item
                            v-for="option in state.operateOptions"
                            :disabled="getDisableOperate(option, index)"
                            :key="option.icon"
                            @click="handleRemoveOperation(option, index)"
                          >
                            <div class="menu-item jz-flex jz-flex-cc" style="padding: 4px 0">
                              <svg-icon :icon-name="`ic_${option.icon}`" style="margin-right: 8px" />
                              <span>{{ option.label }}</span>
                            </div>
                          </a-menu-item>
                        </a-menu>
                      </template>
                    </a-dropdown>
                    <div class="card-item jz-flex">
                      <div class="card-num jz-flex jz-flex-center">{{ getMsgNumber(index) }}</div>
                      <div class="card-content">
                        <MessageCardWithType :item="item" :msgType="item.msg_type" />
                      </div>
                      <div class="card-extra jz-flex">
                        <div class="operate-btns jz-flex jz-flex-cc">
                          <UploadFile
                            :data="item"
                            v-if="isResMsg(item)"
                            class="jz-flex jz-flex-cc"
                            @change="(file) => handleSelectedFile({ file, item }, index, 'update')"
                          >
                            <a-tooltip title="编辑">
                              <svg-icon icon-name="ic_edit" />
                            </a-tooltip>
                          </UploadFile>
                          <a-tooltip title="编辑" v-else>
                            <SvgIcon icon-name="ic_edit" @click="handleCurdOperate('edit', item, index)" />
                          </a-tooltip>
                          <MessageTypeDropdown
                            :disabled="isUpperLimitWithType('addContent')"
                            @select="(item) => handleSelectMenu(item, index, 'insert')"
                            @select-file="(res) => handleSelectedFile(res, index, 'insert')"
                          >
                            <template #insert-item>
                              <p style="color: rgba(0, 0, 0, 0.4); padding: 8px 0 8px 8px">下方新增一条</p>
                            </template>
                            <template #adduction>
                              <SvgIcon icon-name="ic_add" />
                            </template>
                          </MessageTypeDropdown>
                          <a-tooltip title="删除">
                            <SvgIcon
                              icon-name="ic_delete"
                              @click="handleCurdOperate('delete', item, index)"
                            />
                          </a-tooltip>
                        </div>
                        <div class="time-bar jz-flex jz-flex-cc">
                          <span>停留时间</span>
                          <a-input-number v-model:value="item.wait" :min="0" :max="999" class="time-input">
                            <template #addonAfter>
                              <api-select v-model:value="item.time_type" :options="state.timeOptions" style="width: 60px" />
                            </template>
                          </a-input-number>
                        </div>
                      </div>
                    </div>
                  </div>
                </template>
              </draggable>
            </div>
            <div class="add-content jz-flex jz-flex-cc">
              <MessageTypeDropdown
                :disabled="isUpperLimitWithType('addContent')"
                :menus="menus"
                @select="handleSelectMenu"
                @select-file="handleSelectedFile"
              >
                <template #adduction>
                  <div class="jz-flex jz-flex-cc">
                    <plus-circle-filled class="add-icon" />
                    <a-button type="link">添加内容</a-button>
                  </div>
                </template>
              </MessageTypeDropdown>
              <span class="desc">{{ modelRef.auto_message_config?.length || 0 }}/20</span>
            </div>
          </div>
        </div>
      </a-tab-pane>

      <template #rightExtra>
        <div class="tab-right-box jz-flex jz-flex-center">
          <a-tooltip placement="top">
            <template #title>
              <span>新增天数</span>
            </template>
            <span class="back-btn jz-flex jz-flex-center jz-pointer" @click="closeDrawer">
              <SvgIcon icon-name="add" class="add-btn" @click="handleAddTabs(false)" />
            </span>
          </a-tooltip>
        </div>
      </template>
      <template #moreIcon>
        <SvgIcon icon-name="jz_more" />
      </template>
    </a-tabs>
    <ul
      class="self-tip jz-flex jz-flex-col"
      ref="tipBox"
      v-if="state.showTip"
      @mouseleave="state.showTip = false"
    >
      <li class="jz-flex jz-flex-cc jz-flex-1" @click="handleAddTabs(true)">复制并新增 1 天</li>
      <li class="jz-flex jz-flex-cc jz-flex-1" @click="handleDelDay">删除</li>
    </ul>
    <EditorTextModal ref="textRef" @success="handleMsgMoadlCallback" :msgTags="state.msgTags" />
    <EditorLinkModal ref="linkRef" @success="handleMsgMoadlCallback" />
    <EditorResourceModal ref="resRef" @success="handleMsgMoadlCallback" />
    <EditorMAcementModal ref="acement" @success="handleMsgMoadlCallback" />
    <EditorGroupModal ref="invite" @success="handleGroupCallback" />
    <EditorMediaModal
      :media_length="modelRef.auto_message_config?.length || 0"
      ref="mediaRef"
      @success="handleMediaMoadCallback"
    />
    <!--批量修好时间间隔-->
    <UpdateBatchTimeDrawer :register="batchTimeDrawer" @success="updateWaitTime" />
  </div>
</template>

<script setup>
import dayjs from 'dayjs'
import { MessageTypeEnum } from '@/enums/MessageTypeEnum'
import draggable from 'vuedraggable'
import { cloneDeep } from 'lodash-es'
import { useDrawer } from '@/components/basic/drawer'
import { onMounted, onUnmounted, reactive, toRaw } from 'vue'
import { uploadFile, uploadImage, uploadVideo } from '@/api/common'
import useMessage from '@/composables/web/useMessage'
import { isWechatMsg, isResMsg } from '../../customerOperationManager/copms/popover/utils'
const MAX_DAY_NUM = 10 // 最大添加天数
const { createMessage, createConfirm } = useMessage()
const [batchTimeDrawer, { openDrawer: openBatchTimeDrawer }] = useDrawer()
const tipBox = ref(null)
const N_Y_R = `${new Date().getFullYear()}-${new Date().getMonth() + 1}-${new Date().getDate()}`
const menus = ref([
  {
    label: '群公告',
    icon: 'acement',
    key: MessageTypeEnum.acement
  },
  {
    label: '群邀请',
    icon: 'invite',
    key: MessageTypeEnum.invite
  }
])
const state = reactive({
  isRepeat: false,
  mouseKey: null,
  isDrag: false,
  showTip: false,
  activeKey: 1,
  errDayMsg: '',
  start_y: 0,
  end_y: 0,
  panes: [
    {
      num: 1,
      title: '第 1 天',
      key: 1,
      data: {
        day: 1,
        type: 1,
        time: [dayjs(`${N_Y_R} 08:00:00`), dayjs(`${N_Y_R} 10:00:00`)],
        start_time: '08:00:00',
        end_time: '10:00:00',
        content: []
      }
    }
  ],
  typeList: [
    { label: '时间段随机发送', value: 2 },
    { label: '立即发送', value: 1 }
  ],
  form: {
    auto_message_config: []
  },
  timeOptions: [
    { label: '秒', value: 1 },
    { label: '分', value: 2 },
    { label: '时', value: 3 }
  ],
  operateOptions: [
    { label: '置顶', icon: 'top', key: 1 },
    { label: '上移一条', icon: 'up', key: 2 },
    { label: '下移一条', icon: 'down', key: 3 },
    { label: '置底', icon: 'bottom', key: 4 }
  ]
})

const textRef = ref()
const linkRef = ref()
const resRef = ref()
const mediaRef = ref()
const acement = ref()
const invite = ref()
const modelRef = toRef(state, 'form')

watch(
  () => state.form.auto_message_config,
  (val) => {
    if (state.panes[state.activeKey - 1]) {
      state.panes[state.activeKey - 1].data.content = toRaw(cloneDeep(val))
    }
  },
  {
    deep: true
  }
)

onMounted(() => {
  document.body.addEventListener('click', handleTip)
})

// 重置数据
const resetPre = () => {
  state.activeKey = 1
  state.mouseKey = null
  state.isRepeat = false
  state.panes = [
    {
      num: 1,
      title: '第 1 天',
      key: 1,
      data: {
        day: 1,
        type: 1,
        time: [dayjs(`${N_Y_R} 08:00:00`), dayjs(`${N_Y_R} 10:00:00`)],
        start_time: '08:00:00',
        end_time: '10:00:00',
        content: []
      }
    }
  ]
  unref(modelRef).auto_message_config = []
}

// 更新停留时间
const updateWaitTime = (tConfing) => {
  state.panes.forEach((i) => {
    i.data.content.forEach((cel) => {
      if (tConfing.range === 2) {
        cel.wait = tConfing.time
        cel.time_type = tConfing.type
      }
    })
  })
  unref(modelRef).auto_message_config.forEach((mel) => {
    mel.wait = tConfing.time
    mel.time_type = tConfing.type
  })
}

// 编辑回填数据
const setPre = (res) => {
  let arr = []
  res.forEach((i) => {
    i.num = i.day
    i.title = `第 ${i.day} 天`
    i.key = i.day
    i.data = {}
    i.data.day = i.day
    i.data.type = i.type
    i.data.time = [dayjs(`${N_Y_R} ${i.start_time}`), dayjs(`${N_Y_R} ${i.end_time}`)]
    i.data.start_time = i.start_time
    i.data.end_time = i.end_time
    i.data.content = i.content
    arr.push(i)
  })
  state.panes = cloneDeep(arr)
  unref(modelRef).auto_message_config = state.panes[0].data.content
  state.activeKey = state.panes[0].key
}

/**
 * @desc 修改天数
 * @param val 需要修改的天数
 */
const handleAddDay = (val, index) => {
  let nums = state.panes.map((i) => i.num)
  if (!val || val > 99 || nums.includes(val)) {
    state.isRepeat = true
    state.errDayMsg = !val
      ? '天数不能为空'
      : val > 99
      ? '天数不能大于99'
      : state.panes[index].num !== val
      ? '已存在的天数不能重复'
      : ''
  } else {
    state.isRepeat = false
    nums.push(val)
    nums.sort((x, y) => x - y)
    let _addIndex = nums.findIndex((i) => i === val)
    let _delIndex = state.panes.findIndex((i) => i.key === +state.activeKey)
    let _item = cloneDeep(state.panes[_delIndex === -1 ? 0 : _delIndex])
    _item.num = val
    _item.title = `第 ${val} 天`
    _item.key = val
    _item.data.type = val !== 1 ? 2 : _item.data.type
    state.panes.splice(_delIndex, 1)
    state.panes.splice(_addIndex, 0, _item)
    state.activeKey = _item.key
    unref(modelRef).auto_message_config = _item.data.content
    setTimeout(() => {
      state.isRepeat = false
      state.errDayMsg = ''
    }, 100)
  }
  if (state.panes[index].num === val) {
    state.isRepeat = false
  }
}

/**
 * @desc 切换tab
 */
const changTab = () => {
  let index = state.panes.findIndex((i) => i.key === +state.activeKey)
  unref(modelRef).auto_message_config = state.panes[index].data.content
  state.isRepeat = !(state.panes[index].num === state.panes[index].data.day)
}

/**
 * @desc 更新时间
 */
const handleTime = (val) => {
  let index = state.panes.findIndex((i) => i.key === +state.activeKey)
  state.panes[index].data.start_time = val ? dayjs(val[0])?.format?.('HH:mm:ss') : undefined
  state.panes[index].data.end_time = val ? dayjs(val[1])?.format?.('HH:mm:ss') : undefined
}

/**
 * @desc 删除天数
 */
const handleDelDay = () => {
  if (state.panes.length <= 1) {
    createMessage.warn('至少保留一天')
    return
  }
  createConfirm({
    cancelText: '取消',
    okText: '确定',
    content: '是否确定删除',
    async onOk() {
      // 调用清空接口
      state.panes.splice(+state.mouseKey, 1)
      if (+state.mouseKey) {
        unref(modelRef).auto_message_config = state.panes[state.mouseKey - 1].data.content
        state.activeKey = state.panes[state.mouseKey - 1].key
      } else {
        unref(modelRef).auto_message_config = state.panes[0].data.content
        state.activeKey = state.panes[0].key
      }
    }
  })
}

/**
 * @desc 隐藏tip
 */
const handleTip = () => {
  state.showTip = false
}

const handleTabLeave = (e) => {
  state.end_y = e.pageY - 3
  if (state.end_y <= state.start_y) {
    state.showTip = false
  }
}

/**
 * @desc 获取tab位置信息
 */
const handleTabEnter = (e) => {
  state.start_y = e.pageY
  state.mouseKey = e.target?.getAttribute('data-id') ?? null
  state.showTip = true
  nextTick(() => {
    let { x, y } = e?.target.getBoundingClientRect()
    tipBox.value.style = `left:${x - 160}px;top:${y - 28}px`
  })
}

/**
 * @desc 添加tab
 * @param isCopy 是否是复制天数
 */
const handleAddTabs = (isCopy = false) => {
  if (state.panes[state.panes.length - 1].num >= 99) {
    createMessage.info('最大只能设置第99天请修改天数后再增加')
    return
  }
  if (state.isRepeat) {
    createMessage.info('请先设置正确的天数再添加')
    return
  }
  if (state.panes.length >= MAX_DAY_NUM) {
    createMessage.info(`最多只能添加${MAX_DAY_NUM}天`)
    return
  }
  let data = {}
  let _defObj = {
    day: state.panes[state.panes.length - 1].num + 1,
    type: 2,
    time: [dayjs(`${N_Y_R} 08:00:00`), dayjs(`${N_Y_R} 10:00:00`)],
    start_time: '08:00:00',
    end_time: '10:00:00',
    content: []
  }

  if (!isCopy) {
    data = _defObj
  } else {
    data = {
      ...cloneDeep(state.panes[+state.mouseKey].data),
      day: state.panes[state.panes.length - 1].num + 1,
      type: 2
    }
  }
  state.panes.push({
    num: state.panes[state.panes.length - 1].num + 1,
    title: `第 ${state.panes[state.panes.length - 1].num + 1} 天`,
    key: state.panes[state.panes.length - 1].num + 1,
    data
  })
  state.activeKey = state.panes[state.panes.length - 1].num
  unref(modelRef).auto_message_config = isCopy ? state.panes[+state.mouseKey].data.content : []
}

// 群邀请回调
const handleGroupCallback = (item) => {
  if (item.isUpdate && ~currMessageItemIndex.value) {
    unref(modelRef).auto_message_config[unref(currMessageItemIndex)] = item
  } else {
    unref(modelRef).auto_message_config.push(item)
  }
  currMessageItemIndex.value = -1
}

// 消息=========================start

// 上限判断
const isUpperLimitWithType = (type) => {
  if (type === 'addContent') {
    return unref(modelRef).auto_message_config?.length >= 20
  }
}

// 添加消息内容
const handleSelectMenu = (item, index, operType) => {
  let { icon: type } = item
  currMessageItemIndex.value = index
  handleOpenMsgModal(type, item, false, operType)
}

//素材库信息
const handleMediaMoadCallback = (data) => {
  for (let item of data) {
    unref(modelRef).auto_message_config.push(item)
  }
  createMessage.success('导入成功')
}

// 保存消息成功回调处理
const handleMsgMoadlCallback = (_, { isUpdate, data, operType }) => {
  if (Array.isArray(data)) {
    let textList = data.map((row) => ({ ...row, wait: row.wait || 10, time_type: row.time_type || 1 }))
    if (operType === 'insert') {
      unref(modelRef).auto_message_config.splice(currMessageItemIndex.value + 1, 0, ...textList)
    } else {
      unref(modelRef).auto_message_config.push(...textList)
    }
    return
  }
  const params = {
    ...data,
    wait: data.wait || 10,
    time_type: data.time_type || 1
  }
  if (isUpdate && ~currMessageItemIndex.value) {
    unref(modelRef).auto_message_config[unref(currMessageItemIndex)] = params
  } else {
    if (operType === 'insert') {
      unref(modelRef).auto_message_config.splice(currMessageItemIndex.value + 1, 0, params)
    } else {
      unref(modelRef).auto_message_config.push(params)
    }
  }
  currMessageItemIndex.value = -1
}

// 拖动动效
const dragOptions = ref({
  animation: 200,
  disabled: false,
  ghostClass: 'ghost'
})

const currMessageItemIndex = ref(-1)

// 删除/修改操作
const handleCurdOperate = (operType, item, index) => {
  let { msg_type } = item
  currMessageItemIndex.value = index
  switch (operType) {
    case 'edit':
      handleOpenMsgModal(MessageTypeEnum[msg_type], item, true)
      break
    case 'delete':
      unref(modelRef).auto_message_config.splice(index, 1)
      break
  }
}

const handleOpenMsgModal = (type, item = {}, isUpdate, operType) => {
  const { key, msg_type } = item
  switch (type) {
    case 'invite':
      invite.value.openModal({
        isUpdate,
        operType,
        data: cloneDeep(item)
      })
      break
    case 'acement':
      acement.value.openModal({
        isUpdate,
        operType,
        data: cloneDeep(item)
      })
      break
    case 'media':
      mediaRef.value.openModal({
        isUpdate,
        operType,
        data: cloneDeep(item)
      })
      break
    case 'text':
      textRef.value.openModal({
        isUpdate,
        operType,
        data: cloneDeep(item)
      })
      break
    case 'link':
      linkRef.value.openModal({
        isUpdate,
        operType,
        data: cloneDeep(item)
      })
      break
    default:
      if (isWechatMsg(item)) {
        resRef.value.openModal({
          isUpdate,
          operType,
          title: item.label,
          data: {
            ...cloneDeep(item),
            msg_type: key || msg_type
          }
        })
      }
      break
  }
}

// 上传图片/文件/文档
const handleSelectedFile = async ({ file, item: { key, msg_type } }, updateIndex, operType) => {
  key = key ?? msg_type
  if (file) {
    let index = -1
    if (updateIndex !== undefined && updateIndex > -1) {
      if (operType !== 'insert') {
        const editItem = unref(modelRef).auto_message_config[updateIndex]
        if (editItem) {
          editItem.msg.url = ''
          editItem.msg.name = file.name
          editItem.uploading = true
        }
      }
      index = operType === 'insert' ? updateIndex + 1 : updateIndex
    } else {
      index = unref(modelRef).auto_message_config.push(addNewMsg()) - 1
    }
    try {
      const uploadRequest =
        key === MessageTypeEnum.image ? uploadImage : key === MessageTypeEnum.video ? uploadVideo : uploadFile
      const { data } = await uploadRequest({ file })
      if (operType === 'insert') {
        unref(modelRef).auto_message_config.splice(index, 0, addNewMsg())
      } else {
        unref(modelRef).auto_message_config[index].msg.url = data.url
      }
      createMessage.success('上传成功')
    } catch (err) {
      unref(modelRef).auto_message_config.splice(index, 1)
    } finally {
      unref(modelRef).auto_message_config[index].uploading = false
    }
  }

  function addNewMsg() {
    return {
      msg_type: key,
      wait: 10,
      time_type: 1,
      msg: {
        name: file.name,
        url: ''
      },
      uploading: true
    }
  }
}

const getMsgNumber = (index) => {
  return +index + 1 < 10 ? `0${index + 1}` : index + 1
}

const getDisableOperate = (item, index) => {
  let { icon: key } = item
  let isDisabled = false
  switch (key) {
    case 'top':
    case 'up':
      isDisabled = index === 0
      break
    case 'bottom':
    case 'down':
      isDisabled = index === unref(modelRef).auto_message_config.length - 1
      break
  }
  return isDisabled
}

// 移动操作
const handleRemoveOperation = (item, index) => {
  let isDisabled = getDisableOperate(item, index)
  if (isDisabled) return

  const { icon: key } = item
  const [removeItem] = unref(modelRef).auto_message_config.splice(index, 1)
  switch (key) {
    case 'top':
    case 'bottom':
      unref(modelRef).auto_message_config[key === 'top' ? 'unshift' : 'push'](removeItem)
      break
    case 'up':
    case 'down':
      let idx = key === 'up' ? index - 1 : index + 1
      unref(modelRef).auto_message_config.splice(idx, 0, removeItem)
      break
  }
}

// 获取消息信息
const getPre = () => {
  return toRaw(state.panes)
}

// 消息=========================end

onUnmounted(() => {
  document.body.removeEventListener('click', handleTip)
})

defineExpose({
  getPre,
  setPre,
  resetPre
})
</script>

<style lang="less" scoped>
.self-tip {
  position: fixed;
  width: 155px;
  height: 96px;
  padding: 8px;
  z-index: 10;
  border-radius: 6px;
  background: #ffffff;
  box-shadow: 0px 0px 20px 0px rgba(0, 0, 0, 0.08);
  li {
    cursor: pointer;
    font-size: 14px;
    padding-left: 8px;
    &:hover {
      background: #f3f3f3;
    }
  }
}

.msg-wrapper {
  width: 100%;
  height: 100%;
  padding-right: 32px;
  .card-item-wrap {
    width: 100%;
    &:hover {
      .card-item .card-extra .operate-btns {
        visibility: visible;
        .svg-icon {
          width: 24px !important;
          height: 24px !important;
          padding: 4px;
          &:hover {
            background: rgba(0, 0, 0, 0.04);
            border-radius: 4px;
          }
        }
      }
      :deep(.anticon-menu) {
        visibility: visible;
      }
    }
    :deep(.anticon-menu) {
      margin-right: 12px;
      padding-top: 3px;
      visibility: hidden;
      :hover {
        color: @primary-color;
      }
    }
    .card-item {
      flex: auto;
      min-height: 56px;
      padding: 12px;
      background: rgba(0, 0, 0, 0.04);
      border-radius: 6px;
      box-sizing: border-box;
      .card-num {
        width: 24px;
        height: 24px;
        align-items: center;
        border-radius: 50%;
        background: #eeeeee;
        color: #000000;
        font-size: 12px;
        margin-right: 16px;
      }
      .card-content {
        flex: auto;
      }

      .card-extra {
        flex: none;
        display: flex;
        align-items: flex-start;
        .operate-btns {
          height: 32px;
          visibility: hidden;
          > * {
            margin-right: 16px;
            cursor: pointer;
          }
        }
        .time-bar {
          > span {
            margin-right: 12px;
            color: rgba(0, 0, 0, 0.4);
          }
          .time-input {
            :deep(.ant-input-number-input-wrap) {
              width: 56px;
            }
            :deep(.ant-select-selector) {
              width: 56px;
            }
          }
        }
      }
    }
    + .card-item-wrap {
      margin-top: 12px;
    }
    + .add-content {
      margin-top: 16px;
    }
  }
  .add-content {
    .add-icon {
      font-size: 16px;
      color: @primary-color;
    }
    .decs {
      margin-left: 8px;
      color: rgba(0, 0, 0, 0.4);
    }
  }
}
.sop-tabs {
  width: 100%;
  height: 100%;
  flex: 1;
}
.type-select {
  width: 208px;
}
.tab-right-box {
  height: 48px;
  margin-left: 8px;
  padding-right: 28px;
  .svg-icon {
    cursor: pointer;
    width: 20px !important;
    height: 20px !important;
  }
  .add-btn {
    &:hover {
      background: #f5f5f5;
    }
  }
}
.day-box {
  height: 64px;
  width: 100%;
  padding-right: 32px;
  position: relative;
  .day-wrap {
    position: relative;
  }
  .day-tip {
    position: absolute;
    bottom: -6px;
    color: #f23944;
  }
}
.icon-down {
  display: none;
}

:deep(.ant-picker) {
  width: 230px;
  margin-left: 16px;
}
.ant-picker-range-arrow::after {
  width: 0px;
}
.time-select {
  :deep(.ant-select-selector) {
    width: 208px;
  }
}

.error-input {
  color: #f23944;
  border: 1px solid #f23944;
}

:deep(.ant-picker-range-arrow::after) {
  width: 0px;
}
:deep(.ant-tabs-top > .ant-tabs-nav) {
  margin: 0 0 8px 0;
}
:deep(.ant-tabs) {
  height: 100%;
  display: flex;
  flex-direction: column;
}
:deep(.ant-tabs-content) {
  height: 100%;
  overflow: hidden;
}
:deep(.ant-tabs-tabpane) {
  height: 100%;
  overflow: hidden;
}
:deep(.ant-popover-content) {
  margin-bottom: 0px;
}
:deep(.ant-popover-inner-content) {
  padding: 0;
}
:deep(.ant-popover-arrow) {
  width: 0px;
}
:deep(.ant-popover) {
  width: 155px;
}
:deep(.ant-tabs-tab-btn > span > .icon-down) {
  display: inline-block;
  &:hover {
    background: #f5f5f5;
  }
}
:deep(.ant-tabs > .ant-tabs-nav .ant-tabs-nav-more) {
  cursor: pointer;
}
:deep(.ant-tabs-card > .ant-tabs-nav .ant-tabs-tab) {
  background: #fff;
}
:deep(.ant-tabs-card.ant-tabs-top > .ant-tabs-nav .ant-tabs-tab) {
  border: none;
  width: 102px;
  padding: 0;
  height: 47px;
  display: flex;
  justify-content: center;
  align-items: center;
  position: relative;
  &::after {
    height: 40%;
    width: 1px;
    background-color: #eee;
    transform: scaleX(0.6);
    position: absolute;
    bottom: 0;
    right: 0;
    top: 35%;
    content: '';
  }
}

:deep(.ant-tabs-tab-active) {
  &::before {
    position: absolute;
    width: 77%;
    left: 50%;
    content: '';
    height: 2px;
    margin-left: -40px;
    bottom: 0;
    background: #3165f5;
  }
}
</style>

<style lang="less">
.sop-picker {
  .ant-picker-range-wrapper {
    .ant-picker-range-arrow {
      width: 0px;
    }
  }
}
</style>
