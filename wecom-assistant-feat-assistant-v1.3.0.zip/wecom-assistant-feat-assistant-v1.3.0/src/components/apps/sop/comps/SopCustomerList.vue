<template>
  <div class="sop-customer-list jz-flex">
    <div class="form-box jz-flex jz-flex-dir-col">
      <a-form class="editor-form ant-form-small">
        <div class="ant-form-head jz-flex jz-flex-cc jz-flex-rb">
          <span class="wecom-title">筛选</span>
          <a-button type="link" :disabled="!isChangeForm" @click="() => clearFields()">清空筛选</a-button>
        </div>
        <a-form-item v-bind="validateInfos.keyword">
          <a-input
            class="keywork-search-input"
            v-model:value="form.keyword"
            allowClear
            placeholder="关键词筛选"
          >
            <template #suffix v-if="!form.keyword">
              <svg-icon icon-name="ic_search" />
            </template>
          </a-input>
        </a-form-item>
        <a-form-item v-bind="validateInfos.label_options">
          <CustomTagPopover
            is-search
            needCheckGroup
            :isReset="isReset"
            :data="{ label_id: form.label_ids }"
            @select-change="handleSelectedTag"
          >
            <span>
              <rich-input
                v-model:value="form.label_options"
                tagMode
                :allowInput="false"
                allowClear
                placeholder="标签"
                :setTagClass="
                  (item) =>
                    item?.type ? (item.type === 2 ? 'ant-tag-personal' : 'ant-tag-primary') : 'ant-tag-plain'
                "
              >
                <template #prefix>
                  <span>{{ label_type_name }}</span>
                </template>
                <template #suffix>
                  <down-outlined />
                </template>
              </rich-input>
            </span>
          </CustomTagPopover>
        </a-form-item>
        <a-form-item name="add_time" v-bind="validateInfos.add_time">
          <a-range-picker
            v-model:value="form.add_time"
            value-format="YYYY-MM-DD"
            allowClear
            :ranges="{
              当天: [dayjs(), dayjs()],
              昨天: [dayjs().startOf('day').subtract(1, 'days'), dayjs().startOf('day').subtract(1, 'days')],
              最近3天: [dayjs().startOf('day').subtract(2, 'days'), dayjs()],
              最近7天: [dayjs().startOf('day').subtract(6, 'days'), dayjs()],
              最近30天: [dayjs().startOf('day').subtract(29, 'days'), dayjs()]
            }"
          />
        </a-form-item>
        <a-form-item v-bind="validateInfos.group_type_text">
          <GroupTypePopover
            v-model:item="form.group_ids"
            :isReset="isReset"
            @onChange="handleGroupTypeChange"
          >
            <a-input
              class="ant-input-ellipsis"
              v-model:value="form.group_type_text"
              allowClear
              :readonly="true"
              placeholder="按群查询"
            >
              <template #prefix v-if="groupTypeObj.label">
                <label>{{ groupTypeObj.label }}</label>
              </template>
              <template #suffix>
                <div class="ant-select-arrow">
                  <down-outlined />
                </div>
              </template>
            </a-input>
          </GroupTypePopover>
        </a-form-item>
        <a-form-item v-bind="validateInfos.is_remark">
          <api-select
            v-model:value="form.is_remark"
            allowClear
            :options="dictMap.is_remark"
            :replaceFields="dictFields"
            placeholder="有无企微备注"
          />
        </a-form-item>
        <a-form-item v-bind="validateInfos.is_name">
          <api-select
            v-model:value="form.is_name"
            allowClear
            :options="dictMap.is_name"
            :replaceFields="dictFields"
            placeholder="有无称呼"
          />
        </a-form-item>
        <a-form-item v-bind="validateInfos.sex">
          <api-select
            v-model:value="form.sex"
            allowClear
            :options="dictMap.sex"
            :replaceFields="dictFields"
            placeholder="性别"
          />
        </a-form-item>
        <a-form-item v-bind="validateInfos.source">
          <api-select
            v-model:value="form.source"
            allowClear
            :options="dictMap.source"
            :replaceFields="dictFields"
            placeholder="来源"
          />
        </a-form-item>
        <a-form-item v-bind="validateInfos.friend_status">
          <api-select
            v-model:value="form.friend_status"
            allowClear
            :options="dictMap.friend_status"
            :replaceFields="dictFields"
            placeholder="好友关系"
          />
        </a-form-item>
        <a-form-item v-bind="validateInfos.wx_type">
          <api-select
            v-model:value="form.wx_type"
            allowClear
            :options="dictMap.wx_type"
            :replaceFields="dictFields"
            placeholder="微信类型"
          />
        </a-form-item>
        <a-form-item v-bind="validateInfos.is_friend_add">
          <api-select
            v-model:value="form.is_friend_add"
            allowClear
            :options="dictMap.is_friend_add"
            :replaceFields="dictFields"
            placeholder="是否主动加好友"
          />
        </a-form-item>

        <div class="ant-form-head jz-flex jz-flex-rb">
          <span class="wecom-title">学员筛选</span>
        </div>
        <a-form-item v-bind="validateInfos.user_ids">
          <api-select
            class="user-select"
            v-model:value="form.user_ids"
            rowKey="user_id"
            :api="searchUser"
            allowClear
            remote-search
            placeholder="用户ID/手机号"
            :params="(name) => ({ name })"
          >
            <template #option="{ item }">
              <div class="user-option jz-flex jz-flex-cc">
                <img class="img" :src="item.avatar" v-if="item.avatar" />
                <div class="item-content">
                  <span>{{ item.nickname }}</span>
                  <p>{{ item.mobile }}</p>
                </div>
              </div>
            </template>
            <template #suffix>
              <search-outlined />
            </template>
          </api-select>
        </a-form-item>
        <a-form-item v-bind="validateInfos.project_id">
          <api-select
            v-model:value="form.project_id"
            allowClear
            filterOption
            :show-search="true"
            resultField="data.list"
            :replaceFields="replaceFields"
            :api="queryProductList"
            placeholder="项目"
          />
        </a-form-item>
        <a-form-item v-bind="validateInfos.camp_id">
          <api-select
            v-model:value="form.camp_id"
            immediate
            allowClear
            remote-search
            :api="searchCamp"
            autoClearMismatchValue
            :params="(name) => ({ name, project_id: form.project_id, flag: 1 })"
            :replaceFields="replaceFields"
            placeholder="课程ID/名称"
          />
        </a-form-item>
        <a-form-item v-bind="validateInfos.term">
          <api-select
            v-model:value="form.term"
            :disabled="!form.camp_id"
            allowClear
            mode="multiple"
            :api="searchTerm"
            placeholder="期数"
            autoClearMismatchValue
            :replaceFields="{ value: 'tm' }"
            :params="{ camp_id: form.camp_id }"
          >
            <template #option="{ item }">
              {{ formatDate(item.t) }}
            </template>
          </api-select>
        </a-form-item>
        <a-form-item v-bind="validateInfos.is_phone">
          <api-select
            v-model:value="form.is_phone"
            allowClear
            :options="dictMap.is_phone"
            :replaceFields="dictFields"
            placeholder="有无绑定手机"
          />
        </a-form-item>
        <a-form-item v-bind="validateInfos.app">
          <api-select
            v-model:value="form.app"
            :options="dictMap.app"
            :replaceFields="dictFields"
            placeholder="有无App"
            allowClear
          />
        </a-form-item>
      </a-form>
      <div class="sop-exclude-box jz-flex jz-flex-center jz-pointer" @click.stop.prevent="handleOpenSider()">
        设置排除条件 （{{ exclude_count }}）
        <SvgIcon :icon-name="excludeCollapsed ? 'arrow_right' : 'arrow_left'" />
      </div>
    </div>

    <div
      v-click-outside="handleOpenSider2"
      class="exclude-form"
      :style="{
        left: excludeCollapsed ? '0px' : '257px'
      }"
    >
      <ExcludeForm :isParentNode="true" ref="ExcludeFormRef" @excludeChange="excludeChange" />
    </div>

    <div class="list-box jz-flex jz-flex-dir-col" v-loading="state.loading">
      <div class="group-head jz-flex jz-flex-rb">
        <div class="jz-flex">
          <a-checkbox v-model:checked="state.allCheck" @change="handleChange" />
          <selectNum />
        </div>
        <div class="jz-flex jz-flex-1 jz-flex-rr">仅显示已选</div>
        <a-switch class="switch" v-model:checked="state.isSwitch" @change="changeSwitch" />
      </div>

      <ul
        class="jz-flex-1 group-wraper"
        v-infinite-scroll="getCustomerList"
        :infinite-scroll-immediate-check="false"
        :infinite-scroll-disabled="state.isFinished"
        :infinite-scroll-watch-disabled="state.isFinished"
        :infinite-scroll-distance="10"
        v-if="state.list.length"
      >
        <li
          class="item jz-flex jz-flex-center"
          :class="{ 'item-selected': item.isCheck }"
          v-for="(item, index) in state.list"
          :key="index"
        >
          <a-checkbox v-model:checked="item.isCheck" @change="selectItem(item)" />
          <div class="jz-flex-1 jz-flex jz-flex-cc">
            <img :src="item.avatar" alt="" />
            <div class="jz-flex-1 jz-flex jz-flex-col">
              <span class="lineClamp1">{{ item.name }}</span>
              <span style="color: #ed7b2f" v-if="item.wx_type_val === '企业微信'" class="lineClamp1"
                >@{{ item.wx_type_val }}</span
              >
              <span style="color: #57be6a" v-if="item.wx_type_val === '个人微信'" class="lineClamp1"
                >@{{ item.wx_type_val }}</span
              >
            </div>
          </div>
        </li>
      </ul>
      <div class="not-more jz-flex jz-flex-col jz-flex-center jz-flex-1" v-else>
        <img src="@/assets/imgs/not_more.png" alt="" />
        <span>无内容</span>
      </div>
      <div class="group-footer">
        <a-button :disabled="state.list.filter((i) => i.isCheck).length === 0" @click="clearGroup"
          >清空已选</a-button
        >
      </div>
    </div>
  </div>
</template>

<script setup>
import { queryProductList, searchTerm, searchCamp, searchUser } from 'api/common'
import dayjs from 'dayjs'
import { computed, defineExpose, onMounted, reactive, ref, toRaw, toRef, unref } from 'vue'
import { Form } from 'ant-design-vue'
import { dictStore } from '@/store/modules/dict'
import { cloneDeep, debounce } from 'lodash-es'
import { queryList } from 'api/customerManager'
import { customerStore } from '@/store/modules/customer'
const state = reactive({
  allCheck: false,
  isSwitch: false,
  isFinished: false,
  page: 1,

  loading: false,
  list: [],
  all_group_list: [],
  checked_group_list: [], // 已选数据
  count: 0,
  originCount: 0
})
const form = reactive({
  add_time: [],
  keyword: '',
  sex: undefined,
  project_id: undefined,
  camp_id: undefined,
  term: undefined,
  source: undefined,
  user_ids: undefined,
  label_ids: undefined,
  label_options: undefined,
  is_name: undefined,
  is_remark: undefined,
  is_phone: undefined,
  friend_status: undefined,
  group_type: undefined,
  group_type_text: '',
  label_type: undefined,
  wx_type: undefined,
  app: undefined,
  is_friend_add: undefined
})
const store2 = customerStore()

const useForm = Form.useForm
const rulesRef = reactive({})
const isReset = ref(false)
const { validateInfos, resetFields } = useForm(form, rulesRef)
const label_type_name = ref('')
const groupTypeObj = reactive({
  label: ''
})
const emit = defineEmits(['success'])

const store = dictStore()
const dictMap = toRef(store, 'dictMap')
store.tryFetchData()

const dictFields = computed(() => ({ label: 'val', value: 'key' }))
const replaceFields = computed(() => ({ label: 'name', value: 'id' }))
const formatDate = (value, format = 'YYYY-MM-DD') => dayjs(value * 1000).format(format)

const isChangeForm = computed(() =>
  Object.keys(form).some((key) =>
    Array.isArray(form[key])
      ? !!form[key].length
      : form[key] !== null && form[key] !== undefined && form[key] !== ''
  )
)
// 标签查询
const handleSelectedTag = ({ type, tags }) => {
  form.label_type = type
  label_type_name.value = type === 1 ? '任意' : type === 2 ? '带有' : type === 3 ? '除开' : '未打标签好友'
  form.label_options = tags
}
// 选择按群查询
const handleGroupTypeChange = ({ labelInValue, checkedRows }) => {
  groupTypeObj.label = labelInValue.label
  form.group_type = labelInValue.value
  form.group_ids = checkedRows.map((item) => item.id)
  form.group_type_text = checkedRows.map((item) => item.name).join('、')
}
const clearFields = () => {
  resetFields()
  state.allCheck = false
  form.label_ids = []
  form.label_options = []
  form.group_ids = []
  label_type_name.value = ''
  form.group_type_text = ''
  groupTypeObj.label = ''
  isReset.value = true
  emit('success', [])
}

//获取客户列表
const querySearch = async (params) => {
  try {
    if (state.isFinished) return false
    state.loading = true
    const { data } = await queryList({ ...params, page: state.page || 1, limit: 20 })
    state.loading = false

    if (data.list.length) {
      state.all_group_list = []
      state.list = []

      let ids = state.all_group_list?.map((i) => i.id)
      let checkIds = state.checked_group_list?.map((i) => i.id)

      data.list.forEach((i) => {
        if (state.allCheck) {
          i.isCheck = true
        }
        if (!ids.includes(i.id)) {
          state.all_group_list.push(i)
        }
        if (!checkIds.includes(i.id) && i.isCheck) {
          state.checked_group_list.push(i)
        }
      })
      state.list = [...state.list, ...data.list]
      state.page += 1
    } else {
      state.list = []
      state.isFinished = true
    }
    if (data.total <= 20) {
      state.isFinished = true
    }
    state.count = +data.total
    state.originCount = +data.total
    store2.customerCount = state.count
  } catch (error) {
    state.loading = false
  }
}

const debounceSearch = debounce(querySearch, 350)

const selectItem = (i) => {
  let index = unref(state.checked_group_list).findIndex((el) => el.ac_id === i.ac_id)
  if (~index) {
    unref(state.checked_group_list).splice(index, 1)
  } else {
    unref(state.checked_group_list).push(i)
  }
  let checkedNum = state.list.filter((i) => i.isCheck).length
  store2.customerSelectCount = checkedNum
  state.allCheck = checkedNum === state.list.length

  emit('success', unref(state.checked_group_list))
}

// 仅显示已选
const changeSwitch = (val) => {
  state.list = val ? [...state.checked_group_list] : state.all_group_list
}

//回显
const echoData = (data) => {
  clearGroup()
  state.checked_group_list.value = []
  let checkIds = data.map((i) => i.id)
  store2.customerSelectCount = checkIds.length
  state.list.forEach((i) => {
    if (checkIds.includes(i.ac_id)) {
      unref(state.checked_group_list).push(i)
      i.isCheck = true
    } else {
      i.isCheck = false
    }
  })

  state.isSwitch = store2.customerSelectCount > 0 ? true : false
  state.list = store2.customerSelectCount > 0 ? [...state.checked_group_list] : state.all_group_list
  state.page = 1
}

const handleChange = () => {
  state.list.forEach((i) => {
    i.isCheck = state.allCheck
  })
  if (state.allCheck) {
    state.checked_group_list = [...state.list]
    store2.customerSelectCount = state.checked_group_list.length
  } else {
    state.checked_group_list = []
    store2.customerSelectCount = 0
  }
  emit('success', unref(state.checked_group_list))
}

// 排除条件过滤\
const excludeParams = ref({})
const exclude_count = ref(0)
const excludeCollapsed = ref(true)

const handleOpenSider2 = () => {
  excludeCollapsed.value = true
}
const handleOpenSider = () => {
  excludeCollapsed.value = !excludeCollapsed.value
}

const excludeChange = (params, num) => {
  state.isFinished = false
  state.page = 1
  excludeParams.value = params
  isReset.value = false
  exclude_count.value = num
  const updateParams = { ...unref(getParams), ...unref(excludeParams) }
  const totalParams = {}
  Object.keys(updateParams).forEach((key) => {
    if (Array.isArray(updateParams[key])) {
      totalParams[key] = updateParams[key].join(',')
    } else {
      totalParams[key] = updateParams[key]
    }
  })
  debounceSearch(toRaw(totalParams))
}

/**
 * computed属性
 * @type {ComputedRef<{[p: string]: *}>}
 */
const getParams = computed(() => {
  const deepData = cloneDeep(form)
  let labelOptions = cloneDeep(deepData.label_options || [])
  Reflect.deleteProperty(deepData, 'label_options')
  deepData.keyword = deepData.keyword === '' ? undefined : deepData.keyword
  if (deepData.add_time?.[1]) {
    deepData.add_time[1] += ' 23:59:59'
  }
  return {
    ...deepData,
    group_type_text: undefined,
    label_ids: labelOptions.map((row) => row.value),
    add_start_time: deepData?.add_time?.length ? dayjs(deepData.add_time[0])?.unix?.() : undefined,
    add_end_time: deepData?.add_time?.length ? dayjs(deepData.add_time[1])?.unix?.() : undefined,
    add_time: undefined
  }
})

//清空已选
const clearGroup = () => {
  state.allCheck = false
  state.checked_group_list = []
  state.list.forEach((i) => (i.isCheck = false))
  state.list = state.all_group_list

  state.isSwitch = false
  store2.customerSelectCount = 0
}

// 获取客户列表数据
const getCustomerList = () => {
  const updateParams = { ...unref(getParams), ...unref(excludeParams) }
  const totalParams = {}
  Object.keys(updateParams).forEach((key) => {
    if (Array.isArray(updateParams[key])) {
      totalParams[key] = updateParams[key].join(',')
    } else {
      totalParams[key] = updateParams[key]
    }
  })
  debounceSearch(toRaw(totalParams))
}
// 重置群数据
const resetGroup = () => {
  state.page = 1
  state.list = []
  state.count = 0
  store2.customerCount = 0
  store2.customerSelectCount = 0
  state.isFinished = false
  state.checked_group_list = []
  state.all_group_list = []
  state.isSwitch = false
}

onMounted(async () => {
  await getCustomerList()
})

defineExpose({ clearFields, echoData, resetGroup })

watch(
  () => form,
  async () => {
    await resetGroup()
    await getCustomerList()
  },
  {
    deep: true
  }
)
</script>

<style lang="less" scoped>
.sop-customer-list {
  position: relative;
  height: 100%;
  .form-box {
    position: relative;
    width: 257px;
    height: 100%;
    z-index: 3;
    background-color: white;
    &::after {
      content: '';
      position: absolute;
      right: 0;
      top: 0;
      bottom: 0;
      width: 1px;
      height: 100%;
      background-color: #eee;
      transform: scaleX(0.6);
    }
    .sop-exclude-box {
      user-select: none;
      height: 64px;
      font-size: 16px;
      color: #3165f5;
    }
    .editor-form {
      height: 100%;
      flex: 1;
      overflow: auto;
      padding: 0 16px 16px;
      // 修改滚动条
      &:hover {
        &::-webkit-scrollbar-thumb {
          visibility: visible;
        }
        .page-side-fold.is-expand {
          opacity: 1;
        }
      }
      &::-webkit-scrollbar {
        width: 2px;
      }
      &::-webkit-scrollbar-thumb {
        visibility: hidden;
        transition: all 0.28s;
      }
      //padding: 27px 16px 16px 16px;
      .ant-form-head {
        margin-bottom: 17px;
        padding-top: 27px;
        top: 0px;
        background-color: white;
        z-index: 2;
        position: sticky;
        .ant-btn-link {
          padding-right: 0px;
        }
      }
    }
  }
  .fade-enter-active {
    transition: all 0.2s ease;
  }
  .fade-leave-active {
    transition: all 0.2s cubic-bezier(1, 0.5, 0.8, 1);
  }
  .fade-enter, .fade-leave-to /* .fade-leave-active in <2.1.8 */ {
    transform: translateX(5px);
    opacity: 0;
  }
  .exclude-form {
    position: absolute;
    width: 257px;
    height: 100%;
    left: 0px;
    z-index: 2;
    background-color: white;
    //visibility: hidden;
    transition: all 0.2s;
    padding: 28px 0;
  }
  .list-box {
    flex: 1;
    height: 100%;
    width: 360px;
    z-index: 1;
    .group-head {
      color: #999;
      padding: 0 16px 0 16px;
      margin-top: 32px;
      margin-bottom: 16px;
      .switch {
        margin-left: 16px;
      }
    }
    .group-wraper {
      overflow-y: auto;
      height: 100%;
      padding: 0 8px;
      // 修改滚动条
      &:hover {
        &::-webkit-scrollbar-thumb {
          visibility: visible;
        }
        .page-side-fold.is-expand {
          opacity: 1;
        }
      }
      &::-webkit-scrollbar {
        width: 2px;
      }
      &::-webkit-scrollbar-thumb {
        visibility: hidden;
        transition: all 0.28s;
      }
      .item {
        width: 100%;
        height: 54px;
        min-height: 54px;
        padding: 0 8px;
        cursor: pointer;
        transition: all 0.3s;

        &.item-selected {
          background: #ebf0fe !important;
        }

        > div {
          margin-left: 28px;

          img {
            width: 36px;
            height: 36px;
            border-radius: 8px;
            margin-right: 12px;
          }

          span:first-child {
            font-size: 14px;
          }

          span:last-child {
            font-size: 12px;
            color: #999999;
          }
        }

        &:hover {
          background: rgba(0, 0, 0, 0.02);
        }
      }
    }
    .not-more {
      width: 100%;
      img {
        width: 110px;
        height: 110px;
        display: block;
        margin-bottom: 4px;
      }
      span {
        font-size: 12px;
        color: #999;
      }
    }
    .group-footer {
      height: 64px;
      display: flex;
      justify-content: flex-end;
      align-items: center;
      padding-right: 16px;
    }
  }
}
</style>
