import { MessageTypeEnum } from '@/enums/MessageTypeEnum'

let tagStyles = [
  { color: '#000', border: '1px solid rgba(0,0,0,0.1)' },
  { color: '#F23944', border: '1px solid rgba(242,57,68,0.1)' }
]
const isincludes = (val, arrays) => arrays.includes(val)

export const isResMsg = (item) => {
  let isTrue = item.icon === 'image' || item.icon === 'video' || item.icon === 'file'
  if (!isTrue) {
    return isincludes(item.msg_type, [MessageTypeEnum.image, MessageTypeEnum.video, MessageTypeEnum.file])
  }
  return isTrue
}

export const isWechatMsg = (item) => {
  let isTrue = item.icon === 'mini' || item.icon === 'voice' || item.icon === 'video_num'
  if (!isTrue) {
    return isincludes(item.msg_type, [MessageTypeEnum.mini, MessageTypeEnum.voice, MessageTypeEnum.video_num])
  }
  return isTrue
}

export const getCellTagStyle = (item, dictMap) => {
  const { friend_status } = unref(dictMap)
  let styles = friend_status?.reduce((bo, next, index) => {
    bo[next.key] = {
      val: next.val,
      style: { ...tagStyles[index], background: '#fff', marginLeft: '8px' }
    }
    return bo
  }, {})
  return styles[item.friend_status].style
}
