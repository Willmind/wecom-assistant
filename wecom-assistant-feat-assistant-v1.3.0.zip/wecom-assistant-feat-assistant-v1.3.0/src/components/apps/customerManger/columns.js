export default () => [
  {
    title: '客户信息',
    width: 280,
    key: 'customer_info',
    dataIndex: 'info'
  },
  { title: '企微标签', width: 260, dataIndex: 'tag', key: 'tag_info' },
  { title: '用户', width: 230, dataIndex: 'user', key: 'user_info' },
  { title: '来源', width: 130, dataIndex: 'source_val', key: 'source_info' },
  { title: '添加好友时间', width: 160, dataIndex: 'add_time', key: 'time_info' }
]
