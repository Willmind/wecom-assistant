<template>
  <div class="page-wrapper">
    <a-layout class="page-layout">
      <a-layout-sider
        v-model:collapsed="collapsed"
        :width="257"
        theme="light"
        collapsible
        :trigger="null"
        :collapsedWidth="0"
        class="page-sider"
        ref="pageSider"
        :style="{
          overflowY: 'auto',
          overflowX: 'hidden',
          height: 'calc(100% - 0px)',
          position: 'fixed'
        }"
      >
        <div>
          <div
            class="page-side-fold jz-flex jz-flex-center"
            :class="{ 'is-expand': !collapsed }"
            @click="toggleFold"
            v-if="excludeCollapsed"
          >
            <left-outlined v-if="!collapsed" />
            <right-outlined v-else />
          </div>
          <div style="padding-bottom: 64px">
            <a-form class="editor-form ant-form-small">
              <div class="ant-form-head jz-flex jz-flex-cc jz-flex-rb ant-form-top">
                <span class="wecom-title">筛选</span>
                <a-button type="link" :disabled="!isChangeForm" @click="() => clearFields()"
                  >清空筛选</a-button
                >
              </div>
              <a-form-item v-bind="validateInfos.keyword">
                <a-input
                  class="keywork-search-input"
                  v-model:value="form.keyword"
                  allowClear
                  placeholder="关键词筛选"
                >
                  <template #suffix v-if="!form.keyword">
                    <svg-icon icon-name="ic_search" />
                  </template>
                </a-input>
              </a-form-item>
              <a-form-item v-bind="validateInfos.label_options">
                <CustomTagPopover
                  is-search
                  needCheckGroup
                  :isReset="isReset"
                  :data="{ label_id: form.label_ids }"
                  @select-change="handleSelectedTag"
                >
                  <span>
                    <rich-input
                      v-model:value="form.label_options"
                      tagMode
                      :allowInput="false"
                      allowClear
                      placeholder="标签"
                      :setTagClass="
                        (item) =>
                          item?.type
                            ? item.type === 2
                              ? 'ant-tag-personal'
                              : 'ant-tag-primary'
                            : 'ant-tag-plain'
                      "
                    >
                      <template #prefix>
                        <span>{{ label_type_name }}</span>
                      </template>
                      <template #suffix>
                        <down-outlined />
                      </template>
                    </rich-input>
                  </span>
                </CustomTagPopover>
              </a-form-item>
              <a-form-item name="add_time" v-bind="validateInfos.add_time">
                <a-range-picker
                  v-model:value="form.add_time"
                  value-format="YYYY-MM-DD"
                  allowClear
                  :ranges="{
                    当天: [dayjs(), dayjs()],
                    昨天: [
                      dayjs().startOf('day').subtract(1, 'days'),
                      dayjs().startOf('day').subtract(1, 'days')
                    ],
                    最近3天: [dayjs().startOf('day').subtract(2, 'days'), dayjs()],
                    最近7天: [dayjs().startOf('day').subtract(6, 'days'), dayjs()],
                    最近30天: [dayjs().startOf('day').subtract(29, 'days'), dayjs()]
                  }"
                />
              </a-form-item>
              <a-form-item v-bind="validateInfos.group_type_text">
                <GroupTypePopover
                  v-model:item="form.group_ids"
                  :isReset="isReset"
                  @onChange="handleGroupTypeChange"
                >
                  <a-input
                    class="ant-input-ellipsis"
                    v-model:value="form.group_type_text"
                    allowClear
                    :readonly="true"
                    placeholder="按群查询"
                  >
                    <template #prefix v-if="groupTypeObj.label">
                      <label>{{ groupTypeObj.label }}</label>
                    </template>
                    <template #suffix>
                      <div class="ant-select-arrow">
                        <down-outlined />
                      </div>
                    </template>
                  </a-input>
                </GroupTypePopover>
              </a-form-item>
              <a-form-item v-bind="validateInfos.is_remark">
                <api-select
                  v-model:value="form.is_remark"
                  allowClear
                  :options="dictMap.is_remark"
                  :replaceFields="dictFields"
                  placeholder="有无企微备注"
                />
              </a-form-item>
              <a-form-item v-bind="validateInfos.is_name">
                <api-select
                  v-model:value="form.is_name"
                  allowClear
                  :options="dictMap.is_name"
                  :replaceFields="dictFields"
                  placeholder="有无称呼"
                />
              </a-form-item>
              <a-form-item v-bind="validateInfos.sex">
                <api-select
                  v-model:value="form.sex"
                  allowClear
                  :options="dictMap.sex"
                  :replaceFields="dictFields"
                  placeholder="性别"
                />
              </a-form-item>
              <a-form-item v-bind="validateInfos.source">
                <api-select
                  v-model:value="form.source"
                  allowClear
                  :options="dictMap.source"
                  :replaceFields="dictFields"
                  placeholder="来源"
                />
              </a-form-item>
              <a-form-item v-bind="validateInfos.friend_status">
                <api-select
                  v-model:value="form.friend_status"
                  allowClear
                  :options="dictMap.friend_status"
                  :replaceFields="dictFields"
                  placeholder="好友关系"
                />
              </a-form-item>
              <a-form-item v-bind="validateInfos.wx_type">
                <api-select
                  v-model:value="form.wx_type"
                  allowClear
                  :options="dictMap.wx_type"
                  :replaceFields="dictFields"
                  placeholder="微信类型"
                />
              </a-form-item>
              <a-form-item v-bind="validateInfos.is_friend_add">
                <api-select
                  v-model:value="form.is_friend_add"
                  allowClear
                  :options="dictMap.is_friend_add"
                  :replaceFields="dictFields"
                  placeholder="是否主动加好友"
                />
              </a-form-item>
              <div class="ant-form-head jz-flex jz-flex-rb" style="margin-top: 48px">
                <span class="wecom-title">学员筛选</span>
              </div>
              <a-form-item v-bind="validateInfos.user_ids">
                <api-select
                  class="user-select"
                  v-model:value="form.user_ids"
                  rowKey="user_id"
                  :api="searchUser"
                  allowClear
                  remote-search
                  placeholder="用户ID/手机号"
                  :params="(name) => ({ name })"
                >
                  <template #option="{ item }">
                    <div class="user-option jz-flex jz-flex-cc">
                      <img class="img" :src="item.avatar" v-if="item.avatar" />
                      <div class="item-content">
                        <span>{{ item.nickname }}</span>
                        <p>{{ item.mobile }}</p>
                      </div>
                    </div>
                  </template>
                  <template #suffix>
                    <search-outlined />
                  </template>
                </api-select>
              </a-form-item>
              <a-form-item v-bind="validateInfos.project_id">
                <api-select
                  v-model:value="form.project_id"
                  allowClear
                  filterOption
                  :show-search="true"
                  resultField="data.list"
                  :replaceFields="replaceFields"
                  :api="queryProductList"
                  placeholder="项目"
                />
              </a-form-item>
              <a-form-item v-bind="validateInfos.camp_id">
                <api-select
                  v-model:value="form.camp_id"
                  immediate
                  allowClear
                  remote-search
                  :api="searchCamp"
                  autoClearMismatchValue
                  :params="(name) => ({ name, project_id: form.project_id, flag: 1 })"
                  :replaceFields="replaceFields"
                  placeholder="课程ID/名称"
                />
              </a-form-item>
              <a-form-item v-bind="validateInfos.term">
                <api-select
                  v-model:value="form.term"
                  :disabled="!form.camp_id"
                  allowClear
                  mode="multiple"
                  :api="searchTerm"
                  placeholder="期数"
                  autoClearMismatchValue="force"
                  :replaceFields="{ value: 'tm' }"
                  :params="{ camp_id: form.camp_id }"
                >
                  <template #option="{ item }">
                    {{ formatDate(item.t) }}
                  </template>
                </api-select>
              </a-form-item>
              <a-form-item v-bind="validateInfos.is_phone">
                <api-select
                  v-model:value="form.is_phone"
                  allowClear
                  :options="dictMap.is_phone"
                  :replaceFields="dictFields"
                  placeholder="有无绑定手机"
                />
              </a-form-item>
              <a-form-item v-bind="validateInfos.app">
                <api-select
                  v-model:value="form.app"
                  :options="dictMap.app"
                  :replaceFields="dictFields"
                  placeholder="有无App"
                  allowClear
                />
              </a-form-item>
            </a-form>
          </div>
        </div>
        <div class="exclude-box jz-flex jz-flex-center" @click="handleOpenSider(false)">
          设置排除条件 ({{ exclude_count }})
          <SvgIcon :icon-name="excludeCollapsed ? 'arrow_right' : 'arrow_left'" />
        </div>
      </a-layout-sider>
      <a-layout-sider
        v-model:collapsed="excludeCollapsed"
        :width="257"
        theme="light"
        collapsible
        :trigger="null"
        :collapsedWidth="0"
        class="page-other-sider"
        ref="pageSider"
        :style="{
          overflowY: 'auto',
          overflowX: 'hidden',
          height: 'calc(100% - 0px)',
          position: 'fixed',
          paddingTop: '48px',
          marginLeft: `${pageSideWidth - 257}px`
        }"
      >
        <ExcludeForm :isParentNode="false" @excludeChange="excludeChange" />
      </a-layout-sider>
      <a-layout
        :style="{ marginLeft: `${pageSideWidth}px`, paddingTop: '48px', background: '#fff' }"
        @click="handleOpenSider(true)"
      >
        <a-layout-content :style="{ background: '#fff' }">
          <div class="page-content" ref="contentRef">
            <a-table
              class="customer-table"
              row-key="ac_id"
              :loading="loading"
              :dataSource="list"
              :pagination="false"
              :scroll="{ y: tableHeight, scrollToFirstRowOnChange: true }"
              :rowSelection="rowSelection"
              :columns="columns"
            >
              <template #title>
                <div class="ant-table-head jz-flex jz-flex-cc jz-flex-rb">
                  <span>我的客户</span>
                  <div class="operate-btns">
                    <a-button type="primary" @click="openFriendsDrawer">主动加好友</a-button>
                    <!--                    <a-button type="primary" @click="openAdvancedMassSendDrawer"> 高级群发</a-button>-->
                    <a-dropdown>
                      <template #overlay>
                        <a-menu>
                          <a-menu-item key="1" @click="openAdvancedMassSendDrawer">
                            高级群发
                          </a-menu-item>
                          <a-menu-item key="2" @click="openRapidMassSendDrawer">
                            极速群发
                          </a-menu-item>
                        </a-menu>
                      </template>
                      <a-button type="primary">
                        群发
                        <DownOutlined />
                      </a-button>
                    </a-dropdown>
                    <a-button type="primary" @click="openGroupAnnouncementDrawer"> 群公告</a-button>
                    <a-button type="primary" :disabled="!isSelectedRow" @click="batchUpdateInfo('tag')"
                      >批量修改标签</a-button
                    >
                    <a-button type="primary" :disabled="!isSelectedRow" @click="batchUpdateInfo('remark')"
                      >批量备注</a-button
                    >
                  </div>
                </div>
              </template>
              <template #headerCell="{ title, column }">
                <span v-if="column.key === getColumnKey('customer')">
                  <template v-if="selectedRowKeys.length">
                    已选择{{ selectedTotal }}位客户
                    <a href="javascript:;" @click="handleViewInfo">查看</a>
                  </template>
                  <template v-else>{{ title }}</template>
                </span>
              </template>
              <template #bodyCell="{ record, column }">
                <template v-if="column.key === getColumnKey('customer')">
                  <div class="item-cell jz-flex jz-flex-col">
                    <div class="user-info jz-flex jz-flex-center">
                      <img :src="record.avatar" />
                      <div class="info-con jz-flex-1 jz-flex jz-flex-col">
                        <span>
                          <span>{{ record.name }}</span>
                          <a-tag :style="getCellTagStyle(record, dictMap)">{{
                            record.friend_status_val
                          }}</a-tag>
                        </span>
                        <p :class="record.wx_type === 1 ? 'wx_type' : 'comp_wx_type'">
                          @ {{ record.wx_type_val }}
                        </p>
                      </div>
                    </div>
                    <a-form class="ant-form-small" :colon="false" :model="record">
                      <a-form-item name="remark" label="备注">
                        <a-input
                          size="small"
                          v-model:value="record.remark"
                          placeholder="备注"
                          @blur="handleUpdateTableCell('remark', record)"
                        />
                      </a-form-item>
                      <a-form-item
                        v-for="(item, index) in record.contact_name"
                        :label="getContactLabel(index)"
                        :key="index"
                      >
                        <a-input
                          size="small"
                          v-model:value="item[`name${index}`]"
                          :placeholder="getContactLabel(index)"
                          @blur="handleUpdateTableCell('contact', item, record, index)"
                        />
                      </a-form-item>
                    </a-form>
                  </div>
                </template>
                <template v-if="column.key === getColumnKey('tag')">
                  <CustomTagPopover
                    :ac-id="record.ac_id"
                    :data="record.label"
                    height
                    is-search
                    is-update
                    @success="() => fetchData()"
                  >
                    <div class="p-info">
                      <a-tag
                        class="ant-tag-primary"
                        :class="{ 'ant-tag-personal': item.type === 2 }"
                        v-for="(item, index) in record.label"
                        :key="index"
                      >
                        {{ item.name }}
                      </a-tag>
                    </div>
                  </CustomTagPopover>
                </template>
                <template v-if="column.key === getColumnKey('user')">
                  <p class="p-info">
                    <label>用户ID：</label>
                    <span>{{ record.user_id || '无匹配' }}</span>
                    <a-tooltip title="复制" v-if="record.user_id">
                      <SvgIcon icon-name="ic_copy" v-copy="record.user_id" />
                    </a-tooltip>
                  </p>
                  <p class="p-info">
                    <label>手机号：</label>
                    <span>{{ record.mobile ? record.mobile : '无手机号' }}</span>
                    <a-tooltip title="复制" v-if="record.mobile">
                      <SvgIcon icon-name="ic_copy" v-copy="record.mobile" />
                    </a-tooltip>
                  </p>
                </template>
                <template v-if="column.key === getColumnKey('time')">
                  {{ dayjs(+record.add_time * 1000).format('YYYY-MM-DD HH:mm:ss') }}
                </template>
                <template v-if="column.key === getColumnKey('source')">
                  <div class="jz-flex jz-flex-col">
                    <span>{{ record.source_val }}</span>
                    <span v-if="record.is_friend_add">主动加好友</span>
                  </div>
                </template>
              </template>
              <template #emptyText>
                <div class="not-more jz-flex jz-flex-center jz-flex-col">
                  <img src="@/assets/imgs/not_more.png" alt="" />
                  <span>无内容</span>
                </div>
              </template>
            </a-table>
          </div>
          <a-layout-footer class="ant-pagination-fixed" :style="getLeftPage">
            <basic-pagination :showQuickJumper="false" @change="pageChange" :params="getPagination">
              <template #extra>
                <span class="pageination-extra">共 {{ getPagination.total }} 客户</span>
              </template>
            </basic-pagination>
          </a-layout-footer>
        </a-layout-content>
      </a-layout>
    </a-layout>
    <CustomerInfoDrawer :register="registerDrawer" />
    <BatchUpdateTags :register="tagsDrawer" @success="() => fetchData()" />
    <BatchUpdateRemark :register="remarkDrawer" @success="() => fetchData()" />
    <!--主动添加好友抽屉-->
    <AddfriendsDrawer :register="friendsDrawer" @success="() => fetchData()" />
    <!--新建群公告抽屉-->
    <GroupAnnouncementDrawer :register="groupAnnouncementDrawer" @success="() => fetchData()" />
    <AdvancedMassSendDrawer :register="registerAdvancedMassSendDrawer" @success="() => fetchData()" />
    <rapidMassSendDrawer :register="registerRapidMassSendDrawer" @success="() => fetchData()" />
  </div>
</template>
<script setup>
import dayjs from 'dayjs'
import getColumns from './columns'
import { cloneDeep, debounce, isEqual } from 'lodash-es'
import { Form } from 'ant-design-vue'
import { getCellTagStyle } from './utils.js'
import { queryProductList, searchTerm, searchCamp, searchUser } from 'api/common'
import { queryList, saveCall, removeCall, updateRemark } from 'api/customerManager'
import { useCreateListHTTP } from '@/composables/common/useCreate'
import { computed, nextTick, onBeforeUnmount, onMounted, reactive, ref, toRaw, toRef, watch } from 'vue'
import CustomerInfoDrawer from './comps/CustomerInfoDrawer.vue'
import { useDrawer } from '@/components/basic/drawer'
import CustomTagPopover from './comps/CustomTagPopover.vue'
import GroupTypePopover from './comps/GroupTypePopover.vue'
import BatchUpdateRemark from './comps/BatchUpdateRemark.vue'
import BatchUpdateTags from './comps/BatchUpdateTags.vue'
import AddfriendsDrawer from './drawer/AddfriendsDrawer.vue'
import GroupAnnouncementDrawer from './drawer/GroupAnnouncementDrawer.vue'
import AdvancedMassSendDrawer from './comps/AdvancedMassSendDrawer.vue'
import useMessage from '@/composables/web/useMessage'
import { dictStore } from '@/store/modules/dict'

const useForm = Form.useForm
const columns = getColumns()
const collapsed = ref(false)
const excludeCollapsed = ref(true)
const selectedRows = ref([])
const selectedRowKeys = ref([])
const pageSider = ref()
const pagerWidth = ref()
const pageSideWidth = ref(257)
const tableHeight = ref(300)
const isSelectAll = ref(false)
const isReset = ref(false)
const searchHash = ref('')

let sideWidth = 0
const form = reactive({
  add_time: [],
  keyword: '',
  sex: undefined,
  project_id: undefined,
  camp_id: undefined,
  term: undefined,
  source: undefined,
  user_ids: undefined,
  label_ids: undefined,
  label_options: undefined,
  is_name: undefined,
  is_remark: undefined,
  is_phone: undefined,
  friend_status: undefined,
  group_type: undefined,
  group_type_text: '',
  label_type: undefined,
  wx_type: undefined,
  app: undefined,
  is_friend_add: undefined
})
const rulesRef = reactive({})
const contentRef = ref()
const excludeKeys = ref([])
const exclude_count = ref(0)

const { createMessage } = useMessage()

const [registerDrawer, { openDrawer: openInfoDrawer }] = useDrawer()
const [remarkDrawer, { openDrawer: openRemarkDrawer }] = useDrawer()
const [tagsDrawer, { openDrawer: openTagDrawer }] = useDrawer()
const [friendsDrawer, { openDrawer: openFriendsDrawer }] = useDrawer()
const [registerAdvancedMassSendDrawer, { openDrawer: openAdvancedMassSendDrawer }] = useDrawer()
const [registerRapidMassSendDrawer, { openDrawer: openRapidMassSendDrawer }] = useDrawer()
const [groupAnnouncementDrawer, { openDrawer: openGroupAnnouncementDrawer }] = useDrawer()

const store = dictStore()
const dictMap = toRef(store, 'dictMap')
store.tryFetchData()

const {
  items: list,
  loading,
  pagination,
  fetchData,
  updateParams
} = useCreateListHTTP(queryList, {}, (res) => {
  list.value = transformList(res.list)
  searchHash.value = res.hash
  if (isSelectAll.value) {
    nextTick(() => {
      handleMultipleSelectedRow(cloneDeep(list.value), [...excludeKeys.value])
    })
  }
})

const debounceSearch = debounce(querySearch, 350)

const getPagination = computed(() => ({
  ...pagination.value,
  showSizeChanger: false,
  showQuickJumper: false
}))

const replaceFields = computed(() => ({ label: 'name', value: 'id' }))
const dictFields = computed(() => ({ label: 'val', value: 'key' }))

const selectedTotal = computed(() =>
  isSelectAll.value ? pagination.value.total - excludeKeys.value?.length || 0 : selectedRowKeys.value.length
)

function querySearch(params = {}) {
  const queryParams = {}
  Object.keys(params).forEach((key) => {
    if (Array.isArray(params[key])) {
      queryParams[key] = params[key].join(',')
    } else {
      queryParams[key] = params[key]
    }
  })
  updateParams({ ...queryParams, page: 1 })
}

const clearSelectedRows = () => {
  selectedRowKeys.value = []
  selectedRows.value = []
  excludeKeys.value = []
  isSelectAll.value = false
}

onMounted(async () => {
  pagerWidth.value = sideWidth = pageSider.value?.width + 80 + 16
  setTableHeight()
  window.addEventListener('resize', setTableHeight)
  await fetchData()
})

onBeforeUnmount(() => {
  window.removeEventListener('resize', setTableHeight)
})

const transformList = (list = []) => {
  return list.map((item) => {
    const contactNames =
      item.contact_name.length === 0
        ? new Array(2).fill({})
        : item.contact_name.length < 2
        ? item.contact_name.concat({})
        : item.contact_name
    return {
      ...item,
      remark_1: item.remark,
      contact_name: contactNames.map((row, index) => ({ ...row, [`name${index}`]: row.name || '' }))
    }
  })
}

const setTableHeight = () => {
  nextTick(() => {
    tableHeight.value = window.innerHeight - 272
  })
}

const pageChange = ({ current }) => updateParams({ page: current })

const getLeftPage = computed(() => {
  return {
    right: 0,
    left: 'inherit',
    background: '#fff',
    padding: '16px 32px 16px 16px',
    width: `calc(100% - ${excludeCollapsed.value ? pagerWidth.value : pagerWidth.value * 2}px)`
  }
})

// const pageContentStyles = computed(() => {
//   return {
//     width: `calc(100% - ${!collapsed.value ? pagerWidth.value - 55 : 0}px)`
//   }
// })

const isChangeForm = computed(() =>
  Object.keys(form).some((key) =>
    Array.isArray(form[key])
      ? !!form[key].length
      : form[key] !== null && form[key] !== undefined && form[key] !== ''
  )
)

const getColumnKey = (prefix) => prefix + '_info'

const { validateInfos, resetFields } = useForm(form, rulesRef)

const toggleFold = () => {
  collapsed.value = !unref(collapsed)
  pagerWidth.value = unref(collapsed) ? 80 : sideWidth
  pageSideWidth.value = unref(collapsed) ? 0 : 257
}
const ZH_NUM = ['一', '二', '三']
const getContactLabel = (index) => `称呼${ZH_NUM[index]}`

const handleUpdateTableCell = async (type, row, recrod, index) => {
  switch (type) {
    case 'remark':
      if (isEqual(row.remark, row.remark_1)) {
        row.remark = row.remark_1
        return
      }
      await updateRemark({ ac_id: row.ac_id, remark: row.remark })
      row.remark_1 = row.remark
      createMessage.success('设置成功')
      break
    case 'contact':
      if (!row[`name${index}`]) {
        if (row.id) {
          await removeCall({ id: row.id, ac_id: recrod.ac_id })
          fetchData()
          createMessage.success('删除成功')
        }
        return
      }
      if (isEqual(row[`name${index}`], row.name)) {
        row[`name${index}`] = row.name
        return
      }
      const { data } = await saveCall({ id: row.id, ac_id: recrod.ac_id, name: row[`name${index}`] })
      row.name = row[`name${index}`]
      row.id = data.id || row.id
      createMessage.success('设置成功')
      break
  }
}

const handleOpenSider = (isClose = false) => {
  if (excludeCollapsed.value && isClose) return
  excludeCollapsed.value = !excludeCollapsed.value
  pageSideWidth.value = !unref(excludeCollapsed) ? 257 * 2 : 257
}

const batchUpdateInfo = (type) => {
  let ids = toRaw(selectedRowKeys.value.slice())
  const label_ids = selectedRows.value
    .map((item) => item.contact_label.label_id)
    .filter((row) => Array.isArray(row) && row.length)
  if (type === 'remark') {
    openRemarkDrawer({
      ids,
      hash: isSelectAll.value && searchHash.value,
      isAll: isSelectAll.value,
      excludeIds: excludeKeys.value
    })
  } else if (type === 'tag') {
    openTagDrawer({
      ids,
      hash: isSelectAll.value && searchHash.value,
      isAll: isSelectAll.value,
      excludeIds: excludeKeys.value,
      label_ids: label_ids.flat(Infinity)
    })
  }
}

const handleViewInfo = () => {
  openInfoDrawer({
    data: cloneDeep(toRaw(selectedRows.value)),
    excludeIds: excludeKeys.value,
    isAll: isSelectAll.value
  })
}

const isSelectedRow = computed(() => !!selectedRowKeys.value.length)

const rowSelection = computed(() => {
  return {
    fixed: true,
    columnWidth: 55,
    preserveSelectedRowKeys: true,
    selectedRowKeys: selectedRowKeys.value,
    onChange: (rowkeys, rows) => {
      selectedRowKeys.value = rowkeys
      selectedRows.value = rows
    },
    onSelectAll: (selected) => {
      //跨页选择
      isSelectAll.value = selected
      if (!selected) {
        console.log('取消全选')
        clearSelectedRows()
      } else {
        excludeKeys.value = []
      }
    },
    onSelect: (row, isSelect) => {
      removeItem(row)
      if (!isSelect) {
        excludeKeys.value.push(row.ac_id)
      }
    }
  }
})

function removeItem(record) {
  let index = excludeKeys.value.findIndex((id) => id === record.ac_id)
  ~index && excludeKeys.value.splice(index, 1)
}

//  ---------------左侧表单----------------
const groupTypeObj = reactive({
  label: ''
})
const label_type_name = ref('')
// 选择按群查询
const handleGroupTypeChange = ({ labelInValue, checkedRows }) => {
  groupTypeObj.label = labelInValue.label
  form.group_type = labelInValue.value
  form.group_ids = checkedRows.map((item) => item.id)
  form.group_type_text = checkedRows.map((item) => item.name).join('、')
}

// 标签查询
const handleSelectedTag = ({ type, tags }) => {
  form.label_type = type
  label_type_name.value = type === 1 ? '任意' : type === 2 ? '带有' : type === 3 ? '除开' : '未打标签好友'
  form.label_options = tags
}

watch(
  () => form.label_options,
  (ls) => {
    form.label_ids = ls.map((row) => row.value)
  }
)

const handleMultipleSelectedRow = (rows, excludeKeys) => {
  let newRows = unref(rows).slice()
  newRows.forEach((item) => {
    if (
      !unref(selectedRows).some((row) => row.ac_id === item.ac_id) &&
      !excludeKeys.some((key) => key === item.ac_id)
    ) {
      selectedRows.value.push(item)
    }
  })
  selectedRowKeys.value = selectedRows.value.map((item) => item.ac_id)
}

const getParams = computed(() => {
  const deepData = cloneDeep(form)
  let labelOptions = cloneDeep(deepData.label_options || [])
  Reflect.deleteProperty(deepData, 'label_options')
  deepData.keyword = deepData.keyword === '' ? undefined : deepData.keyword
  if (deepData.add_time?.[1]) {
    deepData.add_time[1] += ' 23:59:59'
  }
  return {
    ...deepData,
    group_type_text: undefined,
    label_ids: labelOptions.map((row) => row.value),
    add_start_time: deepData?.add_time?.length ? dayjs(deepData.add_time[0])?.unix?.() : undefined,
    add_end_time: deepData?.add_time?.length ? dayjs(deepData.add_time[1])?.unix?.() : undefined,
    add_time: undefined
  }
})

const formatDate = (value, format = 'YYYY-MM-DD') => dayjs(value * 1000).format(format)

const clearFields = () => {
  resetFields()
  form.label_ids = []
  form.label_options = []
  form.group_ids = []
  label_type_name.value = ''
  form.group_type_text = ''
  groupTypeObj.label = ''
  isReset.value = true
}

watch(
  () => form,
  () => {
    const params = unref(getParams)
    isSelectAll.value = false
    clearSelectedRows()
    debounceSearch(toRaw(params))
    isReset.value = false
  },
  {
    deep: true
  }
)

// 排除条件过滤
const excludeChange = (params, num) => {
  isSelectAll.value = false
  clearSelectedRows()
  debounceSearch(toRaw(params))
  isReset.value = false
  exclude_count.value = num
}
</script>

<style lang="less">
.page-wrapper {
  height: 100%;
  width: 100%;
  background: #ffffff;
  overflow-y: auto;

  .page-layout {
    position: relative;
    width: 100%;
    height: 100%;
    background: #fff;
    .ant-layout-sider.page-sider {
      &:hover {
        &::-webkit-scrollbar-thumb {
          visibility: visible;
        }
        .page-side-fold.is-expand {
          opacity: 1;
        }
      }
      // 修改滚动条
      &::-webkit-scrollbar {
        width: 3px;
      }

      &::-webkit-scrollbar-thumb {
        visibility: hidden;
        transition: all 0.28s;
      }
      .editor-form {
        &:after {
          content: ' ';
          position: absolute;
          top: 0;
          right: 0;
          width: 1px;
          height: 100%;
          transition: left 0.28s;
          background: @border-color-split;
        }
      }
      &.is-expand {
        width: 257px;
        opacity: 1;
        padding-right: 16px;
        flex: 0 0 257px;
      }
      &.ant-layout-sider-collapsed {
        .editor-form {
          &:after {
            opacity: 0;
          }
        }
      }
    }
    .page-side-fold {
      position: fixed;
      top: 200px;
      left: 80px;
      width: 16px;
      height: 58px;
      background: #eeeeee;
      border-top-left-radius: 0;
      border-bottom-left-radius: 0;
      border-top-right-radius: 6px;
      border-bottom-right-radius: 6px;
      cursor: pointer;
      transition: left 0.28s;
      z-index: 1;
      &.is-expand {
        left: 329px;
        border-radius: 24px;
        opacity: 0;
      }

      .anticon {
        font-size: 12px;
        cursor: pointer;
        color: rgba(0, 0, 0, 0.2);
      }
    }
    .page-content {
      margin: 0 16px;
    }
  }

  .user-info {
    width: 100%;
    flex-wrap: nowrap;
    margin-bottom: 14px;
    img {
      width: 40px;
      height: 40px;
      display: block;
      border-radius: 8px;
      margin-right: 16px;
    }
    .info-con {
      align-items: flex-start;
      justify-content: center;
      > span {
        margin-bottom: 2px;
      }
      > p:last-child {
        line-height: 16px;
        &.wx_type {
          color: #57be6a;
        }
        &.comp_wx_type {
          color: #eda150;
        }
      }
    }
  }

  .p-info {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    cursor: pointer;
    min-height: 50px;
    > label {
      color: rgba(0, 0, 0, 0.4);
      margin-right: 8px;
    }
    .ant-tag {
      margin-bottom: 10px;
    }
    .ant-tag-personal {
      color: #06d1d1;
      background-color: rgba(6, 209, 209, 0.1);
    }
    .svg-icon {
      &:hover {
        color: #000;
      }
    }
  }
  .pageination-extra {
    color: rgba(0, 0, 0, 0.4);
    font-size: 14px;
    line-height: 16px;
    margin-left: 8px;
  }

  .editor-form {
    padding: 0 16px 16px;
    box-sizing: border-box;
    padding-bottom: 56px;
    .ant-form-head {
      line-height: 20px;
      margin-bottom: 16px;
      position: sticky;
      top: 0;
      z-index: 2;
      background: #fff;
      .btn {
        color: rgba(0, 0, 0, 0.25);
      }
      .ant-btn {
        padding-right: 0;
      }
      &:nth-of-type(2n) {
        margin-top: 48px;
      }
    }
    .ant-form-top {
      padding-top: 48px;
    }
    .ant-form-item {
      .ant-form-item-label {
        width: 46px;
        margin-right: 15px;
        > label {
          color: rgba(0, 0, 0, 0.4);
        }
      }
    }
  }
  .ant-table-title {
    padding-top: 0;
    .ant-table-head {
      .operate-btns {
        > button {
          margin-left: 12px;
        }
      }
    }
  }

  .user-select {
    .ant-select-selector {
      height: 46px;
    }
    .ant-select-selection-placeholder {
      height: 43px;
      line-height: 43px;
    }
    &.ant-select-single:not(.ant-select-customize-input)
      .ant-select-selector
      .ant-select-selection-search-input {
      height: 43px;
    }
  }

  .item-cell {
    .ant-form-small {
      .ant-form-item-label {
        width: 50px;
        margin-right: 10px;
        display: inline-flex;
        justify-content: flex-end;
        &:first-child {
          padding-left: 2px;
        }
        > label {
          height: auto;
          color: rgba(0, 0, 0, 0.4);
        }
      }
    }
  }
  .customer-table {
    .ant-table-thead > tr > th {
      color: @font-minor-color;
      border-bottom: none;
    }
    .ant-table-tbody > tr.ant-table-row-selected > td {
      background: rgba(49, 101, 245, 0.04);
    }
    .ant-table-thead
      > tr
      > th:not(:last-child):not(.ant-table-selection-column):not(.ant-table-row-expand-icon-cell):not([colspan])::before {
      width: 0;
    }
    .not-more {
      img {
        width: 110px;
        height: 110px;
        margin-bottom: 4px;
      }
      span {
        font-size: 12px;
      }
    }
  }
}

.user-option {
  height: 100%;
  .img {
    width: 30px;
    height: 30px;
    border-radius: 8px;
    margin-right: 16px;
  }
  .item-content {
    flex: auto;
    display: flex;
    flex-wrap: wrap;
    flex-direction: column;
    justify-content: center;
    line-height: 22px;
    > p {
      margin: 0;
      padding: 0;
    }
  }
}
.keywork-search-input {
  .ant-input-affix-wrapper .anticon {
    width: auto;
    height: auto;
    &.ant-input-clear-icon-has-suffix {
      margin: 0;
    }
  }
}
.exclude-box {
  height: 64px;
  color: #3165f5;
  position: fixed;
  width: 251px;
  left: 80px;
  bottom: 0;
  background: #fff;
  cursor: pointer;
  z-index: 10;
  .svg-icon {
    margin-top: 2px;
    position: absolute;
    right: 50px;
  }
}
.page-other-sider {
  transition: none;
}
</style>
