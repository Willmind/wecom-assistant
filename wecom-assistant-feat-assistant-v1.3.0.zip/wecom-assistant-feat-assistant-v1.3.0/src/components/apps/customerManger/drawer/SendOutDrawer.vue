<template>
  <BasicDrawer
    :register="registerDrawer"
    showFooter
    width="560px"
    title="发送设置"
    okText="确定"
    @ok="handleConfirm"
    :loading="state.loading"
    @visible-change="handelVisibleChange"
  >
    <div class="container">
      <div class="edit-box jz-flex jz-flex-col">
        <div class="info jz-flex-1 jz-flex jz-flex-col">
          <div class="item jz-flex">
            <span class="label" style="font-weight: 600">休眠时间段</span>
            <div class="jz-flex-1 jz-input"><a-switch v-model:checked="is_dormancy" /></div>
          </div>
          <div class="item jz-flex jz-flex-cc" v-if="is_dormancy">
            <span class="label">每日</span>
            <div class="jz-flex-1 jz-input jz-flex jz-flex-rl">
              <div
                ref="picker1"
                class="time-picker jz-flex jz-flex-center"
                @click.stop.prevent="handleShowTime(1)"
                :class="state.timeType === 1 && 'current'"
              >
                <span>{{ form.dormancy_time_start }}</span>
              </div>
              <span class="dot jz-flex jz-flex-center">-</span>
              <div
                ref="picker2"
                class="time-picker jz-flex jz-flex-center"
                @click.stop.prevent="handleShowTime(2)"
                :class="state.timeType === 2 && 'current'"
              >
                <span>{{ form.dormancy_time_end }}</span>
              </div>
            </div>
          </div>
          <div class="item jz-flex" style="margin-top: 32px">
            <span class="label jz-flex jz-flex-rr jz-flex-cc" style="font-weight: 600">每日上限设置</span>
            <div class="jz-flex-1 jz-input jz-flex jz-flex-cc">
              <a-input-number
                v-model:value="form.upper_limit"
                :min="1"
                :controls="false"
                @input="changeUpperNum"
              />
              <span style="margin: 0 32px 0 8px">次</span>
              <a-button
                @click="form.upper_limit = 100"
                style="border-color: #eee"
                :disabled="upperBtnDisabled"
                >恢复推荐值</a-button
              >
            </div>
          </div>
          <div class="item jz-flex" style="margin: 10px 0 16px 0px">
            <span class="label"></span>
            <div class="jz-flex-1 jz-input color-gray">每日发送好友申请上限次数</div>
          </div>
          <div class="item jz-flex">
            <span class="label jz-flex jz-flex-rr jz-flex-cc" style="font-weight: 600">
              添加好友间隔
              <a-tooltip placement="top">
                <template #title>
                  <span>从上一个好友申请发送时间到下一个好友申请发送时间的间隔。</span>
                </template>
                <question-circle-outlined class="ask" />
              </a-tooltip>
            </span>
            <div class="jz-flex-1 jz-input jz-flex jz-flex-rl">
              <a-input-number
                v-model:value="form.frequency_start"
                :min="1"
                :controls="false"
                @input="changeFrequencyStart"
              />
              <span class="dot jz-flex jz-flex-center">-</span>
              <a-input-number
                v-model:value="form.frequency_end"
                :min="1"
                :controls="false"
                @input="changeFrequencyEnd"
              />
              <span style="line-height: 32px; margin: 0 32px 0 8px">秒</span>
              <a-button @click="updatefrequency" style="border-color: #eee" :disabled="btnDisabled"
                >恢复推荐值</a-button
              >
            </div>
          </div>
          <div class="item jz-flex">
            <span class="label"></span>
            <div class="jz-flex-1 jz-input color-gray">自动通过新客户申请的时间区间</div>
          </div>
        </div>
        <div
          class="time-box jz-flex jz-flex-col"
          v-if="state.showTime"
          @click.stop.prevent
          v-click-outside="hideOutside"
          :style="computedStyle"
        >
          <div class="jz-flex-1 jz-flex">
            <ul class="time-ul jz-flex-1 jz-flex jz-flex-col">
              <li
                v-for="(item, index) in state.hourArr"
                :key="index"
                :class="item.check && 'current'"
                @click="selectHour(item)"
              >
                {{ item.num }}
              </li>
            </ul>
            <ul class="time-ul jz-flex-1 jz-flex jz-flex-col">
              <li
                v-for="(item, index) in state.minArr"
                :key="index"
                :class="item.check && 'current'"
                @click="selectMin(item)"
              >
                {{ item.num }}
              </li>
            </ul>
          </div>
          <div class="time-btn jz-flex jz-flex-rr jz-flex-cc">
            <a-button type="primary" @click="hideOutside">确定</a-button>
          </div>
        </div>
      </div>
    </div>
    <template #footer>
      <div class="jz-flex jz-flex-rr">
        <a-button style="margin-right: 10px" @click="closeDrawer">取消</a-button>
        <a-button type="primary" @click="onsubmit">保存</a-button>
      </div>
    </template>
  </BasicDrawer>
</template>
<script setup>
import { useDrawerInner } from '@/components/basic/drawer'
import { reactive } from 'vue'
import datajs from 'dayjs'
import useMessage from '@/composables/web/useMessage'
import { getAddSetting, addSetting } from '@/api/customerManager'
import { addZero } from '@/assets/js/utils'
import { nextTick } from 'process'
const { createMessage } = useMessage()
const is_dormancy = ref(false)
const isLock = ref(false)
const emit = defineEmits(['success'])
const state = reactive({
  hourArr: [],
  minArr: [],
  showTime: false,
  timeType: 1,
  loading: false
})
const picker1 = ref(null)
const picker2 = ref(null)
const form = reactive({
  upper_limit: 1,
  frequency_start: 20,
  frequency_end: 30,
  dormancy_time_start: '00:00', // 休眠开始时间
  dormancy_time_end: '00:08' // 休眠开始时间
})

defineProps({
  register: Function
})

// ========================methods

const hideOutside = () => {
  state.timeType = -1
  state.showTime = false
}

const changeFrequencyStart = (val) => {
  let str = val + ''
  if (str.length >= 4) {
    nextTick(() => {
      form.frequency_start = val.slice(0, 3)
    })
  }
}

const changeFrequencyEnd = (val) => {
  let str = val + ''
  if (str.length >= 4) {
    nextTick(() => {
      form.frequency_end = val.slice(0, 3)
    })
  }
}

const changeUpperNum = (val) => {
  let str = val + ''
  if (str.length >= 5) {
    nextTick(() => {
      form.upper_limit = val.slice(0, 4)
    })
  }
}

// 选择时
const selectHour = (item) => {
  if (state.timeType === 1) {
    form.dormancy_time_start = item.num + ':' + form.dormancy_time_start.split(':')[1]
  } else {
    form.dormancy_time_end = item.num + ':' + form.dormancy_time_end.split(':')[1]
  }

  state.hourArr.forEach((i) => (i.check = false))
  item.check = true
}

// 选择秒
const selectMin = (item) => {
  if (state.timeType === 1) {
    form.dormancy_time_start = form.dormancy_time_start.split(':')[0] + ':' + item.num
  } else {
    form.dormancy_time_end = form.dormancy_time_end.split(':')[0] + ':' + item.num
  }
  state.minArr.forEach((i) => (i.check = false))
  item.check = true
}

// 选择时间
const handleShowTime = (type) => {
  state.timeType = type
  state.showTime = true
  if (form.dormancy_time_start) {
    let _tagArr = type === 1 ? form.dormancy_time_start.split(':') : form.dormancy_time_end.split(':')
    state.hourArr.forEach((i) => (i.check = i.num === _tagArr[0]))
    state.minArr.forEach((i) => (i.check = i.num === _tagArr[1]))
  }
  if (form.dormancy_time_end) {
    let _tagArr = type === 1 ? form.dormancy_time_start.split(':') : form.dormancy_time_end.split(':')
    state.hourArr.forEach((i) => (i.check = i.num === _tagArr[0]))
    state.minArr.forEach((i) => (i.check = i.num === _tagArr[1]))
  }
}
// 恢复默认值
const updatefrequency = () => {
  form.frequency_start = 20
  form.frequency_end = 30
}

// 获取任务设置信息
const getSettingInfo = async () => {
  initTime()
  let { code, data } = await getAddSetting()
  if (code === 1000) {
    let { is_dormancy: dormancy, frequency_start, frequency_end, upper_limit } = data
    is_dormancy.value = dormancy === 1 ? true : false
    form.dormancy_time_start = data.dormancy_time_start
    form.dormancy_time_end = data.dormancy_time_end
    form.frequency_start = +frequency_start
    form.frequency_end = +frequency_end
    form.upper_limit = upper_limit
  }
}
const initTime = () => {
  state.hourArr = new Array(24).fill(0).map((i, index) => {
    return {
      num: addZero(index),
      check: false
    }
  })
  state.minArr = new Array(60).fill(0).map((i, index) => {
    return {
      num: addZero(index),
      check: false
    }
  })
}
// 提交
const onsubmit = () => {
  if (+form.frequency_start > +form.frequency_end) {
    createMessage.warn('开始频率数不能大于结束频率数')
    return
  }
  if (isLock.value) {
    return
  }
  isLock.value = true
  let _startTime = datajs(form.dormancy_time_start, 'HH:mm')
  let _endTime = datajs(form.dormancy_time_end, 'HH:mm')
  let dormancy_time_start = addZero(_startTime.$H) + ':' + addZero(_startTime.$m)
  let dormancy_time_end = addZero(_endTime.$H) + ':' + addZero(_endTime.$m)
  let params = {
    dormancy_time_start,
    dormancy_time_end,
    is_dormancy: is_dormancy.value ? 1 : 0,
    upper_limit: form.upper_limit,
    frequency_start: form.frequency_start,
    frequency_end: form.frequency_end
  }
  addSetting(params)
    .then((res) => {
      if (res.code === 1000) {
        createMessage.success('设置成功')
        emit('success')
        closeDrawer()
      }
    })
    .finally(() => {
      isLock.value = false
    })
}

const computedStyle = computed(() => {
  let leftNum = ''
  if (state.timeType === 1) {
    leftNum = picker1.value.offsetLeft + 'px'
  } else {
    leftNum = picker2.value.offsetLeft + 'px'
  }
  return `left:${leftNum}`
})

const upperBtnDisabled = computed(() => {
  return +form.upper_limit === 100 ? true : false
})
const btnDisabled = computed(() => {
  return form.frequency_start === 20 && form.frequency_end === 30
})

// 抽屉参数
const [registerDrawer, { closeDrawer }] = useDrawerInner()

// 抽屉展示关闭
const handelVisibleChange = (val) => {
  if (val) {
    getSettingInfo()
  }
}

// 确认提交
const handleConfirm = () => {
  closeDrawer()
}
</script>
<style lang="less" scoped>
.edit-box {
  padding: 0px 12px 20px;
  width: 100%;
  height: 100%;
  position: relative;
  font-size: 14px;
  margin-top: 8px;
  .tit {
    margin-bottom: 8px;
    color: @font-minor-color;
  }
  .dot {
    width: 16px;
    height: 100%;
    color: #999;
  }
  .color-gray {
    color: @font-minor-color;
  }
  .info {
    .item {
      width: 100%;
      margin-top: 16px;
      position: relative;
      .label {
        font-weight: 500;
        margin-right: 32px;
        width: 104px;
        text-align: right;
        position: relative;
        color: @font-body-color;
      }
      .ask {
        position: absolute;
        right: -20px;
        color: #999;
      }
    }
    .line {
      margin: 48px 0;
      width: 100%;
      height: 0.5px;
      background: #eee;
    }
  }
}

.time-picker {
  width: 54px;
  height: 32px;
  font-size: 14px;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  border: 1px solid #eeeeee;
  &.current {
    border: 1px solid #3165f5;
  }
}
.time-box {
  position: absolute;
  width: 168px;
  height: 344px;
  border-radius: 5px;
  left: 130px;
  top: 95px;
  right: 0;
  background: #fff;
  z-index: 100;
  box-shadow: 0px 0px 24px 0px rgba(0, 0, 0, 0.2);
  > div {
    width: 100%;
    height: 100%;
    overflow-y: auto;
  }
  .time-ul {
    width: 100%;
    height: 100%;
    overflow-y: auto;
    padding: 8px 8px 0;
    li {
      width: 100%;
      height: 40px;
      line-height: 40px;
      text-align: center;
      cursor: pointer;
      &:hover {
        background: #f5f5f5;
        border-radius: 4px;
      }
      &.current {
        background: #ebf0fe;
        color: #3165f5;
        border-radius: 4px;
      }
    }
  }
  .time-btn {
    width: 100%;
    height: 56px;
    padding-right: 12px;
  }
}
:deep(.ant-input-number) {
  width: 65px;
  border-radius: 6px;
}
:deep(.ant-input-number-input) {
  border-radius: 6px;
  text-align: center;
}
:deep(.ant-input-number-input:hover) {
  border-radius: 6px;
  border-color: #3165f5;
}
:deep(.ant-radio-inner) {
  border-color: rgba(0, 0, 0, 0.1);
}
:deep(.ant-radio-checked .ant-radio-inner) {
  border-color: #3165f5;
}
:deep(.ant-radio-inner::after) {
  background-color: #3165f5;
}
</style>
