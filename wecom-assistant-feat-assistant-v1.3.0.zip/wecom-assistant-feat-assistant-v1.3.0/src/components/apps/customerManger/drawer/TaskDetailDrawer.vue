<template>
  <BasicDrawer
    :register="registerDrawer"
    :showFooter="false"
    width="864px"
    okText="确定"
    :showClose="false"
    @visible-change="handelVisibleChange"
  >
    <template #title>
      <div class="head jz-flex jz-flex-cc">
        <span class="back-btn jz-flex jz-flex-center jz-pointer" @click="close">
          <svg-icon icon-name="login_back" style="width: 32px; height: 32px" />
        </span>
        <span class="tit">任务详情</span>
      </div>
    </template>
    <div class="container">
      <a-tabs v-model:activeKey="state.activeKey">
        <a-tab-pane key="1" tab="发送对象">
          <div class="task-form jz-flex">
            <a-form layout="inline">
              <a-form-item style="width: 311px">
                <a-input
                  class="keywork-search-input"
                  v-model:value="form.keyword"
                  allowClear
                  placeholder="微信昵称/手机号/群名"
                >
                  <template #suffix v-if="!form.keyword"> <svg-icon icon-name="ic_search" /> </template
                ></a-input>
              </a-form-item>
              <a-form-item style="width: 146px; margin-right: 16px">
                <a-select
                  v-model:value="form.type"
                  :options="state.typeList"
                  placeholder="客户群"
                  allow-clear
                />
              </a-form-item>
              <a-form-item style="width: 146px; margin-right: 0px">
                <a-select
                  v-model:value="form.status"
                  :options="state.statusList"
                  placeholder="状态"
                  allow-clear
                />
              </a-form-item>
            </a-form>
          </div>
          <div class="table-box">
            <a-table
              row-key="id"
              :columns="state.columns"
              :data-source="state.list"
              :bordered="false"
              :pagination="false"
            >
              <template #bodyCell="{ column, record }">
                <template v-if="column.key === 'customerAction'">
                  <div class="jz-flex jz-flex jz-flex-cc">
                    <img :src="record.avatar" alt="" style="width: 40px; height: 40px; border-radius: 8px" />
                    <div
                      class="jz-flex jz-felx-l jz-flex-col"
                      style="margin-left: 16px"
                      v-if="record.msg_member_type === 1"
                    >
                      <span>{{ record.name }}</span>
                      <span style="color: #57be6a" v-if="record.wx_type === 1">@ 微信</span>
                      <span style="color: #eda150" v-if="!+record.wx_type">@ 企业微信</span>
                    </div>
                    <div class="jz-flex jz-felx-l jz-flex-col" style="margin-left: 16px" v-else>
                      <span>{{ record.name }}</span>
                      <span style="color: #999">群成员：{{ record.number }}</span>
                    </div>
                  </div>
                </template>
                <template v-if="column.key === 'send_time_action'">
                  <span v-if="record.send_time">{{
                    dayjs(+record.send_time * 1000).format('YYYY-MM-DD HH:mm:ss')
                  }}</span>
                </template>
                <template v-if="column.key === 'action'">
                  <div v-if="record.msg_member_status !== 3">
                    <span v-if="+record.msg_member_status === 1" class="wait-dot jz-flex jz-flex-cc"
                      ><i></i>
                      等待中
                    </span>
                    <span v-else-if="+record.msg_member_status === 2" class="apply-dot jz-flex jz-flex-cc"
                      ><i></i>已发送申请</span
                    >
                    <span v-else style="color: #999">{{ record.msg_member_status_val }}</span>
                  </div>
                  <div v-else style="color: #999">
                    <span class="jz-flex jz-flex-cc">
                      {{ record.msg_member_status_val }} . {{ record.fail_msg }}
                    </span>
                  </div>
                </template>
              </template>

            </a-table>
          </div>
          <div class="pagination-box" v-if="state.activeKey === '1'">
            <basic-pagination @change="pageChange" :params="state.paginationParams">
              <template #extra>
                <span class="page-total">共 {{ state.paginationParams.total }} 条</span>
              </template>
            </basic-pagination>
          </div>
        </a-tab-pane>
        <a-tab-pane key="2" tab="发送内容">
          <div class="msg-detail jz-flex jz-flex-col">
            <div class="msg-item jz-flex" v-if="state.group_content">
              <div class="msg-label">群公告内容</div>
              <div class="jz-flex-1" style="overflow-y: auto; height: 100%">
                {{ state.group_content }}
              </div>
            </div>
            <div class="msg-item jz-flex">
              <div class="msg-label">群发内容</div>
              <div class="jz-flex-1" style="overflow-y: auto; height: 100%">
                <div class="card-list jz-flex jz-flex-col">
                  <draggable
                    handle=".menu-handle"
                    itemKey="uid"
                    :component-data="{
                      tag: 'div',
                      type: 'transition-group',
                      name: !state.isDrag ? 'flip-list' : null
                    }"
                    v-model="state.auto_message_config"
                  >
                    <template #item="{ element: item, index }">
                      <div class="card-item-wrap jz-flex jz-flex-cc" :key="index">
                        <div class="card-item jz-flex">
                          <div class="card-num jz-flex jz-flex-center">{{ getMsgNumber(index) }}</div>
                          <div class="card-content">
                            <MessageCardWithType :item="item" :msgType="item.msg_type" />
                          </div>
                        </div>
                      </div>
                    </template>
                  </draggable>
                </div>
              </div>
            </div>
          </div>
        </a-tab-pane>
      </a-tabs>
    </div>
  </BasicDrawer>
</template>
<script setup>
import dayjs from 'dayjs'
import draggable from 'vuedraggable'
import { useDrawerInner } from '@/components/basic/drawer'
import { reactive } from 'vue'
import { cloneDeep, debounce } from 'lodash-es'
import { getTask, getTaskMember } from '@/api/customerManager'
const columns = [
  { title: '序号', dataIndex: 'index', key: 'index', width: '80px' },
  { title: '客户', key: 'customerAction', width: '270px' },
  { title: '实际发送时间', key: 'send_time_action', width: '270px' },
  { title: '状态', key: 'action', width: '200px' }
]
defineProps({
  register: Function
})

const form = reactive({
  id: '',
  type: undefined,
  status: undefined,
  time: '',
  keyword: ''
})
const state = reactive({
  visible: false,
  activeKey: '1',
  paginationParams: {
    total: 0,
    current: 1,
    showSizeChanger: false
  },
  list: [],
  loading: false,
  typeList: [
    { label: '客户/客户群', value: 0 },
    { label: '客户', value: 1 },
    { label: '客户群', value: 2 }
  ],
  statusList: [
    { label: '等待中', value: 1 },
    { label: '已完成', value: 2 },
    { label: '未完成', value: 3 }
  ],
  columns: columns,
  group_content: '',
  auto_message_config: []
})

// 监听=======
watch(
  () => form,
  () => {
    state.paginationParams.current = 1
    const params = unref(getParams)
    debounceSearch(toRaw(params))
  },
  {
    deep: true
  }
)

watch(
  () => unref(state).activeKey,
  (val) => {
    val === '2' && !state.auto_message_config.length && handleGetTask()
  }
)

// computed==========

// 获取form参数
const getParams = computed(() => {
  const deepData = cloneDeep(form)
  return {
    ...deepData,
    type: deepData.type || undefined,
    add_time_start: deepData?.time?.length ? dayjs(deepData.time[0])?.unix?.() : undefined,
    add_time_end: deepData?.time?.length ? dayjs(deepData.time[1])?.unix?.() : undefined,
    status: deepData.status,
    time: undefined,
    page: state.paginationParams.current,
    limit: 10
  }
})

// ========================methods

const close = () => {
  state.list = []
  state.paginationParams.current = 1
  state.paginationParams.total = 0
  state.auto_message_config = []
  state.activeKey = '1'
  form.type = undefined
  form.status = undefined
  form.keyword = undefined
  closeDrawer()
}

const getMsgNumber = (index) => {
  return +index + 1 < 10 ? `0${index + 1}` : index + 1
}

const handleGetTask = async () => {
  let { data } = await getTask({ id: form.id })
  state.group_content = data.group_content
  data.send_content = data.send_content.map((i) => {
    return {
      msg_type: i.msg_type,
      msg: {
        ...i
      }
    }
  })
  state.auto_message_config = data.send_content
}

const querySearch = async (params) => {
  state.loading = true
  let { data } = await getTaskMember(params)
  data.list.forEach((i, index) => (i.index = index + 1))
  state.list = data.list
  state.paginationParams.total = data.total
  state.loading = false
}

// 页码回调
const pageChange = (_params) => {
  state.paginationParams.current = _params.current
  const params = unref(getParams)
  debounceSearch(toRaw(params))
}

// 抽屉参数
const [registerDrawer, { closeDrawer }] = useDrawerInner((res) => {
  form.id = res.id
})

// 抽屉展示关闭
const handelVisibleChange = (val) => {
  if (!val) {
    close()
  } else {
    const params = unref(getParams)
    debounceSearch(toRaw(params))
  }
}

const debounceSearch = debounce(querySearch, 350)
</script>
<style lang="less" scoped>
.head {
  position: relative;
  display: flex;
  padding: 16px 0;
  .tit {
    font-size: 20px;
    font-weight: bold;
  }
  .back-btn {
    width: 32px;
    height: 32px;
    margin-right: 8px;
  }
}
.msg-item {
  width: 100%;
  margin-bottom: 32px;
  .msg-label {
    width: 102px;
    text-align: right;
    padding-right: 32px;
    font-weight: bold;
  }
}
.card-list {
  width: 100%;
  .card-item-wrap {
    width: 100%;
    &:hover {
      .card-item .card-extra .operate-btns {
        visibility: visible;
        .svg-icon {
          width: 24px !important;
          height: 24px !important;
          padding: 4px;
          &:hover {
            background: rgba(0, 0, 0, 0.04);
            border-radius: 4px;
          }
        }
      }
      :deep(.anticon-menu) {
        visibility: visible;
      }
    }
    :deep(.anticon-menu) {
      margin-right: 12px;
      padding-top: 3px;
      visibility: hidden;
      :hover {
        color: @primary-color;
      }
    }
    .card-item {
      flex: auto;
      min-height: 56px;
      padding: 12px;
      background: rgba(0, 0, 0, 0.04);
      border-radius: 6px;
      box-sizing: border-box;
      .card-num {
        width: 24px;
        height: 24px;
        align-items: center;
        border-radius: 50%;
        background: #eeeeee;
        color: #000000;
        font-size: 12px;
        margin-right: 16px;
      }
      .card-content {
        flex: auto;
      }

      .card-extra {
        flex: none;
        display: flex;
        align-items: flex-start;
        .operate-btns {
          height: 32px;
          visibility: hidden;
          > * {
            margin-right: 16px;
            cursor: pointer;
          }
        }
        .time-bar {
          > span {
            margin-right: 12px;
            color: rgba(0, 0, 0, 0.4);
          }
          .time-input {
            :deep(.ant-input-number-input-wrap) {
              width: 56px;
            }
          }
        }
      }
    }
    + .card-item-wrap {
      margin-top: 12px;
    }
    + .add-content {
      margin-top: 16px;
    }
  }
}
.wait-dot,
.apply-dot {
  i {
    width: 6px;
    height: 6px;
    display: block;
    border-radius: 50%;
    margin-right: 10px;
    background: #ed7b2f;
  }
}
.apply-dot {
  i {
    background: #06d1d1;
  }
}
.container {
  padding: 18px 32px 0px;
  overflow: hidden;
  height: 100%;
  .tip {
    color: #ed7b2f;
    margin: 24px 0 12px 0;
    > div {
      margin-left: 11px;
    }
  }
}
.table-box {
  margin-top: 24px;
}

.page-total {
  margin-left: 8px;
  color: @font-minor-color;
}
.popover-p {
  height: 40px;
  line-height: 40px;
  margin-bottom: 0px;
  padding: 0 8px;
  &:hover {
    background: #f5f5f5;
  }
}
.pagination-box {
  position: absolute;
  left: 0;
  bottom: 0;
  right: 0;
  height: 64px;
  padding: 0 32px;
  background: #fff;
}
:deep(.basic-drawer__body) {
  overflow-y: hidden;
}
:deep(.ant-tabs-top) {
  height: 100%;
}
:deep(.ant-tabs-content-holder) {
  height: 100%;
  overflow: auto;
}
:deep(.ant-tabs-tab + .ant-tabs-tab) {
  margin: 0 0 0 80px;
}
:deep(.ant-tabs-nav) {
  margin-bottom: 24px;
}
:deep(.ant-table-thead > tr > th) {
  color: @font-minor-color;
  border-bottom: none;
}
::-webkit-scrollbar {
  width: 0px;
  height: 0px;
}
:deep(.ant-table-thead
    > tr
    > th:not(:last-child):not(.ant-table-selection-column):not(.ant-table-row-expand-icon-cell):not([colspan])::before) {
  width: 0;
}
</style>
