<template>
  <BasicDrawer
    :register="registerDrawer"
    innerPage
    showForehead
    okText="确定"
    @ok="handleConfirm"
    :loading="state.loading"
    :mask="false"
    :disabled="computedLock"
    :showClose="false"
    :showFooter="true"
    :push="false"
    classes="editor-drawer"
    :cancelBtnProps="{ disabled: false }"
    @visible-change="handelVisibleChange"
    :get-container="false"
  >
    <template #title>
      <div class="head jz-flex jz-flex-cc">
        <a-tooltip placement="top">
          <template #title>
            <span>返回</span>
          </template>
          <span class="back-btn jz-flex jz-flex-center jz-pointer" @click="closeDrawer">
            <svg-icon icon-name="login_back" style="width: 32px; height: 32px" />
          </span>
        </a-tooltip>

        <span class="tit">主动加好友</span>
        <div class="jz-flex jz-flex-1 jz-flex-cc jz-flex-rr">
          <span style="margin-right: 24px"
            >添加好友时间间隔：{{ state.frequency_start }}-{{ state.frequency_end }}秒
          </span>
          <a-button style="margin-right: 8px" @click="openSendDrawer">发送设置</a-button>
          <a-badge :count="state.ongoing">
            <a-button @click="openTaskListDrawer">任务列表</a-button>
          </a-badge>
        </div>
      </div>
    </template>

    <div class="container">
      <div class="tip jz-flex jz-flex-cc">
        <exclamation-circle-filled style="color: #ed7b2f; font-size: 17px" />
        <div>
          今日已发送 {{ state.success_total }}/{{ state.total }}
          次好友申请，已添加过的好友勿重复添加避免打扰用户。
        </div>
      </div>
      <div class="content">
        <div class="task-tit">任务设置</div>
        <div class="item jz-flex jz-flex-cc">
          <div class="label">任务标题</div>
          <div class="jz-flex-1">
            <a-input
              placeholder="请输入标题"
              style="width: 226px"
              v-model:value="modelRef.title"
              :maxlength="15"
            />
            <span style="margin-left: 8px; color: #999">{{ modelRef.title.length }}/15</span>
          </div>
        </div>
        <div class="item jz-flex">
          <div class="label">主动加好友</div>
          <div class="jz-flex-1 jz-flex jz-flex-col">
            <a-radio-group v-model:value="modelRef.type" :options="state.friendOptions" />
            <div class="item-camp jz-flex jz-flex-col">
              <div class="jz-flex jz-flex-cc" style="height: 72px">
                <div class="jz-flex-1" v-if="modelRef.type === 1">
                  <div class="name lineClamp1" v-if="modelRef.camp_info">
                    《{{ state.product_name }}》{{ modelRef.camp_info.term_date }} 期-{{
                      ['未添加', '曾添加', '未添加&曾添加'][modelRef.camp_info.status - 1]
                    }}学员
                  </div>
                  <div class="num lineClamp1">{{ modelRef.mobile_term_List.length }} 个有效手机号</div>
                </div>
                <div class="jz-flex-1 jz-flex-col" v-else s>
                  <span style="padding-left: 12px">添加手机号</span>
                  <div class="num lineClamp1">{{ modelRef.mobile_manual_List.length }} /1000</div>
                </div>
                <div class="camp-box jz-flex jz-flex-cc jz-flex-rr">
                  <template v-if="modelRef.type === 2">
                    <PhoneGroupPopover :ids="getSelectedPhoneIds()" @success="handleSelectedphoneGroup">
                      <a-button style="margin-right: 8px">手动输入</a-button>
                    </PhoneGroupPopover>
                    <a-button>导入表格 <input type="file" class="fileBtn" @change="readExcel" /></a-button>

                    <ExcelPopover>
                      <a-button type="link">Excel 格式</a-button>
                    </ExcelPopover>

                    <a-button
                      type="link"
                      @click="handleEmptyManual"
                      :disabled="!unref(modelRef).mobile_manual_List.length"
                      >清空</a-button
                    >
                  </template>
                  <template v-else>
                    <UpdateStudentPopover @success="getTermMobile">
                      <a-button style="margin-right: 12px">更改/学员详情</a-button>
                    </UpdateStudentPopover>
                  </template>
                </div>
              </div>
              <div class="info jz-flex-1 jz-flex jz-flex-wrap" v-if="modelRef.type === 1">
                <span v-for="(item, index) in modelRef.mobile_term_List" :key="index"
                  >{{ item }}{{ index === modelRef.mobile_manual_List.length - 1 ? '' : '、' }}</span
                >
              </div>
              <div class="info jz-flex-1 jz-flex jz-flex-wrap" v-else>
                <span v-for="(item, index) in modelRef.mobile_manual_List" :key="index"
                  >{{ item }}{{ index === modelRef.mobile_manual_List.length - 1 ? '' : '、' }}</span
                >
              </div>
            </div>
          </div>
        </div>
        <div class="item jz-flex">
          <div class="label">验证消息选填</div>
          <div class="jz-flex-1 jz-flex jz-flex-col">
            <a-textarea
              ref="inputRef"
              :maxlength="50"
              placeholder="请输入验证消息"
              v-model:value="modelRef.verify_msg"
              style="width: 643px"
            />
            <span style="margin-top: 10px; color: #999">{{ modelRef.verify_msg.length }}/50</span>
          </div>
        </div>
        <div class="item jz-flex jz-flex-cc">
          <div class="label">添加客户账号</div>
          <div class="jz-flex-1 jz-flex">
            <a-checkbox-group v-model:value="modelRef.wx_type">
              <a-checkbox value="1">微信</a-checkbox>
              <!-- <a-checkbox value="0">企业微信号</a-checkbox> -->
            </a-checkbox-group>
          </div>
        </div>
        <div class="item jz-flex">
          <div class="label">自动打标签</div>
          <div class="jz-flex" style="width: 645px">
            <CustomTagPopover
              is-search
              :limit="10"
              :data="{ label_id: modelRef.auto_label_config.label }"
              @select-change="handleSelectedLabel"
            >
              <rich-input
                tag-mode
                :allowInput="false"
                :fieldName="{ label: 'name', value: 'id' }"
                v-model:tagsOption="modelRef.auto_label_config.label"
                placeholder="请选择标签"
                :setTagClass="
                  (item) =>
                    item?.type ? (item.type === 2 ? 'ant-tag-personal' : 'ant-tag-primary') : 'ant-tag-plain'
                "
              />
            </CustomTagPopover>
          </div>
        </div>
        <div class="line"></div>
        <div class="remark jz-flex jz-flex-cc">
          <label>自动备注</label>
          <a-switch v-model:checked="modelRef.is_auto_remark" :checkedValue="1" :unCheckedValue="0" />
        </div>
        <div class="item jz-flex">
          <div class="label">处理规则</div>
          <div class="jz-flex-1 jz-flex jz-flex-col rule">
            <span>打招呼时，手机号对应的微信</span>
            <span>· 若为新好友</span>
            <span
              >优先执行此处设置的自动备注，此处未设置则执行 <label>新客户运营</label> 内设置的自动备注</span
            >
            <span>· 若已是好友</span>
            <a-radio-group v-model:value="modelRef.auto_remark_rule" :options="state.updateRemarkOptions" />
          </div>
        </div>
        <div class="item jz-flex">
          <div class="label">备注内容</div>
          <div class="jz-flex jz-flex-col jz-flex-1" style="width: 645px">
            <div class="tag-group jz-flex">
              <a-tag
                class="ant-tag-plain ant-tag-big"
                v-for="(item, index) in state.remarkOptions"
                :key="index"
                style="margin-bottom: 0"
                @click="handleSelectedTag(item)"
                >{{ item }}</a-tag
              >
            </div>
            <div class="rich-input">
              <RichEdtior
                bordered
                ref="richRef"
                :value="modelRef.remarkJSON"
                :toolbar="['tag']"
                :autoRows="{ minRow: 2 }"
                placeholder="请输入备注"
                @change="handleRemarkContentChange"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--发送设置-->
    <SendOutDrawer :register="sendDrawer" @success="() => sendCallBack()" />
    <!--任务列表-->
    <TaskListDrawer
      :register="taskListDrawer"
      @success="(data) => taskCallBack(data)"
      @close="() => getAddSetCofig()"
    />
  </BasicDrawer>
</template>
<script setup>
import { cloneDeep } from 'lodash-es'
import { useDrawerInner, useDrawer } from '@/components/basic/drawer'
import CustomTagPopover from '../comps/CustomTagPopover.vue'
import PhoneGroupPopover from '../comps/PhoneGroupPopover.vue'
import UpdateStudentPopover from '../comps/UpdateStudentPopover.vue'
import ExcelPopover from '../comps/ExcelPopover.vue'
import SendOutDrawer from './SendOutDrawer.vue'
import TaskListDrawer from './TaskListDrawer.vue'

import useMessage from '@/composables/web/useMessage'
import { phoneReg } from '@/assets/js/utils'
import { addTask, getAddSetting, statisticAddFriend } from '@/api/customerManager'
import { getTranformJSONContentToText, getTranformRemarkToJSONContent } from '@/utils/customer'
import { computed, toRaw, unref } from 'vue'
const { createMessage } = useMessage()
const [sendDrawer, { openDrawer: openSendDrawer }] = useDrawer()
const [taskListDrawer, { openDrawer: openTaskListDrawer }] = useDrawer()
defineProps({
  register: Function
})

// ========================变量
const state = reactive({
  total: 0,
  ongoing: 0,
  success_total: 0,
  product_name: '',
  term_date: '',
  loading: true,
  frequency_start: '',
  frequency_end: '',
  friendOptions: [
    { label: '按期数-未添加学员', value: 1 },
    { label: '手动添加手机号', value: 2 }
  ],
  customerOptions: ['微信号', '企业微信号'],
  updateRemarkOptions: [
    { label: '不更新备注', value: 1 },
    { label: '按照此处设置更新备注', value: 2 }
  ],
  form: {
    title: '',
    type: 1,
    verify_msg: '',
    remarkJSON: null,
    wx_type: ['1'],
    is_auto_remark: 0,
    auto_remark_rule: 1,
    camp_info: null,
    auto_remark_config: {
      remark: [],
      data: []
    },
    auto_label_config: {
      label: []
    },
    mobile_term_List: [], // 期数电话号码
    mobile_manual_List: [] // 手动添加号码
  },
  remarkOptions: ['微信昵称', '性别', '添加日期']
})
const modelRef = toRef(state, 'form')
const richRef = ref()

//=========================computed

const computedLock = computed(() => {
  let _lock = false
  if (!unref(modelRef).title || !unref(modelRef).wx_type.length) {
    _lock = true
  }
  if (unref(modelRef).type === 1 && !unref(modelRef).mobile_term_List.length) {
    _lock = true
  }
  if (unref(modelRef).type === 2 && !unref(modelRef).mobile_manual_List.length) {
    _lock = true
  }
  return _lock
})

// ========================methods

// 清空手机号
const handleEmptyManual = () => {
  unref(modelRef).mobile_manual_List = []
  createMessage.info('至少添加一个手机号')
}

const handleRemarkContentChange = ({ json }) => {
  unref(modelRef).auto_remark_config.remark = getTranformJSONContentToText(json)
}

// 更改学员回调参数
const getTermMobile = (arr, params) => {
  let originArr = toRaw(unref(modelRef).mobile_term_List)
  unref(modelRef).mobile_term_List = [...new Set([...originArr, ...arr])]
  unref(modelRef).camp_info = { ...params }
  state.product_name = params.camp_name
}

// 已选电话号码
const getSelectedPhoneIds = () => {
  return unref(modelRef).mobile_manual_List
}

const sendCallBack = () => {
  getAddSetCofig()
}

// 任务列表回调
const taskCallBack = (data) => {
  data.wx_type = (data.wx_type + '').split(',')
  state.form = Object.assign({}, state.form, data || {})
  if (data.type === 1) {
    state.form.mobile_term_List = [...data.mobile]
  } else {
    state.form.mobile_manual_List = [...data.mobile]
  }
  state.product_name = data.camp_info.camp_name
  state.form.remarkJSON = getTranformRemarkToJSONContent(state.form.auto_remark_config?.data)
  state.form.auto_remark_config.remark = getTranformJSONContentToText(state.form.remarkJSON)
}

// 已选电话号码回调
const handleSelectedphoneGroup = (arr = []) => {
  let originArr = toRaw(unref(modelRef).mobile_manual_List)
  unref(modelRef).mobile_manual_List = [...new Set([...originArr, ...arr])]
}

// 选择自动打标签
const handleSelectedLabel = (res) => {
  let labelValues = toRaw(unref(modelRef).auto_label_config.label)?.map((i) => i.value)
  res?.tags.forEach((i) => {
    if (!labelValues.includes(i.value)) {
      unref(modelRef).auto_label_config.label.push(i)
    }
  })
}

// 选择备注标签
const handleSelectedTag = (tag) => {
  unref(richRef).editorRef.chain().focus().setTag(tag).run()
}

// 转换数据
const getTranformParams = (res = {}) => {
  let params = { ...res }

  const {
    auto_remark_config: { remark = '' },
    auto_label_config: { label = [] }
  } = cloneDeep(params)
  if (Array.isArray(params.auto_remark_config.remark)) {
    params.auto_remark_config.remark = ''
  }
  params.wx_type = params.wx_type.join(',')
  params.mobile = params.type === 1 ? params.mobile_term_List.join(',') : params.mobile_manual_List.join(',')
  if (params.type === 1) {
    params.camp_info.term_date = params.camp_info.term_date.replace(/\-/g, '/')
  } else {
    delete params.camp_info
  }

  delete params.mobile_manual_List
  delete params.mobile_term_List
  return {
    ...params,
    auto_label_config: {
      label: label.map((item) => ({
        id: item.value || item.id,
        name: item.label || item.name,
        type: item.type
      }))
    }
  }
}

// 抽屉参数
const [registerDrawer, { closeDrawer }] = useDrawerInner()

const readExcel = (e) => {
  const files = e.target.files
  // 如果没有文件名
  if (files.length <= 0) {
    e.target.value = ''
    return false
  } else if (!/\.(xls|xlsx)$/.test(files[0].name.toLowerCase())) {
    createMessage.warn('上传格式不正确，请上传xls或者xlsx格式')
    e.target.value = ''
    return false
  }
  let fileSize = files[0].size / 1024
  fileSize = parseFloat(fileSize / 1000)
  if (fileSize > 5) {
    e.target.value = ''
    createMessage.warn('上传文件不能大于5M')
    return
  }

  const fileReader = new FileReader()
  fileReader.onload = (ev) => {
    try {
      const data = ev.target.result
      // 切换为新的调用方式
      const workbook = window.XLSX.read(data, {
        type: 'binary'
      })
      // 取第一张表
      const wsname = workbook.SheetNames[0]
      handleExcelData(workbook.Sheets[wsname])
      e.target.value = ''
    } catch (err) {
      console.log(err)
      return false
    }
  }
  fileReader.readAsBinaryString(files[0])
}

// 处理表格数据
const handleExcelData = (excelData) => {
  let reg = /\d/g
  let list = []
  for (let key in excelData) {
    if (key.match(reg) && key !== '!ref') {
      let _arr = Object.values(excelData[key]).filter((i) => phoneReg.test(i) && i)
      if (!_arr.length) {
        list = []
        createMessage.warn('导入数据格式有误')
        return
      }
      list.push(_arr[0])
    }
  }
  // 存在重复号码
  if (list.length && list.length !== [...new Set(list)].length) {
    list = []
    createMessage.warn('存在重复号码请重新导入')
    return
  }
  if (list.length + unref(modelRef).mobile_manual_List.length > 1000) {
    list = []
    createMessage.warn('最多只能导入一千个号码')
    return
  }
  unref(modelRef).mobile_manual_List = [...unref(modelRef).mobile_manual_List, ...list]
  list.length ? createMessage.success('导入成功') : createMessage.warn('导入数据不能为空')
}

// 抽屉展示关闭
const handelVisibleChange = async (val) => {
  if (val) {
    // 获取默认课程
    //getDefault()
    // 获取好友时间
    await getAddSetCofig()
    state.loading = false
  } else {
    close()
  }
}

const close = () => {
  unref(modelRef).title = ''
  unref(modelRef).verify_msg = ''
  unref(modelRef).is_auto_remark = 0
  unref(modelRef).auto_remark_rule = 1
  state.product_name = ''
  state.form.camp_info = null
  unref(modelRef).auto_remark_config = {
    remark: '',
    data: []
  }
  state.form.remarkJSON = getTranformRemarkToJSONContent([])
  state.form.auto_remark_config.remark = getTranformJSONContentToText(state.form.remarkJSON)
  unref(modelRef).auto_label_config = {
    label: []
  }
  unref(modelRef).mobile_term_List = []
  unref(modelRef).mobile_manual_List = []
  unref(modelRef).wx_type = ['1']
}

const getAddSetCofig = async () => {
  let { data } = await getAddSetting()
  state.frequency_start = data.frequency_start
  state.frequency_end = data.frequency_end
  let {
    data: { total, success, ongoing }
  } = await statisticAddFriend()
  state.total = total
  state.success_total = success
  state.ongoing = ongoing
}

// 确认提交
const handleConfirm = async () => {
  const params = toRaw(getTranformParams(state.form))
  let { code } = await addTask(params)
  if (code === 1000) {
    createMessage.success('设置成功')
    closeDrawer()
  }
}
</script>
<style lang="less" scoped>
.head {
  position: relative;
  padding-top: 28px;
  .tit {
    font-size: 20px;
    font-weight: bold;
  }
  .back-btn {
    margin-right: 8px;
    border-radius: 4px;
    padding-left: 0px;
    position: relative;
    width: 32px;
    height: 32px;
    .svg-icon {
      position: absolute;
      left: 8px;
    }
  }
}
.container {
  position: relative;
  padding: 0 32px 32px;
  .tip {
    height: 44px;
    background: rgba(237, 123, 47, 0.1);
    padding-left: 12px;
    border-radius: 8px;
    > div {
      font-size: 14px;
      color: #ed7b2f;
      margin-left: 10px;
    }
  }
  .content {
    width: 100%;
    position: relative;
    margin-top: 48px;
    .task-tit {
      font-size: 20px;
      font-weight: bold;
      margin-bottom: 39px;
    }
    .item {
      width: 100%;
      margin-bottom: 38px;
      .label {
        width: 126px;
        text-align: right;
        padding-right: 32px;
        font-weight: bold;
      }
      .item-camp {
        width: 643px;
        height: 136px;
        margin-top: 16px;
        border-radius: 6px;
        border: 1px solid #eeeeee;
        .name {
          padding-left: 12px;
        }
        .num {
          padding-left: 12px;
          color: #999999;
        }
        .info {
          background: #f5f5f5;
          width: 100%;
          padding: 12px 12px 0px;
          color: #999999;
          overflow-y: auto;
        }
        .camp-box {
          width: 320px;
          height: 100%;
        }
      }
      .tag-group {
        .ant-tag-plain {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          margin-bottom: 8px;
          max-width: 145px;
          white-space: nowrap;
          text-overflow: ellipsis;
          overflow: hidden;
          cursor: pointer;
          img {
            width: 28px;
            height: 28px;
            border-radius: 6px;
            margin-right: 8px;
          }
        }
      }
      .rich-input {
        margin-top: 16px;
      }
      .rule {
        label {
          color: #3165f5;
        }
        span {
          display: block;
          &:nth-of-type(1) {
            color: #999;
            margin-bottom: 24px;
          }
          &:nth-of-type(2),
          &:nth-of-type(4) {
            margin-bottom: 10px;
          }
          &:nth-of-type(3) {
            margin-bottom: 24px;
          }
        }
      }
    }
    .line {
      margin: 48px 0;
      width: 100%;
      height: 1px;
      background-color: #eee;
      transform: scaleY(0.6);
    }
    .remark {
      font-size: 20px;
      margin-bottom: 34px;
      label {
        font-weight: bold;
        margin-right: 20px;
      }
    }
  }
}
.footer {
  height: 64px;
  width: 100%;
}
.fileBtn {
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  right: 0;
  opacity: 0;
}
</style>
