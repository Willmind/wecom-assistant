<template>
  <BasicDrawer
    :register="registerDrawer"
    :showFooter="false"
    width="864px"
    okText="确定"
    @ok="handleConfirm"
    @visible-change="handelVisibleChange"
  >
    <template #title>
      <div class="head jz-flex jz-flex-cc">
        <span class="tit">任务列表</span>
      </div>
    </template>
    <div class="container">
      <div class="task-form jz-flex">
        <a-form layout="inline">
          <a-form-item style="width: 311px">
            <a-input
              class="keywork-search-input"
              v-model:value="form.keyword"
              allowClear
              placeholder="任务标题"
            >
              <template #suffix v-if="!form.keyword"> <svg-icon icon-name="ic_search" /> </template
            ></a-input>
          </a-form-item>
          <a-form-item style="width: 311px">
            <a-range-picker
              v-model:value="form.time"
              value-format="YYYY-MM-DD"
              allowClear
              :ranges="{
                当天: [dayjs(), dayjs()],
                昨天: [
                  dayjs().startOf('day').subtract(1, 'days'),
                  dayjs().startOf('day').subtract(1, 'days')
                ],
                最近3天: [dayjs().startOf('day').subtract(2, 'days'), dayjs()],
                最近7天: [dayjs().startOf('day').subtract(6, 'days'), dayjs()],
                最近30天: [dayjs().startOf('day').subtract(29, 'days'), dayjs()]
              }"
            />
          </a-form-item>
          <a-form-item style="width: 136px; margin-right: 0px">
            <a-select v-model:value="form.status" :options="state.typeList" placeholder="状态" allow-clear />
          </a-form-item>
        </a-form>
      </div>
      <div class="tip jz-flex jz-flex-cc">
        <exclamation-circle-filled style="color: #ed7b2f; font-size: 17px" />
        <div>仅保留最近 1 个月的任务记录。</div>
      </div>
      <div class="table-box jz-flex">
        <a-table
          row-key="id"
          :columns="state.columns"
          :data-source="state.list"
          :bordered="false"
          :pagination="false"
          :customRow="rowClick"
        >
          <template #bodyCell="{ column, record }">
            <template v-if="column.key === 'titAction'">
              <div class="title lineClamp2">
                {{ record.title.length > 15 ? record.title.substr(0, 15) : record.title }}
                <span style="color: #999">{{ record.msg_task_type === 1 ? '群公告' : '' }}</span>
              </div>
            </template>
            <template v-if="column.key === 'timeAction'">
              <div class="jz-flex-1 jz-flex jz-flex-col">
                <span>{{ record.msg_send_type === 1 ? '立即发送' : '定时发送' }}</span>
                <span v-if="record.task_time">
                    {{ dayjs(+record.task_time * 1000).format('YYYY-MM-DD HH:mm:ss') }}
                  </span>
              </div>
            </template>
            <template v-if="column.key === 'createTimeAction'">
              <span>{{ dayjs(+record.create_time * 1000).format('YYYY-MM-DD HH:mm:ss') }}</span>
            </template>
            <template v-if="column.key === 'statusAction'">
              <div class="jz-flex-1 jz-flex jz-flex-col">
                <a-progress
                  :percent="((+record.member_success + +record.member_fail) / record.member_count) * 100"
                  strokeColor="#3165F5"
                  :showInfo="false"
                  v-if="record.task_status === 2 || record.task_status === 3"
                />
                <div style="color: #3165f5" v-if="record.task_status === 2">
                  {{ +record.member_success + +record.member_fail }} <label for="">/</label>
                  {{ record.member_count }}
                  <span>· 执行中</span>
                </div>
                <div style="color: #999" v-else>
                  {{ +record.member_success + +record.member_fail }} <label for="">/</label>
                  {{ record.member_count }}
                  <span>· {{ record.task_status_val }}</span>
                  {{}}
                </div>
              </div>
            </template>
            <template v-if="column.key === 'action'">
              <div class="jz-flex jz-flex-cc task-btn">
                <svg-icon
                  icon-name="task_start"
                  class="jz-pointer"
                  @click.stop="handleTask(record.id, true)"
                  v-if="record.task_status === 3"
                />
                <svg-icon
                  icon-name="task_stop"
                  class="jz-pointer"
                  v-if="record.task_status === 2 || record.task_status === 1"
                  @click.stop="handleTask(record.id, false)"
                />
                <a-popover
                  placement="bottomLeft"
                  v-model:visible="record.visible"
                  class="popover-wraper"
                  :getPopupContainer="
                      (triggerNode) => {
                        return triggerNode.parentNode || document.body
                      }
                    "
                >
                  <template #content>
                    <p class="jz-pointer popover-p" @click.stop="openTaskDetailDrawer({ id: record.id })">
                      查看
                    </p>
                    <p class="jz-pointer popover-p" @click.stop="handleCopy(record.id)">复制</p>
                    <p class="jz-pointer popover-p" @click.stop="handleMaterial(record)">生成我的素材</p>
                    <p
                      class="jz-pointer popover-p"
                      @click.stop="handleCancel(record.id)"
                      v-if="record.task_status !== 5 && record.task_status !== 4"
                    >
                      取消
                    </p>
                  </template>
                  <svg-icon icon-name="task_pr" class="jz-pointer" />
                </a-popover>
              </div>
            </template>

          </template>
          <template #emptyText>
            <div class="not-more jz-flex jz-flex-center jz-flex-col">
              <img src="@/assets/imgs/not_more.png" alt="" />
              <span>无内容</span>
            </div>
          </template>
        </a-table>
      </div>
      <div class="pagination-box">
        <basic-pagination @change="pageChange" :params="state.paginationParams">
          <template #extra>
            <span class="page-total">共 {{ state.paginationParams.total }} 条</span>
          </template>
        </basic-pagination>
      </div>
    </div>
    <a-modal v-model:visible="state.modalVisible" title="复制" @ok="handleOk" centered :mask="false">
      <p>
        复制此任务的内容到
        <span style="color: #3165f5">高级群发 > {{ state.task_type === 1 ? '群公告' : '新建群发' }}</span
        >。
      </p>
      <p>选择发送对象</p>
      <a-radio-group v-model:value="state.copy_type" :options="state.copyOptions" />
    </a-modal>
    <!--任务详情-->
    <TaskDetailDrawer :register="taskDetailDrawer" />
    <NewMaterialDrawer
      :register="registerNewMaterialDrawer"
      :mask="true"
      :showForehead="false"
      :innerPage="false"
      :getContainer="true"
      headHeight="auto"
    />
  </BasicDrawer>
</template>
<script setup>
import dayjs from 'dayjs'
import { useDrawer, useDrawerInner } from '@/components/basic/drawer'
import { reactive } from 'vue'
import useMessage from '@/composables/web/useMessage'
import { cloneDeep, debounce } from 'lodash-es'
import TaskDetailDrawer from './TaskDetailDrawer.vue'
import {
  getTaskList,
  setTaskPause,
  setTaskContinue,
  setTaskCancel,
  getTask,
  getTaskMember
} from '@/api/customerManager'
const [taskDetailDrawer, { openDrawer: openTaskDetailDrawer }] = useDrawer()
const [registerNewMaterialDrawer, { openDrawer: openNewMaterialDrawer }] = useDrawer()
const { createConfirm, createMessage } = useMessage()
const columns = [
  { title: '任务标题', key: 'titAction', width: '320px' },
  { title: '更新时间', key: 'timeAction', width: '270px' },
  { title: '创建时间', key: 'createTimeAction', width: '270px' },
  { title: '状态', key: 'statusAction', width: '270px' },
  { title: '操作', key: 'action', width: '200px' }
]
defineProps({
  register: Function
})

const emit = defineEmits(['success', 'close'])
const form = reactive({
  status: [],
  time: [],
  keyword: ''
})
const state = reactive({
  task_id: '',
  copy_type: 2,
  visible: false,
  task_type: 2, // 默认是普通群发
  modalVisible: false,
  paginationParams: {
    total: 0,
    current: 1,
    showSizeChanger: false
  },
  copyOptions: [
    { label: '全部对象', value: 1 },
    { label: '仅失败的发送对象', value: 2 }
  ],
  list: [],
  loading: false,
  typeList: [
    { label: '等待中', value: 1 },
    { label: '执行中', value: 2 },
    { label: '已暂停', value: 3 },
    { label: '已结束', value: 4 },
    { label: '已取消', value: 5 }
  ],
  columns: columns
})

// 监听=======
watch(
  () => form,
  () => {
    state.paginationParams.current = 1
    const params = unref(getParams)
    search(unref(params))
  },
  {
    deep: true
  }
)

// computed==========

// 获取form参数
const getParams = computed(() => {
  const deepData = cloneDeep(form)
  if (deepData.time?.[1]) {
    deepData.time[1] += ' 23:59:59'
  }
  return {
    ...deepData,
    add_time_start: deepData?.time?.length ? dayjs(deepData.time[0])?.unix?.() : undefined,
    add_time_end: deepData?.time?.length ? dayjs(deepData.time[1])?.unix?.() : undefined,
    status: !Array.isArray(deepData.status) ? deepData.status : '',
    time: undefined,
    page: state.paginationParams.current,
    limit: 10,
    task_type: state.task_type
  }
})

// ========================methods

// 任务暂停或开启
const handleTask = async (id, isStart) => {
  let { code } = !isStart ? await setTaskPause({ id }) : await setTaskContinue({ id })
  if (code === 1000) {
    createMessage.success(isStart ? '已开启任务' : '已暂停任务')
    const params = unref(getParams)
    search(params)
  }
}

const querySearch = async (params) => {
  let { data } = await getTaskList(params)
  if (data.list.length) {
    data.list.forEach((i) => (i.visible = false))
  }
  state.list = data.list
  state.paginationParams.total = data.total
  state.loading = false
}

const debounceSearch = debounce(querySearch, 350)

// 取消任务
const handleCancel = (id) => {
  createConfirm({
    content: `确认取消此任务？`,
    async onOk() {
      // 调用清空接口
      let { code } = await setTaskCancel({ id })
      if (code === 1000) {
        createMessage.success('任务已取消')
        const params = unref(getParams)
        search(params)
      }
    }
  })
}

//生成我的素材
const handleMaterial = async (record) => {
  let { data: msgObj } = await getTask({ id: record.id })
  let tempData = []
  for (let item of msgObj.send_content) {
    tempData.push({
      msg_type: item.msg_type,
      wait: 10,
      time_type: 1,
      msg: item,
      uploading: false
    })
  }
  openNewMaterialDrawer({
    data: {
      media_content: tempData,
      title: record.title
    },
    isUpdate: false,
    isCopy: true
  })
}

// 复制
const handleCopy = (id) => {
  state.task_id = id
  state.modalVisible = true
}

// 确认复制
const handleOk = async () => {
  let params = {
    id: state.task_id,
    page: 1,
    limit: 10000
  }
  if (state.copy_type === 2) {
    params.status = 3
  }
  state.modalVisible = false
  let { data: TaskMemberData } = await getTaskMember(params)
  let groupArr = TaskMemberData?.list?.map((i) => {
    return {
      ...i,
      id: i.member_id,
      isCheck: true,
      room_members: i.number
    }
  })
  let { data: msgObj } = await getTask({ id: state.task_id })
  msgObj.send_content = msgObj.send_content.map((i) => {
    return {
      msg_type: i.msg_type,
      msg: {
        ...i
      }
    }
  })
  handleReset()
  emit('success', { groupArr, msgObj })
  closeDrawer()
}

const rowClick = (record)=>{
  return {
    onclick: (event) => {
      openTaskDetailDrawer({ id: record.id })
    }
  }
}

const handleReset = () => {
  state.copy_type = 2
  form.status = []
  form.time = []
  form.keyword = ''
  state.paginationParams.current = 1
}

// 页码回调
const pageChange = (_params) => {
  state.loading = true
  state.paginationParams.current = _params.current
  const params = unref(getParams)
  debounceSearch(toRaw(params))
}

// 搜索
const search = (params) => {
  state.loading = true
  debounceSearch(toRaw(params))
}

// 抽屉参数
const [registerDrawer, { closeDrawer }] = useDrawerInner((res) => {
  console.log(res)
  if (res?.task_type) {
    state.task_type = 1
  }
})

// 抽屉展示关闭
const handelVisibleChange = (val) => {
  if (val) {
    const params = unref(getParams)
    search(params)
    window.TasklocalTime = setInterval(() => {
      search(unref(getParams))
    }, 5000)
  } else {
    emit('close')
    handleReset()
    clearInterval(window.TasklocalTime)
  }
}

// 确认提交
const handleConfirm = () => {
  closeDrawer()
}
</script>
<style lang="less" scoped>
.head {
  position: relative;
  display: flex;
  padding: 16px 0;
  height: 60px;

  .tit {
    font-size: 20px;
    font-weight: bold;
  }

  .back-btn {
    margin-right: 8px;
    border-radius: 4px;
    padding-left: 0px;
    position: relative;
    width: 32px;
    height: 32px;
    .svg-icon {
      position: absolute;
      left: 8px;
    }
  }

  .line {
    width: 100%;
    height: 1px;
    background-color: #eee;
    transform: scaleY(0.6);
    position: absolute;
    left: 0;
    bottom: 0;
    right: 0;
  }
}
.container {
  padding: 18px 32px 150px;
  overflow: hidden;
  height: 100%;
  .tip {
    color: #ed7b2f;
    margin: 24px 0 12px 0;
    > div {
      margin-left: 11px;
    }
  }
}
.table-box {
  height: 100%;
  overflow-y: auto;
  .not-more {
    img {
      width: 110px;
      height: 110px;
      margin-bottom: 4px;
    }
    span {
      font-size: 12px;
    }
  }
}
.task-btn {
  .svg-icon {
    width: 20px !important;
    height: 20px !important;
    &:first-child {
      margin-right: 16px;
    }
  }
}
.popover-wraper {
  font-size: 14px;
}

.page-total {
  margin-left: 8px;
  color: @font-minor-color;
}
.popover-p {
  height: 40px;
  line-height: 40px;
  margin-bottom: 0px;
  padding: 0 8px;
  width: 130px;
  &:hover {
    background: #f5f5f5;
  }
}
.pagination-box {
  position: absolute;
  left: 0;
  bottom: 0;
  right: 0;
  height: 64px;
  padding: 0 32px;
  background: #fff;
}
:deep(.ant-table-thead > tr > th) {
  color: @font-minor-color;
  border-bottom: none;
}
::-webkit-scrollbar {
  width: 0px;
  height: 0px;
}
:deep(.ant-table-thead
    > tr
    > th:not(:last-child):not(.ant-table-selection-column):not(.ant-table-row-expand-icon-cell):not([colspan])::before) {
  width: 0;
}
:deep(.ant-progress-outer) {
  height: 4px;
}
:deep(.ant-progress-outer > .ant-progress-inner) {
  height: 4px;
}
:deep(.ant-progress-outer > .ant-progress-inner > .ant-progress-bg) {
  height: 4px !important;
}
:deep(.ant-progress-bg) {
  height: 4px;
}
:deep(.ant-popover-inner) {
  border-radius: 6px;
}
:deep(.ant-popover-arrow) {
  width: 0px;
}
:deep(.ant-popover-inner-content) {
  padding: 8px !important;
}
</style>
