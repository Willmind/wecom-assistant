<template>
  <BasicDrawer
    :register="registerDrawer"
    :showFooter="false"
    innerPage
    showForehead
    okText="确定"
    :loading="state.loading"
    :mask="false"
    :push="false"
    :showClose="false"
    classes="editor-drawer"
    @visible-change="handelVisibleChange"
    :get-container="false"
  >
    <template #title>
      <div class="head jz-flex jz-flex-cc">
        <a-tooltip placement="top">
          <template #title>
            <span>返回</span>
          </template>
          <span class="back-btn jz-flex jz-flex-center jz-pointer" @click="closeTagDrawer">
            <svg-icon icon-name="login_back" style="width: 32px; height: 32px" />
          </span>
        </a-tooltip>
        <span class="tit">新建群公告</span>
        <div class="jz-flex jz-flex-1 jz-flex-cc jz-flex-rr" v-if="state.megConfig">
          <span style="margin-right: 24px">
            消息发送间隔：{{ state.megConfig.msg_frequency_start }}-{{ state.megConfig.msg_frequency_end }}秒
          </span>
          <span style="margin-right: 24px">
            对象发送间隔：
            {{ state.megConfig.contact_frequency_start }}-{{ state.megConfig.contact_frequency_end }}秒
          </span>
          <span style="margin-right: 24px">
            客户群发送间隔：
            {{ state.megConfig.group_frequency_start }}-{{ state.megConfig.group_frequency_end }}秒
          </span>
          <a-button style="margin-right: 8px" @click="openMsgSendDrawer">发送设置</a-button>
          <a-badge :count="state.taskCount">
            <a-button @click="openTaskGroupListDrawer({ task_type: true })">任务列表</a-button>
          </a-badge>
        </div>
        <div class="line"></div>
      </div>
    </template>
    <div class="container jz-flex">
      <!--form表单盒子-->
      <div class="form-box">
        <a-form class="ant-form-small">
          <div class="ant-form-head jz-flex jz-flex-cc jz-flex-rb">
            <span class="wecom-title">筛选</span>
            <a-button
              type="link"
              style="height: auto; padding-right: 0px"
              :disabled="!isChangeForm"
              @click="() => clearFields()"
              >清空筛选</a-button
            >
          </div>
          <a-form-item>
            <a-input
              class="keywork-search-input"
              v-model:value="groupForm.keyword"
              allowClear
              placeholder="关键词筛选"
            >
              <template #suffix v-if="!groupForm.keyword">
                <svg-icon icon-name="ic_search" />
              </template>
            </a-input>
          </a-form-item>
          <a-form-item>
            <a-select
              v-model:value="groupForm.type"
              :options="state.typeList"
              placeholder="是否群主/群管理员"
            />
          </a-form-item>
          <a-form-item>
            <a-popover
              placement="bottom"
              trigger="click"
              v-model:visible="state.visible"
              class="popover-wraper"
              :getPopupContainer="
                (triggerNode) => {
                  return triggerNode.parentNode || document.body
                }
              "
            >
              <template #content>
                <div class="count-box jz-flex jz-flex-col">
                  <div class="count-input jz-flex jz-flex-center">
                    <a-input-number
                      v-model:value="state.min_count"
                      :min="1"
                      :max="999"
                      placeholder="最小值"
                      :controls="false"
                      style="width: 86px"
                    />
                    <span class="count-line">-</span>
                    <a-input-number
                      v-model:value="state.max_count"
                      :min="1"
                      :max="1000"
                      placeholder="最大值"
                      :controls="false"
                      style="width: 86px"
                    />
                  </div>
                  <div class="count-btn jz-flex jz-flex-rr">
                    <a-button
                      type="primary"
                      :disabled="!(state.max_count && state.min_count)"
                      @click="handlegetGroupNum"
                      >确定</a-button
                    >
                  </div>
                </div>
              </template>
              <a-input v-model:value="groupForm.num" allowClear placeholder="群人数" readonly>
                <template #suffix>
                  <down-outlined />
                </template>
              </a-input>
            </a-popover>
          </a-form-item>
          <a-form-item name="add_time">
            <a-range-picker
              v-model:value="groupForm.add_time"
              value-format="YYYY-MM-DD"
              allowClear
              :ranges="{
                当天: [dayjs(), dayjs()],
                昨天: [dayjs().startOf('day').subtract(1, 'days'), dayjs().startOf('day').subtract(1, 'days')],
                最近3天: [dayjs().startOf('day').subtract(2, 'days'), dayjs()],
                最近7天: [dayjs().startOf('day').subtract(6, 'days'), dayjs()],
                最近30天: [dayjs().startOf('day').subtract(29, 'days'), dayjs()]
              }"
            />
          </a-form-item>
        </a-form>
      </div>
      <!--群列表盒子-->
      <div class="group-box jz-flex jz-flex-col">
        <div class="group-head jz-flex jz-flex-rb jz-flex-cc">
          <a-checkbox v-model:checked="checkAll" style="margin-right: 20px" @change="handleChange" />
          <span class="head-num"
            >客户群{{ state.list.filter((i) => i.isCheck).length }}/{{ state.count }}</span
          >
          <div class="jz-flex jz-flex-1 jz-flex-rr">仅显示已选</div>
          <a-switch class="switch" v-model:checked="state.isSwitch" @change="changeSwitch" />
        </div>
        <div class="tip jz-flex jz-flex-cc">
          <exclamation-circle-filled style="color: #ed7b2f; font-size: 17px" />
          <div>仅展示群主或管理员的客户群。</div>
        </div>
        <ul
          class="jz-flex jz-flex-col jz-flex-1 group-wraper"
          v-infinite-scroll="getGroupList"
          :infinite-scroll-immediate-check="false"
          :infinite-scroll-disabled="state.isFinished"
          :infinite-scroll-watch-disabled="state.isFinished"
          :infinite-scroll-distance="10"
          v-if="state.list.length"
        >
          <li
            class="item jz-flex jz-flex-center"
            :class="{ 'item-selected': item.isCheck }"
            v-for="(item, index) in state.list"
            :key="index"
          >
            <a-checkbox v-model:checked="item.isCheck" @change="selectItem(item)" />
            <div class="jz-flex-1 jz-flex jz-flex-cc">
              <img :src="item.avatar" alt="" />
              <div class="jz-flex-1 jz-flex jz-flex-col">
                <span class="lineClamp1">{{ item.name }}</span>
                <span class="lineClamp1">群成员：{{ item.room_members }}</span>
              </div>
            </div>
          </li>
        </ul>
        <div class="not-more jz-flex jz-flex-col jz-flex-center" v-else>
          <img src="@/assets/imgs/not_more.png" alt="" />
          <span>无内容</span>
        </div>
        <div class="group-clear jz-flex jz-flex-rr jz-flex-cc">
          <a-button :disabled="state.list.filter((i) => i.isCheck).length === 0" @click="clearGroup"
            >清空已选</a-button
          >
        </div>
      </div>
      <div class="form-editor jz-flex jz-flex-1 jz-flex-col">
        <div class="tit">群公告设置</div>
        <div class="jz-flex-1" style="height: 100%; overflow-y: auto">
          <a-form :colon="false" v-bind="formLayout">
            <a-form-item label="群公告主题">
              <div class="jz-flex jz-flex-cc">
                <a-input
                  v-model:value="state.form.title"
                  :maxlength="15"
                  placeholder="请输入主题，用于标识"
                  style="width: 226px; margin-right: 8px"
                />
                <span style="color: #999">{{ state.form.title.length }}/15</span>
              </div>
            </a-form-item>
            <a-form-item label="群公告内容">
              <a-textarea
                :maxlength="3000"
                placeholder="请输入文字"
                style="margin-bottom: 10px"
                v-model:value="state.form.group_content"
              />
              <span style="color: #999">{{ state.form.group_content.length }}/3000</span>
            </a-form-item>
            <a-form-item label="追加内容" class="form-item-auto-msg">
              <div class="card-list jz-flex jz-flex-col">
                <draggable
                  handle=".menu-handle"
                  itemKey="uid"
                  :component-data="{
                    tag: 'div',
                    type: 'transition-group',
                    name: !state.isDrag ? 'flip-list' : null
                  }"
                  v-model="modelRef.auto_message_config"
                  v-bind="dragOptions"
                  @start="state.isDrag = true"
                  @end="state.isDrag = false"
                >
                  <template #item="{ element: item, index }">
                    <div class="card-item-wrap jz-flex jz-flex-cc" :key="index">
                      <a-dropdown :trigger="['click']">
                        <a-tooltip title="长按拖拽 点击打开菜单">
                          <menu-outlined class="menu-handle" />
                        </a-tooltip>
                        <template #overlay>
                          <a-menu class="menu-list">
                            <a-menu-item
                              v-for="option in state.operateOptions"
                              :disabled="getDisableOperate(option, index)"
                              :key="option.icon"
                              @click="handleRemoveOperation(option, index)"
                            >
                              <div class="menu-item jz-flex jz-flex-cc" style="padding: 4px 0">
                                <svg-icon :icon-name="`ic_${option.icon}`" style="margin-right: 8px" />
                                <span>{{ option.label }}</span>
                              </div>
                            </a-menu-item>
                          </a-menu>
                        </template>
                      </a-dropdown>
                      <div class="card-item jz-flex">
                        <div class="card-num jz-flex jz-flex-center">{{ getMsgNumber(index) }}</div>
                        <div class="card-content">
                          <MessageCardWithType :item="item" :msgType="item.msg_type" />
                        </div>
                        <div class="card-extra jz-flex">
                          <div class="operate-btns jz-flex jz-flex-cc">
                            <UploadFile
                              :data="item"
                              v-if="isResMsg(item)"
                              class="jz-flex jz-flex-cc"
                              @change="(file) => handleSelectedFile({ file, item }, index, 'update')"
                            >
                              <a-tooltip title="编辑">
                                <svg-icon icon-name="ic_edit" />
                              </a-tooltip>
                            </UploadFile>
                            <a-tooltip title="编辑" v-else>
                              <SvgIcon icon-name="ic_edit" @click="handleCurdOperate('edit', item, index)" />
                            </a-tooltip>
                            <MessageTypeDropdown
                              :disabled="isUpperLimitWithType('addContent')"
                              @select="(item) => handleSelectMenu(item, index, 'insert')"
                              @select-file="(res) => handleSelectedFile(res, index, 'insert')"
                            >
                              <template #insert-item>
                                <p style="color: rgba(0, 0, 0, 0.4); padding: 8px 0 8px 8px">下方新增一条</p>
                              </template>
                              <template #adduction>
                                <SvgIcon icon-name="ic_add" />
                              </template>
                            </MessageTypeDropdown>
                            <a-tooltip title="删除">
                              <SvgIcon
                                icon-name="ic_delete"
                                @click="handleCurdOperate('delete', item, index)"
                              />
                            </a-tooltip>
                          </div>
                        </div>
                      </div>
                    </div>
                  </template>
                </draggable>
              </div>
              <div class="add-content jz-flex jz-flex-cc">
                <MessageTypeDropdown
                  :disabled="isUpperLimitWithType('addContent')"
                  @select="handleSelectMenu"
                  @select-file="handleSelectedFile"
                >
                  <template #adduction>
                    <div class="jz-flex jz-flex-cc">
                      <plus-circle-filled class="add-icon" />
                      <a-button type="link">添加内容</a-button>
                    </div>
                  </template>
                </MessageTypeDropdown>
                <span class="desc">{{ modelRef.auto_message_config?.length || 0 }}/20</span>
              </div>
            </a-form-item>
          </a-form>
        </div>
        <div class="footer-btn jz-flex jz-flex-rr jz-flex-cc">
          <a-button @click="handleCancel">取消</a-button>
          <a-button @click="state.sendVisible = true" :disabled="computedBtn">定时发送</a-button>
          <a-button type="primary" :disabled="computedBtn" @click="handleSubmit">立即发送</a-button>
        </div>
        <EditorTextModal ref="textRef" @success="handleMsgMoadlCallback" :msgTags="state.msgTags" />
        <EditorLinkModal ref="linkRef" @success="handleMsgMoadlCallback" />
        <EditorResourceModal ref="resRef" @success="handleMsgMoadlCallback" />
      </div>
    </div>
    <a-modal
      v-model:visible="state.sendVisible"
      title="定时发送"
      @ok="handleSendOk"
      centered
      :bodyStyle="{ padding: '16px 32px' }"
    >
      <div class="jz-flex jz-flex-col send-box">
        <div class="tip jz-flex jz-flex-cc">
          <exclamation-circle-filled style="color: #ed7b2f; font-size: 17px" />
          <div>单次定时仅支持设置未来 3 个月内的时间。</div>
        </div>
        <div class="txt">单次定时</div>
        <a-date-picker
          v-model:value="state.time"
          placeholder="发送时间"
          format="YYYY-MM-DD HH:mm"
          :show-time="{ format: 'HH:mm' }"
          @change="handleTimeChange"
        />
      </div>
    </a-modal>
    <!--任务列表-->
    <TaskGroupListDrawer
      :register="taskGroupListDrawer"
      @success="(res) => taskCallback(res)"
      @close="() => getCount()"
    />
    <!--发送设置-->
    <SetMsgSendDrawer :register="setMsgSendDrawer" @success="() => getMsgConfig()" />
    <EditorMediaModal
      :media_length="modelRef.auto_message_config?.length || 0"
      ref="mediaRef"
      @success="handleMediaMoadCallback"
    />
  </BasicDrawer>
</template>
<script setup>
import dayjs from 'dayjs'
import draggable from 'vuedraggable'
import { cloneDeep, debounce } from 'lodash-es'
import { useDrawerInner, useDrawer } from '@/components/basic/drawer'
import { MessageTypeEnum } from '@/enums/MessageTypeEnum'
import { Form } from 'ant-design-vue'
import { uploadFile, uploadImage, uploadVideo, searchGroup, addMsgSend } from '@/api/common'
import useMessage from '@/composables/web/useMessage'
import { isWechatMsg, isResMsg } from '../../customerOperationManager/copms/popover/utils'
import SetMsgSendDrawer from './SetMsgSendDrawer.vue'
import TaskGroupListDrawer from './TaskGroupListDrawer.vue'
import { getTaskCount, getMsgSendConfig } from '@/api/customerManager'
import { unref } from 'vue'
import { isTimeFrame } from '@/assets/js/utils'
const { createConfirm, createMessage } = useMessage()
const [setMsgSendDrawer, { openDrawer: openMsgSendDrawer }] = useDrawer()
const [taskGroupListDrawer, { openDrawer: openTaskGroupListDrawer }] = useDrawer()
const props = defineProps({
  mediaData: Array,
  register: Function
})

// ========================变量
const useForm = Form.useForm

const formLayout = {
  labelCol: { span: 4 },
  wrapperCol: { span: 20 }
}
const checkAll = ref(false)
const rulesRef = reactive({})
const selectedRows = ref([])
const state = reactive({
  page: 1,
  isFinished: false,
  time: '',
  visible: false,
  sendVisible: false,
  min_count: '',
  max_count: '',
  isDrag: false,
  list: [],
  all_group_list: [],
  checked_group_list: [], // 已选数据
  count: 0,
  originCount: 0,
  taskCount: 0,
  isSwitch: false,
  loading: false,
  megConfig: null,
  msgTags: [{ label: '@所有人', value: 6 }],
  typeList: [
    { label: '仅群主', value: 1 },
    { label: '仅群管理员', value: 2 },
    { label: '群主/群管理员', value: 3 },
    { label: '群成员', value: 4 }
  ],
  form: {
    title: '',
    task_type: 1,
    send_type: 1,
    send_time: '',
    group_content: '',
    auto_message_config: []
  },
  operateOptions: [
    { label: '置顶', icon: 'top', key: 1 },
    { label: '上移一条', icon: 'up', key: 2 },
    { label: '下移一条', icon: 'down', key: 3 },
    { label: '置底', icon: 'bottom', key: 4 }
  ]
})

const groupForm = reactive({
  num: '',
  type: [],
  add_time: [],
  keyword: ''
})

const textRef = ref()
const linkRef = ref()
const resRef = ref()
const mediaRef = ref()

const modelRef = toRef(state, 'form')

// 搜索全form
const { resetFields } = useForm(groupForm, rulesRef)

// =========================watch

watch(
  () => groupForm,
  () => {
    resetGroup()
    const params = unref(getParams)
    debounceSearch(toRaw(params))
  },
  {
    deep: true
  }
)

// =========================computed

const getParams = computed(() => {
  const deepData = cloneDeep(groupForm)
  deepData.keyword = deepData.keyword === '' ? undefined : deepData.keyword
  if (deepData.add_time?.[1]) {
    deepData.add_time[1] += ' 23:59:59'
  }
  return {
    ...deepData,
    start_time: deepData?.add_time?.length ? dayjs(deepData.add_time[0])?.unix?.() : undefined,
    end_time: deepData?.add_time?.length ? dayjs(deepData.add_time[1])?.unix?.() : undefined,
    add_time: undefined,
    is_admin: 1,
    type: !Array.isArray(deepData.type) ? deepData.type : '',
    num: deepData.num.replace(/\-/g, ',')
  }
})

const isChangeForm = computed(() =>
  Object.keys(groupForm).some((key) =>
    Array.isArray(groupForm[key])
      ? !!groupForm[key].length
      : groupForm[key] !== null && groupForm[key] !== undefined && groupForm[key] !== ''
  )
)

// 按钮禁止提交
const computedBtn = computed(() => {
  let lock = true
  let groupdArr = state.list.filter((i) => i.isCheck)
  if (state.form.title && state.form.group_content && groupdArr.length) {
    lock = false
  }
  return lock
})

// ========================methods

const clearGroup = () => {
  checkAll.value = false
  state.checked_group_list = []
  state.list.forEach((i) => (i.isCheck = false))
  state.isSwitch = false
  state.count = state.originCount
}

const handleChange = () => {
  state.list.forEach((i) => {
    i.isCheck = checkAll.value
  })
  if (checkAll.value) {
    state.checked_group_list = [...state.list]
  } else {
    state.checked_group_list = []
  }
}

const selectItem = (i) => {
  let index = unref(state.checked_group_list).findIndex((el) => el.id === i.id)
  if (~index) {
    unref(state.checked_group_list).splice(index, 1)
  } else {
    unref(state.checked_group_list).push(i)
  }
  let checkedNum = state.list.filter((i) => i.isCheck).length
  checkAll.value = checkedNum === state.list.length
}

// 任务列表抽屉回调
const taskCallback = (res) => {
  let { title, send_content, group_content } = res.msgObj
  state.form.title = title
  checkAll.value = false
  state.form.group_content = group_content
  state.list = [...res.groupArr]
  let allIds = state.all_group_list.map((i) => i.id)
  res.groupArr.forEach((i) => {
    if (!allIds.includes(i.id)) {
      state.all_group_list.push(i)
    }
  })
  let ids = res.groupArr.map((i) => i.id)
  state.all_group_list.forEach((i) => {
    i.isCheck = ids.includes(i.id)
  })

  state.checked_group_list = [...res.groupArr]
  state.isSwitch = res.groupArr.length ? true : false
  state.page = 1
  state.count = res.groupArr.length
  unref(modelRef).auto_message_config = send_content
}

// 选择发送时间
const handleTimeChange = (value, dateString) => {
  state.form.send_time = new Date(dateString).getTime() / 1000
}

// 立即发送处理
const handleSubmit = () => {
  state.form.send_type = 1
  handleSendMsg()
}

// 发送群消息
const handleSendMsg = async () => {
  let group_ids = state.list.filter((i) => i.isCheck).map((el) => el.id)
  let send_content = state.form.auto_message_config.map((row) => {
    return {
      ...row.msg,
      msg_type: row.msg_type
    }
  })
  let { title, group_content, send_type, send_time, task_type } = state.form
  await addMsgSend({
    title,
    send_type,
    task_type,
    group_ids: group_ids.join(','),
    send_content,
    group_content,
    send_time
  })
  createMessage.success('发送群公告成功')
  closeTagDrawer()
}

// 取消发送
const handleCancel = () => {
  createConfirm({
    content: `取消后编辑的内容不会保存，是否确认取消？`,
    onOk() {
      closeTagDrawer()
    }
  })
}

// 重置群数据
const resetGroup = () => {
  state.page = 1
  state.list = []
  state.count = 0
  state.isFinished = false
  state.checked_group_list = []
  state.all_group_list = []
  state.isSwitch = false
}

// 选择群人数
const handlegetGroupNum = () => {
  state.visible = false
  groupForm.num = `${state.min_count}-${state.max_count}`
}

// 定时发送出来
const handleSendOk = () => {
  let { $y, $M, $D } = state.time
  let _d = new Date()
  let startTime = `${_d.getFullYear()}-${_d.getMonth() + 1}-${_d.getDate()}`
  var lastDate = new Date(_d.getFullYear(), _d.getMonth() + 3, _d.getDate())
  let endTime = `${lastDate.getFullYear()}-${lastDate.getMonth() + 1}-${lastDate.getDate()}`
  if (!state.time) {
    createMessage.warn('请填写发送时间')
    return
  }
  if (!isTimeFrame(startTime, endTime, `${$y}-${$M + 1}-${$D}`)) {
    createMessage.warn('不在未来三个月范围内，请重新选择时间')
    return
  }
  state.form.send_type = 2
  state.sendVisible = false
  setTimeout(() => {
    handleSendMsg()
  }, 500)
}

// 获取群列表数据
const getGroupList = () => {
  const params = unref(getParams)
  debounceSearch(toRaw(params))
}

// 仅显示已选
const changeSwitch = (val) => {
  state.list = val ? [...state.checked_group_list] : state.all_group_list
  state.count = val ? state.checked_group_list.length : state.originCount
}

// 搜索群列表
const querySearch = async (params) => {
  try {
    if (state.isFinished) return false
    state.loading = true
    const { data } = await searchGroup({ ...params, page: state.page || 1, limit: 20 })
    state.loading = false
    if (data.data.length) {
      let ids = state.all_group_list?.map((i) => i.id)
      let checkIds = state.checked_group_list?.map((i) => i.id)
      data.data.forEach((i) => {
        if (checkAll.value) {
          i.isCheck = true
        }
        if (!ids.includes(i.id)) {
          state.all_group_list.push(i)
        }
        if (!checkIds.includes(i.id) && i.isCheck) {
          state.checked_group_list.push(i)
        }
      })
      state.list = [...state.list, ...data.data]
      state.page += 1
    } else {
      state.isFinished = true
    }
    if (data.total <= 20) {
      state.isFinished = true
    }
    state.count = +data.total
    state.originCount = +data.total
  } catch (error) {
    state.loading = false
  } finally {
    selectedRows.value = []
  }
}
const debounceSearch = debounce(querySearch, 350)

// 清空表单
const clearFields = () => {
  resetFields()
}

// 重置数据
const resetAllData = () => {
  resetFields()
  resetGroup()
  state.time = ''
  state.form.title = ''
  state.form.send_time = ''
  state.form.group_content = ''
  state.auto_message_config = []
  unref(modelRef).auto_message_config = []
}

// 抽屉参数
const [registerDrawer, { closeDrawer }] = useDrawerInner()

// 抽屉展示关闭
const handelVisibleChange = (val) => {
  let headBox = document.querySelector('.ant-drawer-header')
  if (val) {
    getCount()
    getMsgConfig()
    nextTick(() => {
      headBox && (headBox.style.paddingBottom = '0px')
      if (props.mediaData) {
        unref(modelRef).auto_message_config = props.mediaData
      }
    })
    const params = unref(getParams)
    debounceSearch(toRaw(params))
  } else {
    headBox && (headBox.style.paddingBottom = '')
  }
}

// 获取消息默认配置
const getMsgConfig = async () => {
  let { data } = await getMsgSendConfig()
  state.megConfig = data
}

// 获取任务数量
const getCount = async () => {
  let {
    data: { run }
  } = await getTaskCount({ task_type: 1 })
  state.taskCount = run
}

// 返回
const closeTagDrawer = () => {
  resetAllData()
  closeDrawer()
}

// 消息=========================start

// 上限判断
const isUpperLimitWithType = (type) => {
  if (type === 'addContent') {
    return unref(modelRef).auto_message_config?.length >= 20
  }
}

// 添加消息内容
const handleSelectMenu = (item, index, operType) => {
  let { icon: type } = item
  currMessageItemIndex.value = index
  handleOpenMsgModal(type, item, false, operType)
}

//素材库信息
const handleMediaMoadCallback = (data) => {
  for (let item of data) {
    unref(modelRef).auto_message_config.push(item)
  }
  createMessage.success('导入成功')
}

// 保存消息成功回调处理
const handleMsgMoadlCallback = (_, { isUpdate, data, operType }) => {
  if (Array.isArray(data)) {
    let textList = data.map((row) => ({ ...row, wait: row.wait || 10, time_type: row.time_type || 1 }))
    if (operType === 'insert') {
      unref(modelRef).auto_message_config.splice(currMessageItemIndex.value + 1, 0, ...textList)
    } else {
      unref(modelRef).auto_message_config.push(...textList)
    }
    return
  }
  const params = {
    ...data,
    wait: data.wait || 10,
    time_type: data.time_type || 1
  }
  if (isUpdate && ~currMessageItemIndex.value) {
    unref(modelRef).auto_message_config[unref(currMessageItemIndex)] = params
  } else {
    if (operType === 'insert') {
      unref(modelRef).auto_message_config.splice(currMessageItemIndex.value + 1, 0, params)
    } else {
      unref(modelRef).auto_message_config.push(params)
    }
  }
  currMessageItemIndex.value = -1
}

// 拖动动效
const dragOptions = ref({
  animation: 200,
  disabled: false,
  ghostClass: 'ghost'
})

const currMessageItemIndex = ref(-1)

// 删除/修改操作
const handleCurdOperate = (operType, item, index) => {
  let { msg_type } = item
  currMessageItemIndex.value = index
  switch (operType) {
    case 'edit':
      handleOpenMsgModal(MessageTypeEnum[msg_type], item, true)
      break
    case 'delete':
      unref(modelRef).auto_message_config.splice(index, 1)
      break
  }
}

const handleOpenMsgModal = (type, item = {}, isUpdate, operType) => {
  const { key, msg_type } = item
  switch (type) {
    case 'media':
      mediaRef.value.openModal({
        isUpdate,
        operType,
        data: cloneDeep(item)
      })
      break
    case 'text':
      textRef.value.openModal({
        isUpdate,
        operType,
        data: cloneDeep(item)
      })
      break
    case 'link':
      linkRef.value.openModal({
        isUpdate,
        operType,
        data: cloneDeep(item)
      })
      break
    default:
      if (isWechatMsg(item)) {
        resRef.value.openModal({
          isUpdate,
          operType,
          title: item.label,
          data: {
            ...cloneDeep(item),
            msg_type: key || msg_type
          }
        })
      }
      break
  }
}

// 上传图片/文件/文档
const handleSelectedFile = async ({ file, item: { key, msg_type } }, updateIndex, operType) => {
  key = key ?? msg_type
  if (file) {
    let index = -1
    if (updateIndex !== undefined && updateIndex > -1) {
      if (operType !== 'insert') {
        const editItem = unref(modelRef).auto_message_config[updateIndex]
        if (editItem) {
          editItem.msg.url = ''
          editItem.msg.name = file.name
          editItem.uploading = true
        }
      }
      index = operType === 'insert' ? updateIndex + 1 : updateIndex
    } else {
      index = unref(modelRef).auto_message_config.push(addNewMsg()) - 1
    }
    try {
      const uploadRequest =
        key === MessageTypeEnum.image ? uploadImage : key === MessageTypeEnum.video ? uploadVideo : uploadFile
      const { data } = await uploadRequest({ file })
      if (operType === 'insert') {
        unref(modelRef).auto_message_config.splice(index, 0, addNewMsg())
      } else {
        unref(modelRef).auto_message_config[index].msg.url = data.url
      }
      createMessage.success('上传成功')
    } catch (err) {
      unref(modelRef).auto_message_config.splice(index, 1)
    } finally {
      unref(modelRef).auto_message_config[index].uploading = false
    }
  }

  function addNewMsg() {
    return {
      msg_type: key,
      wait: 10,
      time_type: 1,
      msg: {
        name: file.name,
        url: ''
      },
      uploading: true
    }
  }
}

const getMsgNumber = (index) => {
  return +index + 1 < 10 ? `0${index + 1}` : index + 1
}

const getDisableOperate = (item, index) => {
  let { icon: key } = item
  let isDisabled = false
  switch (key) {
    case 'top':
    case 'up':
      isDisabled = index === 0
      break
    case 'bottom':
    case 'down':
      isDisabled = index === unref(modelRef).auto_message_config.length - 1
      break
  }
  return isDisabled
}

// 移动操作
const handleRemoveOperation = (item, index) => {
  let isDisabled = getDisableOperate(item, index)
  if (isDisabled) return

  const { icon: key } = item
  const [removeItem] = unref(modelRef).auto_message_config.splice(index, 1)
  switch (key) {
    case 'top':
    case 'bottom':
      unref(modelRef).auto_message_config[key === 'top' ? 'unshift' : 'push'](removeItem)
      break
    case 'up':
    case 'down':
      let idx = key === 'up' ? index - 1 : index + 1
      unref(modelRef).auto_message_config.splice(idx, 0, removeItem)
      break
  }
}

// 消息=========================end
</script>
<style lang="less" scoped>
.head {
  position: relative;
  height: 60px;
  .tit {
    font-size: 20px;
    font-weight: bold;
  }
  .back-btn {
    margin-right: 8px;
    border-radius: 4px;
    padding-left: 0px;
    position: relative;
    width: 32px;
    height: 32px;
    .svg-icon {
      position: absolute;
      left: 8px;
    }
  }
  .line {
    width: 100%;
    height: 1px;
    background-color: #eee;
    transform: scaleY(0.6);
    position: absolute;
    left: 0;
    bottom: 0;
    right: 0;
  }
}
.send-box {
  .tip {
    color: #ed7b2f;
    margin-bottom: 24px;
    > div {
      margin-left: 9px;
    }
  }
  .txt {
    margin-bottom: 10px;
  }
}
.count-box {
  width: 100%;
  .count-line {
    margin: 0 8px;
  }
  .count-btn {
    margin-top: 28px;
  }
}
.not-more {
  width: 100%;
  margin-top: 48px;
  img {
    width: 110px;
    height: 110px;
    display: block;
    margin-bottom: 4px;
  }
  span {
    font-size: 12px;
    color: #999;
  }
}
.container {
  width: 100%;
  height: 100%;
  .form-box,
  .group-box {
    width: 257px;
    height: 100%;
    padding: 32px 16px;
    position: relative;
    .group-clear {
      position: absolute;
      left: 0;
      right: 16px;
      bottom: 0;
      height: 64px;
      background: #fff;
    }
    &::after {
      content: '';
      position: absolute;
      right: 0;
      top: 0;
      bottom: 0;
      width: 1px;
      height: 100%;
      background-color: #eee;
      transform: scaleX(0.6);
    }
    .ant-form-head {
      margin-bottom: 16px;
    }
  }
  .group-box {
    width: 360px;
    padding: 32px 16px 64px;
    .group-head {
      color: #999;
    }
    .switch {
      margin-left: 16px;
    }
    .tip {
      margin: 12px 0;
      > div {
        color: #ed7b2f;
        margin-left: 10px;
      }
    }
    .group-wraper {
      overflow-y: auto;
      height: 100%;
      .item {
        width: 100%;
        height: 54px;
        min-height: 54px;
        padding: 0 8px;
        cursor: pointer;
        &.item-selected {
          background: #ebf0fe !important;
        }
        > div {
          margin-left: 28px;
          img {
            width: 36px;
            height: 36px;
            border-radius: 8px;
            margin-right: 12px;
          }
          span:first-child {
            font-size: 14px;
          }
          span:last-child {
            font-size: 12px;
            color: #999999;
          }
        }
        &:hover {
          background: rgba(0, 0, 0, 0.02);
        }
      }
    }
  }
  .form-editor {
    padding: 32px 32px 0px;
    position: relative;
    width: 100%;
    height: 100%;
    .tit {
      font-size: 20px;
      font-weight: bold;
      margin-bottom: 32px;
    }
    :deep(.ant-form-item) {
      // &.form-item-auto-msg {
      //   .ant-form-item-control {
      //     margin-left: -25px;
      //   }
      // }
      .ant-form-item-label {
        flex: 0 0 110px;
        max-width: 110px;
        display: inline-flex;
        > label {
          width: 90px;
          font-weight: 550;
          font-size: 14px;
          color: #000;
        }
      }
    }
    .card-list {
      width: 100%;
      .card-item-wrap {
        width: 100%;
        &:hover {
          .card-item .card-extra .operate-btns {
            visibility: visible;
            .svg-icon {
              width: 24px !important;
              height: 24px !important;
              padding: 4px;
              &:hover {
                background: rgba(0, 0, 0, 0.04);
                border-radius: 4px;
              }
            }
          }
          :deep(.anticon-menu) {
            visibility: visible;
          }
        }
        :deep(.anticon-menu) {
          margin-right: 12px;
          padding-top: 3px;
          visibility: hidden;
          :hover {
            color: @primary-color;
          }
        }
        .card-item {
          flex: auto;
          min-height: 56px;
          padding: 12px;
          background: rgba(0, 0, 0, 0.04);
          border-radius: 6px;
          box-sizing: border-box;
          .card-num {
            width: 24px;
            height: 24px;
            align-items: center;
            border-radius: 50%;
            background: #eeeeee;
            color: #000000;
            font-size: 12px;
            margin-right: 16px;
          }
          .card-content {
            flex: auto;
          }

          .card-extra {
            flex: none;
            display: flex;
            align-items: flex-start;
            .operate-btns {
              height: 32px;
              visibility: hidden;
              > * {
                margin-right: 16px;
                cursor: pointer;
              }
            }
            .time-bar {
              > span {
                margin-right: 12px;
                color: rgba(0, 0, 0, 0.4);
              }
              .time-input {
                :deep(.ant-input-number-input-wrap) {
                  width: 56px;
                }
              }
            }
          }
        }
        + .card-item-wrap {
          margin-top: 12px;
        }
        + .add-content {
          margin-top: 16px;
        }
      }
    }
    .add-content {
      .add-icon {
        font-size: 16px;
        color: @primary-color;
      }
      .decs {
        margin-left: 8px;
        color: rgba(0, 0, 0, 0.4);
      }
    }
    .footer-btn {
      width: 100%;
      height: 64px;
      .ant-btn {
        margin-right: 10px;
        &:last-child {
          margin-right: 0;
        }
      }
    }
  }
}

:deep(.ant-popover-content) {
  width: 224px;
}
:deep(.ant-popover-inner-content) {
  padding: 16px 14px;
}
:deep(.ant-input-number-input) {
  text-align: center;
}
:deep(.ant-popover-arrow-content) {
  opacity: 0;
}
:deep(.ant-drawer-header) {
  padding: 32px 32px 0 32px;
}
</style>
