<template>
  <!--form表单盒子-->
  <div class="customer-list jz-flex">
    <div class="form-box customer-form-box">
      <a-form class="editor-form customer-form ant-form-small">
        <div class="ant-form-head jz-flex jz-flex-cc jz-flex-rb" style="padding-top: 30px">
          <span class="wecom-title">筛选</span>
          <a-button type="link" :disabled="!isChangeForm" @click="() => clearFields()">清空筛选</a-button>
        </div>
        <a-form-item v-bind="validateInfos.keyword">
          <a-input
            class="keywork-search-input"
            v-model:value="form.keyword"
            allowClear
            placeholder="关键词筛选"
          >
            <template #suffix v-if="!form.keyword">
              <svg-icon icon-name="ic_search" />
            </template>
          </a-input>
        </a-form-item>
        <a-form-item v-bind="validateInfos.label_options">
          <CustomTagPopover
            is-search
            needCheckGroup
            :isReset="isReset"
            :data="{ label_id: form.label_ids }"
            @select-change="handleSelectedTag"
          >
            <span>
              <rich-input
                v-model:value="form.label_options"
                tagMode
                :allowInput="false"
                allowClear
                placeholder="标签"
                :setTagClass="
                  (item) =>
                    item?.type ? (item.type === 2 ? 'ant-tag-personal' : 'ant-tag-primary') : 'ant-tag-plain'
                "
              >
                <template #prefix>
                  <span>{{ label_type_name }}</span>
                </template>
                <template #suffix>
                  <down-outlined />
                </template>
              </rich-input>
            </span>
          </CustomTagPopover>
        </a-form-item>
        <a-form-item name="add_time" v-bind="validateInfos.add_time">
          <a-range-picker
            v-model:value="form.add_time"
            value-format="YYYY-MM-DD"
            allowClear
            :ranges="{
              当天: [dayjs(), dayjs()],
              昨天: [dayjs().startOf('day').subtract(1, 'days'), dayjs().startOf('day').subtract(1, 'days')],
              最近3天: [dayjs().startOf('day').subtract(2, 'days'), dayjs()],
              最近7天: [dayjs().startOf('day').subtract(6, 'days'), dayjs()],
              最近30天: [dayjs().startOf('day').subtract(29, 'days'), dayjs()]
            }"
          />
        </a-form-item>
        <a-form-item v-bind="validateInfos.group_type_text">
          <GroupTypePopover
            v-model:item="form.group_ids"
            :isReset="isReset"
            @onChange="handleGroupTypeChange"
          >
            <a-input
              class="ant-input-ellipsis"
              v-model:value="form.group_type_text"
              allowClear
              :readonly="true"
              placeholder="按群查询"
            >
              <template #prefix v-if="groupTypeObj.label">
                <label>{{ groupTypeObj.label }}</label>
              </template>
              <template #suffix>
                <div class="ant-select-arrow">
                  <down-outlined />
                </div>
              </template>
            </a-input>
          </GroupTypePopover>
        </a-form-item>
        <a-form-item v-bind="validateInfos.is_remark">
          <api-select
            v-model:value="form.is_remark"
            allowClear
            :options="dictMap.is_remark"
            :replaceFields="dictFields"
            placeholder="有无企微备注"
          />
        </a-form-item>
        <a-form-item v-bind="validateInfos.is_name">
          <api-select
            v-model:value="form.is_name"
            allowClear
            :options="dictMap.is_name"
            :replaceFields="dictFields"
            placeholder="有无称呼"
          />
        </a-form-item>
        <a-form-item v-bind="validateInfos.sex">
          <api-select
            v-model:value="form.sex"
            allowClear
            :options="dictMap.sex"
            :replaceFields="dictFields"
            placeholder="性别"
          />
        </a-form-item>
        <a-form-item v-bind="validateInfos.source">
          <api-select
            v-model:value="form.source"
            allowClear
            :options="dictMap.source"
            :replaceFields="dictFields"
            placeholder="来源"
          />
        </a-form-item>
        <a-form-item v-bind="validateInfos.friend_status">
          <api-select
            v-model:value="form.friend_status"
            allowClear
            :options="dictMap.friend_status"
            :replaceFields="dictFields"
            placeholder="好友关系"
          />
        </a-form-item>
        <a-form-item v-bind="validateInfos.wx_type">
          <api-select
            v-model:value="form.wx_type"
            allowClear
            :options="dictMap.wx_type"
            :replaceFields="dictFields"
            placeholder="微信类型"
          />
        </a-form-item>
        <a-form-item v-bind="validateInfos.is_friend_add">
          <api-select
            v-model:value="form.is_friend_add"
            allowClear
            :options="dictMap.is_friend_add"
            :replaceFields="dictFields"
            placeholder="是否主动加好友"
          />
        </a-form-item>

        <div class="ant-form-head jz-flex jz-flex-rb">
          <span class="wecom-title">学员筛选</span>
        </div>
        <a-form-item v-bind="validateInfos.user_ids">
          <api-select
            class="user-select"
            v-model:value="form.user_ids"
            rowKey="user_id"
            :api="searchUser"
            allowClear
            remote-search
            placeholder="用户ID/手机号"
            :params="(name) => ({ name })"
          >
            <template #option="{ item }">
              <div class="user-option jz-flex jz-flex-cc">
                <img class="img" :src="item.avatar" v-if="item.avatar" />
                <div class="item-content">
                  <span>{{ item.nickname }}</span>
                  <p>{{ item.mobile }}</p>
                </div>
              </div>
            </template>
            <template #suffix>
              <search-outlined />
            </template>
          </api-select>
        </a-form-item>
        <a-form-item v-bind="validateInfos.project_id">
          <api-select
            v-model:value="form.project_id"
            allowClear
            filterOption
            :show-search="true"
            resultField="data.list"
            :replaceFields="replaceFields"
            :api="queryProductList"
            placeholder="项目"
          />
        </a-form-item>
        <a-form-item v-bind="validateInfos.camp_id">
          <api-select
            v-model:value="form.camp_id"
            immediate
            allowClear
            remote-search
            :api="searchCamp"
            autoClearMismatchValue
            :params="(name) => ({ name, project_id: form.project_id, flag: 1 })"
            :replaceFields="replaceFields"
            placeholder="课程ID/名称"
          />
        </a-form-item>
        <a-form-item v-bind="validateInfos.term">
          <api-select
            v-model:value="form.term"
            :disabled="!form.camp_id"
            allowClear
            mode="multiple"
            :api="searchTerm"
            placeholder="期数"
            autoClearMismatchValue
            :replaceFields="{ value: 'tm' }"
            :params="{ camp_id: form.camp_id }"
          >
            <template #option="{ item }">
              {{ formatDate(item.t) }}
            </template>
          </api-select>
        </a-form-item>
        <a-form-item v-bind="validateInfos.is_phone">
          <api-select
            v-model:value="form.is_phone"
            allowClear
            :options="dictMap.is_phone"
            :replaceFields="dictFields"
            placeholder="有无绑定手机"
          />
        </a-form-item>
        <a-form-item v-bind="validateInfos.app">
          <api-select
            v-model:value="form.app"
            :options="dictMap.app"
            :replaceFields="dictFields"
            placeholder="有无App"
            allowClear
          />
        </a-form-item>
      </a-form>
      <div class="exclude-box jz-flex jz-flex-center" @click="handleOpenSider">
        设置排除条件 （{{ exclude_count }}）
        <SvgIcon :icon-name="excludeCollapsed ? 'arrow_right' : 'arrow_left'" />
      </div>
    </div>

    <div class="form-box exclude-form" v-show="!excludeCollapsed">
      <ExcludeForm ref="ExcludeFormRef" @excludeChange="excludeChange" />
    </div>

    <!--客户列表盒子-->
    <div class="group-box jz-flex jz-flex-dir-col jz-flex-rb" v-loading="state.loading">
      <div>
        <div class="group-head jz-flex jz-flex-rb">
          <div class="jz-flex">
            <a-checkbox v-model:checked="state.allCheck" @change="selectAllItem" style="margin-left: 6px" />
            <selectNum />
            <!--          <span class="head-num">客户{{ state.checked_group_list.length }}/{{ state.count }}</span>-->
          </div>
          <div class="jz-flex jz-flex-1 jz-flex-rr">仅显示已选</div>
          <a-switch class="switch" v-model:checked="state.isSwitch" @change="changeSwitch" />
        </div>
        <!--        <div class="tip jz-flex jz-flex-cc">-->
        <!--          <exclamation-circle-filled style="color: #ed7b2f; font-size: 17px" />-->
        <!--          <div>仅展示群主或管理员的客户群。</div>-->
        <!--        </div>-->
      </div>
      <div class="jz-flex-1" style="overflow: auto">
        <ul
          class="jz-flex jz-flex-col jz-flex-1 group-wraper"
          v-infinite-scroll="getCustomerList"
          :infinite-scroll-immediate-check="false"
          :infinite-scroll-disabled="state.isFinished"
          :infinite-scroll-watch-disabled="state.isFinished"
          :infinite-scroll-distance="10"
          v-if="state.list.length"
        >
          <li
            class="item jz-flex jz-flex-center"
            :class="{ 'item-selected': item.isCheck }"
            v-for="(item, index) in state.list"
            :key="index"
          >
            <a-checkbox v-model:checked="item.isCheck" @change="selectItem(item)" />
            <div class="jz-flex-1 jz-flex jz-flex-cc">
              <img :src="item.avatar" alt="" />
              <div class="jz-flex-1 jz-flex jz-flex-col">
                <span class="lineClamp1">{{ item.name }}</span>
                <span style="color: #ed7b2f" v-if="item.wx_type_val === '企业微信'" class="lineClamp1"
                  >@{{ item.wx_type_val }}</span
                >
                <span style="color: #57be6a" v-if="item.wx_type_val === '个人微信'" class="lineClamp1"
                  >@{{ item.wx_type_val }}</span
                >
              </div>
            </div>
          </li>
        </ul>
        <div class="not-more jz-flex jz-flex-col jz-flex-center" v-else>
          <img src="@/assets/imgs/not_more.png" alt="" />
          <span>无内容</span>
        </div>
      </div>
      <div class="group-footer">
        <a-button :disabled="store2.customerSelectCount === 0" @click="clearAllCheck">清空已选</a-button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { queryProductList, searchTerm, searchCamp, searchUser } from 'api/common'
import dayjs from 'dayjs'
import { computed, reactive, ref, toRaw, toRef, unref, defineExpose } from 'vue'
import { Form } from 'ant-design-vue'
import { dictStore } from '@/store/modules/dict'
import { cloneDeep, debounce } from 'lodash-es'
import { queryList } from 'api/customerManager'
import { customerStore } from '@/store/modules/customer'
const store = dictStore()

const store2 = customerStore()

const dictMap = toRef(store, 'dictMap')
store.tryFetchData()
const useForm = Form.useForm
const rulesRef = reactive({})

const label_type_name = ref('')
const groupTypeObj = reactive({
  label: ''
})
const isReset = ref(false)
const dictFields = computed(() => ({ label: 'val', value: 'key' }))
const replaceFields = computed(() => ({ label: 'name', value: 'id' }))

const isSelectAll = ref(false)

const form = reactive({
  add_time: [],
  keyword: '',
  sex: undefined,
  project_id: undefined,
  camp_id: undefined,
  term: undefined,
  source: undefined,
  user_ids: undefined,
  label_ids: undefined,
  label_options: undefined,
  is_name: undefined,
  is_remark: undefined,
  is_phone: undefined,
  friend_status: undefined,
  group_type: undefined,
  group_type_text: '',
  label_type: undefined,
  wx_type: undefined,
  app: undefined,
  is_friend_add: undefined
})
const selectedRows = ref([])
const emit = defineEmits(['onSelect'])

const state = reactive({
  page: 1,
  isFinished: false,
  time: '',
  visible: false,
  sendVisible: false,
  min_count: '',
  max_count: '',
  isDrag: false,
  allCheck: false,
  list: [],
  all_group_list: [],
  checked_group_list: [], // 已选数据
  count: 0,
  originCount: 0,
  taskCount: 0,
  isSwitch: false,
  loading: false,
  megConfig: null,
  typeList: [
    { label: '仅群主', value: 1 },
    { label: '仅群管理员', value: 2 },
    { label: '群主/群管理员', value: 3 },
    { label: '群成员', value: 4 }
  ],
  form: {
    title: '',
    task_type: 1,
    send_type: 1,
    send_time: '',
    group_content: '',
    auto_message_config: []
  },
  operateOptions: [
    { label: '置顶', icon: 'top', key: 1 },
    { label: '上移一条', icon: 'up', key: 2 },
    { label: '下移一条', icon: 'down', key: 3 },
    { label: '置底', icon: 'bottom', key: 4 }
  ]
})

const { validateInfos, resetFields } = useForm(form, rulesRef)

// 仅显示已选
const changeSwitch = (val) => {
  state.list = val ? [...state.checked_group_list] : state.all_group_list
  // state.count = val ? state.checked_group_list.length : state.originCount;
}

const getParams = computed(() => {
  const deepData = cloneDeep(form)
  return {
    ...deepData
  }
})

//清空已选
const clearAllCheck = () => {
  state.checked_group_list = []
  state.list.forEach((i) => {
    i.isCheck = false
  })
  state.all_group_list.forEach((i) => {
    i.isCheck = false
  })
  state.isSwitch = false
  state.allCheck = false
  store2.customerSelectCount = 0
  changeSwitch(false)
}

// 获取客户列表数据
const getCustomerList = () => {
  const params = unref(getParams)
  debounceSearch(toRaw(params))
}

const excludeCollapsed = ref(true)
const exclude_count = ref(0)
const pageSideWidth = ref(262)
const handleOpenSider = () => {
  emit('handleExcludeCollapsed', excludeCollapsed.value)
  excludeCollapsed.value = !excludeCollapsed.value
  pageSideWidth.value = !unref(excludeCollapsed) ? 262 * 2 : 262
}

// 排除条件过滤\
const excludeParams = ref({})

const excludeChange = (params, num) => {
  state.isFinished = false
  state.page = 1
  isSelectAll.value = false
  excludeParams.value = params
  const params1 = unref(getParams)
  const updateParams = { ...params1, ...params }
  debounceSearch(toRaw(updateParams))
  isReset.value = false
  exclude_count.value = num
}

const formatDate = (value, format = 'YYYY-MM-DD') => dayjs(value * 1000).format(format)

// 搜索客户列表数据
const querySearch = async (params) => {
  const queryParams = { ...params, ...excludeParams.value }
  if (params) {
    Object.keys(params).forEach((key) => {
      if (Array.isArray(params[key])) {
        queryParams[key] = params[key].join(',')
      } else {
        queryParams[key] = params[key]
      }
    })
  }

  try {
    if (state.isFinished) return false
    state.loading = true

    const { data } = await queryList({ ...queryParams, page: state.page || 1, limit: 20 })
    state.loading = false
    if (data.total === 0) {
      state.list = []
    } else if (data.list.length) {
      state.all_group_list = []
      state.list = []
      let ids = state.all_group_list?.map((i) => i.ac_id)
      data.list.forEach((i) => {
        if (!ids.includes(i.ac_id)) {
          state.all_group_list.push(i)
        }
      })
      state.list = [...state.list, ...data.list]
      state.page += 1
    } else {
      state.isFinished = true
    }
    state.count = +data.total
    store2.customerCount = state.count
    state.originCount = +data.total
  } catch (error) {
    state.loading = false
  } finally {
    selectedRows.value = []
  }
}
const debounceSearch = debounce(querySearch, 350)

const selectItem = (i) => {
  let index = unref(state.checked_group_list).findIndex((el) => el.ac_id === i.ac_id)
  if (~index) {
    unref(state.checked_group_list).splice(index, 1)
  } else {
    unref(state.checked_group_list).push(i)
  }
  if (state.checked_group_list.length !== state.count) {
    state.allCheck = false
  } else {
    state.allCheck = true
  }
  store2.customerSelectCount = state.checked_group_list.length
  if (store2.customerSelectCount === 0) {
    state.all_group_list.forEach((i) => {
      i.isCheck = false
    })
    changeSwitch(false)
    state.isSwitch = false
  }

  emit(
    'onSelect',
    unref(state.checked_group_list).map((el) => el.ac_id)
  )
}

//全选
const selectAllItem = () => {
  state.checked_group_list = []
  for (let item of state.list) {
    item.isCheck = state.allCheck
    if (state.allCheck) {
      unref(state.checked_group_list).push(item)
    }
  }
  if (!state.allCheck) {
    state.checked_group_list = []
  }
  store2.customerSelectCount = state.checked_group_list.length
  emit(
    'onSelect',
    unref(state.checked_group_list).map((el) => el.ac_id)
  )
}

//数据回显
const echoData = (data) => {
  data.forEach((i) => {
    i.ac_id = i.id
  })
  state.checked_group_list = data
  let ids = data.map((i) => i.member_id)
  state.all_group_list.forEach((i) => {
    i.isCheck = ids.includes(i.ac_id)
  })

  store2.customerSelectCount = data.length
  state.isSwitch = data.length > 0 ? true : false
  state.list = [...data]
  state.page = 1
}

const isChangeForm = computed(() =>
  Object.keys(form).some((key) =>
    Array.isArray(form[key])
      ? !!form[key].length
      : form[key] !== null && form[key] !== undefined && form[key] !== ''
  )
)

// 标签查询
const handleSelectedTag = ({ type, tags }) => {
  form.label_type = type
  label_type_name.value = type === 1 ? '任意' : type === 2 ? '带有' : type === 3 ? '除开' : '未打标签好友'
  form.label_options = tags
}
// 选择按群查询
const handleGroupTypeChange = ({ labelInValue, checkedRows }) => {
  groupTypeObj.label = labelInValue.label
  form.group_type = labelInValue.value
  form.group_ids = checkedRows.map((item) => item.id)
  form.group_type_text = checkedRows.map((item) => item.name).join('、')
}

const clearFields = () => {
  resetFields()
  form.label_ids = []
  form.label_options = []
  form.group_ids = []
  label_type_name.value = ''
  form.group_type_text = ''
  groupTypeObj.label = ''
  isReset.value = true
  ExcludeFormRef.value.clearFields()
}
// 重置群数据
const ExcludeFormRef = ref()
const resetGroup = () => {
  state.page = 1
  state.list = []
  state.count = 0
  state.isFinished = false
  state.checked_group_list = []
  state.all_group_list = []
  state.isSwitch = false
  state.allCheck = false
  store2.resetCustomerSelect()
  excludeCollapsed.value = true
}

defineExpose({ resetGroup, clearFields, echoData, clearAllCheck })

watch(
  () => form,
  () => {
    resetGroup()
    const params = unref(getParams)
    debounceSearch(toRaw(params))
  },
  {
    deep: true
  }
)

onMounted(() => {
  resetGroup()
  ExcludeFormRef.value.clearFields()
  clearFields()
  querySearch()
})
</script>

<style lang="less">
.customer-list {
  position: relative;

  .form-box,
  .group-box {
    width: 262px;
    //height: 100%;
    padding: 32px 16px;
    position: relative;

    &::after {
      content: '';
      position: absolute;
      right: 0;
      top: 0;
      bottom: 0;
      width: 1px;
      height: 100%;
      background-color: #eee;
      transform: scaleX(0.6);
    }

    .ant-form-head {
      margin-bottom: 16px;
    }
  }

  .form-box {
    padding: 28px 16px;

    .customer-form {
      flex: 1;
      overflow: auto;
      padding-bottom: 0px;
    }

    .editor-form {
      padding-right: 16px;
      box-sizing: border-box;
      // 修改滚动条
      &::-webkit-scrollbar {
        width: 3px;
      }

      .ant-form-head {
        line-height: 20px;
        margin-bottom: 12px;
        position: sticky;
        top: 0;
        z-index: 2;
        background: #fff;

        .btn {
          color: rgba(0, 0, 0, 0.25);
        }

        &:nth-of-type(2n) {
          margin-top: 48px;
        }
      }

      .ant-form-item {
        .ant-form-item-label {
          width: 46px;
          margin-right: 15px;

          > label {
            color: rgba(0, 0, 0, 0.4);
          }
        }
      }
    }
  }

  .customer-form-box {
    padding: 0 0 56px 0;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    overflow: auto;
  }

  .exclude-form {
    position: absolute;
    height: 100%;
    left: 262px;
    z-index: 3;
    background-color: white;
    transition: left 0.28s;
    padding: 28px 0;
  }

  .group-box {
    width: 360px;
    padding: 32px 0 0 16px;

    .group-head {
      color: #999;
      padding-right: 16px;
    }

    .group-footer {
      height: 64px;
      display: flex;
      justify-content: flex-end;
      align-items: center;
      padding-right: 16px;
    }

    .not-more {
      width: 100%;
      margin-top: 48px;

      img {
        width: 110px;
        height: 110px;
        display: block;
        margin-bottom: 4px;
      }

      span {
        font-size: 12px;
        color: #999;
      }
    }

    .switch {
      margin-left: 16px;
    }

    .tip {
      margin: 12px 0 12px 6px;

      > div {
        color: #ed7b2f;
        margin-left: 10px;
      }
    }

    .group-wraper {
      padding-right: 16px;
      overflow-y: auto;
      height: 100%;
      // 修改滚动条
      &::-webkit-scrollbar {
        width: 3px;
      }

      .item {
        width: 100%;
        height: 54px;
        min-height: 54px;
        padding: 0 8px;
        cursor: pointer;

        &.item-selected {
          background: #ebf0fe !important;
        }

        > div {
          margin-left: 28px;

          img {
            width: 36px;
            height: 36px;
            border-radius: 8px;
            margin-right: 12px;
          }

          span:first-child {
            font-size: 14px;
          }

          span:last-child {
            font-size: 12px;
            color: #999999;
          }
        }

        &:hover {
          background: rgba(0, 0, 0, 0.02);
        }
      }
    }
  }

  .exclude-box {
    height: 64px;
    color: #3165f5;
    left: 0;
    bottom: 0;
    right: 0;
    cursor: pointer;
    font-size: 16px;

    .svg-icon {
      margin-top: 2px;
    }
  }
}
</style>
