<template>
  <div class="card-list" v-if="isNotEmpty" :style="{ height }">
    <template v-for="item in mapObj" :key="item.type">
      <div class="card-group" v-if="item.items && item.items.length">
        <p>{{ item.label }}</p>
        <div class="card-item" v-for="option in item.items" :key="option.group_id">
          <div class="card-head" v-if="item.type !== 2">
            <p class="sub-title">{{ option.group }}</p>
          </div>
          <div class="items" :class="{ 'people-tags': item.type === 2 }">
            <a-checkable-tag
              class="ant-tag-big"
              v-model:checked="row.checked"
              v-for="row in option.label"
              :key="row.label_id"
              @change="(checked) => handleCheckChange(row, checked, item.type)"
            >
              {{ row.name }}
            </a-checkable-tag>
          </div>
        </div>
      </div>
    </template>
  </div>
</template>
<script setup>
import { computed, reactive, toRaw, toRefs, watchEffect } from 'vue'

const props = defineProps({
  data: {
    type: Object
  },
  height: String
})

const mapObj = reactive([])

watchEffect(() => {
  let { data } = props
  mapObj.length = 0
  if (data && Object.keys(data).length) {
    Object.keys(data).forEach((key) => {
      mapObj.push({
        type: key === 'company' ? 1 : 2,
        label: key === 'company' ? '企业标签' : '个人标签',
        items: data[key]
      })
    })
    console.log('mapObj', mapObj)
  }
})

const { height } = toRefs(props)

const emit = defineEmits(['checkChange'])

const isNotEmpty = () => computed(() => props.data && !!Object.keys(props.data).length)

const handleCheckChange = (row, _, type) => {
  emit('checkChange', { ...toRaw(row), type })
}
</script>
<style lang="less" scoped>
.card-list {
  height: 100%;
  overflow-y: auto;
  .card-group {
    > p {
      margin-bottom: 10px;
    }
  }
  .card-head {
    > p {
      color: #000;
      font-size: 14px;
      margin-bottom: 8px;
      &:first-child {
        margin-bottom: 2px;
      }
    }
    .sub-title {
      color: rgba(0, 0, 0, 0.4);
    }
    + .card-head {
      margin-top: 32px;
    }
  }
  .card-item {
    margin-bottom: 16px;
  }
  .items {
    :deep(.ant-tag) {
      margin-top: 8px;
    }
    &.people-tags {
      :deep(.ant-tag) {
        &-checkable {
          &:not(.ant-tag-checkable-checked):hover {
            color: #06d1d1;
            background-color: rgba(6, 209, 209, 0.1);
          }
        }
        &-checkable-checked {
          color: #06d1d1;
          background-color: rgba(6, 209, 209, 0.1);
        }
      }
    }
  }
}
</style>
