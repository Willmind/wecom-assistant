<template>
  <BasicDrawer
    :register="registerDrawer"
    :showFooter="false"
    :showClose="false"
    innerPage
    showForehead
    :loading="state.loading"
    classes="editor-drawer"
    :mask="false"
    :push="false"
    :get-container="false"
    @visible-change="handelVisibleChange"
  >
    <template #title>
      <div class="head jz-flex jz-flex-cc">
        <a-tooltip placement="top">
          <template #title>
            <span>返回</span>
          </template>
          <span class="back-btn jz-flex jz-flex-center jz-pointer" @click="closeTagDrawer()">
            <svg-icon icon-name="login_back" style="width: 32px; height: 32px" />
          </span>
        </a-tooltip>
        <span class="tit">高级群发</span>
        <div class="jz-flex jz-flex-1 jz-flex-cc jz-flex-rr" v-if="state.megConfig">
          <span style="margin-right: 24px">
            消息发送间隔：{{ state.megConfig.msg_frequency_start }}-{{ state.megConfig.msg_frequency_end }}秒
          </span>
          <span style="margin-right: 24px">
            对象发送间隔：
            {{ state.megConfig.contact_frequency_start }}-{{ state.megConfig.contact_frequency_end }}秒
          </span>
          <span style="margin-right: 24px">
            客户群发送间隔：
            {{ state.megConfig.group_frequency_start }}-{{ state.megConfig.group_frequency_end }}秒
          </span>
          <a-button style="margin-right: 8px" @click="openMsgSendDrawer">发送设置</a-button>
          <a-badge :count="state.taskCount">
            <a-button @click="openTaskGroupListDrawer">任务列表</a-button>
          </a-badge>
        </div>
        <div class="line"></div>
      </div>
    </template>
    <div class="container jz-flex">
      <div
        class="left-content jz-flex jz-flex-dir-col"
        :style="{
          marginLeft: collapsed ? '-617px' : '0px'
        }"
      >
        <div
          class="page-side-fold jz-flex jz-flex-center"
          :class="{ 'is-expand': !collapsed }"
          @click="toggleFold"
        >
          <left-outlined v-if="!collapsed" />
          <right-outlined v-else />
        </div>
        <a-menu v-model:selectedKeys="current" mode="horizontal">
          <a-menu-item key="myself"> 我的客户 </a-menu-item>
          <a-menu-item key="group"> 客户群 </a-menu-item>
        </a-menu>
        <div class="form-content jz-flex-1" style="height: calc(100% - 48px)">
          <div v-show="isMyself">
            <SopCustomerList @success="getCustomerCheckList" ref="SopCustomerListRef" />
          </div>
          <div v-show="!isMyself">
            <SopGroupList @success="getGroupCheckList" ref="SopGroupListRef" />
          </div>
        </div>
      </div>

      <div class="right-content jz-flex jz-flex-dir-col">
        <div class="tit">群发设置</div>
        <a-form
          class="jz-flex-1 jz-flex jz-flex-dir-col"
          style="overflow: auto"
          :colon="false"
          v-bind="formLayout"
        >
          <a-form-item label="群发主题">
            <div class="jz-flex jz-flex-cc">
              <a-input
                v-model:value="state.form.title"
                :maxlength="15"
                placeholder="请输入主题，用于标识"
                style="width: 226px; margin-right: 8px"
              />
              <span style="color: #999">{{ state.form.title.length }}/15</span>
            </div>
          </a-form-item>

          <a-form-item label="群发内容" class="form-item-auto-msg">
            <div class="card-list jz-flex jz-flex-col">
              <draggable
                handle=".menu-handle"
                itemKey="uid"
                :component-data="{
                  tag: 'div',
                  type: 'transition-group',
                  name: !state.isDrag ? 'flip-list' : null
                }"
                v-model="modelRef.auto_message_config"
                v-bind="dragOptions"
                @start="state.isDrag = true"
                @end="state.isDrag = false"
              >
                <template #item="{ element: item, index }">
                  <div class="card-item-wrap jz-flex jz-flex-cc" :key="index">
                    <a-dropdown :trigger="['click']">
                      <a-tooltip title="长按拖拽 点击打开菜单">
                        <menu-outlined class="menu-handle" />
                      </a-tooltip>
                      <template #overlay>
                        <a-menu class="menu-list">
                          <a-menu-item
                            v-for="option in state.operateOptions"
                            :disabled="getDisableOperate(option, index)"
                            :key="option.icon"
                            @click="handleRemoveOperation(option, index)"
                          >
                            <div class="menu-item jz-flex jz-flex-cc" style="padding: 4px 0">
                              <svg-icon :icon-name="`ic_${option.icon}`" style="margin-right: 8px" />
                              <span>{{ option.label }}</span>
                            </div>
                          </a-menu-item>
                        </a-menu>
                      </template>
                    </a-dropdown>
                    <div class="card-item jz-flex">
                      <div class="card-num jz-flex jz-flex-center">{{ getMsgNumber(index) }}</div>
                      <div class="card-content">
                        <MessageCardWithType :item="item" :msgType="item.msg_type" />
                      </div>
                      <div class="card-extra jz-flex">
                        <div class="operate-btns jz-flex jz-flex-cc">
                          <UploadFile
                            :data="item"
                            v-if="isResMsg(item)"
                            class="jz-flex jz-flex-cc"
                            @change="(file) => handleSelectedFile({ file, item }, index, 'update')"
                          >
                            <a-tooltip title="编辑">
                              <svg-icon icon-name="ic_edit" />
                            </a-tooltip>
                          </UploadFile>
                          <a-tooltip title="编辑" v-else>
                            <SvgIcon icon-name="ic_edit" @click="handleCurdOperate('edit', item, index)" />
                          </a-tooltip>
                          <MessageTypeDropdown
                            :disabled="isUpperLimitWithType('addContent')"
                            @select="(item) => handleSelectMenu(item, index, 'insert')"
                            @select-file="(res) => handleSelectedFile(res, index, 'insert')"
                          >
                            <template #insert-item>
                              <p style="color: rgba(0, 0, 0, 0.4); padding: 8px 0 8px 8px">下方新增一条</p>
                            </template>
                            <template #adduction>
                              <SvgIcon icon-name="ic_add" />
                            </template>
                          </MessageTypeDropdown>
                          <a-tooltip title="删除">
                            <SvgIcon
                              icon-name="ic_delete"
                              @click="handleCurdOperate('delete', item, index)"
                            />
                          </a-tooltip>
                        </div>
                      </div>
                    </div>
                  </div>
                </template>
              </draggable>
            </div>
            <div class="add-content jz-flex jz-flex-cc">
              <MessageTypeDropdown
                :disabled="isUpperLimitWithType('addContent')"
                @select="handleSelectMenu"
                @select-file="handleSelectedFile"
              >
                <template #adduction>
                  <div class="jz-flex jz-flex-cc">
                    <plus-circle-filled class="add-icon" />
                    <a-button type="link">添加内容</a-button>
                  </div>
                </template>
              </MessageTypeDropdown>
              <span class="desc">{{ modelRef.auto_message_config?.length || 0 }}/20</span>
            </div>
          </a-form-item>
        </a-form>

        <div class="footer-btn jz-flex jz-flex-rr jz-flex-cc">
          <a-button @click="handleCancel">取消</a-button>
          <a-button @click="state.sendVisible = true" :disabled="computedBtn">定时发送</a-button>
          <a-button type="primary" :disabled="computedBtn" @click="handleSubmit">立即发送</a-button>
        </div>
        <EditorTextModal ref="textRef" @success="handleMsgMoadlCallback" :msgTags="state.msgTags" />
        <EditorLinkModal ref="linkRef" @success="handleMsgMoadlCallback" />
        <EditorResourceModal ref="resRef" @success="handleMsgMoadlCallback" />
        <EditorMediaModal
          :media_length="modelRef.auto_message_config?.length || 0"
          ref="mediaRef"
          @success="handleMediaMoadCallback"
        />
      </div>
    </div>
    <a-modal
      centered
      :bodyStyle="{ padding: '16px 32px' }"
      v-model:visible="state.sendVisible"
      title="定时发送"
      @ok="handleSendOk"
    >
      <div class="jz-flex jz-flex-col send-box">
        <div class="tip jz-flex jz-flex-cc">
          <exclamation-circle-filled style="color: #ed7b2f; font-size: 17px" />
          <div>单次定时仅支持设置未来 3 个月内的时间。</div>
        </div>
        <div class="txt">单次定时</div>
        <a-date-picker
          v-model:value="state.time"
          placeholder="发送时间"
          show-time
          @change="handleTimeChange"
        />
      </div>
    </a-modal>

    <!--发送设置-->
    <SetMsgSendDrawer :register="setMsgSendDrawer" @success="() => getMsgConfig()" />
    <!--任务列表-->
    <TaskGroupListDrawer
      :register="taskGroupListDrawer"
      @success="(res) => taskCallback(res)"
      @close="() => getCount()"
    />
  </BasicDrawer>
</template>

<script setup>
/**
 * data
 */
// 抽屉参数
import { useDrawer, useDrawerInner } from '@/components/basic/drawer'
import { reactive, ref, unref } from 'vue'
import { createSopTask, getFilterMember, getSopTempInfo, getSopTempList } from 'api/sop'
import useMessage from '@/composables/web/useMessage'
import { customerStore } from '@/store/modules/customer'
import { getMsgSendConfig, getTaskCount } from 'api/customerManager'
import draggable from 'vuedraggable'

import { isWechatMsg, isResMsg } from '../../customerOperationManager/copms/popover/utils'
import { MessageTypeEnum } from '@/enums/MessageTypeEnum'
import { addMsgSend, uploadFile, uploadImage, uploadVideo } from 'api/common'
import { cloneDeep } from 'lodash-es'
import { isTimeFrame } from '@/assets/js/utils'

const { createMessage, createConfirm } = useMessage()
const store2 = customerStore()
const [setMsgSendDrawer, { openDrawer: openMsgSendDrawer }] = useDrawer()
const [taskGroupListDrawer, { openDrawer: openTaskGroupListDrawer }] = useDrawer()

const [registerDrawer, { closeDrawer }] = useDrawerInner(async (res) => {})
const props = defineProps({
  mediaData: Array,
  register: Function
})
const formLayout = {
  labelCol: { span: 4 },
  wrapperCol: { span: 20 }
}

const current = ref(['myself'])
const isMyself = computed(() => current.value.some((item) => item === 'myself'))

const collapsed = ref(false)
const toggleFold = () => {
  collapsed.value = !unref(collapsed)
}
const activeKey = ref(1)
const mode = ref('top')
const ac_ids = ref([])
const group_ids = ref([])
const textRef = ref()
const linkRef = ref()
const resRef = ref()
const mediaRef = ref()
const state = reactive({
  megConfig: null,
  sendVisible: false,
  filterList: [],
  loading: false,
  activeKey: '1',
  msgTags: [{ label: '@所有人', value: 6 }],

  isDrag: false,
  operateOptions: [
    { label: '置顶', icon: 'top', key: 1 },
    { label: '上移一条', icon: 'up', key: 2 },
    { label: '下移一条', icon: 'down', key: 3 },
    { label: '置底', icon: 'bottom', key: 4 }
  ],
  form: {
    title: '',
    template_list: [],
    template_map: {},
    temp_id: null,
    selectData: {},

    task_type: 2,
    send_type: 1,
    send_time: '',
    auto_message_config: []
  }
})
const modelRef = toRef(state, 'form')

const selectData = ref({})

// 删除/修改操作
const handleCurdOperate = (operType, item, index) => {
  let { msg_type } = item
  currMessageItemIndex.value = index
  switch (operType) {
    case 'edit':
      handleOpenMsgModal(MessageTypeEnum[msg_type], item, true)
      break
    case 'delete':
      unref(modelRef).auto_message_config.splice(index, 1)
      break
  }
}

const handleOpenMsgModal = (type, item = {}, isUpdate, operType) => {
  const { key, msg_type } = item
  switch (type) {
    case 'media':
      mediaRef.value.openModal({
        isUpdate,
        operType,
        data: cloneDeep(item)
      })
      break
    case 'text':
      textRef.value.openModal({
        isUpdate,
        operType,
        data: cloneDeep(item)
      })
      break
    case 'link':
      linkRef.value.openModal({
        isUpdate,
        operType,
        data: cloneDeep(item)
      })
      break
    default:
      if (isWechatMsg(item)) {
        resRef.value.openModal({
          isUpdate,
          operType,
          title: item.label,
          data: {
            ...cloneDeep(item),
            msg_type: key || msg_type
          }
        })
      }
      break
  }
}

// 上限判断
const isUpperLimitWithType = (type) => {
  if (type === 'addContent') {
    return unref(modelRef).auto_message_config?.length >= 20
  }
}
const currMessageItemIndex = ref(-1)

// 添加消息内容
const handleSelectMenu = (item, index, operType) => {
  let { icon: type } = item
  currMessageItemIndex.value = index
  handleOpenMsgModal(type, item, false, operType)
}

// 立即发送处理
const handleSubmit = () => {
  state.form.send_type = 1
  handleSendMsg()
}

// 选择发送时间
const handleTimeChange = (value, dateString) => {
  state.form.send_time = new Date(dateString).getTime() / 1000
}

// 保存消息成功回调处理
const handleMsgMoadlCallback = (_, { isUpdate, data, operType }) => {
  if (Array.isArray(data)) {
    let textList = data.map((row) => ({ ...row, wait: row.wait || 10, time_type: row.time_type || 1 }))
    if (operType === 'insert') {
      unref(modelRef).auto_message_config.splice(currMessageItemIndex.value + 1, 0, ...textList)
    } else {
      unref(modelRef).auto_message_config.push(...textList)
    }
    return
  }
  const params = {
    ...data,
    wait: data.wait || 10,
    time_type: data.time_type || 1
  }
  if (isUpdate && ~currMessageItemIndex.value) {
    unref(modelRef).auto_message_config[unref(currMessageItemIndex)] = params
  } else {
    if (operType === 'insert') {
      unref(modelRef).auto_message_config.splice(currMessageItemIndex.value + 1, 0, params)
    } else {
      unref(modelRef).auto_message_config.push(params)
    }
  }
  currMessageItemIndex.value = -1
}

//素材库信息
const handleMediaMoadCallback = (data) => {
  for (let item of data) {
    unref(modelRef).auto_message_config.push(item)
  }
  createMessage.success('导入成功')
}

// 上传图片/文件/文档
const handleSelectedFile = async ({ file, item: { key, msg_type } }, updateIndex, operType) => {
  key = key ?? msg_type
  if (file) {
    let index = -1
    if (updateIndex !== undefined && updateIndex > -1) {
      if (operType !== 'insert') {
        const editItem = unref(modelRef).auto_message_config[updateIndex]
        if (editItem) {
          editItem.msg.url = ''
          editItem.msg.name = file.name
          editItem.uploading = true
        }
      }
      index = operType === 'insert' ? updateIndex + 1 : updateIndex
    } else {
      index = unref(modelRef).auto_message_config.push(addNewMsg()) - 1
    }
    try {
      const uploadRequest =
        key === MessageTypeEnum.image ? uploadImage : key === MessageTypeEnum.video ? uploadVideo : uploadFile
      const { data } = await uploadRequest({ file })
      if (operType === 'insert') {
        unref(modelRef).auto_message_config.splice(index, 0, addNewMsg())
      } else {
        unref(modelRef).auto_message_config[index].msg.url = data.url
      }
      createMessage.success('上传成功')
    } catch (err) {
      unref(modelRef).auto_message_config.splice(index, 1)
    } finally {
      unref(modelRef).auto_message_config[index].uploading = false
    }
  }

  function addNewMsg() {
    return {
      msg_type: key,
      wait: 10,
      time_type: 1,
      msg: {
        name: file.name,
        url: ''
      },
      uploading: true
    }
  }
}

const getDisableOperate = (item, index) => {
  let { icon: key } = item
  let isDisabled = false
  switch (key) {
    case 'top':
    case 'up':
      isDisabled = index === 0
      break
    case 'bottom':
    case 'down':
      isDisabled = index === unref(modelRef).auto_message_config.length - 1
      break
  }
  return isDisabled
}

// 移动操作
const handleRemoveOperation = (item, index) => {
  let isDisabled = getDisableOperate(item, index)
  if (isDisabled) return

  const { icon: key } = item
  const [removeItem] = unref(modelRef).auto_message_config.splice(index, 1)
  switch (key) {
    case 'top':
    case 'bottom':
      unref(modelRef).auto_message_config[key === 'top' ? 'unshift' : 'push'](removeItem)
      break
    case 'up':
    case 'down':
      let idx = key === 'up' ? index - 1 : index + 1
      unref(modelRef).auto_message_config.splice(idx, 0, removeItem)
      break
  }
}

const getMsgNumber = (index) => {
  return +index + 1 < 10 ? `0${index + 1}` : index + 1
}

/**
 * methods
 * @param val
 */
// 定时发送出来
const handleSendOk = () => {
  let { $y, $M, $D } = state.time
  let _d = new Date()
  let startTime = `${_d.getFullYear()}-${_d.getMonth() + 1}-${_d.getDate()}`
  var lastDate = new Date(_d.getFullYear(), _d.getMonth() + 3, _d.getDate())
  let endTime = `${lastDate.getFullYear()}-${lastDate.getMonth() + 1}-${lastDate.getDate()}`
  if (!state.time) {
    createMessage.warn('请填写发送时间')
    return
  }
  if (!isTimeFrame(startTime, endTime, `${$y}-${$M + 1}-${$D}`)) {
    createMessage.warn('不在未来三个月范围内，请重新选择时间')
    return
  }

  state.form.send_type = 2
  state.sendVisible = false
  setTimeout(() => {
    handleSendMsg()
  }, 500)
}

// 发送群消息
const handleSendMsg = async () => {
  let { code } = await addMsgSend(unref(sendParams))
  if (code === 1000) {
    createMessage.success('发送群信息成功')
    closeTagDrawer()
  }
}

// 抽屉展示关闭
const handelVisibleChange = async (val) => {
  if (!val) {
    current.value = ['myself']
    store2.customerSelectCount = 0
    store2.groupsSelectCount = 0
    group_ids.value = []
    selectData.value = {}
    collapsed.value = false
    ac_ids.value = []
    state.form.temp_id = null

    state.form.auto_message_config = []
    state.form.title = ''
  } else {
    await getCount()
    await getMsgConfig()

    if (props.mediaData) {
      unref(modelRef).auto_message_config = props.mediaData
    }
  }
}

// 拖动动效
const dragOptions = ref({
  animation: 200,
  disabled: false,
  ghostClass: 'ghost'
})

// 获取任务数量
const getCount = async () => {
  let {
    data: { run }
  } = await getTaskCount({ task_type: 2 })
  state.taskCount = run
}

// 返回
const SopGroupListRef = ref()
const SopCustomerListRef = ref()

const closeTagDrawer = () => {
  SopGroupListRef.value.clearFields()
  SopGroupListRef.value.resetGroup()
  SopCustomerListRef.value.clearFields()
  SopCustomerListRef.value.resetGroup()

  closeDrawer()
}

// 任务列表抽屉回调
const taskCallback = (res) => {
  SopCustomerListRef.value.echoData(res.groupArr.filter((i) => i.msg_member_type === 1))
  SopGroupListRef.value.echoData(res.groupArr.filter((i) => i.msg_member_type === 2))

  let { title, send_content } = res.msgObj
  state.form.title = title
  unref(modelRef).auto_message_config = send_content
}

// 取消发送
const handleCancel = () => {
  createConfirm({
    content: `取消后编辑的内容不会保存，是否确认取消？`,
    onOk() {
      closeTagDrawer()
    }
  })
}

const sendParams = computed(() => {
  let { title, send_type, send_time, task_type } = state.form
  let send_content = state.form.auto_message_config.map((row) => {
    return {
      ...row.msg,
      msg_type: row.msg_type
    }
  })

  return {
    title,
    send_type,
    task_type,
    send_content,
    send_time,
    ac_ids: unref(ac_ids).join(','),
    group_ids: unref(group_ids).join(',')
  }
})

const getCustomerCheckList = (value) => {
  ac_ids.value = value.map((i) => i.ac_id)
}

const getGroupCheckList = (value) => {
  group_ids.value = value
}

// 获取群发默认配置
const getMsgConfig = async () => {
  let { data } = await getMsgSendConfig()
  state.megConfig = data
}

// 按钮禁止提交
const computedBtn = computed(() => {
  let lock = true
  if (
    state.form.title &&
    store2.customerSelectCount + store2.groupsSelectCount > 0 &&
    state.form.auto_message_config?.length
  ) {
    lock = false
  }
  return lock
})

onMounted(async () => {})

/**
 * watch / hooks
 */
</script>

<style lang="less" scoped>
:deep(.ant-drawer-header) {
  padding: 32px 32px 0 32px;
}

.head {
  position: relative;
  height: 60px;

  .tit {
    font-size: 20px;
    font-weight: bold;
  }

  .back-btn {
    margin-right: 8px;
    border-radius: 4px;
    padding-left: 0px;
    position: relative;
    width: 32px;
    height: 32px;

    .svg-icon {
      position: absolute;
      left: 8px;
    }
  }

  .line {
    width: 100%;
    height: 1px;
    background-color: #eee;
    transform: scaleY(0.6);
    position: absolute;
    left: 0;
    bottom: 0;
    right: 0;
  }
}

.container {
  width: 100%;
  height: 100%;

  .left-content {
    height: 100%;
    width: 617px;
    border-right: 1px solid rgba(238, 238, 238, 0.6);
    visibility: visible;
    transition: all 0.2s;
    .page-side-fold {
      position: fixed;
      top: 200px;
      left: 0px;
      width: 16px;
      height: 58px;
      background: #eeeeee;
      border-top-left-radius: 0;
      border-bottom-left-radius: 0;
      border-top-right-radius: 6px;
      border-bottom-right-radius: 6px;
      cursor: pointer;
      transition: left 0.28s;
      z-index: 1;

      &.is-expand {
        left: 608px;
        border-radius: 24px;
        opacity: 0;
      }

      .anticon {
        font-size: 12px;
        cursor: pointer;
        color: rgba(0, 0, 0, 0.2);
      }
    }

    &:hover {
      .page-side-fold.is-expand {
        opacity: 1;
      }
    }

    .ant-menu {
      height: 48px;
      margin-left: 32px;
      :deep(.ant-menu-item) {
        padding-left: 0px;
        margin-right: 60px;
        color: #999999;
        &:hover {
          color: #3165f5;
        }
        &::after {
          left: 0px;
        }
        &:hover {
          &::after {
            border-bottom: 2px solid transparent;
          }
        }
      }
      :deep(.ant-menu-item-selected) {
        &:hover {
          &::after {
            border-bottom: 2px solid #3165f5;
          }
        }
        .ant-menu-title-content {
          color: #3165f5;
        }
      }
    }
    .ant-menu-horizontal {
      border-bottom: 1px solid rgba(238, 238, 238, 0.6);
    }
    .form-content {
      > div {
        height: 100%;
      }
    }
  }
  .right-content {
    height: 100%;
    flex: 1;
    padding: 32px 32px 0 32px;
    overflow: auto;
    .tit {
      font-size: 20px;
      font-weight: bold;
      margin-bottom: 32px;
    }

    .add-content {
      .add-icon {
        font-size: 16px;
        color: @primary-color;
      }

      .decs {
        margin-left: 8px;
        color: rgba(0, 0, 0, 0.4);
      }
    }
    .card-list {
      width: 100%;

      .card-item-wrap {
        width: 100%;

        &:hover {
          .card-item .card-extra .operate-btns {
            visibility: visible;

            .svg-icon {
              width: 24px !important;
              height: 24px !important;
              padding: 4px;

              &:hover {
                background: rgba(0, 0, 0, 0.04);
                border-radius: 4px;
              }
            }
          }

          :deep(.anticon-menu) {
            visibility: visible;
          }
        }

        :deep(.anticon-menu) {
          margin-right: 12px;
          padding-top: 3px;
          visibility: hidden;

          :hover {
            color: @primary-color;
          }
        }

        .card-item {
          flex: auto;
          min-height: 56px;
          padding: 12px;
          background: rgba(0, 0, 0, 0.04);
          border-radius: 6px;
          box-sizing: border-box;

          .card-num {
            width: 24px;
            height: 24px;
            align-items: center;
            border-radius: 50%;
            background: #eeeeee;
            color: #000000;
            font-size: 12px;
            margin-right: 16px;
          }

          .card-content {
            flex: auto;
          }

          .card-extra {
            flex: none;
            display: flex;
            align-items: flex-start;

            .operate-btns {
              height: 32px;
              visibility: hidden;

              > * {
                margin-right: 16px;
                cursor: pointer;
                &:last-child {
                  margin-right: 0;
                }
              }
            }

            .time-bar {
              > span {
                margin-right: 12px;
                color: rgba(0, 0, 0, 0.4);
              }

              .time-input {
                :deep(.ant-input-number-input-wrap) {
                  width: 56px;
                }
              }
            }
          }
        }

        + .card-item-wrap {
          margin-top: 12px;
        }

        + .add-content {
          margin-top: 16px;
        }
      }
    }

    :deep(.ant-form-item) {
      .ant-form-item-label {
        flex: 0 0 80px;
        max-width: 80px;
        display: inline-flex;

        > label {
          width: 90px;
          font-weight: 550;
          font-size: 14px;
          color: #000;
        }
      }
    }
    :deep(.ant-tabs-content-holder) {
      height: 100%;
    }
    :deep(.ant-tabs-content) {
      height: 100%;
      .ant-tabs-tabpane {
        height: 100%;
        display: flex;
        flex-direction: column;
      }
    }

    .table-tip {
      margin: 8px 0 16px 0;
      .nav-text {
        color: #ed7b2f;
        margin-left: 10px;
        white-space: nowrap;
      }
    }

    .auto-message-list {
      overflow: auto;
      padding-right: 6px;
      // 修改滚动条
      &:hover {
        &::-webkit-scrollbar-thumb {
          visibility: visible;
        }
        .page-side-fold.is-expand {
          opacity: 1;
        }
      }
      &::-webkit-scrollbar {
        width: 2px;
      }
      &::-webkit-scrollbar-thumb {
        visibility: hidden;
        transition: all 0.28s;
      }
      .auto-message-item {
        padding: 12px;
        background: #f5f5f5;
        border-radius: 6px 6px 6px 6px;
        margin-bottom: 12px;
        &:last-child {
          margin-bottom: 0px;
        }
        .box-serial {
          font-size: 12px;
          font-weight: 400;
          color: #999999;
          line-height: 14px;
          background: #eeeeee;
          width: 24px;
          height: 24px;
          display: flex;
          justify-content: center;
          align-items: center;
          border-radius: 50%;
          margin-right: 16px;
        }
        .text-type {
          color: #000;
          font-size: 14px;
        }

        .img-type {
          img {
            width: 120px;
            height: 120px;
            border-radius: 4px;
          }
        }

        .video-type {
          position: relative;

          > video {
            width: 120px;
            height: 120px;
            object-fit: cover;
            border-radius: 4px;
          }

          .svg-icon {
            position: absolute;
            left: 15px;
            top: 10px;
            color: #fff;
            width: 16px !important;
            height: 16px !important;
          }
        }

        .file-type {
          .svg-icon {
            width: 20px !important;
            height: 20px !important;
            min-width: 20px;
            min-height: 20px;
            margin-right: 4px;
          }
        }

        .link-type {
          width: 90px;
          height: 42px;
          background: #eee;
          position: relative;
          padding: 5px;
          border-radius: 4px;

          &::before {
            content: '';
            width: 0;
            height: 0;
            left: -7px;
            top: 10px;
            position: absolute;
            border-right: 5px solid transparent;
            border-left: 5px solid transparent;
            border-bottom: 5px solid #eee;
            transform: rotate(-90deg);
          }

          .link-tit {
            font-size: 6px;
            color: #000;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 2;
            overflow: hidden;
            line-height: 7px;
            text-align: left;
            width: 100%;
          }

          .desc {
            width: 100%;

            &-text {
              font-size: 5px;
              color: @font-minor-color;
              overflow: hidden;
            }

            img {
              width: 18px;
              height: 18px;
            }
          }
        }

        .wx-type {
          width: 90px;
          height: 100px;
          background: #eee;
          position: relative;
          padding: 5px;
          border-radius: 4px;

          &::before {
            content: '';
            width: 0;
            height: 0;
            left: -7px;
            top: 10px;
            position: absolute;
            border-right: 5px solid transparent;
            border-left: 5px solid transparent;
            border-bottom: 5px solid #eee;
            transform: rotate(-90deg);
          }

          .logo-box {
            width: 100%;
            font-size: 8px;
            color: @font-minor-color;
            margin-bottom: 2px;

            img {
              width: 8px;
              height: 8px;
              border-radius: 50%;
              margin-right: 5px;
            }
          }

          .wx-bg {
            width: 100%;
            height: 100%;

            img {
              width: 100%;
              height: 100%;
            }
          }

          .wx-name {
            font-size: 6px;
            margin-top: 3px;
            display: block;
            width: 100%;
            display: flex;
          }
        }

        .audio-type {
          .svg-icon {
            width: 58px !important;
            height: 24px !important;
          }
        }

        .voice-type {
          width: 58px;
          height: 24px;
          background: #eeeeee;
          border-radius: 4px;
        }

        .wx-video-type {
          width: 83px;
          height: 110px;
          position: relative;
          border-radius: 4px;
          background: #eeeeee linear-gradient(360deg, rgba(0, 0, 0, 0.5) 0%, rgba(0, 0, 0, 0) 100%);

          .head {
            width: 100%;
            height: 100%;
            position: relative;

            .svg-icon {
              width: 16px !important;
              height: 16px !important;
              left: 50%;
              top: 50%;
              position: absolute;
              color: #fff;
              margin-left: -8px;
            }

            img {
              width: 100%;
              height: 100%;
              border-radius: 4px;
            }
          }

          .wx-tit {
            font-size: 6px;
            color: #fff;
            position: absolute;
            left: 0;
            bottom: 0px;
            right: 0;
            padding-left: 4px;

            img {
              width: 10px;
              height: 10px;
              margin-right: 3px;
            }
          }
        }

        .group-invite-box {
          background: #fdeee4;
          color: #ed7b2f;
          width: 52px;
          height: 22px;
          border-radius: 4px 4px 4px 4px;
          font-size: 12px;
        }
        .group-notice-box {
          background: #fff6e5;
          color: #ffa800;
          width: 52px;
          height: 22px;
          border-radius: 4px 4px 4px 4px;
          font-size: 12px;
          margin-bottom: 6px;
        }
        .group-invite-text {
          margin-top: 6px;
          color: #ed7b2f;
        }

        .auto-message-item-time {
          color: #999999;
          margin-left: 16px;
        }
      }
    }
    .footer-btn {
      width: 100%;
      height: 64px;

      .ant-btn {
        margin-right: 10px;

        &:last-child {
          margin-right: 0;
        }
      }
    }
  }
}
.send-box {
  .tip {
    color: #ed7b2f;
    margin-bottom: 24px;

    > div {
      margin-left: 9px;
    }
  }

  .txt {
    margin-bottom: 10px;
  }
}
</style>

<style lang="less">
.created-sop-modal {
  .ant-modal-footer {
    border-top: 1px solid rgba(238, 238, 238, 0.6);
  }
  .tip {
    color: #999999;
  }
  .txt {
    margin-top: 24px;
  }
  .send-list {
    margin-top: 8px;
    .send-item {
      background: #f5f5f5;
      border-radius: 6px 6px 6px 6px;
      padding: 10px 16px 10px 10px;
      font-size: 14px;
      margin-right: 8px;
      margin-bottom: 8px;
      img {
        width: 28px;
        height: 28px;
        border-radius: 4px;
        margin-right: 8px;
      }
    }
  }
}
</style>
