<template>
  <a-popover
    overlayClassName="ant-phone-popover"
    v-model:visible="visible"
    trigger="click"
    :disabled="disabled"
    placement="bottomRight"
    @visibleChange="handleChange"
    :getPopupContainer="
      (triggerNode) => {
        return triggerNode.parentNode || document.body
      }
    "
  >
    <template #content>
      <div class="pop jz-flex jz-flex-col">
        <div class="search jz-flex jz-flex-cc">
          <div class="search-input jz-flex jz-flex-cc" :class="state.isError && 'error'">
            <input
              type="number"
              class="jz-flex-1"
              ref="inputRef"
              placeholder="输入回车后可添加"
              v-model="state.phone"
              @input="handlePhone"
              @keydown="addMobile"
            /><label v-if="state.isError">请输入正确手机号</label>
          </div>
          <span style="color: #999; margin-left: 8px">{{ state.list.length }}/1000</span>
        </div>
        <ul class="list">
          <template v-if="state.list.length">
            <li class="item jz-flex jz-flex-center" v-for="(item, index) in state.list" :key="index">
              <a-tag closable @close="state.list.splice(index, 1)">{{ item }}</a-tag>
            </li>
          </template>
          <template v-else>
            <div style="color: #f23944">至少添加一个手机号</div>
          </template>
        </ul>
        <div class="ant-popover-footer ant-popover-footer-line jz-flex jz-flex-rr" style="border: none">
          <div class="btns">
            <a-button @click="close">取消</a-button>
            <a-button type="primary" @click="handleConfirm" :disabled="!state.list.length">确定</a-button>
          </div>
        </div>
      </div>
    </template>
    <slot></slot>
  </a-popover>
</template>
<script setup>
import useMessage from '@/composables/web/useMessage'
import { phoneReg } from '@/assets/js/utils'
import { toRaw } from 'vue'
const { createMessage } = useMessage()
const emit = defineEmits(['success'])
const visible = ref(false)
const props = defineProps({
  ids: Array,
  disabled: Boolean
})
const state = reactive({
  phone: '',
  list: [],
  isError: false
})

// 输入号码
const handlePhone = () => {
  let _strPhone = state.phone + ''
  state.phone = _strPhone.length > 11 ? _strPhone.substring(0, 11) : state.phone
  if (state.phone && !phoneReg.test(state.phone)) {
    state.isError = true
  } else {
    state.isError = false
  }
}

const addMobile = (e) => {
  if (e.keyCode === 13 && !state.isError) {
    if (state.phone === '') {
      createMessage.info('手机号码格式错误')
      return
    }
    if (state.list.length >= 1000) {
      createMessage.info('最多只能添加1000个号码')
      return
    }
    if (state.list.includes(state.phone)) {
      createMessage.error(`号码${state.phone}重复了`)
      return
    }
    state.list.push(state.phone)
    state.list = [...new Set([...state.list])]
    state.phone = ''
  }
}

// 确认提交
const handleConfirm = () => {
  emit('success', toRaw(state.list))
  close()
}

// 展示提示框
const handleChange = (show) => {
  if (show) {
    state.list = [...props.ids]
  }
}

// 关闭
const close = () => {
  state.list = []
  state.phone = ''
  visible.value = false
}
</script>
<style lang="less" scoped>
.pop {
  overflow: hidden;
  height: 100%;
  .pop-tit {
    font-size: 16px;
    font-weight: bold;
  }
  .search {
    width: 100%;
    height: 32px;
    &-input {
      width: 100%;
      height: 100%;
      box-shadow: 0px 6px 58px 0px rgba(196, 203, 214, 0.1);
      border-radius: 8px;
      border: 1px solid #eee;
      padding: 0px 8px;
      input {
        outline: none;
        border: none;
      }
      &.error {
        border: 1px solid #f5313d;
        input {
          color: #f23944;
        }
      }
      label {
        color: #f23944;
      }
    }
  }
  .list {
    width: 100%;
    min-height: 160px;
    max-height: 160px;
    overflow-y: auto;
    border-radius: 6px;
    margin-top: 16px;
    padding: 12px 12px 16px;
    background: #fafafa;
    li {
      width: 109px;
      font-size: 12px;
      background: #f0f0f0;
      height: 22px;
      border-radius: 4px;
      padding: 0 8px;
      cursor: pointer;
      margin-right: 8px;
      margin-bottom: 8px;
      float: left;
      &:nth-child(4n + 4) {
        margin-right: 0px;
      }
    }
  }
}
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none !important;
}
input[type='number'] {
  -moz-appearance: textfield;
}
:deep(.ant-tag) {
  background: #f0f0f0;
  margin-right: 0px;
}
</style>
<style lang="less">
.ant-phone-popover {
  .ant-popover-content {
    width: 516px;
    height: 296px;
    background: #fff;
    .ant-popover-inner {
      height: 100%;
    }
    .ant-popover-inner-content {
      height: 100%;
    }
    .ant-popover-arrow-content {
      opacity: 0;
    }
  }
}
</style>
