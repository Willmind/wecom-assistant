<template>
  <BasicDrawer
    :register="registerDrawer"
    showFooter
    :showCancelBtn="false"
    title="批量修改备注"
    :width="600"
    :confirmLoading="isSubmiting"
    @ok="handleConfirm"
    @visible-change="handleVisivleChange"
  >
    <div class="wrapper">
      <a-tabs v-model:activeKey="activeTab">
        <a-tab-pane key="def" tab="统一修改">
          <div class="tag-list jz-flex">
            <a-tag class="ant-tag-plain ant-tag-big" @click="handlePickTag('当前备注')">当前备注</a-tag>
            <a-tag class="ant-tag-plain ant-tag-big" @click="handlePickTag('昵称')">昵称</a-tag>
            <a-tag class="ant-tag-plain ant-tag-big" @click="handlePickTag('性别')">性别</a-tag>
            <a-tag class="ant-tag-plain ant-tag-big" @click="handlePickTag('添加日期')">添加日期</a-tag>
          </div>
          <a-form class="editor-form">
            <a-form-item v-bind="validInfo.remark">
              <RichEdtior
                bordered
                ref="richRef"
                :value="form.jsonContent"
                :toolbar="['tag']"
                :autoRows="{ minRow: 3 }"
                placeholder="请输入备注"
                @change="handleContentChange"
              />
            </a-form-item>
          </a-form>
          <a-divider />
          <div class="desc-box">
            <div class="desc-title">举例</div>
            <div class="desc-card">
              <div class="line-wrap jz-flex">
                <div class="line-item">
                  <label for="">当前备注</label>
                  <span>小明妈妈</span>
                </div>
                <div class="line-item">
                  <label for="">统一格式效果</label>
                  <span>
                    <a-tag class="ant-tag-plain">当前备注</a-tag>
                    <span class="split">-</span>
                    <a-tag class="ant-tag-plain">性别</a-tag>
                    <span class="split">-</span>
                    <a-tag class="ant-tag-plain">添加日期</a-tag>
                    <span class="split">-</span>
                    <span>数学</span>
                  </span>
                </div>
                <div class="line-item">
                  <label>修改后</label>
                  <span>小明妈妈-女-220910-数学</span>
                </div>
              </div>
            </div>
            <div class="remark">
              <p>1.变量间如需分隔符请自行设置。</p>
              <p>2.在已有备注基础上增加信息，可选中“当前备注”添加其他属性。</p>
              <p>3.超出 20 字的部分无法显示。</p>
            </div>
          </div>
        </a-tab-pane>
        <a-tab-pane key="keywork" tab="关键词修改">
          <a-form :colon="false" class="keywork-form">
            <a-form-item label="关键词" v-bind="keyworkValidInfo.search_word">
              <a-input v-model:value="keyworkForm.search_word" placeholder="请输入关键词" />
            </a-form-item>
            <a-form-item label="替换为" v-bind="keyworkValidInfo.replace_word">
              <a-input v-model:value="keyworkForm.replace_word" placeholder="请输入替换的文本" />
            </a-form-item>
          </a-form>
          <a-divider />
          <div class="desc-box">
            <div class="desc-title">举例</div>
            <div class="desc-card">
              <div class="line-wrap jz-flex">
                <div class="line-item">
                  <label for="">当前备注</label>
                  <span>小明妈妈 - 20 级数学班</span>
                </div>
                <div class="line-item">
                  <label for="">统一格式效果</label>
                  <span> “20” 修改为 “21” </span>
                </div>
                <div class="line-item">
                  <label>修改后</label>
                  <span>小明妈妈-21 级数学班</span>
                </div>
              </div>
            </div>
            <div class="remark">
              <p>1.若备注中不包含关键词，将不进行修改。</p>
              <p>2.超出 20 字的部分无法显示。</p>
            </div>
          </div>
        </a-tab-pane>
      </a-tabs>
    </div>
  </BasicDrawer>
</template>
<script setup>
import { batchReplaceRemarkWork, batchUpdateRemark } from '@/api/customerManager'
import { useDrawerInner } from '@/components/basic/drawer'
import { Form } from 'ant-design-vue'
import { reactive, ref, toRaw, unref } from 'vue'
import { getTranformJSONContentToText } from '@/utils/customer'

defineProps({
  register: Function
})

const emit = defineEmits(['success'])

const activeTab = ref('def')
const ids = ref([])
const richRef = ref()
const tagList = ref([])
const isSubmiting = ref(false)
const useForm = Form.useForm
const useFormForKeywork = Form.useForm
const state = reactive({
  notIds: [],
  hash: null,
  isAll: false
})
const form = reactive({
  remark: '',
  jsonContent: null
})
const keyworkForm = reactive({
  search_word: '',
  replace_word: ''
})
const rulesRefs = ref({
  remark: [{ required: true, message: '请输入备注', trigger: 'change' }]
})

const keyRulesRefs = ref({
  search_word: [{ required: true, message: '请输入关键词', trigger: 'change' }],
  replace_word: [{ required: true, message: '请输入替换的文本', trigger: 'change' }]
})

const { validateInfos: validInfo, validate, resetFields } = useForm(form, rulesRefs)
const {
  validateInfos: keyworkValidInfo,
  validate: keyworkValidate,
  resetFields: keywordResetFields
} = useFormForKeywork(keyworkForm, keyRulesRefs)

const [registerDrawer, { closeDrawer }] = useDrawerInner((res) => {
  if (res?.ids) {
    ids.value = res.ids
  }
  state.hash = res.hash
  state.isAll = res.isAll
  state.notIds = res.excludeIds || []
})

const handleConfirm = () => {
  let params = {}
  if (activeTab.value === 'keywork') {
    keyworkValidate().then(async () => {
      isSubmiting.value = true
      params = {
        ac_ids: unref(ids).join(','),
        ...toRaw(keyworkForm)
      }
      if (state.isAll) {
        if (state.notIds?.length) {
          params.not_ids = state.notIds.join(',')
        } else if (state.hash) {
          params.hash = state.hash
          delete params.ac_ids
        }
      }
      try {
        await batchReplaceRemarkWork(params)
        emitSuccess()
      } catch (error) {
        isSubmiting.value = false
      }
    })
  } else if (activeTab.value === 'def') {
    validate().then(async () => {
      try {
        params = {
          ac_ids: unref(ids).join(','),
          remark: form.remark
        }
        if (state.isAll) {
          if (state.notIds?.length) {
            params.not_ids = state.notIds.join(',')
          } else if (state.hash) {
            params.hash = state.hash
            delete params.ac_ids
          }
        }
        isSubmiting.value = true
        await batchUpdateRemark(params)
        emitSuccess()
      } catch (error) {
        isSubmiting.value = false
      }
    })
  }
}

const handleContentChange = ({ json }) => {
  form.remark = getTranformJSONContentToText(json)
}

const handlePickTag = (tag) => {
  unref(richRef).editorRef.chain().focus().setTag(tag).run()
}

const emitSuccess = () => {
  isSubmiting.value = false
  resetFields()
  emit('success')
  closeDrawer()
}

const handleVisivleChange = (v) => {
  if (!v) {
    clearData()
  }
}

const clearData = () => {
  ids.value = []
  form.remark = ''
  state.isAll = false
  state.notIds = []
  state.hash = null
  tagList.value = []
  resetFields()
  form.jsonContent = null
  keywordResetFields()
}
</script>
<style lang="less" scoped>
.wrapper {
  padding: 0 32px;
  .tag-list,
  .keywork-form {
    margin-top: 16px;
  }

  .editor-form {
    margin-top: 16px;
    padding: 0;
    .form-select {
      max-height: 98px;
      overflow-y: auto;
    }
  }

  .keywork-form {
    :deep(.ant-form-item) :deep(.ant-form-item-label) {
      margin-right: 32px;
      font-weight: 550;
    }
  }

  .desc-box {
    .desc-title {
      line-height: 16px;
      color: rgba(0, 0, 0, 0.4);
    }
    .desc-card {
      margin-top: 10px;
      width: 403px;
      height: 110px;
      padding: 16px;
      background: rgba(0, 0, 0, 0.04);
      border-radius: 6px;
      .line-wrap {
        align-items: center;
        flex-wrap: wrap;
        .line-item {
          display: flex;
          align-items: center;
          color: #000000;
          width: 100%;
          > label {
            width: 84px;
            flex: 0 0 86px;
            text-align: right;
            margin-right: 16px;
          }
          > span {
            flex: auto;
          }
          .split {
            margin-right: 8px;
          }
          + .line-item {
            margin-top: 10px;
          }
        }
      }
    }
  }
  .remark {
    margin-top: 10px;
    > p {
      margin-bottom: 4px;
      color: rgba(0, 0, 0, 0.4);
    }
  }
}
</style>
