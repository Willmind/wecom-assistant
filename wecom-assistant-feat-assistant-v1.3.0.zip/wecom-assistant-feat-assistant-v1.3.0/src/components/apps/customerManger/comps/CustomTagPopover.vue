<template>
  <a-popover
    overlayClassName="ant-popover-not-arrow"
    v-model:visible="visible"
    trigger="click"
    placement="bottomLeft"
    @visibleChange="handleChange"
  >
    <template #content>
      <div class="card-content ant-popover-content" v-loading="loading">
        <div class="card-topic" v-if="isSearch">
          <a-input
            ref="searchRef"
            class="input-search"
            v-model:value="form.label_name"
            allow-clear
            placeholder="搜索"
          >
            <template #prefix>
              <svg-icon icon-name="ic_search" />
            </template>
          </a-input>
          <div class="check-groups" v-if="needCheckGroup">
            <a-radio-group v-model:value="form.type" :options="options" />
          </div>
        </div>
        <TagsList
          v-if="form.type !== 4"
          :data="tagMap"
          :height="isSearch && needCheckGroup ? 'calc(100% - 100px)' : null"
          @checkChange="handleCheckChange"
        />
      </div>
      <div class="ant-popover-footer jz-flex jz-flex-rr" v-if="showFooter">
        <div class="btns">
          <a-button @click="onClose">取消</a-button>
          <a-button type="primary" :loading="isSubmiting" @click="handleConfirm">确认</a-button>
        </div>
      </div>
    </template>
    <slot></slot>
  </a-popover>
</template>
<script setup>
import { searchTag } from '@/api/common'
import { updateLabel } from '@/api/customerManager'
import { cloneDeep, debounce } from 'lodash-es'
import { ref, reactive, watch, toRaw, toRef, unref, nextTick } from 'vue'
import TagsList from './TagsList.vue'
import useMessage from '@/composables/web/useMessage'
const { createMessage } = useMessage()
const props = defineProps({
  acId: [String, Number],
  data: Object,
  isSearch: Boolean,
  showFooter: {
    type: Boolean,
    default: true
  },
  isUpdate: Boolean,
  isReset: Boolean,
  needCheckGroup: Boolean,
  limit: Number
})
const emit = defineEmits(['success', 'select-change'])

const debounceSearch = debounce(queryTagList, 350)

const visible = ref(false)
const loaded = ref(false)
const searchRef = ref()
const form = reactive({
  label_name: '',
  type: 2
})
const loading = ref(false)
const isSubmiting = ref(false)
const tagMap = ref({
  company: [],
  user: []
})
const originData = ref({})
const dataRef = toRef(props, 'data')
const selectedRows = ref([])

const options = ref([
  { label: '满足任意一个选中标签', value: 1 },
  { label: '所有选中标签', value: 2 },
  { label: '除开选中标签', value: 3 },
  { label: '未打标签好友', value: 4 }
])

// const isEnabelConfirm = computed(() => {
//   return props.isSearch ? form.type || !!selectedRows.value.length : !!selectedRows.value.length
// })

async function queryTagList() {
  loading.value = true
  const { data } = await searchTag({ ...toRaw(form) })
  tagMap.value = data || {}
  originData.value = cloneDeep(data)
  loading.value = false
  loaded.value = true
  nextTick(() => handleMatchLabels(unref(dataRef)))
}

async function handleUpdateTag() {
  let { acId } = props
  let selectRows = selectedRows.value
  isSubmiting.value = true
  try {
    await updateLabel({
      ac_id: acId,
      label_ids: selectRows.map((item) => item.label_id).join(',')
    })
    onClose()
    emit('success')
  } finally {
    isSubmiting.value = false
  }
}

const handleCheckChange = (row) => {
  handleCheckItem(row)
  props.isSearch && !props.showFooter && emitSelectedRows()
}

const handleCheckItem = (row) => {
  removeItem(row)
  if (row.checked) {
    selectedRows.value.push(row)
  }

  function removeItem(row) {
    let index = selectedRows.value.findIndex((item) => item.label_id === row.label_id)
    if (~index) {
      selectedRows.value.splice(index, 1)
    }
  }
}

const emitSelectedRows = () => {
  emit('select-change', {
    type: form.type,
    tags:
      form.type === 4
        ? []
        : selectedRows.value.map((item) => ({ label: item.name, value: item.label_id, type: item.type }))
  })
}

const handleMatchLabels = (data) => {
  if (!data) return
  let label_ids = (Array.isArray(data) ? data || [] : data.label_id || []).map(
    (row) => row.label_id ?? row.id ?? row
  )
  for (let key in tagMap.value) {
    let groups = tagMap.value[key]
    groups.forEach((group) => {
      group.label?.forEach((item) => {
        let isCheck = label_ids?.includes(item.label_id.toString())
        Reflect.set(item, 'checked', isCheck)
        handleCheckItem(item)
      })
    })
  }
}

watch(
  () => form.label_name,
  () => {
    debounceSearch()
  }
)

// watch(
//   () => dataRef.value,
//   (v) => {
//     console.log('------watch---->>', v)
//     handleMatchLabels(v)
//   },
//   {
//     deep: true,
//     immediate: true
//   }
// )

watch(
  () => props.isReset,
  (v) => {
    v && clearData()
  }
)

const handleConfirm = () => {
  if (props.limit && selectedRows.value.length + props.data.label_id.length > props.limit) {
    createMessage.info(`最多只能选择${props.limit}个标签`)
    return
  }
  if (props.isSearch) {
    if (!props.isUpdate) {
      emitSelectedRows()
      onClose()
      return
    }
  }
  handleUpdateTag()
}

const handleChange = (show) => {
  if (show) {
    setTimeout(() => {
      searchRef?.value?.focus()
    }, 300)
    if (loaded.value) {
      handleMatchLabels(dataRef.value)
      return
    }
    queryTagList()
  }
}

const clearData = () => {
  form.type = 2
  form.label_name = ''
  selectedRows.value = []
}

const onClose = () => {
  visible.value = false
}
</script>
<style lang="less" scoped>
.card-content {
  width: 560px;
  max-height: 420px;
  position: relative;
  padding: 0;
  box-sizing: border-box;
  .card-list {
    height: 320px !important;
    margin: 16px -16px 0 0;
  }
  .card-topic {
    position: sticky;
    top: 0;
    .input-search {
      margin-bottom: 16px;
    }
  }

  .check-groups {
    height: 52px;
    display: flex;
    align-items: center;
  }
}

</style>
