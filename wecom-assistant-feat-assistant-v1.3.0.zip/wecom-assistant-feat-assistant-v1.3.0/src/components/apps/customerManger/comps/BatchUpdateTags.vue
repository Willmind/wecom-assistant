<template>
  <BasicDrawer
    v-bind="$attrs"
    showFooter
    :register="registerDrawer"
    :showCancelBtn="false"
    title="批量修改标签"
    :width="560"
    @close="onClose"
    @visible-change="handleVisivleChange"
  >
    <div class="wrapper">
      <div class="head jz-flex">
        <a-input v-model:value="form.label_name" style="flex: 0 0 334px" placeholder="搜索" allow-clear>
          <template #prefix>
            <search-outlined />
          </template>
        </a-input>
        <div class="extra">
          <span>仅显示已选</span>
          <a-switch v-model:checked="form.isShowSelected" />
        </div>
      </div>
      <div class="tag-content">
        <div class="tag-list" v-show="form.isShowSelected ? selectTags.length : true">
          <div class="tag-item jz-flex">
            <div class="tag-item-label">企业标签</div>
            <div class="tag-item-content">
              <div class="content-item" v-for="(item, index) in companyTags" :key="index">
                <div :class="index ? 'item-head' : ''">
                  <p class="sub-title">{{ item.group }}</p>
                </div>
                <div class="items">
                  <a-checkable-tag
                    class="ant-tag-big"
                    v-model:checked="row.checked"
                    v-for="row in item.label"
                    :key="row.label_id"
                    @change="handleCheckChange(row)"
                  >
                    {{ row.name }}
                  </a-checkable-tag>
                </div>
              </div>
            </div>
          </div>
          <div class="tag-item jz-flex">
            <div class="tag-item-label">个人标签</div>
            <div class="tag-item-content">
              <div class="content-item" v-for="(item, index) in userTags" :key="index">
                <div class="items personal">
                  <a-checkable-tag
                    class="ant-tag-big"
                    v-model:checked="row.checked"
                    v-for="row in item.label"
                    :key="row.label_id"
                    @change="handleCheckChange(row)"
                  >
                    {{ row.name }}
                  </a-checkable-tag>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <template #footer>
      <footer class="custom-footer jz-flex jz-flex-rb">
        <div class="btns">
          <a-radio-group v-model:value="state.type">
            <a-tooltip title="对已选择客户批量添加已选中的标签，其他原来的标签保持不变">
              <a-radio :value="1">批量添加标签</a-radio>
            </a-tooltip>
            <a-tooltip title="对已选择客户批量删除已选中的标签，其他原来的标签保持不变">
              <a-radio :value="2">批量删除标签</a-radio>
            </a-tooltip>
          </a-radio-group>
        </div>
        <a-button type="primary" :loading="isSubmiting" :disabled="!selectTags.length" @click="handleConfirm"
          >确定</a-button
        >
      </footer>
    </template>
  </BasicDrawer>
</template>
<script setup>
import { extend, debounce, cloneDeep } from 'lodash-es'
import { reactive, ref, toRef, toRefs, unref, watch } from 'vue'
import { searchTag } from '@/api/common'
import { useDrawerInner } from '@/components/basic/drawer'
import useMessage from '@/composables/web/useMessage'
import { batchAddLabel, batchDelLabel } from '@/api/customerManager'

defineProps({
  register: Function
})
const isSubmiting = ref(false)
const emit = defineEmits(['success'])

const tagMap = reactive({
  company: [],
  user: []
})

const { company: companyTags, user: userTags } = toRefs(tagMap)
const selectedKeys = ref([])
const selectTags = ref([])
const state = reactive({
  form: {
    label_name: ''
  },
  type: 1,
  isAll: false,
  isShowSelected: false,
  notIds: [],
  hash: null
})

const form = toRef(state, 'form')

const { createMessage } = useMessage()

const [registerDrawer, { closeDrawer, setLoading }] = useDrawerInner((res) => {
  if (res?.ids) {
    selectedKeys.value = res.ids
  }
  state.hash = res.hash
  state.isAll = res.isAll
  state.notIds = res.excludeIds || []
})

const queryTagList = async (params = {}) => {
  setLoading()
  if (form.value.isShowSelected) {
    params.label_ids = selectTags.value.map((tag) => (tag?.label_id ? tag.label_id : tag)).join(',')
  }
  const { data } = await searchTag({ ...params, ...form.value })
  extend(tagMap, data)
  setLoading(false)
  handleMatchLabels(cloneDeep(selectTags.value))
}

const debounceSearch = debounce(queryTagList, 350)

watch(
  () => unref(form).label_name,
  () => {
    debounceSearch()
  }
)

watch(
  () => form.value.isShowSelected,
  () => {
    if (!selectTags.value.length) {
      return
    }
    debounceSearch()
    return
  }
)

const handleCheckChange = (row) => {
  removeTag(row)
  if (row.checked) {
    selectTags.value.push(row)
  }

  function removeTag(row) {
    let index = selectTags.value.findIndex((item) => item.label_id + '' === row.label_id + '')
    ~index && selectTags.value.splice(index, 1)
  }
}

const handleMatchLabels = (data) => {
  if (!data) return
  let label_ids = data.map((row) => row.label_id + '')
  // if (selectTags.value.length && selectTags.value.every((row) => label_ids?.includes(row.label_id + '')))
  //   return
  for (let key in tagMap) {
    let groups = tagMap[key]
    groups.forEach((group) => {
      group.label?.forEach((item) => {
        item.checked = label_ids?.includes(item.label_id + '')
        handleCheckChange(item)
      })
    })
  }
}

const handleVisivleChange = (visivle) => {
  if (visivle) {
    queryTagList()
  } else {
    clearData()
  }
}

const handleConfirm = async () => {
  if (!selectTags.value.length) {
    return createMessage.warning('请先选择标签')
  }
  let ac_ids = selectedKeys.value.join(',')
  let label_ids = unref(selectTags)
    .map((row) => row.label_id)
    .join(',')
  const params = {
    ac_ids,
    label_ids
  }
  if (state.isAll) {
    if (state.notIds?.length) {
      params.not_ids = state.notIds.join(',')
    } else if (state.hash) {
      params.hash = state.hash
      delete params.ac_ids
    }
  }
  isSubmiting.value = true
  if (state.type === 1) {
    await batchAddLabel(params)
    emitSuccess()
  } else {
    await batchDelLabel(params)
    emitSuccess()
  }
}

const emitSuccess = () => {
  clearData()
  closeDrawer()
  emit('success')
}

const clearData = () => {
  selectTags.value = []
  form.value.name = ''
  state.hash = null
  state.notIds = []
  state.isAll = false
  selectedKeys.value = []
  form.value.isShowSelected = false
  isSubmiting.value = false
}

const onClose = () => {
  clearData()
}
</script>
<style lang="less" scoped>
.wrapper {
  padding: 0 32px;
  .head {
    position: sticky;
    top: 0;
    padding-top: 24px;
    background-color: #fff;
    align-items: center;
    flex-wrap: nowrap;
    padding-bottom: 16px;
    .search-input {
      width: 334px;
    }
    .extra {
      margin-left: 32px;
      flex: 0 0 200px;
      > span {
        margin-right: 16px;
        color: #000;
      }
    }
  }

  .tag-content {
    margin-top: 14px;
    height: calc(100% - 50px);
    overflow-y: auto;
    .tag-list {
      margin-bottom: 32px;
      .tag-item {
        align-items: baseline;
        width: 100%;
        &-label {
          margin-right: 32px;
          color: #000;
          font-weight: 550;
        }
        &-content {
          flex: 1;
          .content-item {
            .item-head {
              margin-top: 16px;
              line-height: 1;
            }
            .sub-title {
              color: rgba(0, 0, 0, 0.4);
              padding-bottom: 10px;
            }
          }
          .items {
            :deep(.ant-tag-checkable) {
              margin-bottom: 8px;
            }

            &.personal {
              :deep(.ant-tag-checkable-checked) {
                color: #06d1d1;
                background-color: rgba(6, 209, 209, 0.1);
              }
            }
          }
        }
        + .tag-item {
          margin-top: 30px;
        }
      }
    }
  }
}
.custom-footer {
  width: 100%;
  align-items: center;
}
</style>
