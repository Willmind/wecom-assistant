<template>
  <div style="padding-bottom: 16px" class="editor-box">
    <a-form class="editor-form ant-form-small">
      <div class="ant-form-head jz-flex jz-flex-cc jz-flex-rb">
        <span class="wecom-title"
          ><label style="margin-right: 4px">排除条件</label
          ><a-tooltip placement="top" :visible="visible">
            <template #title>
              <span>在筛选条件基础上，剔除满足所有排除条件的客户。</span>
            </template>
            <question-circle-outlined
              class="ask"
              :class="visible && 'blac-ask'"
              @mouseenter="visible = true"
              @mouseleave="visible = false"
            />
          </a-tooltip>
        </span>

        <a-button type="link" :disabled="!isChangeForm" @click="() => clearFields()">清空筛选</a-button>
      </div>
      <a-form-item v-bind="validateInfos.keyword_turn">
        <a-input
          class="keywork-search-input"
          v-model:value="form.keyword_turn"
          allowClear
          placeholder="关键词筛选"
        >
          <template #suffix v-if="!form.keyword_turn">
            <svg-icon icon-name="ic_search" />
          </template>
        </a-input>
      </a-form-item>
      <a-form-item v-bind="validateInfos.label_options_turn">
        <CustomTagPopover
          is-search
          needCheckGroup
          :isReset="isReset"
          :data="{ label_id: form.label_ids_turn }"
          @select-change="handleSelectedTag"
          :getPopupContainer="isParentFun"
        >
          <span>
            <rich-input
              v-model:value="form.label_options_turn"
              tagMode
              :allowInput="false"
              allowClear
              placeholder="标签"
              :setTagClass="
                (item) =>
                  item?.type ? (item.type === 2 ? 'ant-tag-personal' : 'ant-tag-primary') : 'ant-tag-plain'
              "
            >
              <template #prefix>
                <span>{{ label_type_name_turn }}</span>
              </template>
              <template #suffix>
                <down-outlined />
              </template>
            </rich-input>
          </span>
        </CustomTagPopover>
      </a-form-item>
      <a-form-item name="add_time" v-bind="validateInfos.add_time">
        <a-range-picker
          :getPopupContainer="isParentFun"
          v-model:value="form.add_time"
          value-format="YYYY-MM-DD"
          allowClear
          :ranges="{
            当天: [dayjs(), dayjs()],
            昨天: [dayjs().startOf('day').subtract(1, 'days'), dayjs().startOf('day').subtract(1, 'days')],
            最近3天: [dayjs().startOf('day').subtract(2, 'days'), dayjs()],
            最近7天: [dayjs().startOf('day').subtract(6, 'days'), dayjs()],
            最近30天: [dayjs().startOf('day').subtract(29, 'days'), dayjs()]
          }"
        />
      </a-form-item>
      <a-form-item v-bind="validateInfos.group_type_text">
        <GroupTypePopover
          v-model:item="form.group_ids_turn"
          :isReset="isReset"
          @onChange="handleGroupTypeChange"
          :getPopupContainer="isParentFun"
        >
          <a-input
            class="ant-input-ellipsis"
            v-model:value="form.group_type_text"
            allowClear
            :readonly="true"
            placeholder="按群查询"
          >
            <template #prefix v-if="groupTypeObj.label">
              <label>{{ groupTypeObj.label }}</label>
            </template>
            <template #suffix>
              <div class="ant-select-arrow">
                <down-outlined />
              </div>
            </template>
          </a-input>
        </GroupTypePopover>
      </a-form-item>
      <a-form-item v-bind="validateInfos.source_turn">
        <api-select
          v-model:value="form.source_turn"
          allowClear
          :options="dictMap.source"
          :replaceFields="dictFields"
          placeholder="来源"
          :getPopupContainer="isParentFun"
        />
      </a-form-item>
      <a-form-item v-bind="validateInfos.friend_status_turn">
        <api-select
          v-model:value="form.friend_status_turn"
          allowClear
          :options="dictMap.friend_status"
          :replaceFields="dictFields"
          placeholder="好友关系"
          :getPopupContainer="isParentFun"
        />
      </a-form-item>
    </a-form>
  </div>
</template>

<script setup>
import dayjs from 'dayjs'
import { Form } from 'ant-design-vue'
import { cloneDeep } from 'lodash-es'
import { dictStore } from '@/store/modules/dict'
import { defineExpose, toRaw, unref } from 'vue'
const props = defineProps({
  isParentNode: Boolean
})
const useForm = Form.useForm
const isReset = ref(false)
const visible = ref(false)
const label_type_name_turn = ref('')
const emit = defineEmits(['excludeChange'])
const form = reactive({
  add_time: [],
  keyword_turn: '',
  source_turn: undefined,
  label_ids_turn: undefined,
  label_options_turn: undefined,
  label_type_turn: undefined,
  group_type_turn: undefined,
  group_type_text: '',
  group_ids_turn: [],
  friend_status_turn: undefined
})
const rulesRef = reactive({})
const { validateInfos, resetFields } = useForm(form, rulesRef)
const dictFields = computed(() => ({ label: 'val', value: 'key' }))
const store = dictStore()
const dictMap = toRef(store, 'dictMap')
const groupTypeObj = reactive({
  label: ''
})

// watch=============================

watch(
  () => form.label_options_turn,
  (ls) => {
    form.label_ids_turn = ls.map((row) => row.value)
  }
)

watch(
  () => form,
  () => {
    let num = getCount()
    const params = unref(getParams)
    emit('excludeChange', toRaw(params), num)
    isReset.value = false
  },
  {
    deep: true
  }
)

//computed=============================

const getParams = computed(() => {
  const deepData = cloneDeep(form)
  let labelOptions = cloneDeep(deepData.label_options_turn || [])
  Reflect.deleteProperty(deepData, 'label_options_turn')
  deepData.keyword_turn = deepData.keyword_turn === '' ? undefined : deepData.keyword_turn
  if (deepData.add_time?.[1]) {
    deepData.add_time[1] += ' 23:59:59'
  }
  return {
    ...deepData,
    label_ids_turn: labelOptions.map((row) => row.value),
    add_start_time_turn: deepData?.add_time?.length ? dayjs(deepData.add_time[0])?.unix?.() : undefined,
    add_end_time_turn: deepData?.add_time?.length ? dayjs(deepData.add_time[1])?.unix?.() : undefined,
    add_time: undefined,
    group_type_text: undefined
  }
})
const isChangeForm = computed(() =>
  Object.keys(form).some((key) =>
    Array.isArray(form[key])
      ? !!form[key].length
      : form[key] !== null && form[key] !== undefined && form[key] !== ''
  )
)

// methods===========================

const getCount = () => {
  let _num = 0
  let _obj = cloneDeep(toRaw(form))
  delete _obj.group_ids_turn
  delete _obj.group_type_text
  delete _obj.label_ids_turn
  delete _obj.label_type_turn
  Object.values(_obj).forEach((i) => {
    if (Array.isArray(i) && i.length) {
      _num++
    }
    if (!Array.isArray(i) && i) {
      _num++
    }
  })
  return _num
}

// 选择按群查询
const handleGroupTypeChange = ({ labelInValue, checkedRows }) => {
  groupTypeObj.label = labelInValue.label
  form.group_type_turn = labelInValue.value
  form.group_ids_turn = checkedRows.map((item) => item.id)
  form.group_type_text = checkedRows.map((item) => item.name).join('、')
}

// 标签查询
const handleSelectedTag = ({ type, tags }) => {
  form.label_type_turn = type
  label_type_name_turn.value =
    type === 1 ? '任意' : type === 2 ? '带有' : type === 3 ? '除开' : '未打标签好友'
  form.label_options_turn = tags
}

const isParentFun = (triggerNode) => {
  if (props.isParentNode) {
    return triggerNode.parentNode
  } else {
    return document.body
  }
}

// 清空表单
const clearFields = () => {
  resetFields()
  form.label_ids_turn = []
  form.label_options_turn = []
  label_type_name_turn.value = ''
  isReset.value = true
}

defineExpose({ clearFields })
</script>

<style lang="less" scoped>
.editor-form {
  padding: 0 16px 16px;
  .ant-form-head {
    margin-bottom: 16px;
    .ant-btn-link {
      padding-right: 0px;
    }
  }
}
.ask {
  color: #b3b3b3;
}
.blac-ask {
  color: #000;
}
.editor-box {
  height: 100%;
  &::before {
    content: ' ';
    position: absolute;
    top: 0;
    right: 0;
    width: 1px;
    height: 100%;
    transition: left 0.28s;
    background: #eeeeee;
  }
}
</style>
