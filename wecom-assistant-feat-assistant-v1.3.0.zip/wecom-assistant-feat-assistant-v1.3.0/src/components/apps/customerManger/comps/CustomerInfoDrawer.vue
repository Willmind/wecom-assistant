<template>
  <BasicDrawer
    classes="infoDrawer"
    width="600px"
    :title="genTitle"
    :register="registerDrawer"
    showFooter
    :loading="loading"
    footerPlacement="SPACE_BETWEEN"
    :showCancelBtn="false"
    @ok="onOk"
    @visible-change="handelVisibleChange"
  >
    <div class="info-wrap">
      <a-table
        rowKey="ac_id"
        :pagination="false"
        :showHeader="false"
        :rowSelection="rowSelection"
        :dataSource="state.list"
        :columns="columns"
      >
        <template #bodyCell="{ record, column }">
          <template v-if="column.key === 'customer_info'">
            <div class="item-cell">
              <div class="user-info jz-flex jz-flex-center">
                <img :src="record.avatar" />
                <div class="info-con jz-flex-1 jz-flex jz-flex-col">
                  <span>
                    <span> {{ record.name }} </span>
                    <a-tag style="background: #fff" :style="getCellTagStyle(record, store.dictMap)">{{
                      record.friend_status_val
                    }}</a-tag>
                  </span>
                  <p :class="record.wx_type === 1 ? 'wx_type' : 'comp_wx_type'">@ {{ record.wx_type_val }}</p>
                </div>
              </div>
              <a-form class="ant-form-small" :colon="false" :model="record">
                <a-form-item name="remark" label="备注" v-if="record.remark">
                  <span>{{ record.remark }}</span>
                </a-form-item>
                <a-form-item
                  v-for="(item, index) in record.contact_name"
                  :label="getContactLabel(index)"
                  :key="index"
                >
                  <span>{{ item.name }}</span>
                </a-form-item>
              </a-form>
            </div>
          </template>
          <template v-if="column.key === 'tag_info'">
            <div class="p-info">
              <a-tag
                class="ant-tag-primary"
                :class="{ 'ant-tag-personal': item.type === 2 }"
                v-for="(item, index) in record.label"
                :key="index"
              >
                {{ item.name }}
              </a-tag>
            </div>
          </template>
        </template>
      </a-table>
    </div>
    <p class="jz-flex jz-flex-cc loading-bar" v-loading="loading" v-if="state.isBootom"></p>
    <template #left_extra>
      <a-button type="info" plain @click="() => (selectedRowKeys = [])">清除列表</a-button>
    </template>
  </BasicDrawer>
</template>
<script setup>
import { computed, nextTick, reactive, ref, unref, watch } from 'vue'
import { getCellTagStyle } from '../utils'
import { queryList } from 'api/customerManager'
import { useCreateListHTTP } from '@/composables/common/useCreate'
import { useDrawerInner } from '@/components/basic/drawer'
import { dictStore } from '@/store/modules/dict'

defineProps({
  register: Function
})

const columns = ref([
  {
    title: '客户信息',
    key: 'customer_info',
    dataIndex: 'info'
  },
  { title: '企微标签', width: 280, align: 'right', dataIndex: 'tag', key: 'tag_info' }
])

const notIds = ref([])
const selectedRowKeys = ref([])

const store = dictStore()

const state = reactive({
  page: 1,
  list: [],
  isAll: false,
  isBootom: false,
  isFinished: false,
  spinning: false
})

const { loading, initParams, updateParams } = useCreateListHTTP(queryList, {}, (res) => {
  state.list.push(...res.list)
  state.spinning = false
  nextTick(() => (selectedRowKeys.value = state.list.map((row) => row.ac_id)))
  if (!res.list || !res.list.length) {
    state.isFinished = true
    return
  }
  state.page++
})

const unwatch = watch(
  () => loading.value,
  (v) => {
    if (v) {
      state.spinning = v
      unwatch()
    }
  }
)

const rowSelection = computed(() => ({
  columnWidth: 50,
  selectedRowKeys: selectedRowKeys.value,
  onChange: (keys) => {
    selectedRowKeys.value = keys
  }
}))

const [registerDrawer, { closeDrawer }] = useDrawerInner((res) => {
  notIds.value = res.excludeIds || []
  state.isAll = res.isAll
  if (res.isAll) {
    initParams({
      not_ids: unref(notIds).join(',')
    })
  } else {
    state.list = res.data
    selectedRowKeys.value = res.data.map((item) => item.ac_id)
  }
})

const handelVisibleChange = (v) => {
  if (v) {
    nextTick(() =>
      document
        .querySelector('.infoDrawer')
        ?.querySelector('.basic-drawer__body')
        ?.addEventListener('scroll', handleScroll)
    )
    return
  }
  document
    .querySelector('.infoDrawer')
    ?.querySelector('.basic-drawer__body')
    ?.removeEventListener('scroll', handleScroll)
  clearData()
}

const handleScroll = (e) => {
  if (!state.isAll) return
  let isBootom = e.target.scrollTop + e.target.clientHeight >= e.target.scrollHeight - 50
  state.isBootom = isBootom
  if (isBootom && !loading.value && !state.isFinished) {
    updateParams({ page: state.page })
  }
}
const genTitle = computed(() => `已选择 ${selectedRowKeys.value.length} 位客户`)
const ZH_NUM = ['一', '二', '三']
const getContactLabel = (index) => `称呼${ZH_NUM[index]}`

const onOk = () => {
  closeDrawer()
}

const clearData = () => {
  state.list = []
  notIds.value = []
  state.page = 1
  state.isAll = false
  state.spinning = false
  state.isFinished = false
  state.isBootom = false
  selectedRowKeys.value = []
}
</script>
<style lang="less" scoped>
.info-wrap {
  padding: 0 8px;
}
.user-info {
  width: 100%;
  flex-wrap: nowrap;
  img {
    width: 40px;
    height: 40px;
    display: block;
    border-radius: 8px;
    margin-right: 16px;
  }
  .info-con {
    align-items: flex-start;
    > p:first-child {
      margin-right: 6px;
    }
    > p:last-child {
      line-height: 16px;
      margin-top: 2px;
      &.wx_type {
        color: #57be6a;
      }
      &.comp_wx_type {
        color: #eda150;
      }
    }
  }
}
.p-info {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-end;
  cursor: pointer;
  min-height: 50px;
  > label {
    color: #000;
    margin-right: 8px;
  }
  :deep(.ant-tag) {
    margin-bottom: 10px;
    &.ant-tag-personal {
      color: #06d1d1;
      background-color: rgba(6, 209, 209, 0.1);
    }
  }
}
.ant-form-small {
  margin-top: 16px;
  :deep(.ant-form-item) {
    .ant-form-item-label {
      width: 50px;
      margin-right: 7px;
      > label {
        color: rgba(0, 0, 0, 0.4);
      }
    }
  }
}
</style>
