<template>
  <div class="jz-flex jz-flex-dir-col" style="margin-left: 12px">
    <span class="head-num">客户 {{ store.customerSelectCount }}/{{ store.customerCount }}</span>
    <span class="head-num">客户群 {{ store.groupsSelectCount }}/{{ store.groupsCount }}</span>
  </div>
</template>

<script setup>
import { customerStore } from '@/store/modules/customer'
const store = customerStore()
</script>

<style scoped></style>
