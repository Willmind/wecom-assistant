<template>
  <a-popover
    overlayClassName="ant-popover-not-arrow"
    v-model:visible="visible"
    placement="bottomRight"
    :getPopupContainer="
      (triggerNode) => {
        return triggerNode.parentNode || document.body
      }
    "
  >
    <template #content>
      <div class="excel-wrap">
        <div class="tit">Excel 表格示意图</div>
        <p>1.从第一列第一行开始，每个手机号一行。</p>
        <p>2.支持.xls .xlsx 文件。</p>
        <img src="@/assets/imgs/excelbg.png" alt="" />
      </div>
    </template>
    <slot></slot>
  </a-popover>
</template>
<script setup>
const visible = ref(false)
</script>
<style lang="less" scoped>
.excel-wrap {
  width: 338px;
  height: 329px;
  padding: 24px;
  .tit {
    width: 100%;
    text-align: center;
    font-size: 14px;
    margin-bottom: 16px;
  }
  p {
    color: #999;
    font-size: 14px;
  }
  img {
    width: 100%;
  }
}
</style>
