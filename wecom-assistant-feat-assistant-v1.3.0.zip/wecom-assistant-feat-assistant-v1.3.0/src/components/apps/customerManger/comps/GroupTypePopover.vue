<template>
  <a-popover
    overlayClassName="ant-popover-not-arrow"
    v-model:visible="visible"
    :trigger="trigger"
    placement="bottomLeft"
    @visibleChange="handleChange"
  >
    <template #content>
      <div class="card-content" ref="contentRef">
        <div class="wrapper">
          <div class="card-topic">
            <a-input
              ref="searchRef"
              autofocus
              class="input-search"
              v-model:value="form.keyword"
              allow-clear
              placeholder="搜索"
            >
              <template #prefix> <search-outlined /> </template>
            </a-input>
            <div class="check-groups">
              <a-radio-group v-model:value="state.type" :options="options" />
            </div>
          </div>
          <div class="list-wrap" v-loading="loading">
            <ul
              v-infinite-scroll="debounceSerach"
              :infinite-scroll-immediate-check="false"
              :infinite-scroll-disabled="state.isFinished"
              :infinite-scroll-watch-disabled="state.isFinished"
              :infinite-scroll-distance="10"
            >
              <template v-if="groupList.length && state.type !== 3">
                <li
                  class="list-item jz-flex"
                  :class="{ 'is-checked': row.checked }"
                  v-for="(row, index) in groupList"
                  :key="index"
                  @click.stop.prevent="handleCheckChange(row)"
                >
                  <a-checkbox class="item-checkbox" v-model:checked="row.checked" />
                  <div class="item-content jz-flex">
                    <img :src="row.avatar" :alt="row.name" v-if="row.avatar" />
                    <span class="default-img" v-else></span>
                    <div class="info">
                      <span class="p-1">{{ row.name }}</span>
                      <p class="p-2">群成员：{{ row.room_members }}</p>
                    </div>
                  </div>
                </li>
              </template>
              <a-empty v-else-if="state.type !== 3" />
            </ul>
          </div>
        </div>
      </div>
      <div class="ant-popover-footer jz-flex jz-flex-rr" v-if="showFooter">
        <div class="btns">
          <a-button @click="onClose">取消</a-button>
          <a-button type="primary" @click="handleConfirm">确认</a-button>
        </div>
      </div>
    </template>
    <slot></slot>
  </a-popover>
</template>
<script setup>
import { cloneDeep, debounce } from 'lodash-es'
import { searchGroup } from '@/api/common'
import { ref, computed, reactive, toRefs, unref, toRaw, watch, toRef } from 'vue'

const props = defineProps({
  item: [Array, String, Number],
  trigger: {
    type: String,
    default: 'click'
  },
  showFooter: {
    type: Boolean,
    default: true
  },
  isReset: Boolean
})

const { trigger, item } = toRefs(props)
const emit = defineEmits(['onChange', 'update:value'])

const searchRef = ref()
const contentRef = ref()
const loading = ref(false)
const groupList = ref([])
const selectedRows = ref([])
const state = reactive({
  query: {
    keyword: '',
    num: ''
  },
  type: 1,
  total: 0,
  page: 1,
  loaded: false,
  isFinished: false
})

const form = toRef(state, 'query')

const options = computed(() => [
  { label: '在群内', value: 1 },
  { label: '不在群内', value: 2 },
  { label: '零群好友', value: 3 }
])

const visible = ref(false)

const handleSearch = async () => {
  try {
    if (state.isFinished) return false

    loading.value = true
    const { data } = await searchGroup({ ...form.value, page: state.page || 1 })
    loading.value = false
    state.loaded = true
    if (data.data.length) {
      state.total = +data.total
      groupList.value.push(...(data.data || []))
      state.page += 1
    } else {
      state.isFinished = true
    }
  } catch (error) {
    loading.value = false
  } finally {
    selectedRows.value = []
  }
}
const debounceSerach = debounce(handleSearch, 350, { leading: true })

const handleCheckChange = (record) => {
  record.checked = !record.checked
  checkItem(record)
  let deepRows = cloneDeep(toRaw(unref(selectedRows)))
  emit(
    'update:value',
    deepRows.map((item) => item.id)
  )
  // emit('onChange', {
  //   labelInValue: unref(options).find((item) => item.value === state.type),
  //   checkedRows: deepRows
  // })
}

const checkItem = (record) => {
  removeItem(record)
  if (record.checked) {
    selectedRows.value.push(record)
  }

  function removeItem(record) {
    let index = selectedRows.value.findIndex((item) => item.id === record.id)
    ~index && selectedRows.value.splice(index, 1)
  }
}

const handleChange = (show) => {
  if (show) {
    setTimeout(() => {
      searchRef?.value?.focus()
    }, 300)
  }
}

const handleConfirm = () => {
  emitSelectedRows()
  onClose()
}

const onClose = () => {
  visible.value = false
}

const emitSelectedRows = () => {
  emit('onChange', {
    labelInValue: unref(options).find((item) => item.value === state.type),
    checkedRows: state.type !== 3 ? cloneDeep(unref(selectedRows)) : []
  })
}

const clearData = () => {
  state.page = 1
  state.type = 1
  state.isFinished = false
  groupList.value = []
  state.query.keyword = ''
}

watch(
  () => form.value.keyword,
  () => {
    state.page = 1
    state.isFinished = false
    selectedRows.value = []
    groupList.value = []
    debounceSerach()
  }
)

// watch(
//   () => state.type,
//   (type) => {
//     emit('onChange', {
//       labelInValue: unref(options).find((item) => item.value === type),
//       checkedRows: state.type !== 3 ? toRaw(unref(selectedRows)) : []
//     })
//   }
// )

watch(
  () => props.isReset,
  (v) => {
    v && clearData()
  }
)

watch(
  () => item.value,
  (data) => {
    if (!data || !data?.length) {
      groupList.value.forEach((item) => {
        item.checked = false
      })
      selectedRows.value = []
    } else {
      groupList.value.forEach((item) => {
        item.checked = data?.includes(item.id)
        checkItem(item)
      })
    }
  }
)
</script>
<style lang="less" scoped>
.card-content {
  min-width: 400px;
  box-sizing: border-box;
  .card-topic {
    position: sticky;
    top: 0;
  }
  .list-wrap {
    max-height: 324px;
    overflow-y: auto;
    margin: 16px 0 56px 0;
    ul {
      list-style: none;
      display: flex;
      flex-direction: column;
      flex-wrap: wrap;
      .list-item {
        height: 54px;
        align-items: center;
        padding: 9px;
        width: 100%;
        .item-content {
          flex: auto;
          cursor: pointer;
          align-items: center;
          img {
            display: block;
            border-radius: 8px;
            width: 40px;
            height: 40px;
            margin-left: 28px;
            margin-right: 13px;
            flex: 0 0 40px;
          }
          .default-img {
            background: #eeeeee;
            border-radius: 8px;
            width: 40px;
            height: 40px;
            flex: 0 0 40px;
            margin-left: 28px;
            margin-right: 13px;
          }
          .info {
            flex: auto;
            .p-1 {
              color: #000000;
            }
            .p-2 {
              color: rgba(0, 0, 0, 0.4);
            }
          }
        }

        &:hover {
          background: rgba(49, 101, 245, 0.1);
          border-radius: 4px;
        }
        &.is-checked {
          background: rgba(49, 101, 245, 0.1);
          border-radius: 4px;
        }
      }
    }
  }
}
.input-search {
  margin-bottom: 16px;
}
.check-groups {
  height: 52px;
  display: flex;
  align-items: center;
}
</style>
