<template>
  <a-popover
    overlayClassName="student-popover-not-arrow"
    v-model:visible="visible"
    trigger="click"
    placement="bottomRight"
    @visibleChange="handleChange"
    :getPopupContainer="
      (triggerNode) => {
        return triggerNode.parentNode || document.body
      }
    "
  >
    <template #content>
      <div class="pop jz-flex jz-flex-col" v-loading="state.loading">
        <div class="form-box">
          <a-form layout="inline">
            <a-form-item style="width: 146px; margin-right: 16px">
              <a-select
                allowClear
                @change="changeProject"
                placeholder="请选择项目"
                v-model:value="form.project_id"
              >
                <a-select-option v-for="item in state.project_list" :key="item.id" :value="item.id">{{
                  item.name
                }}</a-select-option>
              </a-select>
            </a-form-item>
            <a-form-item style="width: 146px; margin-right: 16px">
              <a-select
                allowClear
                show-search
                :filter-option="false"
                :not-found-content="null"
                placeholder="课程名称/ID"
                v-model:value="form.camp_id"
                @change="changeCamp"
                @search="(e) => searchProduct(e)"
              >
                <a-select-option v-for="item in state.camp_list" :key="item.id" :value="item.id">
                  {{ item.name }}
                </a-select-option>
              </a-select>
            </a-form-item>
            <a-form-item style="width: 146px; margin-right: 16px">
              <a-select
                allowClear
                show-search
                placeholder="期数"
                v-model:value="form.term"
                :disabled="!form.camp_id"
              >
                <a-select-option v-for="item in state.term_list" :key="item.id" :value="item.id">
                  {{ formatDate(item.t) }}</a-select-option
                >
              </a-select>
            </a-form-item>
            <a-form-item style="width: 146px; margin-right: 0px">
              <a-select v-model:value="form.status" :options="state.typeOptions" @change="getList" />
            </a-form-item>
          </a-form>
        </div>
        <div class="tip jz-flex jz-flex-cc">
          <exclamation-circle-filled style="color: #ed7b2f; font-size: 17px" />
          <div>已过滤格式不对或已添加的数据，仅查询你现跟进的学员，不含退款学员。</div>
        </div>
        <div class="table-box jz-flex-1">
          <a-table
            row-key="mobile"
            :columns="state.columns"
            :data-source="state.list"
            :bordered="false"
            :pagination="false"
            :row-selection="{ selectedRowKeys: state.selectedRowKeys, onChange: onSelectChange }"
          >
            <template #bodyCell="{ column, record }">
              <template v-if="column.key === 'action'">
                <div class="cust jz-flex jz-flex-center">
                  <img :src="record.avatar" alt="" />
                  <div class="jz-flex jz-flex-1 jz-flex-col">
                    <span class="lineClamp1">{{ record.name }}</span>
                    <span class="lineClamp1">ID：{{ record.user_id }}</span>
                  </div>
                </div>
              </template>
            </template>
          </a-table>
        </div>
        <div class="footer jz-flex jz-flex-cc">
          <span>已选 {{ state.selectedRowKeys.length }}/{{ state.list.length }}</span>
          <div class="jz-flex jz-flex-rr jz-flex-1">
            <a-button style="margin-right: 8px" @click="close">取消</a-button>
            <a-button type="primary" @click="handleSelect" :disabled="!state.selectedRowKeys.length"
              >确定</a-button
            >
          </div>
        </div>
      </div>
    </template>
    <slot></slot>
  </a-popover>
</template>
<script setup>
import dayjs from 'dayjs'
import useMessage from '@/composables/web/useMessage'
import { reactive, toRaw, unref } from 'vue'
import { queryProductList, searchTerm, searchCamp, getDefaultCamp } from 'api/common'
import { getCampContacts } from 'api/customerManager'
import { nextTick } from 'process'
const { createMessage } = useMessage()
const emit = defineEmits(['success'])
const visible = ref(false)
const columns = [
  { title: '序号', dataIndex: 'index', key: 'index', width: '120px' },
  { title: '客户', key: 'action', width: '270px' },
  { title: '手机号', dataIndex: 'mobile', key: 'mobile', width: '120px' },
  { title: '', width: '120px' }
]
const formatDate = (value, format = 'YYYY-MM-DD') => dayjs(value * 1000).format(format)
const form = reactive({
  project_id: undefined,
  camp_id: undefined,
  term: undefined,
  status: 1
})
const state = reactive({
  project_list: [],
  camp_list: [],
  term_list: [],
  count: 100,
  list: [],
  columns: columns,
  loading: true,
  selectedRowKeys: [],
  typeOptions: [
    { label: '未添加', value: 1 },
    { label: '曾添加', value: 2 },
    { label: '未添加/曾添加', value: 3 }
  ]
})

// ===========================watch
watch(
  () => form.term,
  async (val) => {
    // 获取学员
    val && getList()
  }
)

// ============================method

const changeCamp = (val) => {
  if (val) {
    getTermList()
  } else {
    form.term = undefined
    state.term_list = []
  }
}

// 获取默认参数配置
const initForm = async () => {
  let { data } = await getDefaultCamp()
  let { project_id, product_id: camp_id, camp_term: term } = data
  form.camp_id = camp_id
  form.project_id = project_id ? project_id : undefined
  form.term = term
  // 获取项目数据
  await getProject()
  // 获取课程
  await getCampList()
  // 获取期数
  await getTermList()

  state.loading = false
}

// 搜索课程
const searchProduct = (e) => {
  state.term_list = []
  form.term = undefined
  getCampList(e)
}

// 获取项目数据
const getProject = async () => {
  let { data } = await queryProductList()
  state.project_list = data.list
}

// 获取课程
const getCampList = async (name = '') => {
  let params = { name }
  if (form.project_id) {
    params.project_id = form.project_id
  }
  let { data } = await searchCamp(params)
  unref(state).camp_list = [...data]
}

// 获取期数
const getTermList = async () => {
  let { data } = await searchTerm({ camp_id: form.camp_id })
  state.term_list = data
  if (state.term_list.length) {
    form.term = state.term_list[0].id
  }
}

// 切换项目
const changeProject = async (e) => {
  form.project_id = e
  form.camp_id = undefined
  form.term = undefined
  state.camp_list = []
  state.term_list = []
  // 获取课程
  await getCampList()
}

const getList = async () => {
  let params = { ...unref(form) }
  params.term = state.term_list.find((i) => i.id === params.term).tm
  let { data } = await getCampContacts(params)
  state.list = data
}

// 勾选表格
const onSelectChange = (selectedRowKeys) => {
  state.selectedRowKeys = selectedRowKeys
}

const handleSelect = () => {
  if (!state.selectedRowKeys.length) {
    createMessage.info('请选择学员')
    return
  }
  let { status, camp_id, term: term_id } = form
  let camp_name = state.camp_list.find((i) => i.id === camp_id).name
  let term_obj = state.term_list.find((i) => i.id === term_id)
  let term = term_obj?.tm
  let term_date = term_obj?.t ? formatDate(term_obj.t) : ''
  emit('success', toRaw(state.selectedRowKeys), { status, camp_id, camp_name, term, term_date })
  state.selectedRowKeys = []
  close()
}

// 展示提示框
const handleChange = (show) => {
  if (show) {
    nextTick(() => {
      initForm()
    })
  } else {
    close()
  }
}

// 关闭
const close = () => {
  state.list = []
  state.camp_list = []
  state.project_list = []
  form.camp_id = undefined
  form.term = undefined
  form.project_id = undefined
  form.status = 1
  visible.value = false
  state.selectedRowKeys = []
}
</script>
<style lang="less" scoped>
.pop {
  width: 664px;
  height: 460px;
  overflow: hidden;

  .tip {
    margin: 24px 0 16px 0;
    padding: 0 16px;
    > div {
      color: #ed7b2f;
      margin-left: 10px;
    }
  }
  .form-box {
    padding: 16px 16px 0;
  }
}
.ant-popover-inner-content {
  background: red;
}
.footer {
  width: 100%;
  height: 54px;
  padding: 0px 16px;
  position: relative;
  &::before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    right: 0;
    width: 100%;
    height: 1px;
    background-color: #eee;
    transform: scaleY(0.6);
  }
}
.table-box {
  height: 100%;
  overflow-y: auto;
  padding: 0px 16px;
}

.cust {
  width: 100%;
  img {
    width: 36px;
    height: 36px;
    border-radius: 8px;
    margin-right: 10px;
  }

  div {
    width: 100%;
    span:last-child {
      color: #999999;
    }
  }
}

:deep(.ant-table-thead > tr > th) {
  color: @font-minor-color;
  border-bottom: none;
}
:deep(.ant-table-tbody > tr > td) {
  border-bottom: none;
  cursor: pointer;
}
::-webkit-scrollbar {
  width: 0px;
  height: 0px;
}
:deep(.ant-table-thead
    > tr
    > th:not(:last-child):not(.ant-table-selection-column):not(.ant-table-row-expand-icon-cell):not([colspan])::before) {
  width: 0;
}
</style>
