<template>
  <div id="customer" class="jz-flex jz-flex-col jz-flex-1">
    <div class="customer-container">
      <div class="task-box jz-flex jz-flex-rl">
        <span class="tit">接受任务</span>
        <div class="jz-flex-1 jz-flex jz-flex-rr wraper jz-flex-cc" :class="!state.isStart && 'stop-task'">
          <span class="dot"></span>
          <span class="name">{{ state.isStart ? '任务执行中' : '任务已停用' }}</span>
          <a-button
            type="primary"
            style="margin-right: 8px; border-color: #3165f5; background-color: #3165f5"
            @click="handleTaskStart"
            >{{ state.isStart ? '停用' : '启用' }}</a-button
          >
          <a-button @click="openDrawer" style="border-color: #eee">任务设置</a-button>
        </div>
      </div>
      <div class="tip-box jz-flex jz-flex-cc">
        <exclamation-circle-filled style="color: #ed7b2f; font-size: 20px" />
        <div class="tip-box__txt">
          请先将企业微信手机客户端上“设置-隐私-加我为联系人时需要验证”的开关打开，否则该功能无法生效。
        </div>
      </div>
      <div class="info-box" ref="customerBox">
        <ul class="account jz-flex jz-flex-center" ref="accountBox">
          <li class="jz-flex-1 jz-flex-center jz-flex-col jz-flex">
            <span>{{ state.accept_today }}</span>
            <span>今日已接受申请</span>
          </li>
          <li class="jz-flex-1 jz-flex-center jz-flex-col jz-flex">
            <span>{{ state.to_be_accept_today }}</span>
            <span>今日待接受申请</span>
          </li>
        </ul>
        <div class="nav jz-flex" :class="isfixTab && 'fixTab'">
          <ul class="jz-flex">
            <li
              @click="changeNav(index)"
              class="jz-pointer"
              :class="state.navIndex === index && 'current'"
              v-for="(item, index) in state.nav_list"
              :key="index"
            >
              {{ item }}
            </li>
          </ul>
          <i></i>
        </div>
        <div class="table-wraper">
          <div class="jz-flex-1 jz-flex-cc jz-flex table-tip">
            <exclamation-circle-filled class="nav-icon" />
            <div class="nav-text">
              {{
                !state.navIndex
                  ? '若已无法再自动接受，请前往企业微信客户端核实是否功能被限'
                  : '仅展示一个月内的记录'
              }}
            </div>
          </div>
          <a-table
            row-key="id"
            :columns="state.columns"
            :data-source="state.list"
            :bordered="false"
            :pagination="false"
            :loading="state.tableLoading"
            :row-selection="
              state.navIndex == 3
                ? { selectedRowKeys: state.selectedRowKeys, onChange: onSelectChange }
                : null
            "
          >
            <template #bodyCell="{ column, record }">
              <template v-if="column.key === 'titAction'">
                <div class="user-tb jz-flex jz-flex-center">
                  <img :src="record.avatar" alt="" />
                  <div class="jz-flex-1 jz-flex jz-flex-col">
                    <span>{{ record.nickname }}</span>
                    <span :class="!record.wx_type && 'qw-color'">@{{ record.wx_type_text }}</span>
                  </div>
                </div>
              </template>
              <template v-if="column.key === 'action'">
                <a-button
                  type="link"
                  @click="takeUser([record.id])"
                  v-if="!state.navIndex"
                  style="padding-left: 0px"
                  >接受</a-button
                >
                <a-popconfirm
                  title="确定要删除吗"
                  ok-text="确定"
                  cancel-text="取消"
                  @confirm="deleteUser([record.id])"
                >
                  <a-button
                    type="link"
                    v-if="!state.navIndex || state.navIndex === 3"
                    style="padding-left: 0px"
                    >删除</a-button
                  >
                </a-popconfirm>
              </template>
            </template>
            <template #emptyText>
              <div class="not-more jz-flex jz-flex-center jz-flex-col">
                <img src="@/assets/imgs/not_more.png" alt="" />
                <span>无内容</span>
              </div>
            </template>
          </a-table>
        </div>
      </div>
    </div>
    <div class="pagination-box">
      <basic-pagination @change="pageChange" :params="state.paginationParams">
        <template #btn>
          <a-button
            style="border-color: #eee"
            v-if="!state.navIndex"
            @click="emptyList"
            :disabled="!state.list.length"
            >清空列表</a-button
          >
          <a-button
            v-if="state.navIndex === 3"
            :disabled="!state.selectedRowKeys.length"
            style="margin-right: 10px"
            @click="deleteAllUser"
            >批量删除</a-button
          >
          <a-button v-if="state.navIndex === 3" :disabled="!state.selectedRowKeys.length" @click="taskAllUser"
            >批量转入待接受列表</a-button
          >
        </template>
        <template #extra>
          <span class="page-total">共{{ state.paginationParams.total }}客户</span>
        </template>
      </basic-pagination>
    </div>
    <!--任务设置-->
    <basic-drawer
      width="560px"
      showFooter
      title="接受频率设置"
      okText="保存"
      :register="registerDrawer"
      :showCancelBtn="false"
      @visibleChange="drawerChange"
      @ok="handleOkCallback"
    >
      <div><Edit ref="editCustmer" /></div>
    </basic-drawer>
  </div>
</template>

<script setup>
import Edit from './comps/edit.vue'
import { useDrawer } from '@/components/basic/drawer'
import { onMounted, onUnmounted, reactive, ref } from 'vue'
import {
  getApiApplyList,
  getApifriendPanel,
  apiTakeAccept,
  apiDeleteAccept,
  apiClearAccept,
  apiOpenSetting
} from 'api/customer'
import useMessage from '@/composables/web/useMessage'
const columns1 = [
  { title: '客户信息', key: 'titAction', width: '270px' },
  {
    title: '请求来源',
    dataIndex: 'source_type_text',
    key: 'source_type_text'
  },
  {
    title: '收到好友请求时间 ',
    dataIndex: 'request_time',
    key: 'request_time'
  },
  { title: '操作', key: 'action' }
]
const columns2 = [
  { title: '客户信息', key: 'titAction', width: '270px' },
  {
    title: '失败原因',
    key: 'reason',
    dataIndex: 'reason'
  },
  {
    title: '请求来源',
    dataIndex: 'source_type_text',
    key: 'source_type_text'
  },
  {
    title: '收到好友请求时间 ',
    dataIndex: 'request_time',
    key: 'request_time'
  },
  { title: '操作', key: 'action', width: '200px' }
]
const { createConfirm, createMessage } = useMessage()
const [registerDrawer, { openDrawer }] = useDrawer()
const editCustmer = ref(null)
const state = reactive({
  navIndex: 0,
  list: [],
  to_be_accept: 0,
  accept_today: 0,
  tableLoading: true,
  to_be_accept_today: 0,
  selectedRowKeys: [],
  columns: columns1,
  paginationParams: {
    total: 0,
    current: 1,
    showSizeChanger: false
  },
  isStart: false,
  nav_list: ['待接受', '已接受', '已忽略', '失败']
})
const accountBox = ref(null)
const customerBox = ref(null)
const isfixTab = ref(false)
// methods=======================

// 切换tab
const changeNav = (index) => {
  state.list = []
  state.selectedRowKeys = []
  state.navIndex = index
  state.tableLoading = true
  state.paginationParams.current = 1
  getApplyList()
}

// 勾选表格
const onSelectChange = (selectedRowKeys) => {
  state.selectedRowKeys = selectedRowKeys
}

onMounted(() => {
  // 获取面板信息
  getfriendPanel()
  customerBox.value && customerBox.value.addEventListener('scroll', handleScroll, true)
})

// methods=================================
const drawerChange = (isOpen) => {
  isOpen && editCustmer.value.getSettingInfo()
}
//  批量删除
const deleteAllUser = () => {
  if (!state.selectedRowKeys.length) {
    createMessage.info('请勾选列表')
    return
  }
  deleteUser(state.selectedRowKeys)
}

//   批量接受
const taskAllUser = () => {
  if (!state.selectedRowKeys.length) {
    createMessage.info('请先勾选列表')
    return
  }
  takeUser(state.selectedRowKeys)
}

// 获取面板信息
const getfriendPanel = async () => {
  let { code, data } = await getApifriendPanel()
  if (code === 1000) {
    let { to_be_accept, accept_today, to_be_accept_today } = data
    state.isStart = data.status === 1 ? true : false
    state.to_be_accept = to_be_accept
    state.accept_today = accept_today
    state.to_be_accept_today = to_be_accept_today
    // 获取列表
    getApplyList()
  }
}

// 清空列表
const emptyList = () => {
  createConfirm({
    cancelText: '取消',
    content: `确认清空${state.paginationParams.total}位待接受客户？`,
    onOk() {
      // 调用清空接口
      clearAccept()
    }
  })
}

// 清空列表
const clearAccept = async () => {
  let { code } = await apiClearAccept()
  if (code === 1000) {
    createMessage.success('清空成功')
    getApplyList()
  }
}

// 接受新客户
const takeUser = async (ids) => {
  let { code } = await apiTakeAccept({ id: ids.join(',') })
  if (code === 1000) {
    createMessage.success('接受成功')
    getApplyList()
  }
}

// 删除新客户
const deleteUser = async (ids) => {
  let { code } = await apiDeleteAccept({ id: ids.join(',') })
  if (code === 1000) {
    createMessage.success('删除成功')
    getApplyList()
  }
}

// 停用和启用状态
const handleTaskStart = async () => {
  let { code } = await apiOpenSetting({ showLoading: true })
  if (code === 1000) {
    createMessage.success('操作成功')
  }
  state.isStart = !state.isStart
}

// 获取列表数据
const getApplyList = async () => {
  let { code, data } = await getApiApplyList({
    type: state.navIndex === 2 ? 4 : state.navIndex === 3 ? 3 : state.navIndex + 1,
    page: state.paginationParams.current
  })
  state.columns = state.navIndex === 3 ? columns2 : columns1

  if (code === 1000) {
    state.list = data.data
    state.paginationParams.current = data.current_page
    state.paginationParams.total = data.total
  }
  state.tableLoading = false
}

// 编辑回调
const handleOkCallback = () => {
  editCustmer.value.onsubmit(true)
}

// 监听滚动
const handleScroll = () => {
  let _tagTop = accountBox.value.offsetTop + accountBox.value.clientHeight - 100
  isfixTab.value = customerBox.value.scrollTop > _tagTop ? true : false
}

// 页码回调
const pageChange = (params) => {
  state.paginationParams.current = params.current
  getApplyList()
}

// 页面卸载
onUnmounted(() => {
  customerBox.value && customerBox.value.removeEventListener('scroll', handleScroll, true)
})
</script>

<style lang="less" scoped>
#customer {
  height: 100%;
  width: 100%;
  position: relative;
  padding: 0px 32px 48px;
  background: #fff;
  font-size: 14px;
  .customer-container {
    overflow: hidden;
    .info-box {
      width: 100%;
      height: 100%;
      overflow-y: auto;
      padding-bottom: 200px;
    }
  }
  .task-box {
    margin-top: 48px;
    .tit {
      font-size: 20px;
      font-weight: 600;
    }
    .wraper {
      color: #06d1d1;
      span.dot {
        width: 8px;
        height: 8px;
        margin-right: 14px;
        border-radius: 50%;
        background: #06d1d1;
      }
      span.name {
        margin-right: 24px;
      }
    }
    .stop-task {
      color: #ed7b2f;
      span.dot {
        background: #ed7b2f;
      }
    }
  }
  .fix-task {
    position: absolute;
    top: 0;
    right: 0;
    left: 0;
    padding: 0 32px;
    height: 60px;
    background: #fff;
    z-index: 10;
    opacity: 0;
    margin-top: 0px;
    .tit {
      line-height: 60px;
    }
  }
  .tip-box {
    width: 100%;
    height: 44px;
    padding: 0 14px;
    margin: 14px 0 32px 0;
    border-radius: 8px;
    background: rgba(237, 123, 47, 0.1);
    &__txt {
      color: #ed7b2f;
      padding-left: 10px;
    }
  }
  .account {
    height: 92px;
    border-radius: 12px;
    background: #f5f5f5;
    margin-bottom: 46px;
    position: relative;
    li {
      position: relative;
      span:first-child {
        font-size: 24px;
        font-weight: 500;
        margin-bottom: 5px;
      }
      span:last-child {
        color: @font-minor-color;
      }
    }
    li:first-child::before {
      content: '';
      position: absolute;
      right: 0;
      margin-top: -22px;
      top: 50%;
      width: 1px;
      height: 44px;
      background: rgba(0, 0, 0, 0.08);
    }
  }
  .nav {
    height: 48px;
    position: relative;
    width: 100%;
    i {
      position: absolute;
      left: 0;
      bottom: 0;
      right: 0;
      width: 100%;
      height: 1px;
      background-color: #eee;
      transform: scaleY(0.6);
    }
    ul {
      height: 100%;
      li {
        color: @font-minor-color;
        padding: 0 24px;
        position: relative;
        height: 48px;
        line-height: 48px;
        &.current {
          color: #3165f5;
        }
        &.current::after {
          content: '';
          width: 100%;
          height: 1px;
          display: block;
          margin: 0 auto;
          border-bottom: 2px solid #3165f5;
        }
        &:first-child {
          padding-left: 0px;
        }
      }
    }
  }
  .table-wraper {
    margin-top: 16px;
    .not-more {
      img {
        width: 110px;
        height: 110px;
        margin-bottom: 4px;
      }
      span {
        font-size: 12px;
      }
    }
    .table-tip {
      margin: 16px 0;
      .nav-icon {
        color: #ed7b2f;
        margin-right: 8px;
        font-size: 20px;
      }
      .nav-text {
        color: #ed7b2f;
      }
    }
  }
  .fixTab {
    position: absolute;
    background: #fff;
    z-index: 100;
    width: 95%;
    left: 32px;
    right: 0;
    top: 145px;
  }
  .user-tb {
    width: 100%;
    img {
      width: 40px;
      height: 40px;
      display: block;
      border-radius: 8px;
      margin-right: 16px;
    }
    div {
      span:last-child {
        color: #57be6a;
        &.qw-color {
          color: #eda150;
        }
      }
    }
  }
  .pagination-box {
    position: absolute;
    left: 0;
    bottom: 0;
    right: 0;
    height: 64px;
    padding: 0 32px;
    background: #fff;
  }
}
.page-total {
  margin-left: 16px;
  color: @font-minor-color;
}
:deep(.ant-table-thead > tr > th) {
  color: @font-minor-color;
  border-bottom: none;
}
::-webkit-scrollbar {
  width: 0px;
  height: 0px;
}
:deep(.ant-table-thead
    > tr
    > th:not(:last-child):not(.ant-table-selection-column):not(.ant-table-row-expand-icon-cell):not([colspan])::before) {
  width: 0;
}
</style>
