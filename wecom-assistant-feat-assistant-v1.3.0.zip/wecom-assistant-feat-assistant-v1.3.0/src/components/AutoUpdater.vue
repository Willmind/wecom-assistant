<template>
  <div class="updater-box jz-flex jz-flex-center jz-flex-col" v-if="updateType === 4">
    <a-progress type="circle" :percent="percent" />
    <div class="percent-txt">更新中...</div>
  </div>
</template>
<script setup>
import useMessage from '@/composables/web/useMessage'
const updateType = ref(0)
const percent = ref(0)
const { ipcRenderer } = require('electron')
const { createConfirm, createMessage } = useMessage()
onMounted(async () => {
  nextTick(() => {
    checkUpdater()
  })
})

// 检测是否有新版本
const checkUpdater = () => {
  setTimeout(() => {
    $storeLocal.get('token') && ipcRenderer.send('ev-check-for-update')
  }, 2000)

  ipcRenderer.on('ev-message', (event, params) => {
    console.log(params)
    let { text, type } = params
    switch (type) {
      case 1:
        updateType.value !== type && typeof text === 'string' && createMessage.warn(text)
        break
      case 3:
        updateType.value !== type && createMessage.info(text)
        break
    }
    updateType.value = type
  })

  // 检测更新进度条
  ipcRenderer.on('ev-progress', (event, num) => {
    updateType.value = 4
    percent.value = +Number(num).toFixed(0)
  })

  ipcRenderer.on('ev-should-update', () => {
    if (updateType.value !== 5) {
      updateType.value = 5
      createConfirm({
        content: `检查到新版本，是否更新?`,
        onOk() {
          updateType.value = 0
          ipcRenderer.send('ev-update-now')
        }
      })
    }
  })
}
</script>
<style lang="less" scoped>
.updater-box {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  z-index: 1000;
  background-color: rgba(231, 233, 235, 0.8);
  .percent-txt {
    margin-top: 5px;
  }
}
</style>
