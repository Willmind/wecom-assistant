import { noop } from 'lodash-es'
import { PlacementEnum } from '@/enums/placementEnum'

/**
 * drawer footer props
 */
export const footerProps = {
  okText: {
    type: String,
    default: '确定'
  },
  showClose: {
    type: Boolean,
    default: true
  },
  showOkBtn: {
    type: Boolean,
    default: true
  },
  okType: {
    type: String,
    default: 'primary'
  },
  okBtnProps: Object,
  confirmLoading: Boolean,
  cancelText: {
    type: String,
    default: '取消'
  },
  showCancelBtn: {
    type: Boolean,
    default: true
  },
  disabled: Boolean,
  cancelBtnProps: Object,
  showFooter: Boolean
}

export const basicProps = {
  title: String,
  loading: Boolean,
  visible: Boolean,
  maskClosable: {
    type: Boolean,
    default: true
  },
  register: {
    type: Function,
    default: noop
  },
  innerPage: Boolean, // 覆盖内容页（详情页）
  loadingText: String,
  beforeClose: Function,
  destroyOnClose: Boolean,
  footerHeight: {
    type: String,
    default: '64px'
  },
  footerPlacement: {
    type: String,
    default: PlacementEnum.RIGHT
  },
  ...footerProps
}
