import { isProdMode } from '@/utils/common/env'
import { cloneDeep, extend, isEqual, isFunction, isPlainObject } from 'lodash-es'

const visibleData = ref({})

// 存储回调事件
const _watcherCallbackFns_ = new Map()

export function useDrawer() {
  if (!getCurrentInstance()) {
    throw new Error('useDrawer() can only be used inside setup() or functional components!')
  }

  const drawerRef = ref(null)
  const loaded = ref(false)
  const uid = ref('')
  const dataTransferRef = reactive({})

  function register(drawerInstance, uuid) {
    isProdMode() &&
      onUnmounted(() => {
        loaded.value = null
        drawerRef.value = null
        Reflect.deleteProperty(dataTransferRef, unref(uid))
        _watcherCallbackFns_.delete(unref(uid))
      })

    uid.value = uuid
    drawerRef.value = drawerInstance
    loaded.value = true

    drawerInstance.emitVisible = function (visible, uid) {
      Reflect.set(visibleData, unref(uid), visible)
    }
  }

  const getInstance = () => {
    const instance = unref(drawerRef)
    if (!instance) {
      console.error('drawer instance is undefined')
    }
    return instance
  }

  const methods = {
    setDrawerProps(props) {
      getInstance()?.setDrawerProps(props)
    },
    /**
     * // 设置数据传输
     * @param {Object} data
     * @param {Boolean} set - 直接覆盖
     * @returns
     */
    setDataTransferRef(data, set = true) {
      const fn = _watcherCallbackFns_.get(unref(uid))
      if (!dataTransferRef.hasOwnProperty(unref(uid))) {
        Reflect.set(dataTransferRef, unref(uid), null)
      }
      let cloneData = cloneDeep(toRaw(data) || {})
      if (set) {
        dataTransferRef[unref(uid)] = cloneData
        fn && isFunction(fn) && fn(cloneData)
        return
      }
      let dataTrans = dataTransferRef[unref(uid)]
      const mergeData =
        dataTrans === null || dataTrans === undefined
          ? cloneData
          : extend(Array.isArray(dataTrans) ? [] : {}, dataTrans, cloneData)
      dataTransferRef[unref(uid)] = mergeData
      fn && isFunction(fn) && fn(mergeData)
    },
    setLoading: (loading = true) => {
      methods.setDrawerProps({ loading })
    },
    getVisible: computed(() => !!visibleData[unref(uid)]),
    openDrawer(...args) {
      let [playod, callback] = args
      methods.setDrawerProps({ visible: true })
      if (isPlainObject(playod)) {
        methods.setDataTransferRef(playod)
      }
      callback = callback || playod
      if (callback && isFunction(callback)) {
        const res = callback()
        if (res && (res instanceof Promise || (res.then && res.catch))) {
          ;(async (promiseData) => {
            try {
              methods.setLoading()
              const data = await promiseData
              data && methods.setDataTransferRef(data, false)
            } finally {
              methods.setLoading(false)
            }
          })(res)
          return
        }
        res && methods.setDataTransferRef(res, false)
      }
    },
    closeDrawer() {
      methods.setDrawerProps({ visible: false })
    }
  }

  return [register, methods]
}

/**
 * 二次包装BasicDrawer组件使用（业务Drawer组件）
 * @param {Function} callback
 * @returns
 */
export function useDrawerInner(callback = (d) => d) {
  const instanceRef = ref(null)
  const uid = ref('')
  const currentInstance = getCurrentInstance()
  if (!currentInstance) {
    throw new Error('useDrawerInner() can only be used inside setup() or functional components!')
  }

  function register(drawerInstance, uuid) {
    isProdMode() &&
      onUnmounted(() => {
        instanceRef.value = null
      })

    uid.value = uuid
    instanceRef.value = drawerInstance
    _watcherCallbackFns_.set(uuid, callback)
    currentInstance.props?.register?.(drawerInstance, uuid)
  }

  function getInstance() {
    let instance = unref(instanceRef)
    if (!instance) {
      console.error('drawer instance is undefined')
    }
    return instance
  }

  const methods = {
    setDrawerProps: (props) => {
      getInstance()?.setDrawerProps(props)
    },
    setLoading: (loading = true) => {
      methods.setDrawerProps({ loading })
    },
    getVisible: computed(() => !!visibleData[unref(uid)]),
    setConfirmLoading: (loading = true) => {
      methods.setDrawerProps({ confirmLoading: loading })
    },
    closeDrawer() {
      methods.setDrawerProps({ visible: false })
    }
  }

  return [register, methods]
}
