<template>
  <a-drawer
    v-bind="getBindProps"
    :closable="false"
    :width="getWidth"
    :style="drawerStyle"
    class="basic-drawer"
    :class="[{ 'basic-drawer-show-forehead': showForehead }, classes]"
    @close="onClose"
  >
    <template #extra v-if="getMergeProps.showClose">
      <button class="ant-drawer-close" @click="onClose"><CloseOutlined /></button>
    </template>
    <template v-if="!$slots.title" #title>
      <a-page-header :title="getMergeProps.title" :backIcon="!!innerPage" @back="onClose">
        <template #extra> </template>
      </a-page-header>
    </template>
    <template v-else #title>
      <slot name="title"></slot>
    </template>
    <div
      v-loading.lock="getLoading"
      class="basic-drawer__body"
      :loading-text="loadingText"
      :style="bodyStyle"
    >
      <slot></slot>
    </div>
    <Footer
      v-bind="getProps"
      :disabled="disabledFooter"
      :height="getFooterHeight"
      :placement="getMergeProps.footerPlacement"
      @close="onClose"
      @ok="handleOk"
    >
      <template v-for="name in Object.keys($slots)" #[name]="data">
        <slot :name="name" v-bind="data || {}"></slot>
      </template>
    </Footer>
  </a-drawer>
</template>

<script>
import { basicProps } from '../props'
import Footer from '../comps/Footer.vue'
import { useAttrs } from '@/composables/core/useAttrs'
import { cloneDeep, isFunction, merge } from 'lodash-es'

export default defineComponent({
  name: 'BasicDrawer',
  components: {
    Footer
  },
  inheritAttrs: false,
  props: {
    ...basicProps,
    classes: String,
    showForehead: Boolean,
    drawerStyle: Object
  },
  emits: ['ok', 'close', 'visible-change'],
  setup(props, { emit }) {
    const visibleRef = ref(false)
    const attrs = useAttrs()
    const propsRefs = ref(null)

    const drawerInstance = { setDrawerProps, emitVisible: undefined, afterVisibleChange: undefined }

    const instance = getCurrentInstance()

    // 提供给useDrawer（hook）使用
    instance && props?.register?.(drawerInstance, instance.uid)

    const getMergeProps = computed(() => merge(cloneDeep(props), unref(propsRefs)))

    const getProps = computed(() => {
      const options = {
        placement: 'right',
        ...unref(attrs),
        ...unref(getMergeProps),
        visible: unref(visibleRef)
      }
      options.title = undefined
      options.register = undefined
      return options
    })

    const getBindProps = computed(() => ({ ...unref(attrs), ...unref(getProps) }))

    const getWidth = computed(() => {
      return props.innerPage ? `calc(100% - 80px)` : unref(getProps).width
    })

    const getLoading = computed(() => !!unref(getProps).loading)

    const disabledFooter = computed(() => !!unref(getProps).disabled || unref(getLoading))

    const getFooterHeight = computed(() => {
      const { footerHeight, showFooter } = unref(getProps)
      if (showFooter && footerHeight) {
        return isFinite(footerHeight) ? `${footerHeight}px` : `${footerHeight.replace('px', '')}px`
      }
      return `0px`
    })

    const bodyStyle = computed(() => ({ height: `calc(100% - ${unref(getFooterHeight)})` }))

    function setDrawerProps(props = {}) {
      propsRefs.value = merge(cloneDeep(unref(propsRefs) || {}), props)
      if (props.hasOwnProperty('visible')) {
        visibleRef.value = !!props.visible
      }
    }

    // watch
    watch(
      () => props.visible,
      (newVal, oldVal) => {
        if (newVal !== oldVal) {
          visibleRef.value = newVal
        }
      }
    )

    watch(
      () => unref(visibleRef),
      (v) => {
        nextTick(() => {
          emit('visible-change', v)
          instance && drawerInstance.emitVisible?.(v, instance.uid)
        })
      }
    )

    const onClose = async (e) => {
      const { beforeClose } = unref(getProps)
      if (beforeClose && isFunction(beforeClose)) {
        const ret = beforeClose(e)
        if (ret instanceof Promise || (ret.then && ret.catch)) {
          const val = await ret
          if (val === false) return
          emit('close', e)
          visibleRef.value = false
          return
        }
        emit('close', e)
        visibleRef.value = !ret
        return
      }
      emit('close', e)
      visibleRef.value = false
    }

    const handleOk = () => emit('ok')

    return {
      getWidth,
      getProps,
      bodyStyle,
      getLoading,
      getBindProps,
      getMergeProps,
      disabledFooter,
      getFooterHeight,

      onClose,
      handleOk
    }
  }
})
</script>
<style lang="less">
.basic-drawer {
  &.ant-drawer-open.basic-drawer-show-forehead {
    top: 56px;
    height: calc(100% - 56px);
  }
  .ant-drawer-wrapper-body {
    overflow-y: hidden;
  }
  .ant-page-header {
    padding: 0;
    .ant-page-header-heading-title {
      color: #000000;
      font-weight: 550;
      font-size: 20px;
    }
  }
  .ant-drawer-body {
    height: calc(100% - 94px);
    padding: 0;
    .basic-drawer__body {
      position: relative;
      overflow-x: hidden;
    }
  }
}
</style>
