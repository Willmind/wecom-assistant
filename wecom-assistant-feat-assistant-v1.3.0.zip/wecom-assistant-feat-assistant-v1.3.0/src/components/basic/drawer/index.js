import BasicDrawer from './src/BasicDrawer.vue'

export default BasicDrawer
export { useDrawer, useDrawerInner } from './src/useDrawer.js'
