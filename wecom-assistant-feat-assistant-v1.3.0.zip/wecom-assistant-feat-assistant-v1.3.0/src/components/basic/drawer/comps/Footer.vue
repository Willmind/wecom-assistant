<template>
  <div v-if="showFooter || $slots.footer" class="basic-drawer--footer" :style="getStyle" @close="handleClose">
    <template v-if="!$slots.footer">
      <div class="left-area">
        <slot name="left_extra"></slot>
      </div>
      <div class="right-area">
        <slot name="insertBtn"></slot>
        <a-button v-if="showCancelBtn" :disabled="disabled" v-bind="cancelBtnProps" @click="handleClose">
          {{ cancelText }}
        </a-button>
        <a-button
          v-if="showOkBtn"
          :type="okType"
          :disabled="disabled"
          v-bind="okBtnProps"
          :loading="confirmLoading"
          @click="handleOk"
        >
          {{ okText }}
        </a-button>
        <slot name="appendBtn"></slot>
      </div>
    </template>
    <slot v-else name="footer"></slot>
  </div>
</template>
<script>
import { footerProps } from '../props'
import { PlacementEnum } from '@/enums/placementEnum'

export default defineComponent({
  props: {
    ...footerProps,
    height: {
      type: [Number, String],
      default: '60px'
    },
    placement: {
      type: String,
      default: PlacementEnum.RIGHT
    }
  },
  setup(props, { emit }) {
    const getStyle = computed(() => {
      const heightStr = `${isNaN(+props.height) ? props.height : `${props.height}px`}`
      return {
        height: heightStr,
        justifyContent:
          props.placement && PlacementEnum[props.placement.toUpperCase()]
            ? PlacementEnum[props.placement.toUpperCase()]
            : PlacementEnum.RIGHT
      }
    })

    const handleOk = () => emit('ok')
    const handleClose = () => emit('close')

    return {
      getStyle,
      handleOk,
      handleClose
    }
  }
})
</script>
<style lang="less" scoped>
.basic-drawer--footer {
  position: absolute;
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  right: 0;
  height: 64px;
  z-index: 1;
  padding: 0 32px 0 16px;
  box-sizing: border-box;
  .right-area {
    button {
      margin-left: 8px;
      &:first-child {
        margin-left: unset;
      }
    }
  }
  > * {
    margin-right: 8px;
  }
}
:deep(.ant-btn) {
  padding: 4px 12px;
}
</style>
