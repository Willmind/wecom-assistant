import { isFunction } from 'lodash-es'

/**
 * 统一安装注册 组件/插件
 * @param {app} app
 * @description
 * 针对components/basic目录下的基础组件自动全局安装
 */
export default function unifyInstalls(app) {
  const files = import.meta.globEager('./**/index.js')
  for (let key in files) {
    let module = files[key]
    const component = module.default || {}
    let componentName = component.name || component.componentName || component.__name
    componentName && app.component(componentName, component)
    // 安装插件
    if (module.installDirective && isFunction(module.installDirective)) {
      module.installDirective(app)
    }
  }
}
