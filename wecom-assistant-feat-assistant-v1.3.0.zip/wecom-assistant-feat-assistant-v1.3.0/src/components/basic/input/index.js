import RichInput from './src/RichInput.vue'

export default RichInput
