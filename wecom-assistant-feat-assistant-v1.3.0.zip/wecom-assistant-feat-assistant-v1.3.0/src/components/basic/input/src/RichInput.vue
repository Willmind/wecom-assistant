<template>
  <div class="basic-input" :class="[{ 'basic-input-tags': tagMode }, { 'basic-input-focused': isFocused }]">
    <div
      class="basic-input-wrap"
      :class="[
        { 'basic-input-affix-wrap': isAffix },
        { 'is-prefix': $slots.prefix },
        { 'is-suffix': $slots.suffix || allowClear }
      ]"
      :style="getAffixStyles"
      @click="handleFocusInput()"
    >
      <div ref="prefixRef" class="basic-input-prefix" v-if="$slots.prefix">
        <slot name="prefix"></slot>
      </div>
      <div
        class="basic-input-overflow jz-flex"
        :class="[{ full: useRich }, { 'tag-overflow': getOptions.length }]"
      >
        <template v-if="tagMode">
          <div class="basic-input-overflow-item tag-items" v-for="(item, index) in getOptions" :key="index">
            <a-tag :class="setTagClass(item, index)" closable @close="handleTagClose($event, index)">{{
              isPlainObject(item) ? item.label : item
            }}</a-tag>
          </div>
        </template>
        <div
          style="flex: 1"
          class="basic-input-overflow-item jz-flex-1"
          :class="{ 'is-rich': useRich }"
          :style="{ marginTop: getOptions.length ? '-5px' : 0 }"
        >
          <div class="basic-input-search" :style="getInputWidth">
            <input
              ref="inputRef"
              class="basic-input-search-text"
              :value="inputVal"
              :disabled="disabled"
              :readonly="!allowInput"
              :placeholder="getOptions.length ? '' : placeholder"
              @input="handleInput"
              @keydown="handleKeyEnter"
              @focus="handleFocusInput"
              @blur="() => (isFocused = false)"
              v-if="!useRich"
            />
            <textarea
              v-else
              ref="inputRef"
              :value="inputVal"
              :disabled="disabled"
              :readonly="!allowInput"
              :placeholder="placeholder"
              class="basic-input-search-text"
              @input="handleInput"
              @focus="handleFocusInput"
              :style="getRichStyle"
            >
            </textarea>
            <span ref="mirrorRef" class="basic-input-search-mirror">{{
              inputVal.length ? inputVal : '&nbsp;'
            }}</span>
          </div>
        </div>
      </div>
      <!-- <div class="rich-input-wrapper" v-else>
        <div class="rich-input-contenteditor" :contenteditable="useRich">
          <p ref="editorContentRef"></p>
        </div>
      </div> -->
      <div class="basic-input-overflow-append" v-loading="uploading" @click.stop="handleFocusInput">
        <slot name="appendContent"></slot>
      </div>
      <div ref="suffixRef" class="basic-input-suffix" v-if="$slots.suffix || allowClear">
        <close-circle-filled
          class="basic-input-clear-icon"
          v-if="allowClear ? !!inputVal.length : false"
          @click.prevent="clearInputVal"
        />
        <slot name="suffix"></slot>
      </div>
    </div>
  </div>
</template>
<!-- eslint-disable vue/one-component-per-file -->
<script>
import { isEqual, isPlainObject, omit } from 'lodash-es'
import { useAttrs } from '@/composables/core/useAttrs'
import {
  computed,
  defineComponent,
  ref,
  watch,
  toRaw,
  watchEffect,
  onMounted,
  nextTick,
  onBeforeUnmount,
  unref
} from 'vue'

export default defineComponent({
  name: 'RichInput',
  props: {
    tagMode: Boolean,
    maxTagCount: Number,
    value: [String, Number, Array],
    maxTagTextLength: Number,
    allowClear: Boolean,
    // 适用tagmode 下使用
    fieldName: {
      type: Object,
      default: () => ({ label: 'label', value: 'value' })
    },
    // 适用tag mode
    allowTabKeyEnter: Boolean,
    allowInput: {
      type: Boolean,
      default: true
    },
    disabled: Boolean,
    placeholder: String,
    tagsOption: Array,
    autoRows: {
      type: Object,
      default: () => ({})
    },
    useRich: Boolean,
    setTagClass: {
      type: Function,
      default: () => 'ant-tag-plain'
    }
  },
  emits: ['update:value', 'input', 'pressEnter', 'paste', 'update:tagsOption', 'tag-change'],
  setup(props, { emit, slots }) {
    const attrs = useAttrs()
    const tags = ref([])
    const inputRef = ref()
    const mirrorRef = ref()
    const editorContentRef = ref()
    const inputWidth = ref(0)
    const prefixWidth = ref(0)
    const prefixRef = ref()
    const suffixRef = ref()
    const isFocused = ref(false)
    const inputVal = ref(props.value ?? '')
    const uploading = ref(false)

    const getProps = computed(() => {
      return {
        ...attrs,
        ...props
      }
    })

    const isAffix = computed(() => slots.prefix || slots.suffix)

    const isRows = computed(() => !!props.autoRows.minRow || props.autoRows.maxRow)

    const getOptions = computed(() => {
      let { label, value } = props.fieldName
      let [firstItem] = tags.value
      emit('update:tagsOption', tags.value)
      if (isPlainObject(firstItem)) {
        return tags.value.map((item) => {
          return {
            label: item[label] || item.label,
            value: item[value] || item.value,
            ...omit(item, [label, value])
          }
        })
      }
      return tags.value
    })

    const getInputWidth = computed(() => {
      const isEmpty = inputVal.value.length === 0
      return {
        [isEmpty ? 'minWidth' : ' width']: inputWidth.value + 'px'
      }
    })

    const getRichStyle = computed(() => {
      let height = unref(getAffixStyles).maxHeight || unref(getAffixStyles).minHeight
      let inputHeight = +height.replace('px', '') - 4
      inputHeight = tags.value.length ? inputHeight - 32 : inputHeight
      return {
        height: inputHeight + 'px'
      }
    })

    let mutation = null
    onMounted(() => {
      nextTick(() => {
        if (prefixRef.value) {
          mutation = new MutationObserver((mutations) => {
            let [record] = mutations
            if (record.target) {
              prefixWidth.value = record.target.offsetWidth
            }
          }, {})
          mutation.observe(prefixRef.value, { childList: true, subtree: true })
        }
        unref(inputRef)?.addEventListener('paste', handlePasteCallback)
      })
    })

    onBeforeUnmount(() => {
      mutation?.disconnect()
      mutation = null
      unref(inputRef)?.removeEventListener('paste', handlePasteCallback)
    })

    const handleKeyEnter = (e) => {
      let target = e.target
      let keyCode = e.keyCode || e.which
      if (keyCode === 13 || (props.allowTabKeyEnter && keyCode === 9)) {
        if (props.tagMode) {
          tags.value.push(target.value)
          inputVal.value = ''
          emit('update:value', toRaw(tags.value)?.slice())
        }
        emit('pressEnter', e)
      } else if (keyCode === 8) {
        if (props.tagMode && !inputVal.value.length) {
          getOptions.value.pop()
        }
      }
    }

    const handleInput = (e) => {
      let value = e.target.value
      inputVal.value = value
      emit('input', value)
      emit('update:value', value)
    }

    const handleFocusInput = (e) => {
      const target = e?.target
      if (target) {
        if (target.setSelectionRange) {
          target.focus()
          let len = (target.textContent || target.innerText || target.value)?.length || 4
          target.setSelectionRange(len, len)
        }
        return
      }
      inputRef.value?.focus()
      isFocused.value = true
    }

    const clearInputVal = () => {
      inputVal.value = ''
      tags.value = []
    }

    const handleTagClose = (e, index) => {
      setTimeout(() => {
        let target = e.target.parentNode
        while (target) {
          if (target.classList?.contains('ant-tag-hidden')) {
            target.classList.remove('ant-tag-hidden')
            break
          }
          target = target.parentNode
        }
        tags.value.splice(index, 1)
      })
    }

    const getAffixStyles = computed(() => {
      let minHeight = props.autoRows?.minRow * 32
      let maxHeight = props.autoRows?.maxRow * 32
      return {
        minHeight: minHeight ? minHeight + 'px' : null,
        maxHeight: maxHeight ? maxHeight + 'px' : null,
        paddingLeft: (prefixWidth.value || 0) + 6 + 'px',
        alignItems: minHeight || maxHeight ? 'flex-start' : 'center'
      }
    })

    const handlePasteCallback = (e) => {
      e = e || window.event

      let clipboardData = e.clipboardData || window.clipboardData
      if (!clipboardData || !clipboardData.items) return
      let files = Array.from(clipboardData.files)
      if (files?.length) {
        e.preventDefault()
        e.stopPropagation()
        files.forEach((file) => {
          // 判断是否为文件
          if ((file && file.size) || file instanceof Blob) {
            const reader = new FileReader()
            reader.readAsDataURL(file)
            uploading.value = true
            reader.onload = (event) => {
              uploading.value = false
              emit('paset-image-success', {
                file,
                url: event.target?.result
              })
            }
            reader.onerror = (event) => {
              uploading.value = false
              emit('paset-image-error', { file: file, event: event })
            }
          }
        })
      }
      emit('paset', {
        event: e,
        clipboardData: clipboardData
      })
    }

    watch(
      () => props.value,
      (val, old) => {
        if (!isEqual(val, old)) {
          if (!props.tagMode || !Array.isArray(val)) {
            inputVal.value = val ?? ''
          } else {
            tags.value = val ?? []
          }
        }
      }
    )

    watchEffect(() => {
      tags.value = props.tagsOption || []
    })

    watch(
      () => inputVal.value,
      (val) => {
        // TODO +4?
        inputWidth.value = mirrorRef.value?.scrollWidth + 4
        props.tagMode || emit('update:value', val)
      },
      {
        flush: 'post',
        immediate: true
      }
    )

    watch(
      () => tags,
      (list) => {
        if (props.tagMode) {
          const ls = list.value?.slice()
          if (props.tagsOption !== undefined && props.tagsOption !== null) {
            emit('update:tagsOption', ls)
          } else {
            emit('update:value', ls)
          }
        }
      },
      {
        deep: true
      }
    )

    return {
      tags,
      isRows,
      isAffix,
      getProps,
      inputVal,
      inputRef,
      mirrorRef,
      prefixRef,
      suffixRef,
      getOptions,
      isFocused,
      uploading,
      handleInput,
      getRichStyle,
      editorContentRef,
      getInputWidth,
      isPlainObject,
      clearInputVal,
      handleTagClose,
      handleKeyEnter,
      handleFocusInput,
      getAffixStyles
    }
  }
})
</script>

<style lang="less" scoped>
.basic-input {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
  color: #000000d9;
  font-size: 14px;
  font-variant: tabular-nums;
  line-height: 1.5715;
  list-style: none;
  font-feature-settings: 'tnum';
  position: relative;
  display: inline-block;
  cursor: pointer;
  width: 100%;
  &-prefix,
  &-suffix {
    display: flex;
    align-items: flex-end;
    flex: none;
    font-size: 12px;
    color: rgba(0, 0, 0, 0.25);
  }
  &-prefix {
    position: absolute;
    left: 4px;
    top: 6px;
    z-index: 1;
  }
  &-suffix {
    display: inline-block;
    color: inherit;
    font-style: normal;
    line-height: 0;
    text-transform: none;
    vertical-align: -0.125em;
    text-rendering: optimizelegibility;
    position: absolute;
    top: 50%;
    right: 11px;
    width: 12px;
    height: 12px;
    margin-top: -6px;
    color: rgba(0, 0, 0, 0.25);
    font-size: 12px;
    line-height: 1;
    text-align: center;
    pointer-events: none;
    .basic-input-clear-icon {
      margin: 0 4px;
      color: #00000040;
      font-size: 12px;
      cursor: pointer;
      transition: color 0.3s;
      z-index: 1;
      display: inline-block;
      width: 12px;
      height: 12px;
      font-size: 12px;
      font-style: normal;
      line-height: 1;
      text-align: center;
      text-transform: none;
      background: #fff;
      cursor: pointer;
      text-rendering: auto;
      &:hover {
        color: rgba(0, 0, 0, 0.45);
      }
    }
  }
  &-wrap {
    position: relative;
    cursor: text;
    background-color: #fff;
    border: 1px solid @input-border-color;
    border-radius: 6px;
    transition: all 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);
    &:after {
      display: inline-block;
      width: 0;
      margin: 2px 0;
      line-height: 24px;
      content: '\a0';
    }
    &.basic-input-affix-wrap {
      padding: 4px 8px 4px 6px;
    }
    &:not(.basic-input-disabled):hover {
      border-color: @primary-color;
      border-right-width: 1px !important;
    }
    &:not(.basic-input-disabled):focus {
      box-shadow: 0 0 0 2px rgb(24 144 255 / 20%);
      outline: 0;
    }
  }
  &-search {
    position: relative;
    max-width: 100%;
    // margin-inline-start: 1px;
    &-text {
      cursor: auto;
      margin: 0;
      padding: 0;
      background: transparent;
      border: none;
      outline: none;
      appearance: none;
      box-sizing: border-box;
      outline-offset: -2px;
      display: inline-block;
      border: none;
      outline: none;
      overflow: visible;
      width: 100%;
      min-width: 4.1px;
    }
    &-mirror {
      position: absolute;
      top: 0;
      left: 0;
      z-index: 999;
      white-space: pre;
      visibility: hidden;
    }
  }
  &-overflow {
    position: relative;
    display: flex;
    flex: auto;
    flex-wrap: wrap;
    max-width: 100%;
    &.full {
      width: 100%;
      .basic-input-overflow-item.is-rich {
        width: 100%;
      }
    }
    &.tag-overflow {
      margin-top: 5px;
    }
    &-item {
      flex: none;
      align-self: center;
      max-width: 100%;
      max-height: 28px;
      &.tag-items {
        margin-bottom: 5px;
      }
      + .basic-input-overflow-item {
        .basic-input-search {
          margin-inline-start: 0px;
        }
      }
    }
    &-append {
      flex: none;
      align-self: center;
      max-width: 100%;
      min-height: 28px;
    }
  }
  &.basic-input-tags {
    .basic-input-wrap {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      padding: 1px 4px;
      &.basic-input-affix-wrap {
        padding: 1px 8px 1px 6px;
        &.is-prefix {
          padding-left: 24px;
        }
        &.is-suffix {
          padding-right: 24px;
        }
      }
    }
    .basic-input-search-text {
      width: 100%;
      min-width: 4.1px;
      height: 24px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, 'Noto Sans',
        sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol', 'Noto Color Emoji';
      line-height: 24px;
      transition: all 0.3s;
      &:placeholder-shown {
        text-overflow: ellipsis;
      }
      &::placeholder {
        color: #bfbfbf;
      }
    }
  }
  :deep(.ant-tag-basic) {
    color: #000;
    height: 24px;
    line-height: 22px;
    font-size: 14px;
    border-radius: @border-radius-base;
    border: 1px solid #f0f0f0;
    background: #f5f5f5;
    overflow: hidden;
    white-space: pre;
    text-overflow: ellipsis;
  }
}
.rich-input {
  &-wrapper {
    padding: 4px 0px;
  }
  &-contenteditor {
    outline: 0;
    border: 0;
    cursor: auto;
  }
}
</style>
