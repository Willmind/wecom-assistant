import { SizeEnum } from '@/enums/sizeEnum'
import createLoading from './createLoading'

/**
 * loading指令
 * @example
 * <div v-loading="loading"></div>
 * <div v-loading.fullscreen="loading"></div>  -- 全屏loading
 */
const loadingDirective = {
  mounted(el, binding) {
    let tip = el.getAttribute('loading-text')
    let size = el.getAttribute('loading-size')
    let background = el.getAttribute('loading-background')
    let { fullscreen, lock } = binding.modifiers
    const app = createLoading(
      {
        tip,
        lock,
        background,
        fullscreen,
        size: size || SizeEnum.MINI,
        loading: !!binding.value
      },
      fullscreen ? document.body : el
    )
    el.instance = app
  },
  updated(el, binding) {
    const instance = el.instance
    if (!instance) return
    let loadText = el.getAttribute('loading-text')
    let lock = el.getAttribute('loading-lock')
    lock !== undefined && lock !== null && instance.setProps({ lock: !!lock })
    instance.setLoadingText(loadText)
    if (binding.oldValue !== binding.value) {
      instance.setLoading(!!binding.value)
    }
  },
  unmounted(el) {
    el?.instance?.close()
  }
}

export function installDirective(app) {
  app.directive('loading', loadingDirective)
}

export default loadingDirective
