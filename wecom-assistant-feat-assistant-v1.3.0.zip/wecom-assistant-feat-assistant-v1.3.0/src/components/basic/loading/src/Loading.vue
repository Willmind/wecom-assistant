<template>
  <div
    v-show="loading"
    ref="loadingRef"
    class="loading-wrapper"
    :class="[{ 'loading-area': !fullscreen }, customClass]"
    :style="loadingStyle"
  >
    <a-spin v-bind="$attrs" :tip="tip" :size="size" :spinning="loading">
      <slot></slot>
    </a-spin>
  </div>
</template>

<script>
import { SizeEnum } from '@/enums/sizeEnum'

export default defineComponent({
  name: 'Loading',
  inheritAttrs: false,
  props: {
    tip: String,
    loading: Boolean,
    size: {
      type: String,
      default: SizeEnum.MINI,
      validator(val) {
        return !!SizeEnum[val]
      }
    },
    lock: Boolean,
    zIndex: {
      type: Number,
      default: 1000
    },
    fullscreen: Boolean,
    background: String,
    customClass: String
  },
  setup(props) {
    const offsetTop = ref(0)
    const loadingRef = ref()

    const loadingStyle = computed(() => ({
      backgroundColor: props.background || '',
      zIndex: props.zIndex || 1000,
      top: unref(offsetTop) + 'px'
    }))

    onMounted(() => {
      nextTick(() => {
        let el = unref(loadingRef)
        if (el?.parentNode) {
          if (!props.fullscreen) {
            const position = getComputedStyle(el.parentNode).getPropertyValue('position')
            if (position !== 'relative') {
              el.parentNode.style.position = 'relative'
            }
          }
          props.loading && setLockStyle(props.loading, props.lock)
        }
      })
    })

    watch(
      () => props.loading,
      (v) => {
        setLockStyle(v, props.lock)
      }
    )

    watch(
      () => props.lock,
      (isLock) => setLockStyle(props.loading, isLock)
    )

    function setLockStyle(loading, isLock) {
      if (isLock && unref(loadingRef)?.parentNode) {
        let el = unref(loadingRef)
        let parentNode = el.parentNode
        offsetTop.value = parentNode.scrollTop || 0
        parentNode.style.overflow = loading ? 'hidden' : ''
      }
    }

    return {
      loadingRef,
      loadingStyle
    }
  }
})
</script>
<style lang="less" scoped>
.loading-wrapper {
  position: fixed;
  top: 0;
  left: 0;
  z-index: 1000;
  display: flex;
  width: 100%;
  height: 100%;
  justify-content: center;
  align-items: center;
  background-color: rgba(255, 255, 255, 0.4);
  &.loading-area {
    position: absolute;
    top: 0;
    left: 0;
  }
}
</style>
