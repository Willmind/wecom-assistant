import { isBoolean } from 'lodash-es'
import { render, createVNode, reactive } from 'vue'
import Loading from './Loading.vue'

/**
 * 创建loading实例
 * @param {Object} props
 * @param {HTMLElement} target
 * @param {Boolean} wait
 */
export default function createLoading(props = {}, target, wait = false) {
  let vm = null
  const params = reactive({
    tip: '',
    loading: true,
    ...props
  })
  let loadingCtor = defineComponent({
    render() {
      return h(Loading, { ...params })
    }
  })
  vm = createVNode(loadingCtor)
  render(vm, document.createElement('div'))
  if (wait) {
    setTimeout(() => render(vm, document.createElement('div')))
  } else {
    render(vm, document.createElement('div'))
  }
  let __inserted = false

  const methods = {
    instance: vm,
    open,
    close,
    setLoading(loading) {
      methods.setProps({ loading })
    },
    setLoadingText(tip) {
      methods.setProps({ tip })
    },
    setProps(props = {}) {
      for (let key in props) {
        Reflect.set(params, key, props[key])
      }
    },
    get loading() {
      return vm.loading
    },
    get el() {
      return vm?.el
    }
  }

  function open() {
    let [target, isShow] = arguments
    if (__inserted) {
      if (isBoolean(target)) {
        isShow = target
      }
      methods?.setProps({ loading: !!isShow })
    } else {
      target?.appendChild(vm.el)
      __inserted = true
    }
  }

  /**
   * 关闭loading
   * @param {Boolean} force 是否强制销毁元素
   */
  function close(force) {
    if (vm?.el && force) {
      nextTick(() => {
        vm.el.parentNode?.removeChild(vm.el)
        __inserted = false
      })
      return
    }
    methods?.setProps({ loading: false })
  }

  target && open(target)

  return methods
}
