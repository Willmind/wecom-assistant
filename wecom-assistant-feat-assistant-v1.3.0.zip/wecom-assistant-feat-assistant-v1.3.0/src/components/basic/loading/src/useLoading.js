import createLoading from './createLoading.js'

export default function useLoading(options = {}) {
  let props = null
  let target = document.body

  if (Reflect.has(options, 'target') || Reflect.has(options, 'props')) {
    props = { ...(options.props || {}) }
    target = options.target || target
  } else {
    props = options
  }
  const { open: _open, close, setLoadingText, setProps } = createLoading(props)

  function open(isShow) {
    let el = unref(target)
    if (!el) return
    _open(el, isShow)
  }

  return { open, close, setLoadingText, setProps }
}
