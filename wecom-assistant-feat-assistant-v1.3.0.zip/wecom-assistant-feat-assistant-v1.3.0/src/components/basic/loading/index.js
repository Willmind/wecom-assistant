import Loading from './src/Loading.vue'
import { installDirective } from './src/directive.js'
import useLoading from './src/useLoading.js'
import createLoading from './src/createLoading.js'

export default Loading
export { useLoading }
export { createLoading }
export { installDirective }
