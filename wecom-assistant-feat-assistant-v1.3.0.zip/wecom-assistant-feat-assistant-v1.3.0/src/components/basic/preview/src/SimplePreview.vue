<!-- 用于 table 内部 img slot -->
<template>
  <div class="preview-wrap" v-show="visible">
    <a-modal
      width="720"
      class="preview-modal-wrapper"
      v-model:visible="visible"
      centered
      destroyOnClose
      :footer="null"
      @cancel="onClose"
      v-loading="loading"
    >
      <slot></slot>
    </a-modal>
  </div>
</template>

<script>
import { defineComponent, ref } from 'vue'

export default defineComponent({
  name: 'SimplePreview',
  props: {
    src: String,
    styles: {
      type: Object,
      default: () => ({})
    },
    loading: Boolean
  },
  setup() {
    const visible = ref(false)

    const onOpen = () => {
      visible.value = true
      console.log(visible.value, 'open')
    }
    const onClose = () => {
      visible.value = false
    }

    return {
      visible,
      onOpen,
      onClose
    }
  }
})
</script>

<style lang="less">
.preview-wrap {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.04);
  .close-btn {
    position: absolute;
    top: -20px;
    right: 0;
    width: 40px;
    height: 40px;
  }
}
.preview-modal-wrapper {
  min-width: 480px;
  min-height: 350px;
  .ant-modal-content {
    width: 100%;
    height: 100%;
    background: none;
    box-shadow: none;
    .ant-modal-close {
      top: -34px;
      right: -10px;
    }
  }
}
</style>
