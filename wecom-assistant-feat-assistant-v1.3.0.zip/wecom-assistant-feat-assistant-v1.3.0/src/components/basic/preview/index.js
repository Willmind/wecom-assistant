import SimplePreview from './src/SimplePreview.vue'
export default SimplePreview
