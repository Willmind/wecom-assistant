import VoiceBubble from './src/VoiceBubble.vue'
export default VoiceBubble
