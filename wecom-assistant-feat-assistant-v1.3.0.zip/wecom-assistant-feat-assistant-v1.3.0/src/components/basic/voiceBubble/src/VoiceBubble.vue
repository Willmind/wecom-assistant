<template>
  <div class="speed-bubble" @click="handlePlay">
    <div class="suona-box jz-flex jz-flex-cc">
      <div class="first"></div>
      <div class="second" :class="{ animation: state.isPlaying }"></div>
      <div class="third" :class="{ animation: state.isPlaying }"></div>
    </div>
    <span class="duration">{{ getDuration }}''</span>
  </div>
</template>
<script setup>
import useMessage from '@/composables/web/useMessage'
import { computed, onBeforeUnmount, onMounted, reactive, shallowRef, toRaw } from 'vue'

const props = defineProps({
  url: String,
  duration: [String, Number]
})
const emit = defineEmits(['error', 'play', 'ended', 'loadedmetadata'])
const { createMessage } = useMessage()

const state = reactive({
  isPlaying: false,
  duration: props.duration || 0
})

const rawRudio = shallowRef(new Audio())
rawRudio.value.autoplay = false

const getDuration = computed(() => Math.floor(state.duration)) || 0

const handlePlay = () => {
  const res = rawRudio.value?.play()
  if (res && (res.then || res.catch)) {
    res.catch((e) => {
      if (e && e.name === 'NotAllowedError') {
        state.isPlaying = false
      } else if (~String(e).indexOf('Failed to load')) {
        state.isPlaying = false
      }
      emit('error', e)
    })
  }
}
const handlePause = () => {
  rawRudio.value?.pause()
  state.isPlaying = false
}

const setAudioSrc = (url) => {
  if (!url) return
  rawRudio.value.src = url
  state.duration = rawRudio.value.duration
}

const initAudioEvent = () => {
  rawRudio.value.addEventListener('play', (e) => {
    state.isPlaying = true
    emit('play', e)
  })
  rawRudio.value.addEventListener('ended', (e) => {
    state.isPlaying = false
    emit('ended', e)
  })
  rawRudio.value.addEventListener('error', () => {
    state.isPlaying = false
    createMessage.error('语音播放失败')
    emit('error', e)
  })

  rawRudio.value.addEventListener('loadedmetadata', () => {
    state.duration = rawRudio.value.duration
  })
}

watchEffect(() => {
  setAudioSrc(props.url)
})

onMounted(() => {
  initAudioEvent()
})

onBeforeUnmount(() => {
  if (rawRudio.value) {
    handlePause()
    rawRudio.value = null
  }
})

defineExpose({
  rawRudio: toRaw(rawRudio.value),
  setAudioSrc,
  toPause: handlePause,
  toPlay: handlePlay
})
</script>
<style lang="less" scoped>
.speed-bubble {
  width: 100px;
  height: 44px;
  display: flex;
  padding: 0 10px;
  align-items: center;
  background: #eeeeee;
  box-sizing: border-box;
  position: relative;
  border-radius: 7px;
  cursor: pointer;
  .duration {
    color: #000;
    font-size: 14px;
    margin-left: 10px;
  }
  &:active {
    opacity: 0.8;
  }
  &:before {
    content: ' ';
    position: absolute;
    display: block;
    left: -4px;
    width: 8px;
    height: 8px;
    background: transparent;
    border-style: solid;
    border-width: 4px;
    border-top-color: transparent;
    border-right-color: transparent;
    border-bottom-color: #eeeeee;
    border-left-color: #eeeeee;
    pointer-events: none;
    top: 50%;
    transform: translateY(-50%) rotate(45deg);
  }

  .voice-bar() {
    border-style: solid;
    border-top-color: transparent;
    border-left-color: transparent;
    border-bottom-color: transparent;
    border-radius: 50%;
    box-sizing: border-box;
    vertical-align: middle;
    display: inline-block;
    color: #000;
  }

  .suona-box {
    height: 100%;
    @keyframes play_secord {
      0% {
        opacity: 0;
      }
      30% {
        opacity: 1;
      }
      100% {
        opacity: 0;
      }
    }

    @keyframes play_third {
      0% {
        opacity: 0;
      }
      60% {
        opacity: 1;
      }
      100% {
        opacity: 0;
      }
    }
    .first {
      width: 6px;
      height: 6px;
      .voice-bar;
    }
    > div {
      &:nth-of-type(2) {
        &.animation {
          animation: play_secord 1.5s ease-in-out infinite;
        }
      }
      &:nth-of-type(3) {
        &.animation {
          animation: play_third 1.5s ease-in-out infinite;
        }
      }
    }

    .second {
      width: 16px;
      height: 16px;
      margin-left: -10px;
      opacity: 1;
      .voice-bar;
    }
    .third {
      width: 26px;
      height: 26px;
      margin-left: -20px;
      opacity: 1;
      .voice-bar;
    }
  }
}
</style>
