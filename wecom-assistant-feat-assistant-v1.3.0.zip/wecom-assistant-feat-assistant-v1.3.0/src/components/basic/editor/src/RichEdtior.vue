<template>
  <EditorContent
    class="rich-editor"
    :class="{ border: bordered }"
    :editor="editorRef"
    :style="getEditorStyles"
  />
</template>

<script setup>
import { ref, toRef, watch, nextTick } from 'vue'
import { isPlainObject } from 'lodash-es'
import Text from '@tiptap/extension-text'
import Doc from '@tiptap/extension-document'
import PlaceHolder from '@tiptap/extension-placeholder'
import Paragraph from '@tiptap/extension-paragraph'
import Image from '@tiptap/extension-image'
import TagNode from './tiptap/TagNode'
import EmptyNode from './tiptap/EmptyNode'
import { EditorContent, useEditor } from '@tiptap/vue-3'
import imagePasteHandler from './tiptap/imagePasteHandler'

const props = defineProps({
  autoFocus: Boolean,
  // image, tag
  toolbar: {
    type: Array
  },
  value: {
    type: [String, Object],
    validator: (val) => {
      return typeof val === 'object' ? isPlainObject(val) : true
    }
  },
  placeholder: String,
  bordered: Boolean,
  autoRows: {
    type: Object,
    default: () => ({})
  }
})

const emit = defineEmits(['imagePasted', 'change'])

const customerDoc = Doc.extend({
  addOptions() {
    return {}
  },
  addProseMirrorPlugins() {
    const plugins = []
    if (this.options.imageOnPaset) {
      plugins.push(
        imagePasteHandler({
          editor: this.editor,
          type: this.type,
          callback: ({ file, dataURL }) => {
            emit('imagePasted', { file, dataURL })
          }
        })
      )
    }
    return plugins
  }
})

const customerImage = Image.extend({
  inline: true,
  group: 'inline',
  addCommands() {
    return {
      setImage:
        (options) =>
        ({ commands }) => {
          return commands.insertContent([
            {
              type: this.name,
              attrs: options
            },
            {
              type: 'empty',
              attrs: {}
            }
          ])
        }
    }
  }
})

const extensions = []
const content = ref('')
const state = reactive({
  isNotEmpty: false
})

const getEditorStyles = computed(() => {
  let minHeight = props.autoRows?.minRow * 32
  let maxHeight = props.autoRows?.maxRow * 32
  return {
    minHeight: minHeight ? minHeight + 'px' : null,
    maxHeight: maxHeight ? maxHeight + 'px' : null
  }
})

watchEffect(() => {
  if (props.toolbar?.length > 0) {
    props.toolbar.forEach((v) => {
      if (v === 'image') {
        extensions.push(customerImage)
      } else if (v === 'tag') {
        extensions.push(TagNode)
      }
    })
  }
})

const editorRef = useEditor({
  extensions: [
    Text,
    Paragraph,
    EmptyNode,
    PlaceHolder.configure({
      placeholder: props.placeholder
    }),
    customerDoc.configure({
      imageOnPaset: props.toolbar.includes('image')
    }),
    ...extensions
  ],
  onCreate({ editor }) {
    props.autoFocus && editor.chain().focus()
    content.value = props.value === undefined || props.value === null ? '' : props.value
    editor.commands.setContent(content.value)
    nextTick(() => {
      state.isNotEmpty = editor.getCharacterCount() > 0
    })
  },
  onUpdate: ({ editor }) => {
    state.isNotEmpty = editor.getCharacterCount() > 0
    emit('change', {
      json: editor.getJSON(),
      text: editor.getText({ blockSeparator: '|', textSerializers: { node: TagNode } })
    })
  }
})

watch(
  () => props.value,
  (val) => {
    editorRef.value?.commands?.setContent(val)
  }
)

onBeforeUnmount(() => {
  extensions.length = 0
  content.value = ''
})

defineExpose({
  editorRef,
  isNotEmpty: toRef(state, 'isNotEmpty'),
  getJSON: () => editorRef.value?.getJSON()
})
</script>

<style lang="less" scoped>
.rich-editor {
  width: 100%;
  min-height: 32px;
  box-sizing: border-box;
  margin: 0;
  padding: 0;
  color: #000;
  font-size: 14px;
  font-variant: tabular-nums;
  line-height: 1.5715;
  list-style: none;
  font-feature-settings: 'tnum';
  position: relative;
  display: inline-block;
  outline: 0;
  overflow-y: auto;
  border-radius: @border-radius-base;
  transition: all 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);
  &.border {
    border: 1px solid @input-border-color;
  }
  :deep(.ProseMirror) {
    outline: 0;
    padding: 4px 11px;
    img {
      width: 120px;
      height: auto;
      object-fit: cover;
      border-radius: 6px;
      margin: 8px 0;

      &.ProseMirror-selectednode {
        outline: 2px solid @primary-color;
      }
    }
    /* Placeholder (at the top) */
    p.is-empty:first-child::before {
      content: attr(data-placeholder);
      float: left;
      color: rgba(0, 0, 0, 0.4);
      pointer-events: none;
      height: 0;
    }
  }
  &:after {
    display: inline-block;
    width: 0;
    margin: 2px 0;
    line-height: 24px;
    content: '\a0';
  }
  &:not(.editor-disabled):hover {
    border-color: #40a9ff;
    border-right-width: 1px;
  }
  &:not(.editor-disabled):focus {
    box-shadow: 0 0 0 2px rgb(24 144 255 / 20%);
    outline: 0;
  }
}
</style>
