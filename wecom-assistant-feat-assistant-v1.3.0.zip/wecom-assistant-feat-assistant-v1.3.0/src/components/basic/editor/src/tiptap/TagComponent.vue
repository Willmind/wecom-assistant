<template>
  <node-view-wrapper style="display: inline-block">
    <a-tag class="ant-tag-plain" closable @close="handleTagClose($event)">{{ node.attrs.text }}</a-tag>
  </node-view-wrapper>
</template>
<script setup>
import { nodeViewProps, NodeViewWrapper } from '@tiptap/vue-3'

const props = defineProps({
  ...nodeViewProps
})

const handleTagClose = (event) => {
  const target = event.target
  target && props.deleteNode()
}
</script>
