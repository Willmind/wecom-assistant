import TagComponent from './TagComponent.vue'
import { Node, mergeAttributes } from '@tiptap/core'
import { VueNodeViewRenderer } from '@tiptap/vue-3'

export default Node.create({
  name: 'TagComponent',
  group: 'inline',
  inline: true,
  atom: true,
  leaf: false,
  selectable: false,
  addAttributes() {
    return {
      text: {
        default: ''
      }
    }
  },
  parseHTML() {
    return [
      {
        tag: 'TagComponent'
      }
    ]
  },

  renderHTML({ HTMLAttributes }) {
    return ['TagComponent', mergeAttributes(HTMLAttributes)]
  },
  addNodeView() {
    return VueNodeViewRenderer(TagComponent)
  },
  addCommands() {
    return {
      setTag:
        (text) =>
        ({ commands }) =>
          commands.insertContent({
            type: this.name,
            attrs: {
              text
            }
          })
    }
  }
})
