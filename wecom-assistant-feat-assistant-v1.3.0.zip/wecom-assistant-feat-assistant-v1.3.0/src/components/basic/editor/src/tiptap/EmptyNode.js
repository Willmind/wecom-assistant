import { Node } from '@tiptap/core'
export default Node.create({
  name: 'empty',
  addOptions() {
    return {}
  },
  group: 'inline',
  inline: true,
  atom: true,
  parseHTML() {
    return [{ tag: 'span' }]
  },
  renderHTML() {
    const span = document.createElement('span')
    span.innerHTML = '&#xFEFF;'
    return {
      dom: span
    }
  },
  addCommands() {
    return {
      insertEmpty:
        () =>
        ({ commands }) =>
          commands.insertContent({ type: this.name })
    }
  }
})
