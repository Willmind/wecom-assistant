import { ref } from 'vue'
import { Plugin, PluginKey } from 'prosemirror-state'

export default function (options) {
  return new Plugin({
    key: new PluginKey('handlePasteImage'),
    props: {
      handlePaste(_, event) {
        event = event || window.event
        const { callback } = options

        let clipboardData = event.clipboardData || window.clipboardData
        if (!clipboardData || !clipboardData.items) return
        let files = Array.from(clipboardData.files)
        if (files?.length) {
          event.preventDefault()
          event.stopPropagation()
          files.forEach((file) => {
            // 判断是否为文件
            if ((file && file.size) || file instanceof Blob) {
              const reader = new FileReader()
              reader.readAsDataURL(file)
              reader.onload = (e) => {
                callback && callback({ file, dataURL: e.target.result })
              }
              reader.onerror = () => {}
              return true
            }
          })
        }
      }
    }
  })
}
