import RichEdtior from './src/RichEdtior.vue'
export default RichEdtior
