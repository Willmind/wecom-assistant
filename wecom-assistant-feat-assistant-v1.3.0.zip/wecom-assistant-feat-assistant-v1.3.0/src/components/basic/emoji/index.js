import EmojiPanel from './src/index.vue'
export default EmojiPanel
