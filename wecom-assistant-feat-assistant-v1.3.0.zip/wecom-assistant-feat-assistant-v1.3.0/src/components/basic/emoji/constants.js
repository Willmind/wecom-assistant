const EMOJI_SIZE = 30
const padding = 8
const areaWidth = window.innerWidth || document.body.clientWidth

// emji cdn url
export const EMOJI_SOURCE =
  'https://cq-pic1.jianzhishuyuan.net/dsh/20220920/4c14e81d6c05554680addf7a227a9b3a.png'

export const perLine = Math.floor((areaWidth - padding * 2) / 45)

export const extraPadding = Math.floor((areaWidth - padding * 2 - perLine * EMOJI_SIZE) / (perLine - 1))
