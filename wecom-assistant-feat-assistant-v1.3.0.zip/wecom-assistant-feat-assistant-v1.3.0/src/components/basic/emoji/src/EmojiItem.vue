<template>
  <div :class="`wemoji-item__icon`">
    <span class="emoji-entity" v-if="useHtml && item.html">{{ item.html }}</span>
    <img class="emoji-image" :src="item.url" v-else />
  </div>
</template>

<script setup>
import '../css/emoji.less'

defineProps({
  item: Object,
  useHtml: {
    type: Boolean,
    default: true
  }
})
</script>
