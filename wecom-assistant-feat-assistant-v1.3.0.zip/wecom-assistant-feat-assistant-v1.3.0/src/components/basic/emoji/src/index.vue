<template>
  <div class="weemoji-panel" :style="styles">
    <div class="weemoji-list">
      <div class="used-area" v-if="recentUsed && recentUsed.length">
        <div class="wemoji-head"></div>
        <div class="wemoji-content">
          <template v-for="(item, index) in recentUsed" :key="index">
            <EmojiItem :item="item" :index="index" @click="handelClick(item)" />
          </template>
        </div>
      </div>
      <div class="all-emoji">
        <div class="wemoji-head" v-if="showHeader">所有表情</div>
        <div class="wemoji-content jz-flex jz-flex-1">
          <template v-for="(item, index) in emojiList" :key="index">
            <EmojiItem :item="item" :index="index" @click="handelClick(item)" />
          </template>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import EmojiItem from './EmojiItem.vue'
import emojisList from '@/utils/emoji/emojiData'
import { cloneDeep } from 'lodash-es'

export default defineComponent({
  name: 'EmojiPanel',
  components: {
    EmojiItem
  },
  props: {
    styles: Object,
    recentUsed: {
      type: Array,
      default: () => []
    },
    dataList: {
      type: Array,
      default: () => cloneDeep(emojisList)
    },
    showHeader: Boolean
  },
  emits: ['select'],
  setup(props, { emit }) {
    const handelClick = (item) => {
      emit('select', { ...item })
    }

    const emojiList = ref([])

    watchEffect(() => {
      emojiList.value = props.dataList.map((item) => ({
        ...item,
        reg: item.code && typeof item.code === 'string' ? new RegExp(item.code, 'g') : null
      }))
    })

    return {
      emojiList,
      EmojiItem,
      handelClick
    }
  }
})
</script>
