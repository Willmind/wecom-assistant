import ApiSelect from './src/ApiSelect.vue'

export default ApiSelect
