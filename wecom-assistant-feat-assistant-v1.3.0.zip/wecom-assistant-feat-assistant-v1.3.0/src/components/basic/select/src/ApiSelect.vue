<template>
  <a-select
    v-model:value="state"
    v-bind="$attrs"
    :loading="getLoading"
    :showSearch="isOpenSearch"
    :filter-option="remoteSearch ? false : getFilterOption"
    :not-found-content="getNotFoundContent"
    @change="onChange"
    @search="debounceSearch"
    @dropdownVisibleChange="handleFetch"
  >
    <template v-for="item in Object.keys($slots).filter((key) => key !== 'option')" #[item]="data">
      <slot :name="item" v-bind="data || {}"></slot>
    </template>
    <a-select-option v-for="item in getOptions" :key="getOptKey(item)" :value="getOptVal(item)">
      <template v-if="!$slots.option"> {{ item.label }}</template>
      <slot name="option" :item="item" v-else></slot>
    </a-select-option>
    <template #notFoundContent>
      <div class="api-select--empty">
        <Loading v-if="getLoading" :loading="getLoading" size="small" />
        <div v-else-if="errorState" class="error-state">
          <a-button type="link" block icon="sync" size="small" @click="fetch()">重新加载</a-button>
        </div>
        <a-empty
          v-else-if="getOptions.length === 0"
          class="ant-empty-small"
          :description="notFoundContent"
          :image="emptyImage"
        />
      </div>
    </template>
  </a-select>
</template>
<script>
import {
  cloneDeep,
  debounce,
  get,
  isEqual,
  isFunction,
  isObject,
  isPlainObject,
  omit,
  remove,
  uniqBy
} from 'lodash-es'
import { Empty } from 'ant-design-vue'
import { watch, watchEffect, ref, unref, computed } from 'vue'

const DEFAULT_FIELDS = { label: 'label', value: 'value', disabled: 'disabled', key: 'key' }

export default defineComponent({
  name: 'ApiSelect',
  inheritAttrs: false,
  props: {
    value: {
      type: [Number, String, Array, Object],
      default: undefined
    },
    options: {
      type: [Object, Array],
      default: () => []
    },
    // 接口
    api: Function,
    // 初始化参数 或者 搜索时候传入的参数
    params: {
      type: [Object, Function],
      default: () => ({})
    },
    // 响应数据的字段名
    resultField: {
      type: String,
      default: 'data'
    },
    // 替换 options 中 label,value,key,disabled 字段为 options 中对应的字段
    replaceFields: Object,
    // 是否立即触发请求
    immediate: Boolean,
    // 是否开启接口搜索
    remoteSearch: Boolean,
    // 防抖时间
    debounceWait: {
      type: Number,
      default: 300
    },
    // 手动控制加载时机,如果有params参数并且发生改变则不受影响
    manual: Boolean,
    notFoundContent: {
      type: String,
      default: '暂无数据'
    },
    // item 唯一key
    rowKey: {
      type: String
    },
    filterOption: [Boolean, Function],
    // 限制最大选择条目(mode:multiple 才生效)
    limitCount: Number,
    // Boolean 是否再没有匹配到option 自动清除搜索框的内容，String: force 强制清空数据
    autoClearMismatchValue: [Boolean, String],
    // 接口返回数据格式是否字典类型 比如：{ jianzhikeji: '简知科技有限公司', jianzhiweike: '简直微课' }
    isDict: Boolean,
    // 自定义转换数据格式
    transformDataFunc: Function
  },
  emits: ['change', 'update:value', 'option-change'],
  setup(props, { emit, listeners: $listeners }) {
    const attrs = useAttrs()
    const loading = ref(false)
    const isFirstLoad = ref(true)
    const selectOptions = ref([])
    const originOptions = ref([])
    const selectState = ref(props.value)
    const changeExtraData = ref(null)
    const cahceSelectedOptions = ref([])
    let errorState = ref(false)

    const debounceSearch = debounce(handleSearch, props.debounceWait)

    const isAsyncApi = computed(() => props.api && isFunction(props.api))

    const getBindProps = computed(() => {
      return {
        ...unref(attrs),
        ...props
      }
    })

    const state = computed({
      get() {
        return unref(selectState)
      },
      set(val) {
        if (!isEqual(val, unref(selectState))) {
          selectState.value = val
          nextTick(() => {
            emit('update:value', val, unref(changeExtraData), getSelectedOriginOption(val))
            emit('change', val, unref(changeExtraData), getSelectedOriginOption(val))
          })
        }
      }
    })

    const getTransferOptions = computed(() => {
      let options = unref(isAsyncApi) ? unref(selectOptions) : props.options
      if (Array.isArray(options)) {
        return options
      } else if (isPlainObject(options)) {
        let dataList = []
        // 字典类型
        if (props.isDict) {
          Object.keys(options).forEach((key) => {
            dataList.push({ label: options[key], value: key, key })
          })
          return dataList
        }
        let values = Object.values(options)
        let [first] = values
        if (first !== undefined && !isObject(first)) {
          return [options]
        }
        return values
      }
      return options || []
    })

    const getReplaceFields = computed(() => {
      return Object.assign({}, DEFAULT_FIELDS, props.replaceFields || { key: props.rowKey })
    })

    const getOptions = computed(() => {
      let { label, value, disabled, key } = unref(getReplaceFields)
      let dataOptions = isFunction(props.transformDataFunc)
        ? props.transformDataFunc(selectOptions)
        : unref(getTransferOptions)
      if (key === undefined && !props.rowKey) {
        console.warn('Suggest to specify `rowKey` prop to prevent key error')
      }
      return dataOptions.reduce((data, next) => {
        data.push({
          ...omit(next, [label, value]),
          key: next[key || props.rowKey],
          label: next[label],
          value: next[value],
          disabled: next[disabled] || false
        })
        return data
      }, [])
    })

    const getLoading = computed(() => unref(attrs).loading || unref(loading))

    const getNotFoundContent = computed(() => {
      return unref(isOpenSearch) ? (unref(getLoading) ? undefined : null) : undefined
    })

    // 是否开启搜索
    const isOpenSearch = computed(() => {
      return !!unref(getBindProps).showSearch || !!unref(getBindProps)['show-search'] || props.remoteSearch
    })

    // api 获取数据
    async function fetch(params = {}, prevent = true) {
      if (unref(isAsyncApi)) {
        const request = props.api
        try {
          if (prevent && unref(loading)) return

          selectOptions.value = []
          loading.value = true
          let data = isFunction(props.params) ? props.params() : props.params
          const res = await request({ ...(data || {}), ...params })
          if (Array.isArray(res)) {
            selectOptions.value = res || []
          } else {
            selectOptions.value = get(res, props.resultField) || []
          }
          originOptions.value = cloneDeep(unref(selectOptions))
          loading.value = false
          errorState.value = false
          flushMismatchValue()
          emitOptionChange()
        } catch (error) {
          state.value = undefined
          loading.value = false
          errorState.value = true
        } finally {
          isFirstLoad.value = false
        }
      }
    }

    function handleFetch(visible) {
      if (props.manual) return
      if (visible) {
        if (!props.immediate && !unref(props.remoteSearch) && unref(isFirstLoad)) {
          fetch()
        }
      }
    }

    function flushMismatchValue() {
      if (props.autoClearMismatchValue) {
        if (props.autoClearMismatchValue === 'force') {
          state.value = undefined
          return
        }
        const selectItem = getSelectedOriginOption(unref(state))
        state.value = !selectItem || !selectItem?.length ? undefined : state.value
      }
    }

    function getSelectedOriginOption(val) {
      let selectItem = val ? (Array.isArray(val) ? val : [val]) : []
      setSelectedCacheOption(selectItem)
      return attrs.mode !== 'multiple' ? unref(cahceSelectedOptions)?.[0] : unref(cahceSelectedOptions)
    }

    function setSelectedCacheOption(values = []) {
      let { key, value } = unref(getReplaceFields)
      let attr = props.rowKey ?? value ?? key
      let filterOptions = unref(originOptions).filter((item) => values.includes(getOptVal(item)))
      unref(cahceSelectedOptions).push(...filterOptions)
      // 过滤重复
      cahceSelectedOptions.value = uniqBy(unref(cahceSelectedOptions), attr)
      // 删除没选中的option
      remove(unref(cahceSelectedOptions), (item) => {
        return !values.includes(item[attr])
      })
    }

    watch(
      () => props.value,
      (val) => {
        state.value = val
      }
    )

    watchEffect(() => {
      props.immediate && unref(isFirstLoad) && fetch()
    })

    watch(
      () => (isFunction(props.params) ? props.params() : props.params),
      (news, old) => {
        // 这里需要判断值是否真正被改变了
        if (!isEqual(news, old)) {
          console.log('=======watch params=============>>', news)
          flushMismatchValue()
          unref(isFirstLoad) ? props.manual && fetch() : fetch()
        }
      },
      {
        deep: true
      }
    )

    watch(
      () => unref(getOptions),
      () => {
        emitOptionChange()
      }
    )

    const onChange = (value, vnodes) => {
      if (unref(getBindProps)?.mode === 'multiple' && Array.isArray(value)) {
        let length = value.length
        // 限制选择的条目
        if (length > +props.limitCount) {
          let delIdx = length - 2
          state.value.splice(delIdx, 1)
          vnodes.splice(delIdx, 1)
          changeExtraData.value = vnodes
          return
        }
      }
      changeExtraData.value = vnodes
    }

    // 接口搜索
    function handleSearch(value) {
      props.remoteSearch && fetch(isFunction(props?.params) ? props?.params(value) : {}, false)
    }

    function getOptKey(item) {
      let { value, key } = unref(getReplaceFields)
      return item.key ?? item.value ?? item[key] ?? item[value]
    }

    function getOptVal(item) {
      let { value, key } = unref(getReplaceFields)
      return item.value ?? item[value] ?? item[key]
    }

    function emitOptionChange() {
      emit('option-change', unref(getOptions))
    }

    const getFilterOption = (value, option) => {
      return props.filterOption === true
        ? getMatchOptions(value, option)
        : isFunction(props?.filterOption)
        ? props.filterOption(value, option)
        : false
    }

    const getMatchOptions = (value, option) => {
      let vnodes = option.children(value)
      const textNode = findNode(
        vnodes,
        (node) => node.type.toString() === 'Symbol(Text)' || typeof node?.children === 'string'
      )
      return textNode ? textNode.children?.toLowerCase()?.indexOf(value.toLowerCase()) > -1 : false
    }

    const listenersEvent = computed(() => {
      // 防止重复触发事件
      const $$listeners = cloneDeep($listeners)
      if (!$$listeners) return

      Reflect.deleteProperty($$listeners, 'change')
      Reflect.deleteProperty($$listeners, 'search')
      Reflect.deleteProperty($$listeners, 'dropdownVisibleChange')
      return $$listeners
    })

    function findNode(tree, func, config = { children: 'children' }) {
      const { children } = config
      const list = [...tree]
      for (const node of list) {
        if (typeof func === 'function' && func(node)) return node
        node[children] && Array.isArray(node[children]) && list.push(...node[children])
      }
      return null
    }

    return {
      state,
      getOptKey,
      getOptVal,
      errorState,
      getLoading,
      getOptions,
      getBindProps,
      isOpenSearch,
      listenersEvent,
      getNotFoundContent,
      emptyImage: Empty.PRESENTED_IMAGE_SIMPLE,

      fetch,
      onChange,
      handleFetch,
      debounceSearch,
      getFilterOption
    }
  }
})
</script>
<style lang="less">
.api-select--empty {
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 30px 0;
  .error-state {
    text-align: center;
  }
}
</style>
