<template>
  <div class="base-pagination jz-flex jz-flex-1">
    <div class="jz-flex jz-flex-rl jz-flex-cc">
      <slot name="btn"></slot>
    </div>
    <div class="jz-flex jz-flex-1 jz-flex-rr jz-flex-cc">
      <a-pagination v-bind="getProps" @showSizeChange="change" @change="change" />
    </div>
    <slot name="extra"></slot>
  </div>
</template>

<script>
import { unref } from 'vue'

export default defineComponent({
  name: 'BasicPagination',
  inheritAttrs: false,
  props: {
    current: {
      type: Number,
      default: 1
    },
    total: {
      type: Number,
      default: 0
    },
    pageSize: {
      type: Number,
      default: 10
    },
    disabled: {
      type: Boolean,
      default: false
    },
    showSizeChanger: {
      type: Boolean,
      default: true
    },
    showQuickJumper: {
      type: Boolean,
      default: false
    },
    showTotal: Function,
    params: {
      type: [Object, Function],
      default: () => ({})
    }
  },
  emits: ['change'],
  setup(props, { emit }) {
    // 去重style
    const attrs = useAttrs()
    const getProps = computed(() => {
      return {
        ...unref(attrs),
        ...unref(props),
        ...unref(props.params)
      }
    })

    // 切换页码
    const change = (current, pageSize) => {
      emit('change', unref({ current, pageSize }))
    }

    return {
      getProps,
      change
    }
  }
})
</script>

<style lang="less" scoped>
.base-pagination {
  height: 100%;
  width: 100%;
  align-items: center;
}
:deep(.ant-pagination-item) {
  border: none;
}
:deep(.ant-pagination-prev .ant-pagination-item-link) {
  border: none;
}
:deep(.ant-pagination-next .ant-pagination-item-link) {
  border: none;
}
:deep(.ant-pagination-item-active) {
  background: @primary-color;
  border-radius: 6px;
}
:deep(.ant-pagination-item-active a) {
  color: #fff;
}
</style>
