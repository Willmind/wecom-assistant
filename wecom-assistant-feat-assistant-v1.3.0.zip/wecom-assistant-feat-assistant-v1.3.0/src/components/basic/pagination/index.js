import BasicPagination from './src/BasicPagination.vue'

export default BasicPagination
