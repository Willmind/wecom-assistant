<template>
  <svg
    :class="['svg-icon', $attrs.class]"
    :style="{
      width: iconSize + 'px',
      height: iconSize + 'px',
      outline: 'none'
    }"
    aria-hidden="true"
  >
    <use :xlink:href="'#icon-' + iconName" :fill="color" />
  </svg>
</template>

<script name="SvgIcon">
export default defineComponent({
  props: {
    iconName: {
      type: String,
      required: true
    },
    color: {
      type: String,
      default: ''
    },
    iconSize: {
      type: [Number, String],
      default: 16
    }
  }
})
</script>

<style lang="less" scope>
.svg-icon {
  fill: currentColor;
  vertical-align: middle;
}
</style>
