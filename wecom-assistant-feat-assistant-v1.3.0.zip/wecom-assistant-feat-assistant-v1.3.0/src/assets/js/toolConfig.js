const componentList = import.meta.globEager('../../components/apps/**')
let componentObj = new Object()
Object.keys(componentList).forEach((key) => {
  if (/\.vue$/.test(key)) {
    let keyArray = key.split('/')
    let name = 'jz' + keyArray[keyArray.length - 1].split('.')[0]
    componentObj[name] = componentList[key].default
  }
})
// 功能区组件配置数据
const list = [
  {
    id: 1,
    name: '功能',
    isHide: true,
    isStick: true, // 是否置顶
    icon: 'nav_jz_apply',
    desc: '自动接受新客户添加申请',
    comName: componentObj.jzHome
  },
  {
    id: 2,
    isStick: false,
    name: '接受新客户',
    icon: 'nav_jz_user',
    desc: '自动接受新客户添加申请',
    comName: componentObj.jzCustomer
  },
  {
    id: 3,
    isStick: false,
    name: '新客户运营',
    icon: 'nav_jz_new_user',
    desc: '自动备注、拉群、发欢迎语',
    comName: componentObj.jzCustomerOperation
  },

  {
    id: 4,
    isStick: false,
    name: '客户管理',
    icon: 'nav_jz_user_manage',
    desc: '统一管理客户信息',
    comName: componentObj.jzCustomerManagement
  },
  {
    id: 5,
    isStick: false,
    name: '素材库',
    icon: 'nav_jz_material',
    desc: '素材管理、团队素材共享',
    comName: componentObj.jzCustomerMaterialIndex
  },
  {
    id: 6,
    isStick: false,
    name: 'SOP',
    icon: 'nav_jz_sop',
    desc: '运营标准自动化流程',
    comName: componentObj.jzSopManagement
  },
  {
    id: 7,
    isStick: false,
    name: '关键词拉群',
    icon: 'nav_jz_kewword',
    desc: '触发关键词将客户拉到指定的群里',
    comName: componentObj.jzKeyWordPullGroupIndex
  },
  {
    id: 8,
    isStick: false,
    name: '入群欢迎语',
    icon: 'nav_jz_welcome',
    desc: '新人入群可以自动发送欢迎语',
    comName: componentObj.jzGroupWelcomeIndex
  }
]

export default list
