import { join } from 'path'
import { app } from 'electron'
// 打包后路径访问
export const LOAD_URL = {
  darwin: 'file://' + join(join(__dirname, '../..'), 'index.html') + '#/',
  win32: join(join(__dirname, '../..'), 'index.html') + '#/'
}[process.platform]
// 应用logo
export const APP_ICON = join(__dirname, app.isPackaged ? '../..' : '../../../public', 'logo.ico')
// 运行时访问路径
export const DEV_LOAD_URL = `http://${process.env['VITE_DEV_SERVER_HOST']}:${process.env['VITE_DEV_SERVER_PORT']}/#/`
// perload
export const PERLOAD = join(__dirname, '../preload/index.js')
