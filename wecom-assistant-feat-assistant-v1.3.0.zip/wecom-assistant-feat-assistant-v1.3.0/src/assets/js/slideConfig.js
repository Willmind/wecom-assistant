const list = [
  {
    name: 'apply',
    title: '功能',
    auth: true,
    path: '/home/apply',
    icon: 'ic_apply',
    selectIcon: 'ic_apply_select'
  },
  {
    name: 'chat',
    title: '聊天',
    auth: true,
    path: '/home/chat',
    icon: 'ic_chat',
    selectIcon: 'ic_chat_select'
  },
  {
    name: 'msg',
    title: '消息',
    auth: true,
    path: '/home/msg',
    icon: 'ic_remind',
    selectIcon: 'ic_remind_select'
  }
]
export default list
