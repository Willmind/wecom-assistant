// 计算程序缩放比例
import { screen } from 'electron'
import { toFixed } from './utils'

/**
 * @params width 设计图的宽度
 * @params height 设计图的高度
 * @reutrns object
 */
export default (width = 1200, height = 700) => {
  let { height: clientHeight } = screen.getAllDisplays()[0].workAreaSize
  clientHeight = clientHeight
  let scale = clientHeight < height ? Number(toFixed(clientHeight / height)) : 1
  let scaleWidth = Math.floor(width * scale)
  let scaleHeight = Math.floor(height * scale)
  return {
    width: scaleWidth,
    height: scaleHeight
  }
}
