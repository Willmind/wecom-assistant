// 不建议在渲染层直接调用remote模块，remote模块有很大的性能问题，因此通过事件通知在主进程进行调用主进程方法
import { ipcMain, shell } from 'electron'
// 登录窗口
import createLoginWindow from '../../windows/LoginWindow'
// 主页窗口
import createIndexWindow from '../../windows/IndexWindow'
import electronStorage from 'electron-localstorage'
export default function () {
  // 打包登录窗口
  ipcMain.on('show-login', () => {
    electronStorage.removeItem('token')
    createLoginWindow()
    // 销毁已存在的窗口进程
    global.indexWindow && global.indexWindow.destroy()
  })

  // 打开主页窗口
  ipcMain.on('show-home', (event, token) => {
    !electronStorage.getItem('token') && createIndexWindow()
    electronStorage.setItem('token', token)
    // 销毁已存在的窗口进程
    global.loginWindow && global.loginWindow.destroy()
  })

  // 最小化
  ipcMain.on('minimize', (event, windowsName) => {
    global[windowsName].minimize()
  })

  // 最大化
  ipcMain.on('maximize', (event, windowsName) => {
    const win = global[windowsName]
    if (win.isMaximized()) {
      global[windowsName].unmaximize()
    } else {
      global[windowsName].maximize()
    }
  })

  // 打开外部浏览器
  ipcMain.on('openExternal', (event, url) => {
    shell.openExternal(url)
  })

  // 退出程序
  ipcMain.on('exit', (event, windowsName) => {
    const win = global[windowsName]
    win && win.hide()
  })
}
