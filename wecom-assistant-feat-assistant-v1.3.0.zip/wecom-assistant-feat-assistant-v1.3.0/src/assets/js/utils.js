/**
 * 保留小数
 * @param target 原数字/文本
 * @param decimal 几位小数
 * @returns string
 */
export const toFixed = (target = 0, decimal = 2) => {
  target = Number.isNaN(Number(target)) ? 0 : Number(target)
  return target.toFixed(decimal)
}

/**
 * 判断当前设备是否是Mac
 * @returns boolean
 */
export const isMac = () => {
  return navigator.userAgentData.platform.toLowerCase().includes('mac')
}

// ras加密
export const rsaEncrypt = (str) => {
  const rsa = new RSAKey()
  rsa.setPublic(window.$JZPA, '10001')
  return rsa.encrypt(str)
}

// 手机正则
export const phoneReg = /^1[3-9]\d{9}$/

// 邮箱正则
export const emailReg = /^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/

// 密码校验
export const passwordReg = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?~&_-])[A-Za-z\d$@$!%*#?~&_-]{8,}$/

// 补0
export const addZero = (num) => {
  var num = parseInt(num)
  return num < 10 ? 0 + '' + num : num
}

/**
 * 获取一个范围区间的随机数
 * @param max 最大值
 * @param min 最小值
 * @returns number
 */
export const getRandomNum = (max = 100, min = 0, isInteger = false) => {
  const result = Math.random() * (max - min) + min
  return isInteger ? Math.floor(result) + '' : result
}

/**
 * 判断时间是否在指定范围内
 * @param startT 开始范围 如：2022-10-20
 * @param endT 最后范围 如：2022-10-30
 * @param tagTime 当前时间 如： 2022-10-15
 * @returns blooan false 不在范围内 true 在范围内
 */

export const isTimeFrame = (startT, endT, tagTime) => {
  let dateBegin = new Date(startT)

  let dateEnd = new Date(endT)

  let dateNow = new Date(tagTime)

  let beginDiff = dateNow.getTime() - dateBegin.getTime()

  let beginDayDiff = Math.floor(beginDiff / (24 * 3600 * 1000))

  let endDiff = dateEnd.getTime() - dateNow.getTime()

  let endDayDiff = Math.floor(endDiff / (24 * 3600 * 1000))
  return endDayDiff < 0 || beginDayDiff < 0 ? false : true
}
