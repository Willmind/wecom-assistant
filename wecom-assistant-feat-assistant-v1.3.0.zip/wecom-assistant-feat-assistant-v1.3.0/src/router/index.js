import { createRouter, createWebHashHistory } from 'vue-router'
// 为了配合electron打包访问路径目前只兼容hash模式：createWebHashHistory
const router = createRouter({
  history: createWebHashHistory(),
  routes: [
    {
      path: '/home',
      name: 'home',
      component: () => import(/* webpackChunkName: "index" */ '../views/home/Index.vue'),
      children: [
        {
          path: '/home',
          redirect: '/home/apply'
        },
        {
          name: 'apply',
          path: '/home/apply',
          component: () => import(/* webpackChunkName: "indexApply" */ '../views/home/Apply.vue')
        },
        {
          name: 'chat',
          path: '/home/chat',
          component: () => import(/* webpackChunkName: "chat" */ '../views/home/Chat.vue')
        },
        {
          name: 'msg',
          path: '/home/msg',
          component: () => import(/* webpackChunkName: "chat" */ '../views/home/Message.vue')
        }
      ]
    },

    {
      path: '/login',
      name: 'login',
      component: () => import(/* webpackChunkName: "login" */ '../views/user/Login.vue')
    }
  ]
})

export default router
