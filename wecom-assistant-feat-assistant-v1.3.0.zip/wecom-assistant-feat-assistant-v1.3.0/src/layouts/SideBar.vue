<template>
  <div class="slide jz-flex jz-flex-col">
    <div class="user-logo jz-pointer" @click.stop.prevent="handleShowAccount(true)">
      <img :src="store.getUserInfo.avatar" alt="" />
      <svg-icon icon-name="ic_wx_logo" />
    </div>
    <ul class="menu jz-flex-1">
      <li
        :class="state.routeName === item.name && 'current'"
        class="jz-flex jz-flex-col jz-flex-center jz-pointer"
        v-for="(item, index) in state.list"
        :key="index"
        @click="goPage(item)"
      >
        <svg-icon :icon-name="item.selectIcon" v-if="state.routeName === item.name" />
        <svg-icon :icon-name="item.icon" v-else />
        <span>{{ item.title }}</span>
      </li>
    </ul>
    <div
      class="user-set jz-flex jz-flex-center"
      @click.stop.prevent="handleShowUBox(true)"
      :class="!store.getUserInfo.admin_id && 'not-user'"
    >
      <span v-if="store.getUserInfo.name && store.getUserInfo.admin_id">
        {{ store.getUserInfo.name.substr(0, 1).toLocaleUpperCase() }}
      </span>
      <span v-else>无</span>
    </div>
    <!--个人信息-->
    <div
      v-if="showUbox"
      id="userInfo"
      class="user-info jz-flex jz-flex-ct jz-flex-col"
      @click.stop.prevent
      v-click-outside="hideOutside"
    >
      <div class="user-info-card jz-flex jz-flex-center">
        <span class="name jz-flex jz-flex-center" :class="!store.getUserInfo.admin_id && 'not-user'">
          {{ store.getUserInfo.admin_id ? store.getUserInfo.name.substr(0, 1).toLocaleUpperCase() : '无' }}
        </span>
        <div
          class="card-info jz-flex-1 jz-flex jz-flex-col"
          v-if="store.getUserInfo.admin_id && store.getPermCodeList.length"
        >
          <span class="lineClamp1">{{ store.getPermCodeList[0].name }}</span>
          <span class="lineClamp1">{{ store.getPermCodeList[0].corp_name }}</span>
        </div>
        <div class="card-info jz-flex-1 jz-flex jz-flex-col" v-else>
          <span class="lineClamp2">当前企微未创建客服号，请联系上级创建使用。</span>
        </div>
      </div>
      <div class="user-tip jz-pointer" @click="openInfoDrawer" v-if="store.getUserInfo.admin_id">
        <span>账号信息</span>
      </div>
      <div class="user-tip jz-pointer" @click="logout">
        <span>退出登录</span>
      </div>
      <div class="user-version">{{ version }}</div>
    </div>
    <ul
      v-if="showAccountbox"
      class="account-info jz-flex jz-flex-ct jz-flex-col"
      @click.stop.prevent
      v-click-outside="hideOutside"
    >
      <li class="jz-flex jz-flex-center jz-pointer" v-for="(item, index) in state.accountList" :key="index">
        <img :src="item.avatar" alt="" />
        <div class="jz-flex jz-flex-1 jz-flex-col">
          <span class="lineClamp1">{{ item.name }}</span>
          <span class="lineClamp1">{{ item.corp_name }}</span>
        </div>
        <i class="check jz-flex jz-flex-center" v-if="state.accountIndex === index">
          <svg-icon icon-name="apply_select" style="width: 28px; height: 28px" />
        </i>
      </li>
    </ul>
    <basic-drawer
      width="560px"
      showFooter
      title="账户设置"
      okText="确认修改"
      :register="registerDrawer"
      :showCancelBtn="false"
      @visibleChange="drawerChange"
      @ok="handleOkCallback"
    >
      <userInfo ref="userBox" />
    </basic-drawer>
  </div>
</template>

<script setup>
import { getApiversion } from '@/api/common'
import { apiLoginOut, apiAccountList } from 'api/login'
import { useDrawer } from '@/components/basic/drawer'
import useMessage from '@/composables/web/useMessage'
import list from '@/assets/js/slideConfig'
import pinia from '@/store/index'
import { userStore } from '@/store/modules/user'
const { createMessage, createConfirm } = useMessage()
const store = userStore(pinia)
const [registerDrawer, { openDrawer }] = useDrawer()
const { ipcRenderer } = require('electron')
const router = useRouter()
const version = ref('')
const state = reactive({
  list: list,
  accountList: [],
  accountIndex: 0,
  routeName: ref(router.currentRoute.value.name)
})
const userBox = ref(null)
const showUbox = ref(false)
const showAccountbox = ref(false)

onMounted(() => {
  getAccountList()
})

// ============================methods

const getAccountList = async () => {
  let { code, data } = await apiAccountList()
  if (code === 1000) {
    state.accountList = data
    let _id = $storeLocal.get('jzUserInfo')?.account_id
    state.accountIndex = data.findIndex((i) => i.id === _id)
    store.setPermCodeList([...data])
    data[0].account_id = data[0].id
    store.setUserInfo({ ...data[0] })
    getApiversion().then((res) => {
      if (res.code === 1000) {
        version.value = '企微版本V' + res.data.version
      }
    })
  }
}

// 展示抽屉
const drawerChange = (val) => {
  val && userBox.value.getUserInfo()
}

// 跳转页面
const goPage = (item) => {
  if (item.name === 'apply') return
  createMessage.info('功能升级中，敬请期待！')
  // state.routeName = item.name
  // router.push(item.path)
}

const openInfoDrawer = () => {
  hideOutside()
  openDrawer()
}

// 隐藏个人信息
const hideOutside = () => {
  showUbox.value = false
  showAccountbox.value = false
}

// 展示多个企业号
const handleShowUBox = (show) => {
  showUbox.value = show
  showAccountbox.value = false
}

// 展示个人信息
const handleShowAccount = (show = false) => {
  showAccountbox.value = show
  showUbox.value = false
}

// 退出登录
const logout = async () => {
  hideOutside()
  createConfirm({
    cancelText: '取消',
    okText: '退出登录',
    content: '确定要退出简知企微助手吗？',
    async onOk() {
      // 调用清空接口
      try {
        await apiLoginOut()
      } finally {
        store.resetState()
        $storeLocal.remove('jzUserInfo')
        $storeLocal.remove('token')
        ipcRenderer.send('show-login')
      }
    }
  })
}

// 提交信息回调
const handleOkCallback = () => {
  console.log('提交')
  userBox.value.onsubmit(true)
}

watch(
  () => store.getToken,
  () => {
    getAccountList()
  }
)
</script>

<style lang="less" scoped>
.slide {
  width: 80px;
  min-width: 80px;
  overflow: auto;
  padding-top: 24px;
  background: #e7e9eb;
  align-items: center;
  .user-logo {
    width: 44px;
    height: 44px;
    position: relative;
    img {
      width: 100%;
      height: 100%;
      display: block;
      border-radius: 8px;
    }
    .svg-icon {
      position: absolute;
      bottom: -5px;
      right: -6px;
      width: 22px !important;
      height: 22px !important;
    }
  }
  .menu {
    overflow: hidden;
    margin-top: 28px;
    li {
      width: 64px;
      height: 68px;
      font-size: 12px;
      margin-bottom: 8px;
      cursor: pointer;
      color: rgba(0, 0, 0, 0.4);
      .svg-icon {
        width: 24px !important;
        height: 24px !important;
      }
      &.current {
        border-radius: 10px;
        color: #3165f5;
        background: linear-gradient(0deg, rgba(49, 101, 245, 0.2), rgba(49, 101, 245, 0.2)), #ffffff;
      }
    }
  }
  .user-set {
    width: 46px;
    height: 45px;
    color: #fff;
    background: linear-gradient(294deg, #06d1d1 0%, #3ce5e5 100%);
    border-radius: 100px 100px 100px 100px;
    margin-bottom: 32px;
    position: relative;
    overflow: hidden;
    cursor: pointer;
  }
  .not-user {
    background: #bfbfbf;
  }
  .user-info {
    position: fixed;
    width: 264px;
    height: 194px;
    left: 75px;
    bottom: 32px;
    border-radius: 6px;
    animation: ani-move 0.2s linear;
    background: #ffffff;
    z-index: 100000;
    box-shadow: 0px 0px 24px 0px rgba(0, 0, 0, 0.1);
    &-card {
      width: 100%;
      margin-bottom: 17px;
      padding: 16px 16px 0;
      .name {
        width: 36px;
        height: 36px;
        color: #fff;
        background: linear-gradient(294deg, #06d1d1 0%, #3ce5e5 100%);
        border-radius: 50%;
      }
      .not-user {
        background: #bfbfbf;
      }
      .card-info {
        margin-left: 12px;
        span:first-child {
          color: #000;
          font-size: 14px;
        }
        span:last-child {
          color: #999;
          font-size: 12px;
        }
      }
    }
    .user-tip {
      color: #000;
      height: 40px;
      line-height: 40px;
      width: 100%;
      padding: 0 8px;
      span {
        display: block;
        padding: 0 8px;
        &:hover {
          border-radius: 4px;
          background: RGBA(245, 245, 245, 1);
        }
      }
    }
    .user-version {
      margin-top: 10px;
      font-size: 12px;
      color: #999;
      padding: 0 16px;
    }
  }
  .account-info {
    position: fixed;
    width: 264px;
    max-height: 178px;
    left: 75px;
    top: 80px;
    border-radius: 5px;
    padding: 8px;
    z-index: 100000;
    overflow-y: auto;
    animation: ani-move 0.2s linear;
    background: #ffffff;
    box-shadow: 0px 0px 24px 0px rgba(0, 0, 0, 0.1);
    li {
      width: 100%;
      height: 54px;
      padding: 9px 8px;
      background: #ffffff;
      &:hover {
        background: RGBA(245, 245, 245, 1);
        border-radius: 4px;
      }
      img {
        width: 36px;
        height: 36px;
        border-radius: 6px;
        margin-right: 8px;
      }
      div {
        width: 100%;
        span:first-child {
          font-size: 14px;
        }
        span:last-child {
          color: #999;
          font-size: 12px;
        }
      }
      .check {
        width: 28px;
        height: 28px;
        span {
          color: rgba(49, 101, 245, 1);
        }
      }
    }
  }
}
@keyframes ani-move {
  from {
    transform: translateX(-20px);
  }
  50% {
    transform: translateX(-10px);
  }
  to {
    transform: translateX(0px);
  }
}
</style>
