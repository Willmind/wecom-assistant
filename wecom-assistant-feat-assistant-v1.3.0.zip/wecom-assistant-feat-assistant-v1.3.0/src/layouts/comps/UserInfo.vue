<template>
  <div class="user-box jz-flex jz-flex-col">
    <p class="tit">个人账号信息</p>
    <div class="info jz-flex-1 jz-flex jz-flex-col">
      <div class="item jz-flex">
        <span class="label">用户名</span>
        <div class="jz-flex-1 jz-input">{{ state.from.username }}</div>
      </div>
      <div class="item jz-flex">
        <span class="label">姓名</span>
        <div class="jz-flex-1 jz-input">{{ state.from.name }}</div>
      </div>
      <div class="item jz-flex jz-flex-center">
        <span class="label">昵称</span>
        <div class="jz-flex-1 jz-input">
          <a-input v-model:value="state.from.nickname" placeholder="请输入昵称" />
        </div>
      </div>
      <div class="item jz-flex jz-flex-center" style="margin-top: 10px">
        <span class="label"></span>
        <div class="jz-flex-1 jz-input color-gray">简小知老师的昵称会在 App 上对外显示给学员</div>
      </div>
      <div class="item jz-flex">
        <span class="label">手机号</span>
        <div class="jz-flex-1 jz-input">{{ state.from.mobile }}</div>
      </div>
      <div class="item jz-flex">
        <span class="label">邮箱</span>
        <div class="jz-flex-1 jz-input">{{ state.from.email }}</div>
      </div>
      <div class="item jz-flex">
        <span class="label">职位</span>
        <div class="jz-flex-1 jz-input">{{ state.from.job }}</div>
      </div>
      <div class="item jz-flex">
        <span class="label">所属部门</span>
        <div class="jz-flex-1 jz-input">{{ state.from.position }}</div>
      </div>
      <div class="line"></div>
      <p class="tit" style="padding-left: 29px">修改密码</p>
      <div class="item jz-flex jz-flex-center">
        <span class="label">旧密码</span>
        <div class="jz-flex-1 jz-input">
          <a-input v-model:value="state.from.old_password" placeholder="请输入旧密码" />
        </div>
      </div>
      <div class="item jz-flex jz-flex-center">
        <span class="label">新密码</span>
        <div class="jz-flex-1 jz-input">
          <a-input v-model:value="state.from.password" placeholder="请输入新密码" />
        </div>
      </div>
      <div class="item jz-flex jz-flex-center">
        <span class="label"></span>
        <div class="jz-flex-1 jz-input color-gray">密码不少于 8位，且包含数字、字母和特殊字符。</div>
      </div>
      <div class="item jz-flex jz-flex-center">
        <span class="label">确认密码</span>
        <div class="jz-flex-1 jz-input">
          <a-input v-model:value="state.from.repeat_password" placeholder="请再次输入密码" />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { apiGetUserInfo, apiEditUserInfo } from 'api/login'
import { rsaEncrypt, passwordReg } from '@/assets/js/utils'
import useMessage from '@/composables/web/useMessage'
const { createMessage } = useMessage()
// 表单信息
const state = reactive({
  from: {
    name: '',
    account: '',
    job: '',
    mobile: '',
    email: '',
    position: '',
    username: '',
    nickname: '',
    old_password: '',
    password: '',
    repeat_password: ''
  }
})
const isLock = ref(false)
const getUserInfo = async () => {
  let { code, data } = await apiGetUserInfo()
  if (code === 1000) {
    state.from = { ...state.from, ...data }
  }
}

const updateNickname = (nickname) => {
  if (isLock.value) return
  isLock.value = true
  apiEditUserInfo({
    nickname
  })
    .then((res) => {
      if (res.code === 1000) {
        createMessage.success('修改昵称成功')
      }
    })
    .finally(() => {
      isLock.value = false
    })
}

// 提交
const onsubmit = () => {
  let _str = '密码不少于8位，且包含数字、字母和特殊字符'
  let { old_password, password, repeat_password, nickname, username } = state.from
  if (nickname && !old_password && !repeat_password && !password) {
    updateNickname(nickname)
    // 只改昵称
    return
  }
  if (!old_password || !repeat_password || !password) {
    createMessage.warn('请填写相关信息')
    return
  }
  if (!passwordReg.test(old_password)) {
    createMessage.warn(_str)
    return
  }
  if (!passwordReg.test(password)) {
    createMessage.warn(_str)
    return
  }
  if (!passwordReg.test(repeat_password)) {
    createMessage.warn(_str)
    return
  }
  if (repeat_password !== password) {
    createMessage.warn('新密码与确认密码不一致')
    return
  }
  if (isLock.value) return
  isLock.value = true
  apiEditUserInfo({
    nickname,
    password: rsaEncrypt(password),
    old_password: rsaEncrypt(old_password),
    repeat_password: rsaEncrypt(repeat_password),
    account: rsaEncrypt(username)
  })
    .then((res) => {
      if (res.code === 1000) {
        createMessage.success('修改成功')
        emptyData()
      }
    })
    .finally(() => {
      isLock.value = false
    })
}

const emptyData = () => {
  state.from.old_password = ''
  state.from.password = ''
  state.from.repeat_password = ''
}

// 暴露方法
defineExpose({
  onsubmit,
  getUserInfo
})
</script>

<style lang="less" scoped>
.user-box {
  padding: 0px 32px 20px;
  width: 100%;
  height: 100%;
  overflow-y: auto;
  .tit {
    margin-bottom: 8px;
    color: @font-minor-color;
  }
  .color-gray {
    color: @font-minor-color;
  }
  .info {
    .item {
      width: 100%;
      margin-top: 16px;
      .label {
        font-weight: 600;
        margin-right: 32px;
        width: 84px;
        text-align: right;
        color: @font-body-color;
      }
    }
    .line {
      margin: 48px 0;
      width: 100%;
      height: 1px;
      background-color: #eee;
      transform: scaleY(0.6);
    }
  }
}
:deep(.ant-input) {
  width: 220px;
  border-radius: 6px;
}
</style>
