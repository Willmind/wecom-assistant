<template>
  <div id="header" class="jz-flex jz-flex-center">
    <div class="logo no-drag jz-flex jz-flex-center">
      <svg-icon icon-name="m_logo" />
    </div>
    <div class="jz-flex-1 jz-flex tab" ref="tab">
      <ul class="tab-ul jz-flex" v-if="showTab" ref="tabUl">
        <li
          class="no-drag"
          v-for="(item, index) in list"
          :key="index"
          :style="tabWidth"
          @click="changeTab(item, true)"
          :class="[currentId === item.id && 'current', preIndex === index && 'not-before']"
        >
          <svg-icon :icon-name="item.icon" />
          <div class="lineClamp1 name jz-flex-1">{{ item.name }}</div>
          <svg-icon
            icon-name="close"
            class="close"
            @click.stop.prevent="changeTab(item, false)"
            v-if="index && !item.isStick"
          />
          <img src="@/assets/imgs/angle_left.png" class="angle_left" v-if="index && currentId === item.id" />
          <img
            src="@/assets/imgs/angle_right.png"
            class="angle_right"
            v-if="index && currentId === item.id"
          />
          <img
            src="@/assets/imgs/angle_1_right.png"
            class="angle_right"
            v-if="!index && currentId === item.id"
          />
        </li>
      </ul>
    </div>
    <div class="handle no-drag jz-flex jz-flex-rr">
      <svg-icon icon-name="hide" @click="handleWindow(1)" class="m-r-17" />
      <svg-icon :icon-name="!isMax ? 'w_max' : 'w_min'" @click="handleWindow(2)" class="m-r-17" />
      <svg-icon icon-name="close" @click="handleWindow(3)" class="m-r-17" />
    </div>
  </div>
</template>

<script setup>
import { applyStore } from '@/store/modules/apply'
import { computed, ref } from 'vue'
const store = applyStore()
const router = useRouter()
const { list, currentId } = storeToRefs(store)
const { ipcRenderer } = require('electron')
const isMax = ref(false)
const tab = ref(null)
const tabUl = ref(null)
const tabWidth = ref('width:192px')
const showTab = ref(true)
onMounted(() => {
  // 监听窗口变化
  handleTabWidth()
  ipcRenderer.on('windows-change', (event, val) => {
    isMax.value = val
    handleTabWidth()
  })
})
// 处理窗口隐藏缩小
const handleWindow = (index) => {
  let name = 'indexWindow'
  index === 1 && ipcRenderer.send('minimize', name)
  index === 2 && ipcRenderer.send('maximize', name)
  index === 3 && ipcRenderer.send('exit', name)
}

// 切换tab
const changeTab = (item, isAdd = true) => {
  store.changeComponent(item, isAdd)
}

// 动态计算导航宽度
const handleTabWidth = () => {
  nextTick(() => {
    let _ulWidth = tab.value.clientWidth
    let _len = tabUl.value.children.length
    tabWidth.value = _len * 192 >= _ulWidth ? `width:${Number(_ulWidth / _len)}px` : 'width:192px'
  })
}

watch(
  () => router.currentRoute.value.name,
  (name) => {
    showTab.value = name === 'apply' ? true : false
  },
  { immediate: true }
)

store.$subscribe(() => {
  nextTick(() => {
    handleTabWidth()
  })
})

// 查找上一个导航id
const preIndex = computed(() => {
  let _preIndex = list.value.findIndex((i) => i.id === currentId.value) - 1
  return ~_preIndex ? _preIndex : ''
})
</script>

<style lang="less" scoped>
#header {
  width: 100%;
  height: 56px;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  cursor: pointer;
  -webkit-app-region: drag;
  background: #e7e9eb;
  .logo {
    width: 80px;
    height: 100%;
    -webkit-app-region: drag;
    .svg-icon {
      margin-top: 5px;
      width: 48px !important;
      height: 48px !important;
    }
  }
  .tab {
    height: 100%;
    width: 100%;
    padding-top: 16px;
    box-sizing: border-box;
    overflow: hidden;
    background: #e7e9eb;
    ul {
      background: rgba(245, 245, 245, 0.5);
      border-top-right-radius: 12px;
      border-top-left-radius: 12px;

      li {
        width: 200px;
        height: 40px;
        display: flex;
        cursor: pointer;
        align-items: center;
        position: relative;
        padding: 0 18px;
        font-weight: 600;
        font-size: 12px;
        font-family: 'PingFang SC';
        font-style: normal;
        .name {
          width: 100%;
          flex: 1;
        }
        .svg-icon {
          margin-right: 8px;
          width: 16px !important;
          height: 16px !important;
          color: #fff !important;
        }
        .close {
          opacity: 0;
          width: 16px !important;
          height: 16px !important;
        }
        &:hover {
          background: rgba(245, 245, 245, 0.8);
          border-top-right-radius: 12px;
          border-top-left-radius: 12px;
          .close {
            opacity: 1;
          }
          &::before {
            width: 1px !important;
            height: 16px;
            left: -0.5%;
            z-index: 10;
            position: absolute;
            background: #f5f5f5;
          }
        }

        &::before {
          content: '';
          width: 1px;
          height: 16px;
          position: absolute;
          right: 0;
          top: 50%;
          margin-top: -8px;
          background: #dbdcdd;
        }
        &.not-before::before {
          width: 0px;
        }
        &.current {
          // background: rgba(245, 245, 245, 1);
          background: #fff;
          border-top-right-radius: 12px !important;
          border-top-left-radius: 12px !important;

          &:hover {
            border-top-right-radius: 0px;
            border-top-left-radius: 0px;
          }
          &::before {
            content: '';
            width: 0px;
          }
          .jl {
            position: absolute;
            right: 0;
            bottom: 0;
            width: 9px;
            height: 9px;
            background: url(~@/assets/imgs/subtract@2x.png) no-repeat;
            background-size: 100% 100%;
          }
        }
        &:first-child.current {
          background: rgba(245, 245, 245, 1);
        }
        &:last-child {
          border-top-right-radius: 12px;
          &::before {
            width: 0px;
          }
        }
        .angle_left {
          position: absolute;
          left: -8px;
          width: 9px;
          height: 9px;
          bottom: 0;
        }
        .angle_right {
          position: absolute;
          right: -8px;
          width: 9px;
          height: 9px;
          bottom: 0;
        }
      }
    }
  }
  .handle {
    width: 135px;
    height: 100%;
    padding-top: 10px;
    .svg-icon {
      width: 20px !important;
      height: 20px !important;
    }
  }
  .m-r-17 {
    margin-right: 17px;
  }
}
</style>
