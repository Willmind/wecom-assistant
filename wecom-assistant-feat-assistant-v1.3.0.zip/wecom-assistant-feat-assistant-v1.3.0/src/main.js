import { createApp } from 'vue'
import App from './App.vue'
import store from 'store'
import dayjs from 'dayjs'
import '@/utils/common/init'
import 'ant-design-vue/dist/antd.less' // UI库
import '@/styles/main.less' //  自定义样式
import 'virtual:svg-icons-register'
// 需要全局引入再添加
import svgIcon from '@/components/SvgIcon/index.vue' // 全局svg图标组件
// 路由
import router from './router/index'
// 状态管理
import { createPinia } from 'pinia'
// 指令
import globalDirective from './directives'
import basicComponentsInstalls from './components/basic/index'

// 滚动加载
import infiniteScroll from 'vue3-infinite-scroll-better'

window.$storeLocal = store
const pinia = createPinia()
const app = createApp(App)
// 统一安装basic组件/插件
basicComponentsInstalls(app)
globalDirective(app)
app.use(pinia)
app.use(router)
app.use(infiniteScroll)
app.component('SvgIcon', svgIcon)

app.mount('#app').$nextTick(() => {
  postMessage({ payload: 'removeLoading' }, '*')
})
app.config.globalProperties.$dayjs = dayjs
process.env['ELECTRON_DISABLE_SECURITY_WARNINGS'] = 'true'
