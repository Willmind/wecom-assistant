import HttpRequest from './http'
import { isDevMode, getEnvConfig } from '../common/env'
import { extend } from 'lodash-es'

const DEFAULT_TIMEOUT = 1000 * 60
const { VITE_APP_REMOTE } = getEnvConfig()

// 默认参数
const getDefaultConfig = () => ({
  showErr: true,
  useToken: true,
  showLoading: false,
  crossDomain: true,
  useCancel: true,
  withCredentials: true,
  timeout: DEFAULT_TIMEOUT,
  baseURL: isDevMode() ? `/api` : VITE_APP_REMOTE
})

export function createHttp(options) {
  return new HttpRequest(extend({}, getDefaultConfig(), options))
}

export default createHttp()
