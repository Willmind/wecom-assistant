import store from 'store'
import { isString } from 'lodash-es'
import { ipcRenderer } from 'electron'
import { RequestEnum, ResultEnum } from '@/enums/httpEnum'
import useMessage from '@/composables/web/useMessage'
import { useLoading } from '@/components/basic/loading'
const { createMessage, createErrorModal, createWarningModal } = useMessage()

const showError = createMessage.error

const { open: openLoading, close: closeLoading } = useLoading()

// 所有参数去除左右空格
const trimParams = (sendParams) => {
  if (sendParams && Object.keys(sendParams).length) {
    for (const i in sendParams) {
      if (sendParams[i] === undefined || sendParams[i] === null) {
        delete sendParams[i]
      }
    }
  }
}

function showErrorMsg(msg, showErrMode) {
  if (showErrMode === 'modal') {
    createErrorModal(msg)
  } else {
    showError(msg)
  }
}

/**
 * 统一处理request, response
 */
export const interceptors = {
  requestInterceptor(config) {
    const params = config.params || {}
    const data = config.data || false
    if (config.method?.toUpperCase() === RequestEnum.POST) {
      if (!isString(params)) {
        if (
          (Reflect.has(config, 'data') && config.data && !!Object.keys(data).length) ||
          data instanceof FormData
        ) {
          config.params = params
          config.data = data
        } else {
          // 非GET请求如果没有提供data，则将params视为data
          config.data = params
          config.params = undefined
        }
      }
    }

    !!config.showLoading && openLoading(true)

    // 使用token
    if (config.useToken) {
      config.headers['Authorization'] = store.get('token')
    }
    trimParams(params)
    trimParams(data)

    return config
  },
  /**
   * 响应错误处理(非200)
   * @param {Axiox.create} axios
   * @param {mixin} err
   * @returns
   */
  responseCatchInterceptor(options, error) {
    const { showErr, showErrMode } = options
    const { response, code, message } = error || {}
    const msg = response?.data?.msg ?? ''
    const err = error?.toString?.() ?? ''
    let errMessage = ''
    closeLoading(true)
    try {
      if (code === 'ECONNABORTED' && message.indexOf('timeout') !== -1) {
        errMessage = '接口请求超时，请稍后再试'
      }
      if (err?.includes('Network Error')) {
        errMessage = '网络异常，请检查您的网络'
      }

      if (errMessage) {
        showErr && showErrorMsg(errMessage, showErrMode)
        return Promise.reject(error)
      }
    } catch (error) {
      throw new Error(error)
    }
    // 响应状态处理
    interceptors.checkResStatus(err?.response?.status, msg, showErr, showErrMode)
    return Promise.reject(err)
  },
  transformBodyHooks(res, options) {
    closeLoading(true)
    const { code, data = {}, msg } = res.data
    // 数据二次处理后抛出
    const result = { code, data: data === null ? {} : data, msg }
    if (Reflect.has(res.data, 'code')) {
      let isSuccess = +code === ResultEnum.SUCCESS
      switch (+code) {
        // token 过期
        case ResultEnum.TOKEN_EXPIRE:
          result.msg = '登录已过期，请重新登录'
          store.remove('jzUserInfo')
          store.remove('token')
          // 跳登录
          !store.get('isLoginOut') && interceptors.loginOut()
          store.set('isLoginOut', true)
          break
        case ResultEnum.ACCOUNT_DISABLED:
          options.showErr = false
          // 账号被盗用
          createWarningModal({ title: '账号被禁用', content: result.msg })
          break
        case ResultEnum.ACCOUNT_LOSE:
          options.showErr = false
          // 账号不可用
          createWarningModal({ title: '账号不可用', content: result.msg })
          break
      }
      options.showErr && !isSuccess && showErrorMsg(result.msg)
      return {
        result,
        isSuccess
      }
    }

    return {
      isSuccess: true,
      result
    }
  },
  // 响应status 处理
  checkResStatus(status, msg, showErr, errorMode) {
    let errorMsg = msg
    switch (status) {
      case 500:
        errorMsg = '服务器异常，请稍后再试'
        break
      case ResultEnum.TOKEN_EXPIRE:
        // token 过期/没权限
        break
    }
    showErr && showErrorMsg(errorMsg, errorMode)
  },

  // 退出登录
  async loginOut() {
    setTimeout(() => {
      if (process.env.disableApp) return
      ipcRenderer.send('show-login')
    }, 800)
  }
}
