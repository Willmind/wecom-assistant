let abortControllerMap = new Map()
const getCancelKey = (config) => [config.url, config.method].join('&')

/**
 * 取消请求
 */
class HttpCancel {
  addController(config) {
    const controller = new AbortController()
    let key = config?.cancelKey || getCancelKey(config)
    config.signal = controller.signal
    abortControllerMap.set(key, controller)
  }

  cancelController(config) {
    let cancelKey = config?.cancelKey || getCancelKey(config)
    if (abortControllerMap.has(cancelKey)) {
      let controller = abortControllerMap.get(cancelKey)
      controller?.abort()
      abortControllerMap.delete(cancelKey)
    }
  }

  cancelAll() {
    abortControllerMap.forEach((controller) => {
      controller.abort()
    })
    this.clear()
  }

  clear() {
    abortControllerMap.clear()
  }

  reset() {
    abortControllerMap = new Map()
  }
}

// 创建单例Cancaler
HttpCancel.create = (() => {
  let canceler = null
  return () => {
    canceler = canceler || new HttpCancel()
    return canceler
  }
})()

export default HttpCancel
