/**
 * request 请求工具
 */
import axios from 'axios'
import HttpCancel from './httpCancel'
import { ContentTypeEnum, RequestEnum } from '@/enums/httpEnum'
import { interceptors } from './httpInterceptors'
import { cloneDeep, isString } from 'lodash-es'
import pinia from '@/store/index'
import { userStore } from '@/store/modules/user'
const store = userStore(pinia)
class HttpRequest {
  constructor(options = {}) {
    this.options = options
    this.initial()
  }

  initial() {
    this.axiosInstance = axios.create(this.options)
    this._setupInterceptor()
  }

  _setupInterceptor() {
    const { requestInterceptor, responseCatchInterceptor } = interceptors
    let canceler = null

    // ---- 请求拦截 ----
    this.axiosInstance.interceptors.request.use(
      (config) => {
        let { useCancel, cancelKey } = config
        useCancel = useCancel || cancelKey || false
        if (useCancel) {
          canceler = HttpRequest.getCanceler()
          canceler?.addController(config)
        }
        return requestInterceptor(config, this.options)
      },
      (err) => {
        return Promise.reject(err)
      }
    )

    // ---- 响应拦截 ----
    this.axiosInstance.interceptors.response.use(
      (res) => {
        if (res?.config?.headers?.Authorization && res?.headers?.authorization) {
          if (res?.config?.headers?.Authorization !== res?.headers?.authorization) {
            console.log('更新了token')
            $storeLocal.set('token', res?.headers?.authorization)
            store.setToken(res?.headers?.authorization)
          }
        }
        try {
          // 取消重复请求
          res && canceler?.cancelController(res.config)
        } catch (error) {
          console.log('abort request：', error)
        }
        return res
      },
      (err) => responseCatchInterceptor(this.options, err)
    )
  }

  /**
   * 统一上传接口
   * @param {*} params
   * @param {} config
   * @returns
   */
  uploadFile(config = {}, params = {}) {
    const formData = new window.FormData()
    const customFilename = params.name || 'file'

    if (params.filename) {
      formData.append(customFilename, params.file, params.filename)
    } else {
      formData.append(customFilename, params.file)
    }

    if (params?.data) {
      Object.keys(params.data).forEach((key) => {
        const value = params.data[key]
        if (Array.isArray(value)) {
          value.forEach((item) => {
            formData.append(`${key}[]`, item)
          })
          return
        }
        formData.append(key, params.data[key])
      })
    }
    return this.request({
      ...config,
      data: formData,
      method: RequestEnum.POST,
      headers: {
        'Content-Type': ContentTypeEnum.FORM_DATA
      }
    })
  }

  /**
   * get 请求
   * @param args  url,params,config
   * @returns
   */
  get(...args) {
    let [arg, config = {}] = args
    if (isString(arg)) {
      config.url = arg
    } else {
      config = arg
    }
    return this.request({ ...config, method: RequestEnum.GET })
  }

  /**
   * post 请求
   * @param  {...any} args
   * @returns
   */
  post(...args) {
    let [arg, data, config = {}] = args
    if (isString(arg)) {
      config.url = arg
      config.data = data
    } else {
      config = arg
    }
    return this.request({ ...config, method: RequestEnum.POST })
  }

  put(...args) {
    let [arg, data, config = {}] = args
    if (isString(arg)) {
      config.url = arg
      config.data = data
    } else {
      config = arg
    }
    return this.request({ ...config, method: RequestEnum.PUT })
  }

  delete(...args) {
    let [arg, config = {}] = args
    if (isString(arg)) {
      config.url = arg
    } else {
      config = arg
    }
    return this.request({ ...config, method: RequestEnum.DELETE })
  }

  request(options = {}) {
    let conf = cloneDeep(options)
    conf = Object.assign({}, this.options, conf)

    const { transformBodyHooks } = interceptors

    return new Promise((resolve, reject) => {
      this.axiosInstance
        .request(conf)
        .then((res) => {
          const { isSuccess, result } = transformBodyHooks(res, conf)
          try {
            isSuccess ? resolve(result) : reject(result)
          } catch (error) {
            reject(err)
          }
        })
        .catch((err) => {
          reject(err)
        })
    })
  }

  static getCanceler() {
    return HttpCancel.create()
  }

  /**
   * 取消请求
   * @param {String} cancelKey
   * @description
   * 通常手动取消请求场景 只适用于外部传入cancelKey 来取消请求
   */
  static cancelAxios(cancelKey) {
    if (!cancelKey) {
      return console.warn('cancelKey is not exists')
    }
    let canceler = HttpRequest.getCanceler()
    canceler?.cancelController({ cancelKey })
  }
}

export default HttpRequest
