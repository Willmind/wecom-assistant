export default [
  {
    id: '',
    name: '笑呵呵',
    url: 'https://emoji-uc.akamaized.net/orig/4f/070ccbbb696c2975bb0da521c2ffc5.png',
    code: 'U+1F600',
    html: '😀',
    class: '',
    text: '[笑呵呵]'
  },
  {
    id: '',
    name: '眨眼',
    url: 'https://emoji-uc.akamaized.net/orig/55/ceb7ce388c8b07ffa8495e9d8905bd.png',
    code: 'U+1F609',
    html: '😉',
    class: '',
    text: '[眨眼]'
  },
  {
    id: '',
    name: '笑嘻嘻',
    url: 'https://emoji-uc.akamaized.net/orig/1a/b6f1ba1292b0d88ce13878dc78baa0.png',
    code: 'U+1F601',
    html: '😁',
    class: '',
    text: '[笑嘻嘻]'
  },
  {
    id: '',
    name: '闭眼睛的笑脸',
    url: 'https://emoji-uc.akamaized.net/orig/12/137f64131d69f3d605077ae5feb986.png',
    code: 'U+1F606',
    html: '😆',
    class: '',
    text: '[闭眼睛的笑脸]'
  },
  {
    id: '',
    name: '苦笑',
    url: 'https://emoji-uc.akamaized.net/orig/54/18c893827bb3ca5e17b44ee148ffc8.png',
    code: 'U+1F605',
    html: '😅',
    class: '',
    text: '[苦笑]'
  },
  {
    id: '',
    name: '喜极而泣',
    url: 'https://emoji-uc.akamaized.net/orig/aa/65a9b30bfe34eb40cece7066291bbe.png',
    code: 'U+1F602',
    html: '😂',
    class: '',
    text: '[喜极而泣]'
  },
  {
    id: '',
    name: '在地板上滚动笑',
    url: 'https://emoji-uc.akamaized.net/orig/a8/3037f0389addfe580a391599c85f1b.png',
    code: 'U+1F923',
    html: '🤣',
    class: '',
    text: '[在地板上滚动笑]'
  },
  {
    id: '',
    name: '满脸堆笑',
    url: 'https://emoji-uc.akamaized.net/orig/70/10eac5870a09f5c95a95fd4da4afd5.png',
    code: 'U+1F60A',
    html: '😊',
    class: '',
    text: '[满脸堆笑]'
  },
  {
    id: '',
    name: '微笑',
    url: 'https://emoji-uc.akamaized.net/orig/b5/6dc44b1241307361edda859bf10548.png',
    code: 'U+1F642',
    html: '🙂',
    class: '',
    text: '[微笑]'
  },
  {
    id: '',
    name: '哈哈大笑',
    url: 'https://emoji-uc.akamaized.net/orig/b7/9f24464ae2bd8fcc5fda823f02469d.png',
    code: 'U+1F604',
    html: '😄',
    class: '',
    text: '[哈哈大笑]'
  },
  {
    id: '',
    name: '倒头',
    url: 'https://emoji-uc.akamaized.net/orig/c1/9a4b5216a288ab979ac04d08856edd.png',
    code: 'U+1F643',
    html: '🙃',
    class: '',
    text: '[倒头]'
  },
  {
    id: '',
    name: '天真',
    url: 'https://emoji-uc.akamaized.net/orig/2e/2f586e290f73437afa0bdd6067368b.png',
    code: 'U+1F607',
    html: '😇',
    class: '',
    text: '[天真]'
  },
  {
    id: '',
    name: '笑盈盈',
    url: 'https://emoji-uc.akamaized.net/orig/80/4139df052e66413dcb2ef0b64d1bdd.png',
    code: 'U+1F603',
    html: '😃',
    class: '',
    text: '[笑盈盈]'
  },
  {
    id: '',
    name: '热吻',
    url: 'https://emoji-uc.akamaized.net/orig/66/402e690a1bd54de348fee6a291fcc5.png',
    code: 'U+1F61A',
    html: '😚',
    class: '',
    text: '[热吻]'
  },
  {
    id: '',
    name: '与微笑的眼睛和三心脏的微笑的面孔',
    url: 'https://emoji-uc.akamaized.net/orig/d3/ab99ac0c75836dedbd9f16fe7112cb.png',
    code: 'U+1F970',
    html: '🥰',
    class: '',
    text: '[与微笑的眼睛和三心脏的微笑的面孔]'
  },
  {
    id: '',
    name: '亲吻',
    url: 'https://emoji-uc.akamaized.net/orig/d5/5fc76a82f547cacd45de26482a33f2.png',
    code: 'U+1F619',
    html: '😙',
    class: '',
    text: '[亲吻]'
  },
  {
    id: '',
    name: '空心笑脸',
    url: 'https://emoji-uc.akamaized.net/orig/f5/99821614795914dc5dcdfc6c4cd78b.png',
    code: 'U+263A',
    html: '☺',
    class: '',
    text: '[空心笑脸]'
  },
  {
    id: '',
    name: '心花怒放',
    url: 'https://emoji-uc.akamaized.net/orig/27/f2d2f72f7e79b792bcb6f1019253ba.png',
    code: 'U+1F60D',
    html: '😍',
    class: '',
    text: '[心花怒放]'
  },
  {
    id: '',
    name: '接吻',
    url: 'https://emoji-uc.akamaized.net/orig/2e/43282373ab27334d859067cfef34b8.png',
    code: 'U+1F617',
    html: '😗',
    class: '',
    text: '[接吻]'
  },
  {
    id: '',
    name: '帶淚的笑臉',
    url: 'https://emoji-uc.akamaized.net/orig/e0/04dd02211c85a91dab2431e712dc06.png',
    code: 'U+1F972',
    html: '🥲',
    class: '',
    text: '[帶淚的笑臉]'
  },
  {
    id: '',
    name: '飞吻',
    url: 'https://emoji-uc.akamaized.net/orig/9d/645adeb0650aca796491495ac92526.png',
    code: 'U+1F618',
    html: '😘',
    class: '',
    text: '[飞吻]'
  },
  {
    id: '',
    name: '咧嘴笑的脸与星眼睛',
    url: 'https://emoji-uc.akamaized.net/orig/12/891eca811472a9587327f1ea5696fd.png',
    code: 'U+1F929',
    html: '🤩',
    class: '',
    text: '[咧嘴笑的脸与星眼睛]'
  },
  {
    id: '',
    name: '好吃',
    url: 'https://emoji-uc.akamaized.net/orig/03/c7ad15c0277cdcdc7b7fa6dd26d595.png',
    code: 'U+1F60B',
    html: '😋',
    class: '',
    text: '[好吃]'
  },
  {
    id: '',
    name: '调皮',
    url: 'https://emoji-uc.akamaized.net/orig/02/4cde61f75c6c5d8bc9032325318aa1.png',
    code: 'U+1F61B',
    html: '😛',
    class: '',
    text: '[调皮]'
  },
  {
    id: '',
    name: '俏皮',
    url: 'https://emoji-uc.akamaized.net/orig/66/cc21fea16b311a56205b92420167b3.png',
    code: 'U+1F61C',
    html: '😜',
    class: '',
    text: '[俏皮]'
  },
  {
    id: '',
    name: '咧着嘴笑的脸庞，一只大眼睛和一只小眼睛',
    url: 'https://emoji-uc.akamaized.net/orig/61/2838d779cf19f763baf9a4168de979.png',
    code: 'U+1F92A',
    html: '🤪',
    class: '',
    text: '[咧着嘴笑的脸庞，一只大眼睛和一只小眼睛]'
  },
  {
    id: '',
    name: '卖萌',
    url: 'https://emoji-uc.akamaized.net/orig/9a/7222cefcd61dcb8cf682884c0a0abf.png',
    code: 'U+1F61D',
    html: '😝',
    class: '',
    text: '[卖萌]'
  },
  {
    id: '',
    name: '钱面孔',
    url: 'https://emoji-uc.akamaized.net/orig/f9/e9f230626d937205ea41b347e9f695.png',
    code: 'U+1F911',
    html: '🤑',
    class: '',
    text: '[钱面孔]'
  },
  {
    id: '',
    name: '思维面孔',
    url: 'https://emoji-uc.akamaized.net/orig/c1/3016642e7e6e385ae4e6e8241f3c05.png',
    code: 'U+1F914',
    html: '🤔',
    class: '',
    text: '[思维面孔]'
  },
  {
    id: '',
    name: '咧嘴笑的脸与星眼睛',
    url: 'https://emoji-uc.akamaized.net/orig/12/891eca811472a9587327f1ea5696fd.png',
    code: 'U+1F929',
    html: '🤩',
    class: '',
    text: '[咧嘴笑的脸与星眼睛]'
  },
  {
    name: '与微笑的眼睛和手覆盖物嘴的微笑的面孔',
    url: 'https://emoji-uc.akamaized.net/orig/64/b8623935853db1dda72d72c29e7a3e.png',
    code: 'U+1F92D',
    html: '🤭',
    class: '',
    text: '[与微笑的眼睛和手覆盖物嘴的微笑的面孔]'
  },
  {
    id: '',
    name: '拥抱面孔',
    url: 'https://emoji-uc.akamaized.net/orig/98/f2180902deba2f6fa719fb382963e0.png',
    code: 'U+1F917',
    html: '🤗',
    class: '',
    text: '[拥抱面孔]'
  },
  {
    id: '',
    name: '面部用手指覆盖闭合的嘴唇',
    url: 'https://emoji-uc.akamaized.net/orig/61/96a137fc540fe6fc5ffd0db9c666e0.png',
    code: 'U+1F92B',
    html: '🤫',
    class: '',
    text: '[面部用手指覆盖闭合的嘴唇]'
  },
  {
    id: '',
    name: '不动声色',
    url: 'https://emoji-uc.akamaized.net/orig/a3/00e6617ec150df17efa0114e6f712c.png',
    code: 'U+1F610',
    html: '😐',
    class: '',
    text: '[不动声色]'
  },
  {
    id: '',
    name: '安静',
    url: 'https://emoji-uc.akamaized.net/orig/40/733c0381c99d2ee6085a46bee632b7.png',
    code: 'U+1F636',
    html: '😶',
    class: '',
    text: '[安静]'
  },
  {
    id: '',
    name: '面对一个眉毛提出',
    url: 'https://emoji-uc.akamaized.net/orig/fd/a0b2c9197561ef2153acb6b62d8370.png',
    code: 'U+1F928',
    html: '🤨',
    class: '',
    text: '[面对一个眉毛提出]'
  },
  {
    id: '',
    name: '鬼脸',
    url: 'https://emoji-uc.akamaized.net/orig/cb/6e968aa5a3c1fbe07a98200304d9d3.png',
    code: 'U+1F62C',
    html: '😬',
    class: '',
    text: '[鬼脸]'
  },
  {
    id: '',
    name: '傻笑',
    url: 'https://emoji-uc.akamaized.net/orig/62/aa3eae88224d55aa05addc4482a6ef.png',
    code: 'U+1F60F',
    html: '😏',
    class: '',
    text: '[傻笑]'
  },
  {
    id: '',
    name: '面无表情',
    url: 'https://emoji-uc.akamaized.net/orig/5b/7e2006ca0062abd30e6d79d6ea22d6.png',
    code: 'U+1F611',
    html: '😑',
    class: '',
    text: '[面无表情]'
  },
  {
    id: '',
    name: '不爽',
    url: 'https://emoji-uc.akamaized.net/orig/87/fa78e4e020b49288d17e27b968e227.png',
    code: 'U+1F612',
    html: '😒',
    class: '',
    text: '[不爽]'
  },
  {
    id: '',
    name: '翻白眼',
    url: 'https://emoji-uc.akamaized.net/orig/4e/574dc039fae5674e0b75dd593e4d15.png',
    code: 'U+1F644',
    html: '🙄',
    class: '',
    text: '[翻白眼]'
  },
  {
    id: '',
    name: '拉链口面',
    url: 'https://emoji-uc.akamaized.net/orig/9f/7f14a9183d4ad0ab3220f854f4f4a6.png',
    code: 'U+1F910',
    html: '🤐',
    class: '',
    text: '[拉链口面]'
  },
  {
    id: '',
    name: '躺着的脸',
    url: 'https://emoji-uc.akamaized.net/orig/ae/1862b2534f3bf915303fe6078bc065.png',
    code: 'U+1F925',
    html: '🤥',
    class: '',
    text: '[躺着的脸]'
  },
  {
    id: '',
    name: '如释重负',
    url: 'https://emoji-uc.akamaized.net/orig/31/6f371576a6f84100ae7461b49d7a8f.png',
    code: 'U+1F60C',
    html: '😌',
    class: '',
    text: '[如释重负]'
  },
  {
    id: '',
    name: '沮丧',
    url: 'https://emoji-uc.akamaized.net/orig/23/b32a817b32b98daae7f429ac0d7fb9.png',
    code: 'U+1F614',
    html: '😔',
    class: '',
    text: '[沮丧]'
  },
  {
    id: '',
    name: '困',
    url: 'https://emoji-uc.akamaized.net/orig/e7/4c441b464e715e1bdf03aacfe399bb.png',
    code: 'U+1F62A',
    html: '😪',
    class: '',
    text: '[困]'
  },
  {
    id: '',
    name: '睡觉',
    url: 'https://emoji-uc.akamaized.net/orig/29/e0fa548dd0621dcbc5787abf0a3c62.png',
    code: 'U+1F634',
    html: '😴',
    class: '',
    text: '[睡觉]'
  },
  {
    id: '',
    name: '流口水',
    url: 'https://emoji-uc.akamaized.net/orig/36/56123190e0a6f156ebcd647b0ccd62.png',
    code: 'U+1F924',
    html: '🤤',
    class: '',
    text: '[流口水]'
  },
  {
    id: '',
    name: '冻脸',
    url: 'https://emoji-uc.akamaized.net/orig/86/6aafe03fd8371d2eb1dbb4cd068ed0.png',
    code: 'U+1F976',
    html: '🥶',
    class: '',
    text: '[冻脸]'
  },
  {
    id: '',
    name: '打喷嚏的脸',
    url: 'https://emoji-uc.akamaized.net/orig/94/f210045070364ed27db1bafa01d6d3.png',
    code: 'U+1F927',
    html: '🤧',
    class: '',
    text: '[打喷嚏的脸]'
  },
  {
    id: '',
    name: '生病',
    url: 'https://emoji-uc.akamaized.net/orig/09/07397d3c2d7fae37fc64652716a71b.png',
    code: 'U+1F637',
    html: '😷',
    class: '',
    text: '[生病]'
  },
  {
    id: '',
    name: '与爆炸的头的震惊面孔',
    url: 'https://emoji-uc.akamaized.net/orig/b6/006751651eeab3a5d8de403cc6bce0.png',
    code: 'U+1F92F',
    html: '🤯',
    class: '',
    text: '[与爆炸的头的震惊面孔]'
  },
  {
    id: '',
    name: '面对不均匀的眼睛和波浪的嘴巴',
    url: 'https://emoji-uc.akamaized.net/orig/09/55b13a1a6afa36ded2f8cba0cb165b.png',
    code: 'U+1F974',
    html: '🥴',
    class: '',
    text: '[面对不均匀的眼睛和波浪的嘴巴]'
  },
  {
    id: '',
    name: '头晕目眩',
    url: 'https://emoji-uc.akamaized.net/orig/cc/9d0f7f886c6d586cd6564a31ebd88e.png',
    code: 'U+1F635',
    html: '😵',
    class: '',
    text: '[头晕目眩]'
  },
  {
    id: '',
    name: '面对温度计',
    url: 'https://emoji-uc.akamaized.net/orig/bc/f1f024cda77326d1332e3b06079db7.png',
    code: 'U+1F912',
    html: '🤒',
    class: '',
    text: '[面对温度计]'
  },
  {
    id: '',
    name: '过热的脸',
    url: 'https://emoji-uc.akamaized.net/orig/2a/47fb4ecc4312057c022e25e7caa230.png',
    code: 'U+1F975',
    html: '🥵',
    class: '',
    text: '[过热的脸]'
  },
  {
    id: '',
    name: '面对张开嘴呕吐',
    url: 'https://emoji-uc.akamaized.net/orig/c9/d9061f1c8706c926104599db35b4ae.png',
    code: 'U+1F92E',
    html: '🤮',
    class: '',
    text: '[面对张开嘴呕吐]'
  },
  {
    id: '',
    name: '面对头绷带',
    url: 'https://emoji-uc.akamaized.net/orig/c0/0aca820c213a4727ba8728155aa26f.png',
    code: 'U+1F915',
    html: '🤕',
    class: '',
    text: '[面对头绷带]'
  },
  {
    id: '',
    name: '恶心的脸',
    url: 'https://emoji-uc.akamaized.net/orig/ec/d72b523ca40f2555ff506f568966f4.png',
    code: 'U+1F922',
    html: '🤢',
    class: '',
    text: '[恶心的脸]'
  },
  {
    id: '',
    name: '變相的臉',
    url: 'https://emoji-uc.akamaized.net/orig/4b/99f044c1e811a54ab73c03052ce9f2.png',
    code: 'U+1F978',
    html: '🥸',
    class: '',
    text: '[變相的臉]'
  },
  {
    id: '',
    name: '面对牛仔帽',
    url: 'https://emoji-uc.akamaized.net/orig/5a/fe6c6ed3869f3eec0812de21f1941f.png',
    code: 'U+1F920',
    html: '🤠',
    class: '',
    text: '[面对牛仔帽]'
  },
  {
    id: '',
    name: '面对党角和党帽子',
    url: 'https://emoji-uc.akamaized.net/orig/9d/06b3d41f3626ac01b0123ed450e97a.png',
    code: 'U+1F973',
    html: '🥳',
    class: '',
    text: '[面对党角和党帽子]'
  },
  {
    id: '',
    name: '书呆子脸',
    url: 'https://emoji-uc.akamaized.net/orig/0c/f0c7fd9dcb878d4ac26424608addd1.png',
    code: 'U+1F913',
    html: '🤓',
    class: '',
    text: '[书呆子脸]'
  },
  {
    id: '',
    name: '酷',
    url: 'https://emoji-uc.akamaized.net/orig/c2/5f0199530ac59c1bcca216cf4453dd.png',
    code: 'U+1F60E',
    html: '😎',
    class: '',
    text: '[酷]'
  },
  {
    id: '',
    name: '面对单片眼镜',
    url: 'https://emoji-uc.akamaized.net/orig/8b/3435d5a5cfc66607847a147d68e565.png',
    code: 'U+1F9D0',
    html: '🧐',
    class: '',
    text: '[面对单片眼镜]'
  },
  {
    id: '',
    name: '迷茫',
    url: 'https://emoji-uc.akamaized.net/orig/71/a782e5bf6ffe9f2927ce1e33083363.png',
    code: 'U+1F615',
    html: '😕',
    class: '',
    text: '[迷茫]'
  },
  {
    id: '',
    name: '困惑',
    url: 'https://emoji-uc.akamaized.net/orig/18/648e884f76d410dad760e9b0523062.png',
    code: 'U+1F616',
    html: '😖',
    class: '',
    text: '[困惑]'
  },
  {
    id: '',
    name: '疼痛',
    url: 'https://emoji-uc.akamaized.net/orig/6f/1b2790979f3d448d1a697769a082c1.png',
    code: 'U+1F627',
    html: '😧',
    class: '',
    text: '[疼痛]'
  },
  {
    id: '',
    name: '面对恳求的眼睛',
    url: 'https://emoji-uc.akamaized.net/orig/65/979b8b29d43a78c60c399ce65a49a4.png',
    code: 'U+1F97A',
    html: '🥺',
    class: '',
    text: '[面对恳求的眼睛]'
  },
  {
    id: '',
    name: '疲勞',
    url: 'https://emoji-uc.akamaized.net/orig/84/47dbb181812c819c08c324d69f29cc.png',
    code: 'U+1F62B',
    html: '😫',
    class: '',
    text: '[疲勞]'
  },
  {
    id: '',
    name: '面對恐懼尖叫',
    url: 'https://emoji-uc.akamaized.net/orig/ea/18952974d24cf08a287a6703b32074.png',
    code: 'U+1F631',
    html: '😱',
    class: '',
    text: '[面對恐懼尖叫]'
  },
  {
    id: '',
    name: '失望',
    url: 'https://emoji-uc.akamaized.net/orig/84/a9483204ff64187bfcf6f9cdfbe216.png',
    code: 'U+1F61E',
    html: '😞',
    class: '',
    text: '[失望]'
  },
  {
    id: '',
    name: '缄默',
    url: 'https://emoji-uc.akamaized.net/orig/4d/dc1f49aa27e396c1d2bca086d3301b.png',
    code: 'U+1F62F',
    html: '😯',
    class: '',
    text: '[缄默]'
  },
  {
    id: '',
    name: '张嘴',
    url: 'https://emoji-uc.akamaized.net/orig/a8/0abb3107eb04c80b0d4d4ba3264d9f.png',
    code: 'U+1F62E',
    html: '😮',
    class: '',
    text: '[张嘴]'
  },
  {
    id: '',
    name: '大声哭',
    url: 'https://emoji-uc.akamaized.net/orig/6b/d4e3b3126e857af94efcfe6a97ac2e.png',
    code: 'U+1F62D',
    html: '😭',
    class: '',
    text: '[大声哭]'
  },
  {
    id: '',
    name: '担心',
    url: 'https://emoji-uc.akamaized.net/orig/4a/044ed98cd064706135ffe9f59002ee.png',
    code: 'U+1F61F',
    html: '😟',
    class: '',
    text: '[担心]'
  },
  {
    id: '',
    name: '冷汗',
    url: 'https://emoji-uc.akamaized.net/orig/85/c6e96ad0ce17594cb32d3a28302fca.png',
    code: 'U+1F613',
    html: '😓',
    class: '',
    text: '[冷汗]'
  },
  {
    id: '',
    name: '厭倦',
    url: 'https://emoji-uc.akamaized.net/orig/88/b64d2609668a41a0b7168196cf574f.png',
    code: 'U+1F629',
    html: '😩',
    class: '',
    text: '[厭倦]'
  },
  {
    id: '',
    name: '哭泣',
    url: 'https://emoji-uc.akamaized.net/orig/ea/5e18a37749cfa889986344a39f54ad.png',
    code: 'U+1F622',
    html: '😢',
    class: '',
    text: '[哭泣]'
  },
  {
    id: '',
    name: '诧异',
    url: 'https://emoji-uc.akamaized.net/orig/7c/8c2eb459807b39cc4170bf10c74bc1.png',
    code: 'U+1F632',
    html: '😲',
    class: '',
    text: '[诧异]'
  },
  {
    id: '',
    name: '恐惧',
    url: 'https://emoji-uc.akamaized.net/orig/30/4b99a9fd45ada85b1b9c9745be50cc.png',
    code: 'U+1F628',
    html: '😨',
    class: '',
    text: '[恐惧]'
  },
  {
    id: '',
    name: '打呵欠的臉',
    url: 'https://emoji-uc.akamaized.net/orig/e9/b1f8728d1d21563db258af3de32bdd.png',
    code: 'U+1F971',
    html: '🥱',
    class: '',
    text: '[打呵欠的臉]'
  },
  {
    id: '',
    name: '通红的脸',
    url: 'https://emoji-uc.akamaized.net/orig/7b/e5a7e335877aa746318f96bcc50455.png',
    code: 'U+1F633',
    html: '😳',
    class: '',
    text: '[通红的脸]'
  },
  {
    id: '',
    name: '微蹙眉',
    url: 'https://emoji-uc.akamaized.net/orig/cb/079e5c09d0921c3c6661692803ee77.png',
    code: 'U+1F641',
    html: '🙁',
    class: '',
    text: '[微蹙眉]'
  },
  {
    id: '',
    name: '松一口气',
    url: 'https://emoji-uc.akamaized.net/orig/06/736c37eae8e71c23bc6cf6156c9eed.png',
    code: 'U+1F625',
    html: '😥',
    class: '',
    text: '[松一口气]'
  },
  {
    id: '',
    name: '决心',
    url: 'https://emoji-uc.akamaized.net/orig/72/dcbb3cf447bf59cf59595d2b361dad.png',
    code: 'U+1F623',
    html: '😣',
    class: '',
    text: '[决心]'
  },
  {
    id: '',
    name: '目瞪口呆',
    url: 'https://emoji-uc.akamaized.net/orig/5b/cb0d3ff3911a0d374302650bbbf571.png',
    code: 'U+1F626',
    html: '😦',
    class: '',
    text: '[目瞪口呆]'
  },
  {
    id: '',
    name: '空心哭脸',
    url: 'https://emoji-uc.akamaized.net/orig/2f/66f8fcd12a1aa5d9bf4121d51c060a.png',
    code: 'U+2639',
    html: '☹',
    class: '',
    text: '[空心哭脸]'
  },
  {
    id: '',
    name: '面對張開嘴和冷汗',
    url: 'https://emoji-uc.akamaized.net/orig/ae/b396eedfbd6abeb07b16ecac73d4dd.png',
    code: 'U+1F630',
    html: '😰',
    class: '',
    text: '[面對張開嘴和冷汗]'
  },
  {
    id: '',
    name: '骷髅和交叉腿骨',
    url: 'https://emoji-uc.akamaized.net/orig/d6/8afe6b0c9f1fd20a34ad76ffbfaff0.png',
    code: 'U+2620',
    html: '☠',
    class: '',
    text: '[骷髅和交叉腿骨]'
  },
  {
    id: '',
    name: '加油',
    url: 'https://emoji-uc.akamaized.net/orig/bf/91212969824c14df4a8d1256da2aa5.png',
    code: 'U+1F624',
    html: '😤',
    class: '',
    text: '[加油]'
  },
  {
    id: '',
    name: '魔鬼',
    url: 'https://emoji-uc.akamaized.net/orig/c2/5e1c1a4dfe039c687f18a38a735bb4.png',
    code: 'U+1F608',
    html: '😈',
    class: '',
    text: '[魔鬼]'
  },
  {
    id: '',
    name: '气到脸都红了',
    url: 'https://emoji-uc.akamaized.net/orig/80/864630847478ce2ab483c21c52d1a2.png',
    code: 'U+1F621',
    html: '😡',
    class: '',
    text: '[气到脸都红了]'
  },
  {
    id: '',
    name: '头骨',
    url: 'https://emoji-uc.akamaized.net/orig/f4/54f581a44e02b9dc62f2c1d862d528.png',
    code: 'U+1F480',
    html: '💀',
    class: '',
    text: '[头骨]'
  },
  {
    id: '',
    name: '恶魔',
    url: 'https://emoji-uc.akamaized.net/orig/bf/235226177c8601f02a65ae4c6985b6.png',
    code: 'U+1F47F',
    html: '👿',
    class: '',
    text: '[恶魔]'
  },
  {
    id: '',
    name: '严肃的面孔与标志覆盖物嘴',
    url: 'https://emoji-uc.akamaized.net/orig/65/edce5189d11a80369a50dfff26246d.png',
    code: 'U+1F92C',
    html: '🤬',
    class: '',
    text: '[严肃的面孔与标志覆盖物嘴]'
  },
  {
    id: '',
    name: '愤怒',
    url: 'https://emoji-uc.akamaized.net/orig/81/1480d67f260d9aa1b88d3c88e17a06.png',
    code: 'U+1F620',
    html: '😠',
    class: '',
    text: '[愤怒]'
  },
  {
    id: '',
    name: '堆便便',
    url: 'https://emoji-uc.akamaized.net/orig/fe/da2cf7320c6aacab49335ec1c339d9.png',
    code: 'U+1F4A9',
    html: '💩',
    class: '',
    text: '[堆便便]'
  },
  {
    id: '',
    name: '小丑脸',
    url: 'https://emoji-uc.akamaized.net/orig/96/a32575058d2a78fd964b00194893ac.png',
    code: 'U+1F921',
    html: '🤡',
    class: '',
    text: '[小丑脸]'
  },
  {
    id: '',
    name: '机器人脸',
    url: 'https://emoji-uc.akamaized.net/orig/6f/628e8f46f911a327e7a3304e7b0571.png',
    code: 'U+1F916',
    html: '🤖',
    class: '',
    text: '[机器人脸]'
  },
  {
    id: '',
    name: '外星人外星人',
    url: 'https://emoji-uc.akamaized.net/orig/c1/2bafcfad730289b11a92a27c416528.png',
    code: 'U+1F47D',
    html: '👽',
    class: '',
    text: '[外星人外星人]'
  },
  {
    id: '',
    name: '异形怪物',
    url: 'https://emoji-uc.akamaized.net/orig/b4/17cc3c2d7b3956e2f63fc91c1102cb.png',
    code: 'U+1F47E',
    html: '👾',
    class: '',
    text: '[异形怪物]'
  },
  {
    id: '',
    name: '鬼',
    url: 'https://emoji-uc.akamaized.net/orig/6c/40816b798e789ee1661f7fe128c710.png',
    code: 'U+1F47B',
    html: '👻',
    class: '',
    text: '[鬼]'
  },
  {
    id: '',
    name: '日本地精',
    url: 'https://emoji-uc.akamaized.net/orig/3b/8f2af65ce58b178bd155771d01a9d2.png',
    code: 'U+1F47A',
    html: '👺',
    class: '',
    text: '[日本地精]'
  },
  {
    id: '',
    name: '日本食人魔',
    url: 'https://emoji-uc.akamaized.net/orig/2e/13612ae3ab4aa1a498011b9ae37cc9.png',
    code: 'U+1F479',
    html: '👹',
    class: '',
    text: '[日本食人魔]'
  },
  {
    id: '',
    name: '疲累的猫',
    url: 'https://emoji-uc.akamaized.net/orig/8d/18d3de471568af02b56f06e0b7a443.png',
    code: 'U+1F640',
    html: '🙀',
    class: '',
    text: '[疲累的猫]'
  },
  {
    id: '',
    name: '亲吻的猫',
    url: 'https://emoji-uc.akamaized.net/orig/3e/4fa20b1401ab59deef4f493f63f421.png',
    code: 'U+1F63D',
    html: '😽',
    class: '',
    text: '[亲吻的猫]'
  },
  {
    id: '',
    name: '笑嘻嘻的貓',
    url: 'https://emoji-uc.akamaized.net/orig/09/1a2bcc79fb4630dac83a2ba29b321f.png',
    code: 'U+1F638',
    html: '😸',
    class: '',
    text: '[笑嘻嘻的貓]'
  },
  {
    id: '',
    name: '哭泣的貓',
    url: 'https://emoji-uc.akamaized.net/orig/3c/f4d4c3c2c3646eb6fadeb101622b96.png',
    code: 'U+1F63F',
    html: '😿',
    class: '',
    text: '[哭泣的貓]'
  },
  {
    id: '',
    name: '生气的猫',
    url: 'https://emoji-uc.akamaized.net/orig/ae/ef4a449efc88d54e42d60e332bc6c1.png',
    code: 'U+1F63E',
    html: '😾',
    class: '',
    text: '[生气的猫]'
  },
  {
    id: '',
    name: '心花怒放的貓',
    url: 'https://emoji-uc.akamaized.net/orig/83/10a75df756a2544e5cc704c1319801.png',
    code: 'U+1F63B',
    html: '😻',
    class: '',
    text: '[心花怒放的貓]'
  },
  {
    id: '',
    name: '哈哈笑的貓',
    url: 'https://emoji-uc.akamaized.net/orig/22/e1de20639f2009b80bd2658111a265.png',
    code: 'U+1F63A',
    html: '😺',
    class: '',
    text: '[哈哈笑的貓]'
  },
  {
    id: '',
    name: '奸笑的貓',
    url: 'https://emoji-uc.akamaized.net/orig/42/846d8b2ec3ae67d07b01f2eda55c62.png',
    code: 'U+1F63C',
    html: '😼',
    class: '',
    text: '[奸笑的貓]'
  },
  {
    id: '',
    name: '喜极而泣的猫',
    url: 'https://emoji-uc.akamaized.net/orig/20/80859c7fb796dc6d46ab54237bbe4a.png',
    code: 'U+1F639',
    html: '😹',
    class: '',
    text: '[喜极而泣的猫]'
  },
  {
    id: '',
    name: '不能听',
    url: 'https://emoji-uc.akamaized.net/orig/10/cb7280be53a4baadf4f8e1cfe90894.png',
    code: 'U+1F649',
    html: '🙉',
    class: '',
    text: '[不能听]'
  },
  {
    id: '',
    name: '不能说',
    url: 'https://emoji-uc.akamaized.net/orig/f3/65fe1567782a416e976b5f098170d7.png',
    code: 'U+1F64A',
    html: '🙊',
    class: '',
    text: '[不能说]'
  },
  {
    id: '',
    name: '不能看',
    url: 'https://emoji-uc.akamaized.net/orig/48/1ba150c0be39f3738950f82893273d.png',
    code: 'U+1F648',
    html: '🙈',
    class: '',
    text: '[不能看]'
  },
  {
    id: '',
    name: '右愤怒泡泡',
    url: 'https://emoji-uc.akamaized.net/orig/7d/8fe21fff946c00ad52cc63eaf9bb0f.png',
    code: 'U+1F5EF',
    html: '🗯',
    class: '',
    text: '[右愤怒泡泡]'
  },
  {
    id: '',
    name: '洞',
    url: 'https://emoji-uc.akamaized.net/orig/c3/47eb025939f653b6068031c6ffefa4.png',
    code: 'U+1F573',
    html: '🕳',
    class: '',
    text: '[洞]'
  },
  {
    id: '',
    name: '左讲话泡泡',
    url: 'https://emoji-uc.akamaized.net/orig/42/79ab93510192997c5578f9eadf57ef.png',
    code: 'U+1F5E8',
    html: '🗨',
    class: '',
    text: '[左讲话泡泡]'
  },
  {
    id: '',
    name: '橙色的心',
    url: 'https://emoji-uc.akamaized.net/orig/d2/5378313bcce5b15240f6847adec924.png',
    code: 'U+1F9E1',
    html: '🧡',
    class: '',
    text: '[橙色的心]'
  },
  {
    id: '',
    name: '心装饰',
    url: 'https://emoji-uc.akamaized.net/orig/9c/444835154725c14d5ad07ae9f3342b.png',
    code: 'U+1F49F',
    html: '💟',
    class: '',
    text: '[心装饰]'
  },
  {
    id: '',
    name: '思想气球',
    url: 'https://emoji-uc.akamaized.net/orig/3b/b44569c1af4a97c19187a449186ca1.png',
    code: 'U+1F4AD',
    html: '💭',
    class: '',
    text: '[思想气球]'
  },
  {
    id: '',
    name: '棕色的心',
    url: 'https://emoji-uc.akamaized.net/orig/ed/e3740ae3702d8c1c95396087d7241d.png',
    code: 'U+1F90E',
    html: '🤎',
    class: '',
    text: '[棕色的心]'
  },
  {
    id: '',
    name: '旋转的心',
    url: 'https://emoji-uc.akamaized.net/orig/e3/b37355bde0ced9afd8405d3038d769.png',
    code: 'U+1F49E',
    html: '💞',
    class: '',
    text: '[旋转的心]'
  },
  {
    id: '',
    name: '白心',
    url: 'https://emoji-uc.akamaized.net/orig/03/e1631e02b63474d6d6895a1a584228.png',
    code: 'U+1F90D',
    html: '🤍',
    class: '',
    text: '[白心]'
  },
  {
    id: '',
    name: '爱情字母',
    url: 'https://emoji-uc.akamaized.net/orig/36/b8f66b3c5ee285e001ba596e1f2b7d.png',
    code: 'U+1F48C',
    html: '💌',
    class: '',
    text: '[爱情字母]'
  },
  {
    id: '',
    name: '黑心',
    url: 'https://emoji-uc.akamaized.net/orig/28/f8dffff847bd84dd2c4582d7703a2c.png',
    code: 'U+1F5A4',
    html: '🖤',
    class: '',
    text: '[黑心]'
  },
  {
    id: '',
    name: '愤怒的象征',
    url: 'https://emoji-uc.akamaized.net/orig/40/8f637c02fe88dec5914d02b9c052d9.png',
    code: 'U+1F4A2',
    html: '💢',
    class: '',
    text: '[愤怒的象征]'
  },
  {
    id: '',
    name: '跳动的心',
    url: 'https://emoji-uc.akamaized.net/orig/91/8618ecb3797167e71164dfb5cad5d7.png',
    code: 'U+1F493',
    html: '💓',
    class: '',
    text: '[跳动的心]'
  },
  {
    id: '',
    name: '百点符号',
    url: 'https://emoji-uc.akamaized.net/orig/78/4c77a8fb21eeb70940ce079977345c.png',
    code: 'U+1F4AF',
    html: '💯',
    class: '',
    text: '[百点符号]'
  },
  {
    id: '',
    name: '两颗心',
    url: 'https://emoji-uc.akamaized.net/orig/a0/a9e4495388581794029bc3bec12182.png',
    code: 'U+1F495',
    html: '💕',
    class: '',
    text: '[两颗心]'
  },
  {
    id: '',
    name: '吻痕',
    url: 'https://emoji-uc.akamaized.net/orig/fd/dd5b841cf3eac8cbaa636a586f3c19.png',
    code: 'U+1F48B',
    html: '💋',
    class: '',
    text: '[吻痕]'
  },
  {
    id: '',
    name: '短划线符号',
    url: 'https://emoji-uc.akamaized.net/orig/ca/c1293a7775af27c7b61dc720b82313.png',
    code: 'U+1F4A8',
    html: '💨',
    class: '',
    text: '[短划线符号]'
  },
  {
    id: '',
    name: '溅汗水符号',
    url: 'https://emoji-uc.akamaized.net/orig/44/9079876600a9e3de1b0cb7c4d82fc4.png',
    code: 'U+1F4A6',
    html: '💦',
    class: '',
    text: '[溅汗水符号]'
  },
  {
    id: '',
    name: '头晕的象征',
    url: 'https://emoji-uc.akamaized.net/orig/20/d45ac026c437c9b9bc17eea764c631.png',
    code: 'U+1F4AB',
    html: '💫',
    class: '',
    text: '[头晕的象征]'
  },
  {
    id: '',
    name: '成长的心',
    url: 'https://emoji-uc.akamaized.net/orig/4f/d395de54c88107db9a8502b9d75951.png',
    code: 'U+1F497',
    html: '💗',
    class: '',
    text: '[成长的心]'
  },
  {
    id: '',
    name: '破碎的心',
    url: 'https://emoji-uc.akamaized.net/orig/83/a99be950a8b11427dbe097e0e1f6c2.png',
    code: 'U+1F494',
    html: '💔',
    class: '',
    text: '[破碎的心]'
  },
  {
    id: '',
    name: '箭头的心',
    url: 'https://emoji-uc.akamaized.net/orig/29/ec43ad26487fa68b54bfe749447ac6.png',
    code: 'U+1F498',
    html: '💘',
    class: '',
    text: '[箭头的心]'
  },
  {
    id: '',
    name: '绿心',
    url: 'https://emoji-uc.akamaized.net/orig/ba/3e73d109f3159487ebe0f25be13314.png',
    code: 'U+1F49A',
    html: '💚',
    class: '',
    text: '[绿心]'
  },
  {
    id: '',
    name: '蓝心',
    url: 'https://emoji-uc.akamaized.net/orig/69/8620de0f9f586e3bd6670bc0612bf1.png',
    code: 'U+1F499',
    html: '💙',
    class: '',
    text: '[蓝心]'
  },
  {
    id: '',
    name: '紫心勋章',
    url: 'https://emoji-uc.akamaized.net/orig/c9/2b1705f353f6aa39c3ce8af75c0d53.png',
    code: 'U+1F49C',
    html: '💜',
    class: '',
    text: '[紫心勋章]'
  },
  {
    id: '',
    name: '黄心',
    url: 'https://emoji-uc.akamaized.net/orig/6c/7234b076d4bae3fc6f22d4f52ce728.png',
    code: 'U+1F49B',
    html: '💛',
    class: '',
    text: '[黄心]'
  },
  {
    id: '',
    name: '碰撞符号',
    url: 'https://emoji-uc.akamaized.net/orig/24/b22fc9ff21f92959f8feb44c990e55.png',
    code: 'U+1F4A5',
    html: '💥',
    class: '',
    text: '[碰撞符号]'
  },
  {
    id: '',
    name: '闪闪发光的心',
    url: 'https://emoji-uc.akamaized.net/orig/63/fb6a46a085c9b2973702846821b311.png',
    code: 'U+1F496',
    html: '💖',
    class: '',
    text: '[闪闪发光的心]'
  },
  {
    id: '',
    name: '语音气球',
    url: 'https://emoji-uc.akamaized.net/orig/f5/f53d2db3262d9950d1e0fb1b74244d.png',
    code: 'U+1F4AC',
    html: '💬',
    class: '',
    text: '[语音气球]'
  },
  {
    id: '',
    name: '炸弹',
    url: 'https://emoji-uc.akamaized.net/orig/e0/30efeafa7c5687f00d569b904f93c7.png',
    code: 'U+1F4A3',
    html: '💣',
    class: '',
    text: '[炸弹]'
  },
  {
    id: '',
    name: '睡觉的符号',
    url: 'https://emoji-uc.akamaized.net/orig/d3/cc21dfc9d3fa563c43acf018339f92.png',
    code: 'U+1F4A4',
    html: '💤',
    class: '',
    text: '[睡觉的符号]'
  },
  {
    id: '',
    name: '粗实心心',
    url: 'https://emoji-uc.akamaized.net/orig/27/1e06f228074c5021ac9ed7f536f6ac.png',
    code: 'U+2764',
    html: '❤',
    class: '',
    text: '[粗实心心]'
  },
  {
    id: '',
    name: '粗心形叹号装饰',
    url: 'https://emoji-uc.akamaized.net/orig/00/2dcb39816468ac2d852c9c8ffb7f3c.png',
    code: 'U+2763',
    html: '❣',
    class: '',
    text: '[粗心形叹号装饰]'
  },
  {
    id: '',
    name: '用丝带的心',
    url: 'https://emoji-uc.akamaized.net/orig/ce/7e8f2c0d9bada62e342132ce5a17af.png',
    code: 'U+1F49D',
    html: '💝',
    class: '',
    text: '[用丝带的心]'
  }
]

// 正能量表情
export const POSITIVE_ENERGY_EMOJIS = [
  {
    id: '',
    name: '笑呵呵',
    url: 'https://emoji-uc.akamaized.net/orig/4f/070ccbbb696c2975bb0da521c2ffc5.png',
    code: 'U+1F600',
    html: '😀',
    class: '',
    text: '[笑呵呵]'
  },
  {
    id: '',
    name: '眨眼',
    url: 'https://emoji-uc.akamaized.net/orig/55/ceb7ce388c8b07ffa8495e9d8905bd.png',
    code: 'U+1F609',
    html: '😉',
    class: '',
    text: '[眨眼]'
  },
  {
    id: '',
    name: '满脸堆笑',
    url: 'https://emoji-uc.akamaized.net/orig/70/10eac5870a09f5c95a95fd4da4afd5.png',
    code: 'U+1F60A',
    html: '😊',
    class: '',
    text: '[满脸堆笑]'
  },
  {
    id: '',
    name: '微笑',
    url: 'https://emoji-uc.akamaized.net/orig/b5/6dc44b1241307361edda859bf10548.png',
    code: 'U+1F642',
    html: '🙂',
    class: '',
    text: '[微笑]'
  },
  {
    id: '',
    name: '哈哈大笑',
    url: 'https://emoji-uc.akamaized.net/orig/b7/9f24464ae2bd8fcc5fda823f02469d.png',
    code: 'U+1F604',
    html: '😄',
    class: '',
    text: '[哈哈大笑]'
  },
  {
    id: '',
    name: '调皮',
    url: 'https://emoji-uc.akamaized.net/orig/02/4cde61f75c6c5d8bc9032325318aa1.png',
    code: 'U+1F61B',
    html: '😛',
    class: '',
    text: '[调皮]'
  },
  {
    id: '',
    name: '俏皮',
    url: 'https://emoji-uc.akamaized.net/orig/66/cc21fea16b311a56205b92420167b3.png',
    code: 'U+1F61C',
    html: '😜',
    class: '',
    text: '[俏皮]'
  },
  {
    id: '',
    name: '鬼脸',
    url: 'https://emoji-uc.akamaized.net/orig/cb/6e968aa5a3c1fbe07a98200304d9d3.png',
    code: 'U+1F62C',
    html: '😬',
    class: '',
    text: '[鬼脸]'
  },
  {
    id: '',
    name: '拥抱面孔',
    url: 'https://emoji-uc.akamaized.net/orig/98/f2180902deba2f6fa719fb382963e0.png',
    code: 'U+1F917',
    html: '🤗',
    class: '',
    text: '[拥抱面孔]'
  },
  {
    id: '',
    name: '西瓜',
    url: 'https://emoji-uc.akamaized.net/orig/b3/a159c384631c098c1c7b8153138315.png',
    code: 'U+1F349',
    html: '🍉',
    class: '',
    text: '[西瓜]'
  },
  {
    id: '',
    name: '粗实心心',
    url: 'https://emoji-uc.akamaized.net/orig/27/1e06f228074c5021ac9ed7f536f6ac.png',
    code: 'U+2764',
    html: '❤',
    class: '',
    text: '[粗实心心]'
  },
  {
    id: '',
    name: '啤酒杯',
    url: 'https://emoji-uc.akamaized.net/orig/a5/71a424fcea3aa44956d5d48cda4b00.png',
    code: 'U+1F37A',
    html: '🍺',
    class: '',
    text: '[啤酒杯]'
  },
  {
    id: '',
    name: '玫瑰',
    url: 'https://emoji-uc.akamaized.net/orig/4c/edf8e6decda9c5854b77e872fc4a96.png',
    code: 'U+1F339',
    html: '🌹',
    class: '',
    text: '[玫瑰]'
  },
  {
    id: '',
    name: '包装的礼物',
    url: 'https://emoji-uc.akamaized.net/orig/27/caa01d30b82f09a061b68eb218725d.png',
    code: 'U+1F381',
    html: '🎁',
    class: '',
    text: '[包装的礼物]'
  },
  {
    id: '',
    name: '无柄茶杯',
    url: 'https://emoji-uc.akamaized.net/orig/5a/bd0ed302d059e64ef0ff24a76a6b2b.png',
    code: 'U+1F375',
    html: '🍵',
    class: '',
    text: '[无柄茶杯]'
  },
  {
    id: '',
    name: '放射光线的实心太阳',
    url: 'https://emoji-uc.akamaized.net/orig/61/f16628bcdd145d6c40a13a2bda6047.png',
    code: 'U+1F375',
    html: '☀',
    class: '',
    text: '[放射光线的实心太阳]'
  }
]
