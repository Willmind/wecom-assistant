/**
 * 转换工具
 */
import emojiData from './emojiData'

const validStr = function (msg) {
  return msg && (msg + '').trim()
}

const emojiTxtReg = /\[(.*?)\]/g

const getImgHtml = function (classNames, src, alt, options) {
  let styles = options.styles || {}
  let width = options.width || 40
  let height = options.height || 40
  styles = {
    ...styles,
    width: uni.upx2px(width) + 'px',
    height: uni.upx2px(height) + 'px'
  }
  let styleStr = ''
  for (let style in styles) {
    styleStr += `${style}:${styles[style]};`
  }
  let className = classNames.join(' ').trim()
  return `<img style="${styleStr}" class="${className}" src="${src}" alt="[${alt}]"/>`
}

const ParseEmoji = {
  /**
   * [xxx]-->unicode字符
   * @param {string} msg
   * @returns {string}
   */
  toUnicode(msg) {
    msg = validStr(msg)
    if (!msg) return msg

    return msg.replace(emojiTxtReg, function (match, text) {
      var item = nameMap[text]
      return (item && item.code) || match
    })
  },

  /**
   * unicode字符-->[xxx]
   * @param {string} msg
   * @returns {string}
   */
  toText(msg) {
    msg = validStr(msg)
    if (!msg) return msg

    //unicode
    emojiData.forEach(function (item) {
      if (!item.code) return

      msg = msg.replace(item.reg, '[' + item.text + ']')
    })

    return msg
  },

  /**
   * [xx]和unicode字符 --> img标签
   * @param {string} msg
   * @param {boolean} [passU] true:不转换unicode表情
   */
  toHtml(
    msg,
    passU = false,
    options = {
      classes: [],
      style: {}
    }
  ) {
    msg = validStr(msg)
    if (!msg) return
    var item
    msg = msg.replace(emojiTxtReg, function (match, text) {
      item = nameMap[text]
      if (item) return getImgHtml([item.class, ...options.classes], item.url, item.name, options)
      else return match
    })
    if (passU) return

    //unicode
    emojiData.forEach(function (item) {
      if (!item.code) return

      msg = msg.replace(item.reg, function () {
        return getImgHtml([item.class, ...options.classes], item.url, item.name, options)
      })
    })

    return msg
  }
}

export default ParseEmoji
