/**
 * 将富文本json格式转换成字符串
 * @param {JSONContent} jsonContent
 * @param {Boolean} section - 是否智能分段
 * @returns
 */
export const getTranformJSONContentToText = (jsonContent, section) => {
  const list = jsonContent.content ?? []
  const strlis = []
  list.map((item, index) => {
    if (item.type === 'paragraph') {
      const items = item.content ?? []
      items.map((row) => {
        if (row.type === 'text') {
          strlis.push(row.text)
        } else if (row.type === 'TagComponent') {
          strlis.push(`{${row.attrs.text}}`)
        }
      })
      // 智能分段
      if (section && index < list.length - 1) {
        strlis.push('\n')
      }
    }
  })
  return `${strlis.join('')}`
}

/**
 * 自动备注转换成富文本json
 * @param {Array} remarkData
 * @returns
 */
export const getTranformRemarkToJSONContent = (remarkData) => {
  const items = remarkData || []
  return items.reduce(
    (data, current) => {
      const isTag = current.type === 2
      data.content[0].content.push({
        type: isTag ? 'TagComponent' : 'text',
        [isTag ? 'attrs' : 'text']: isTag ? { text: current.text } : current.text
      })
      return data
    },
    {
      type: 'doc',
      content: [
        {
          type: 'paragraph',
          content: []
        }
      ]
    }
  )
}
