import { isFunction } from 'lodash-es'

/**
 * 获取插槽 防止出现错误
 */
export default function getSlot(slots, slot = 'default', data) {
  if (!slots || !slots.hasOwnProperty(slot)) {
    return null
  }
  if (!isFunction(slots[slot])) {
    console.error(`${slot} is not a function!`)
    return null
  }
  const slotFn = slots[slot]
  if (!slotFn) return null
  return slotFn(data)
}
