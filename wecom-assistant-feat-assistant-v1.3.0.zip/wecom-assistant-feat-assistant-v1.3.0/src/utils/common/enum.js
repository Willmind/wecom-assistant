/**
 * 获取枚举label
 * @param {Enum} enums
 * @param {String|Number} val
 * @param {String|Number} defaultVal - 默认值
 * @returns
 */
export const getEnumLabel = (enums, val, defaultVal) => {
  if (val === undefined) return defaultVal
  let list = Array.isArray(enums) ? enums : Object.values(enums)
  let item = list.find((item) => item.value === val)
  return item ? item.label : defaultVal
}

/**
 * 创建枚举对象
 * @param {Array|Object} data
 * @returns
 * @example
 * createEnum({enable: 1, disable: 0}) => {enable: 1, disable: 0, 1: 'enable', 0: 'disable'}
 * createEnum(['disable', 'enable']) => {0: 'disable', 1: 'enable', enable: 1, disable: 0, }
 */
export function createEnum(data) {
  if (Array.isArray(data)) {
    return data.reduce((map, item, index) => {
      map[(map[index] = item)] = index
      return map
    }, {})
  } else {
    Object.entries(data).forEach(([key, value]) => {
      data[(data[key] = value)] = key
    })
    return data
  }
}
