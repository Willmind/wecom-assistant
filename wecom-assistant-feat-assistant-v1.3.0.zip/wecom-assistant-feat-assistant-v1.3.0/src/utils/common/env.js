export function getEnvConfig() {
  const ENV = import.meta.env

  const { VITE_APP_REMOTE } = ENV
  return {
    VITE_APP_REMOTE
  }
}

export const DEV = 'development'

export const PROD = 'production'

export function getEnv() {
  return import.meta.env.MODE
}

export const isDevMode = () => import.meta.env.MODE === '"development"'

export const isProdMode = () => import.meta.env.PROD
