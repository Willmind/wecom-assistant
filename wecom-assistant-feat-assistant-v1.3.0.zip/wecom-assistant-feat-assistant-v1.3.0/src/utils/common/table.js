// 用于处理 table

// 设置单个
export const setRowSpanByDataIndex = (data = [], rowSpanDataIndex = '') => {
  if (!rowSpanDataIndex) return data

  const rowSpanKey = `_rowSpan_${rowSpanDataIndex}`

  let startIndex = -1 // 开始位置

  data.forEach((item, index) => {
    if (rowSpanDataIndex in item) {
      // 已经开始
      if (startIndex > -1) {
        if (item[rowSpanDataIndex] === data[index - 1][rowSpanDataIndex]) {
          // 连续
          data[index][rowSpanKey] = 0
          data[startIndex][rowSpanKey]++
        } else {
          // 断开，重新开始
          startIndex = index
          data[index][rowSpanKey] = 1
        }
      } else {
        // 开始
        startIndex = index
        data[index][rowSpanKey] = 1
      }
    } else {
      // 重置
      startIndex = -1
    }
  })

  return data
}

// 根据 dataIndex 合并行
export const setRowSpanByDataIndexs = (data, rowSpanDataIndexs = []) => {
  rowSpanDataIndexs.forEach((item) => setRowSpanByDataIndex(data, item))
  return data
}

// 居中 columns
export const alignColumn = (columns = []) => {
  const fn = (columns) => {
    columns.map((i) => {
      i.align = 'center'
      if (i.children?.length) fn(i.children)
    })
  }

  fn(columns)

  return columns
}
