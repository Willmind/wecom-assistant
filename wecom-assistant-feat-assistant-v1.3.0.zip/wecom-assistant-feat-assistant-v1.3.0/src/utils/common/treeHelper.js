/**
 * 树形数据helper工具
 */

const DEFAULT_CONFIG = {
  id: 'id',
  children: 'children',
  pid: 'pid'
}

function getConfig(config = {}) {
  return Object.assign({}, DEFAULT_CONFIG, config)
}

/**
 * 列表转成树(非递归)
 * @param {Array} list
 * @param {Object} config
 * @param {String|Number} rootId - 根节点值
 * @description
 * 时间复杂度：O(n)
 */
export function listToTree(list, config, rootId = 0) {
  if (!list || !list.length) return null
  const conf = getConfig(config)
  const nodeMap = new Map()
  const result = []
  const { id, children, pid } = conf

  for (const node of list) {
    if (!nodeMap.has(node[id])) {
      node[children] = []
    } else {
      node[children] = nodeMap.get(node[id])[children]
    }
    nodeMap.set(node[id], node)

    const parent = nodeMap.get(node[pid])
    if (!parent) {
      nodeMap.set(node[pid], {
        [children]: []
      })
    } else {
      nodeMap.get(node[pid])[children].push(node)
    }
    if (String(node[pid]) === String(rootId)) {
      result.push(node)
    }
  }
  return result
}

/**
 * 树形结构数据转成flat list
 * @param {Array} tree
 * @param {Object} config
 * @returns
 */
export function treeToList(tree, config) {
  config = getConfig(config)
  const { children } = config
  const result = [...tree]
  for (let i = 0; i < result.length; i++) {
    if (!Array.isArray(result[i][children])) continue
    result.splice(i + 1, 0, ...result[i][children])
  }
  return result
}

/**
 * 获取单个node
 * @param {Array} tree
 * @param {Function} func
 * @param {Object} config
 */
export function findNode(tree, func, config) {
  config = getConfig(config)
  const { children } = config
  const list = [...tree]
  for (const node of list) {
    if (typeof func === 'function' && func(node)) return node
    Array.isArray(node[children]) && list.push(...node[children])
  }
  return null
}

/**
 * 获取node以及node的所有依赖的父级node
 * @param {Array} tree
 * @param {Function} func
 * @param {Object} config
 */
export function findNodeAll(tree, func, config) {
  config = getConfig(config)
  const { children } = config
  const list = [...tree]
  const result = []
  for (const node of list) {
    typeof func === 'function' && func(node) && result.push(node)
    Array.isArray(node[children]) && list.push(...node[children])
  }
  return result
}

/**
 * 获取树paths
 * @param {Array} tree
 * @param {Function} func
 * @param {Object} config
 * @param {Bolean} all - 适合多个根树节点, 返回是二维数组
 * @returns
 */
export function findPaths(tree, func, config, all) {
  config = getConfig(config)
  const path = []
  const list = [...tree]
  const visitedSet = new Set()
  const { children } = config
  let result = []
  while (list.length) {
    const [node] = list
    if (visitedSet.has(node)) {
      path.pop()
      list.shift()
    } else {
      visitedSet.add(node)
      node[children] && list.unshift(...node[children])
      path.push(node)
      if (func && func(node)) {
        if (all) {
          result.push([...path])
        } else {
          return path
        }
      }
    }
  }
  return result
}

/**
 * 树结构变形
 * @param {Array} tree
 * @param {Object} option
 */
export function transformTreeMap(tree, option) {
  return (tree || []).map((item) => transformTreeEach(item, option))
}

/**
 * 树节点遍历
 * @param {Object} data
 * @param {Object} option - {children: String, transform: Function}
 * @param {Object} extra - 额外数据
 * @returns
 */
export function transformTreeEach(data, { children = DEFAULT_CONFIG.children, transform }, extra) {
  const hasChild = Array.isArray(data[children]) && data[children].length > 0
  const transformData =
    transform && typeof transform === 'function' ? transform(data, extra, hasChild) || {} : data
  if (hasChild) {
    return {
      ...transformData,
      [children]: data[children].map((item) =>
        transformTreeEach(
          item,
          {
            children,
            transform
          },
          transformData
        )
      )
    }
  } else {
    return { ...transformData }
  }
}
