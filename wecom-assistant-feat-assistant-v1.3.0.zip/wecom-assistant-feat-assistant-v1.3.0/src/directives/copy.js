import { message as Message } from 'ant-design-vue'
// 使用示例 v-copy='xxxx'
export default {
  beforeMount(el, binding) {
    el.targetContent = binding.value
    el.addEventListener('click', () => {
      if (!el.targetContent) return
      const textarea = document.createElement('textarea')
      textarea.readOnly = 'readonly'
      textarea.style.position = 'fixed'
      textarea.style.top = '-99999px'
      textarea.value = el.targetContent
      document.body.appendChild(textarea)
      textarea.select()
      const res = document.execCommand('Copy')
      res && Message.success('复制成功')
      document.body.removeChild(textarea)
    })
  },
  updated(el, binding) {
    el.targetContent = binding.value
  },
  unmounted(el) {
    el.removeEventListener('click', () => {})
  }
}
