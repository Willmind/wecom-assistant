import copy from './copy'
import clickOutSide from './clickOutSide'
// 导出所有指令
export default function globalDirective(rootApp) {
  rootApp.directive('copy', copy)
  rootApp.directive('click-outside', clickOutSide)
}
